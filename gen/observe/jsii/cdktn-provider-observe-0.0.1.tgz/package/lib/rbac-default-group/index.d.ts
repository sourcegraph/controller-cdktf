import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RbacDefaultGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Observe ID for rbacGroup. Currently API only accepts the ID of `reader`, `writer` or `admin`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_default_group#group RbacDefaultGroup#group}
    */
    readonly group: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_default_group#id RbacDefaultGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_default_group observe_rbac_default_group}
*/
export declare class RbacDefaultGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_rbac_default_group";
    /**
    * Generates CDKTN code for importing a RbacDefaultGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RbacDefaultGroup to import
    * @param importFromId The id of the existing RbacDefaultGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_default_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RbacDefaultGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_default_group observe_rbac_default_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RbacDefaultGroupConfig
    */
    constructor(scope: Construct, id: string, config: RbacDefaultGroupConfig);
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
