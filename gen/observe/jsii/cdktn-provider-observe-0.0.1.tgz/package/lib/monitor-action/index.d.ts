import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MonitorActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * A brief description of the monitor action.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#description MonitorAction#description}
    */
    readonly description?: string;
    /**
    * Icon to be displayed for this object. Icons are sourced from the [fluency-filled](https://icons8.com/icons/fluency-systems-filled) icon set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#icon_url MonitorAction#icon_url}
    */
    readonly iconUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#id MonitorAction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Monitor action name. Must be unique within workspace.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#name MonitorAction#name}
    */
    readonly name: string;
    /**
    * Enables a final update when a monitor action notification is closed (no longer triggered).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#notify_on_close MonitorAction#notify_on_close}
    */
    readonly notifyOnClose?: boolean | cdktn.IResolvable;
    /**
    * Limits 10 alerts to the defined time period. For email actions the minimum
    * is 10m. For webhook actions the minimum is 1s.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#rate_limit MonitorAction#rate_limit}
    */
    readonly rateLimit?: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#workspace MonitorAction#workspace}
    */
    readonly workspace: string;
    /**
    * email block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#email MonitorAction#email}
    */
    readonly email?: MonitorActionEmail;
    /**
    * webhook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#webhook MonitorAction#webhook}
    */
    readonly webhook?: MonitorActionWebhook;
}
export interface MonitorActionEmail {
    /**
    * Template string used to fill body of the email.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#body_template MonitorAction#body_template}
    */
    readonly bodyTemplate: string;
    /**
    * send the email as html allowing rich formatting in the body.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#is_html MonitorAction#is_html}
    */
    readonly isHtml?: boolean | cdktn.IResolvable;
    /**
    * Template string used to build subject line.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#subject_template MonitorAction#subject_template}
    */
    readonly subjectTemplate: string;
    /**
    * Email address(es) to send alert to.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#target_addresses MonitorAction#target_addresses}
    */
    readonly targetAddresses: string[];
}
export declare function monitorActionEmailToTerraform(struct?: MonitorActionEmailOutputReference | MonitorActionEmail): any;
export declare function monitorActionEmailToHclTerraform(struct?: MonitorActionEmailOutputReference | MonitorActionEmail): any;
export declare class MonitorActionEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorActionEmail | undefined;
    set internalValue(value: MonitorActionEmail | undefined);
    private _bodyTemplate?;
    get bodyTemplate(): string;
    set bodyTemplate(value: string);
    get bodyTemplateInput(): string | undefined;
    private _isHtml?;
    get isHtml(): boolean | cdktn.IResolvable;
    set isHtml(value: boolean | cdktn.IResolvable);
    resetIsHtml(): void;
    get isHtmlInput(): boolean | cdktn.IResolvable | undefined;
    private _subjectTemplate?;
    get subjectTemplate(): string;
    set subjectTemplate(value: string);
    get subjectTemplateInput(): string | undefined;
    private _targetAddresses?;
    get targetAddresses(): string[];
    set targetAddresses(value: string[]);
    get targetAddressesInput(): string[] | undefined;
}
export interface MonitorActionWebhook {
    /**
    * Template string used to fill body of request sent to URL.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#body_template MonitorAction#body_template}
    */
    readonly bodyTemplate: string;
    /**
    * Extra headers to send along with the request.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#headers MonitorAction#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * HTTP method to use for the request.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#method MonitorAction#method}
    */
    readonly method?: string;
    /**
    * Template string used to generate the request URL.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#url_template MonitorAction#url_template}
    */
    readonly urlTemplate: string;
}
export declare function monitorActionWebhookToTerraform(struct?: MonitorActionWebhookOutputReference | MonitorActionWebhook): any;
export declare function monitorActionWebhookToHclTerraform(struct?: MonitorActionWebhookOutputReference | MonitorActionWebhook): any;
export declare class MonitorActionWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorActionWebhook | undefined;
    set internalValue(value: MonitorActionWebhook | undefined);
    private _bodyTemplate?;
    get bodyTemplate(): string;
    set bodyTemplate(value: string);
    get bodyTemplateInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _urlTemplate?;
    get urlTemplate(): string;
    set urlTemplate(value: string);
    get urlTemplateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action observe_monitor_action}
*/
export declare class MonitorAction extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_monitor_action";
    /**
    * Generates CDKTN code for importing a MonitorAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MonitorAction to import
    * @param importFromId The id of the existing MonitorAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MonitorAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_action observe_monitor_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MonitorActionConfig
    */
    constructor(scope: Construct, id: string, config: MonitorActionConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _iconUrl?;
    get iconUrl(): string;
    set iconUrl(value: string);
    resetIconUrl(): void;
    get iconUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notifyOnClose?;
    get notifyOnClose(): boolean | cdktn.IResolvable;
    set notifyOnClose(value: boolean | cdktn.IResolvable);
    resetNotifyOnClose(): void;
    get notifyOnCloseInput(): boolean | cdktn.IResolvable | undefined;
    get oid(): string;
    private _rateLimit?;
    get rateLimit(): string;
    set rateLimit(value: string);
    resetRateLimit(): void;
    get rateLimitInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _email;
    get email(): MonitorActionEmailOutputReference;
    putEmail(value: MonitorActionEmail): void;
    resetEmail(): void;
    get emailInput(): MonitorActionEmail | undefined;
    private _webhook;
    get webhook(): MonitorActionWebhookOutputReference;
    putWebhook(value: MonitorActionWebhook): void;
    resetWebhook(): void;
    get webhookInput(): MonitorActionWebhook | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
