import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RbacStatementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#description RbacStatement#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#id RbacStatement#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#role RbacStatement#role}
    */
    readonly role: string;
    /**
    * object block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#object RbacStatement#object}
    */
    readonly object: RbacStatementObject;
    /**
    * subject block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#subject RbacStatement#subject}
    */
    readonly subject: RbacStatementSubject;
}
export interface RbacStatementObject {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#all RbacStatement#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * The Observe ID for a folder.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#folder RbacStatement#folder}
    */
    readonly folder?: string;
    /**
    * The Observe ID for an object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#id RbacStatement#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of object. Can be provided along with `type`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#name RbacStatement#name}
    */
    readonly name?: string;
    /**
    * True to bind to objects owned by the user. Can be provided along with `type`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#owner RbacStatement#owner}
    */
    readonly owner?: boolean | cdktn.IResolvable;
    /**
    * The type of object such as dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#type RbacStatement#type}
    */
    readonly type?: string;
    /**
    * The Observe ID for a workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#workspace RbacStatement#workspace}
    */
    readonly workspace?: string;
}
export declare function rbacStatementObjectToTerraform(struct?: RbacStatementObjectOutputReference | RbacStatementObject): any;
export declare function rbacStatementObjectToHclTerraform(struct?: RbacStatementObjectOutputReference | RbacStatementObject): any;
export declare class RbacStatementObjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RbacStatementObject | undefined;
    set internalValue(value: RbacStatementObject | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _folder?;
    get folder(): string;
    set folder(value: string);
    resetFolder(): void;
    get folderInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): boolean | cdktn.IResolvable;
    set owner(value: boolean | cdktn.IResolvable);
    resetOwner(): void;
    get ownerInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
}
export interface RbacStatementSubject {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#all RbacStatement#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * OID of a RBAC Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#group RbacStatement#group}
    */
    readonly group?: string;
    /**
    * OID of a user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#user RbacStatement#user}
    */
    readonly user?: string;
}
export declare function rbacStatementSubjectToTerraform(struct?: RbacStatementSubjectOutputReference | RbacStatementSubject): any;
export declare function rbacStatementSubjectToHclTerraform(struct?: RbacStatementSubjectOutputReference | RbacStatementSubject): any;
export declare class RbacStatementSubjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RbacStatementSubject | undefined;
    set internalValue(value: RbacStatementSubject | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    resetGroup(): void;
    get groupInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement observe_rbac_statement}
*/
export declare class RbacStatement extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_rbac_statement";
    /**
    * Generates CDKTN code for importing a RbacStatement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RbacStatement to import
    * @param importFromId The id of the existing RbacStatement that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RbacStatement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_statement observe_rbac_statement} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RbacStatementConfig
    */
    constructor(scope: Construct, id: string, config: RbacStatementConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get oid(): string;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _object;
    get object(): RbacStatementObjectOutputReference;
    putObject(value: RbacStatementObject): void;
    get objectInput(): RbacStatementObject | undefined;
    private _subject;
    get subject(): RbacStatementSubjectOutputReference;
    putSubject(value: RbacStatementSubject): void;
    get subjectInput(): RbacStatementSubject | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
