import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * A long-form comment describing the content of the monitor.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#comment Monitor#comment}
    */
    readonly comment?: string;
    /**
    * Monitor definition in JSON format.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#definition Monitor#definition}
    */
    readonly definition?: string;
    /**
    * A brief description of the monitor.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#description Monitor#description}
    */
    readonly description?: string;
    /**
    * Set to `true` to disable monitor.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#disabled Monitor#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Target freshness for results. Tighten the freshness to increase the
    * frequency with which queries are run, which incurs higher transform costs.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#freshness Monitor#freshness}
    */
    readonly freshness?: string;
    /**
    * Icon to be displayed for this object. Icons are sourced from the [fluency-filled](https://icons8.com/icons/fluency-systems-filled) icon set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#icon_url Monitor#icon_url}
    */
    readonly iconUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#id Monitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The inputs map binds dataset OIDs to labels which can be referenced within
    * stage pipelines.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#inputs Monitor#inputs}
    */
    readonly inputs: {
        [key: string]: string;
    };
    /**
    * This resource is template for creating new monitors
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#is_template Monitor#is_template}
    */
    readonly isTemplate?: boolean | cdktn.IResolvable;
    /**
    * Monitor name. Must be unique within workspace.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#name Monitor#name}
    */
    readonly name: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#workspace Monitor#workspace}
    */
    readonly workspace: string;
    /**
    * notification_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#notification_spec Monitor#notification_spec}
    */
    readonly notificationSpec?: MonitorNotificationSpec;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#rule Monitor#rule}
    */
    readonly rule: MonitorRule;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#stage Monitor#stage}
    */
    readonly stage: MonitorStage[] | cdktn.IResolvable;
}
export interface MonitorNotificationSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#importance Monitor#importance}
    */
    readonly importance?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#merge Monitor#merge}
    */
    readonly merge?: string;
    /**
    * Enables a final update when a monitor notification is closed (no longer triggered).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#notify_on_close Monitor#notify_on_close}
    */
    readonly notifyOnClose?: boolean | cdktn.IResolvable;
    /**
    * How often to send reminders when a monitor notification is triggered.
    * To disable reminder notifications, omit this attribute.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#reminder_frequency Monitor#reminder_frequency}
    */
    readonly reminderFrequency?: string;
}
export declare function monitorNotificationSpecToTerraform(struct?: MonitorNotificationSpecOutputReference | MonitorNotificationSpec): any;
export declare function monitorNotificationSpecToHclTerraform(struct?: MonitorNotificationSpecOutputReference | MonitorNotificationSpec): any;
export declare class MonitorNotificationSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorNotificationSpec | undefined;
    set internalValue(value: MonitorNotificationSpec | undefined);
    private _importance?;
    get importance(): string;
    set importance(value: string);
    resetImportance(): void;
    get importanceInput(): string | undefined;
    private _merge?;
    get merge(): string;
    set merge(value: string);
    resetMerge(): void;
    get mergeInput(): string | undefined;
    private _notifyOnClose?;
    get notifyOnClose(): boolean | cdktn.IResolvable;
    set notifyOnClose(value: boolean | cdktn.IResolvable);
    resetNotifyOnClose(): void;
    get notifyOnCloseInput(): boolean | cdktn.IResolvable | undefined;
    get notifyOnReminder(): cdktn.IResolvable;
    private _reminderFrequency?;
    get reminderFrequency(): string;
    set reminderFrequency(value: string);
    resetReminderFrequency(): void;
    get reminderFrequencyInput(): string | undefined;
}
export interface MonitorRuleChange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#aggregate_function Monitor#aggregate_function}
    */
    readonly aggregateFunction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#baseline_time Monitor#baseline_time}
    */
    readonly baselineTime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#change_type Monitor#change_type}
    */
    readonly changeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#compare_function Monitor#compare_function}
    */
    readonly compareFunction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#compare_value Monitor#compare_value}
    */
    readonly compareValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#compare_values Monitor#compare_values}
    */
    readonly compareValues?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#lookback_time Monitor#lookback_time}
    */
    readonly lookbackTime: string;
}
export declare function monitorRuleChangeToTerraform(struct?: MonitorRuleChangeOutputReference | MonitorRuleChange): any;
export declare function monitorRuleChangeToHclTerraform(struct?: MonitorRuleChangeOutputReference | MonitorRuleChange): any;
export declare class MonitorRuleChangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorRuleChange | undefined;
    set internalValue(value: MonitorRuleChange | undefined);
    private _aggregateFunction?;
    get aggregateFunction(): string;
    set aggregateFunction(value: string);
    resetAggregateFunction(): void;
    get aggregateFunctionInput(): string | undefined;
    private _baselineTime?;
    get baselineTime(): string;
    set baselineTime(value: string);
    get baselineTimeInput(): string | undefined;
    private _changeType?;
    get changeType(): string;
    set changeType(value: string);
    resetChangeType(): void;
    get changeTypeInput(): string | undefined;
    private _compareFunction?;
    get compareFunction(): string;
    set compareFunction(value: string);
    get compareFunctionInput(): string | undefined;
    private _compareValue?;
    get compareValue(): number;
    set compareValue(value: number);
    resetCompareValue(): void;
    get compareValueInput(): number | undefined;
    private _compareValues?;
    get compareValues(): number[];
    set compareValues(value: number[]);
    resetCompareValues(): void;
    get compareValuesInput(): number[] | undefined;
    private _lookbackTime?;
    get lookbackTime(): string;
    set lookbackTime(value: string);
    get lookbackTimeInput(): string | undefined;
}
export interface MonitorRuleCount {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#compare_function Monitor#compare_function}
    */
    readonly compareFunction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#compare_value Monitor#compare_value}
    */
    readonly compareValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#compare_values Monitor#compare_values}
    */
    readonly compareValues?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#lookback_time Monitor#lookback_time}
    */
    readonly lookbackTime: string;
}
export declare function monitorRuleCountToTerraform(struct?: MonitorRuleCountOutputReference | MonitorRuleCount): any;
export declare function monitorRuleCountToHclTerraform(struct?: MonitorRuleCountOutputReference | MonitorRuleCount): any;
export declare class MonitorRuleCountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorRuleCount | undefined;
    set internalValue(value: MonitorRuleCount | undefined);
    private _compareFunction?;
    get compareFunction(): string;
    set compareFunction(value: string);
    get compareFunctionInput(): string | undefined;
    private _compareValue?;
    get compareValue(): number;
    set compareValue(value: number);
    resetCompareValue(): void;
    get compareValueInput(): number | undefined;
    private _compareValues?;
    get compareValues(): number[];
    set compareValues(value: number[]);
    resetCompareValues(): void;
    get compareValuesInput(): number[] | undefined;
    private _lookbackTime?;
    get lookbackTime(): string;
    set lookbackTime(value: string);
    get lookbackTimeInput(): string | undefined;
}
export interface MonitorRuleFacet {
    /**
    * Comparison function to use when comparing the field against the desired value(s)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#facet_function Monitor#facet_function}
    */
    readonly facetFunction: string;
    /**
    * The values to compare the field against.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#facet_values Monitor#facet_values}
    */
    readonly facetValues: string[];
    /**
    * Time window to evaluate time_function over.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#lookback_time Monitor#lookback_time}
    */
    readonly lookbackTime: string;
    /**
    * Temporal condition to evaluate the matches against (e.g. "at least once in window")
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#time_function Monitor#time_function}
    */
    readonly timeFunction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#time_value Monitor#time_value}
    */
    readonly timeValue?: number;
}
export declare function monitorRuleFacetToTerraform(struct?: MonitorRuleFacetOutputReference | MonitorRuleFacet): any;
export declare function monitorRuleFacetToHclTerraform(struct?: MonitorRuleFacetOutputReference | MonitorRuleFacet): any;
export declare class MonitorRuleFacetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorRuleFacet | undefined;
    set internalValue(value: MonitorRuleFacet | undefined);
    private _facetFunction?;
    get facetFunction(): string;
    set facetFunction(value: string);
    get facetFunctionInput(): string | undefined;
    private _facetValues?;
    get facetValues(): string[];
    set facetValues(value: string[]);
    get facetValuesInput(): string[] | undefined;
    private _lookbackTime?;
    get lookbackTime(): string;
    set lookbackTime(value: string);
    get lookbackTimeInput(): string | undefined;
    private _timeFunction?;
    get timeFunction(): string;
    set timeFunction(value: string);
    get timeFunctionInput(): string | undefined;
    private _timeValue?;
    get timeValue(): number;
    set timeValue(value: number);
    resetTimeValue(): void;
    get timeValueInput(): number | undefined;
}
export interface MonitorRuleGroupByGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#columns Monitor#columns}
    */
    readonly columns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#group_name Monitor#group_name}
    */
    readonly groupName?: string;
}
export declare function monitorRuleGroupByGroupToTerraform(struct?: MonitorRuleGroupByGroup | cdktn.IResolvable): any;
export declare function monitorRuleGroupByGroupToHclTerraform(struct?: MonitorRuleGroupByGroup | cdktn.IResolvable): any;
export declare class MonitorRuleGroupByGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorRuleGroupByGroup | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorRuleGroupByGroup | cdktn.IResolvable | undefined);
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    resetColumns(): void;
    get columnsInput(): string[] | undefined;
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    resetGroupName(): void;
    get groupNameInput(): string | undefined;
}
export declare class MonitorRuleGroupByGroupList extends cdktn.ComplexList {
    internalValue?: MonitorRuleGroupByGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorRuleGroupByGroupOutputReference;
}
export interface MonitorRuleLog {
    /**
    * Comparison function used to compare the query result against the compare_values.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#compare_function Monitor#compare_function}
    */
    readonly compareFunction: string;
    /**
    * Value(s) to compare the query(ies) against.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#compare_values Monitor#compare_values}
    */
    readonly compareValues?: number[];
    /**
    * Short summary or comment of how the data for monitor is queried.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#expression_summary Monitor#expression_summary}
    */
    readonly expressionSummary?: string;
    /**
    * An id of the stage that is used to generate logs for preview. This is usually a stage before aggregation.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#log_stage_id Monitor#log_stage_id}
    */
    readonly logStageId?: string;
    /**
    * Amount of time to evaluate query and comparison over.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#lookback_time Monitor#lookback_time}
    */
    readonly lookbackTime: string;
    /**
    * ID of the dataset that contains logs for preview.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#source_log_dataset Monitor#source_log_dataset}
    */
    readonly sourceLogDataset?: string;
}
export declare function monitorRuleLogToTerraform(struct?: MonitorRuleLogOutputReference | MonitorRuleLog): any;
export declare function monitorRuleLogToHclTerraform(struct?: MonitorRuleLogOutputReference | MonitorRuleLog): any;
export declare class MonitorRuleLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorRuleLog | undefined;
    set internalValue(value: MonitorRuleLog | undefined);
    private _compareFunction?;
    get compareFunction(): string;
    set compareFunction(value: string);
    get compareFunctionInput(): string | undefined;
    private _compareValues?;
    get compareValues(): number[];
    set compareValues(value: number[]);
    resetCompareValues(): void;
    get compareValuesInput(): number[] | undefined;
    private _expressionSummary?;
    get expressionSummary(): string;
    set expressionSummary(value: string);
    resetExpressionSummary(): void;
    get expressionSummaryInput(): string | undefined;
    private _logStageId?;
    get logStageId(): string;
    set logStageId(value: string);
    resetLogStageId(): void;
    get logStageIdInput(): string | undefined;
    private _lookbackTime?;
    get lookbackTime(): string;
    set lookbackTime(value: string);
    get lookbackTimeInput(): string | undefined;
    private _sourceLogDataset?;
    get sourceLogDataset(): string;
    set sourceLogDataset(value: string);
    resetSourceLogDataset(): void;
    get sourceLogDatasetInput(): string | undefined;
}
export interface MonitorRulePromote {
    /**
    * Dataset field used to set the description for this monitor's events.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#description_field Monitor#description_field}
    */
    readonly descriptionField?: string;
    /**
    * The dataset field used to group notifications for this monitor.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#kind_field Monitor#kind_field}
    */
    readonly kindField?: string;
    /**
    * Key used to deduplicate and and uniquely identify each event.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#primary_key Monitor#primary_key}
    */
    readonly primaryKey: string[];
}
export declare function monitorRulePromoteToTerraform(struct?: MonitorRulePromoteOutputReference | MonitorRulePromote): any;
export declare function monitorRulePromoteToHclTerraform(struct?: MonitorRulePromoteOutputReference | MonitorRulePromote): any;
export declare class MonitorRulePromoteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorRulePromote | undefined;
    set internalValue(value: MonitorRulePromote | undefined);
    private _descriptionField?;
    get descriptionField(): string;
    set descriptionField(value: string);
    resetDescriptionField(): void;
    get descriptionFieldInput(): string | undefined;
    private _kindField?;
    get kindField(): string;
    set kindField(value: string);
    resetKindField(): void;
    get kindFieldInput(): string | undefined;
    private _primaryKey?;
    get primaryKey(): string[];
    set primaryKey(value: string[]);
    get primaryKeyInput(): string[] | undefined;
}
export interface MonitorRuleThreshold {
    /**
    * Comparison function used to compare the query result against the compare_values.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#compare_function Monitor#compare_function}
    */
    readonly compareFunction: string;
    /**
    * Value(s) to compare the query(ies) against.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#compare_values Monitor#compare_values}
    */
    readonly compareValues?: number[];
    /**
    * Amount of time to evaluate query and comparison over.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#lookback_time Monitor#lookback_time}
    */
    readonly lookbackTime: string;
    /**
    * Function used to aggregate threshold events to determine when an alert should be triggered.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#threshold_agg_function Monitor#threshold_agg_function}
    */
    readonly thresholdAggFunction?: string;
}
export declare function monitorRuleThresholdToTerraform(struct?: MonitorRuleThresholdOutputReference | MonitorRuleThreshold): any;
export declare function monitorRuleThresholdToHclTerraform(struct?: MonitorRuleThresholdOutputReference | MonitorRuleThreshold): any;
export declare class MonitorRuleThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorRuleThreshold | undefined;
    set internalValue(value: MonitorRuleThreshold | undefined);
    private _compareFunction?;
    get compareFunction(): string;
    set compareFunction(value: string);
    get compareFunctionInput(): string | undefined;
    private _compareValues?;
    get compareValues(): number[];
    set compareValues(value: number[]);
    resetCompareValues(): void;
    get compareValuesInput(): number[] | undefined;
    private _lookbackTime?;
    get lookbackTime(): string;
    set lookbackTime(value: string);
    get lookbackTimeInput(): string | undefined;
    private _thresholdAggFunction?;
    get thresholdAggFunction(): string;
    set thresholdAggFunction(value: string);
    resetThresholdAggFunction(): void;
    get thresholdAggFunctionInput(): string | undefined;
}
export interface MonitorRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#source_column Monitor#source_column}
    */
    readonly sourceColumn?: string;
    /**
    * change block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#change Monitor#change}
    */
    readonly change?: MonitorRuleChange;
    /**
    * count block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#count Monitor#count}
    */
    readonly count?: MonitorRuleCount;
    /**
    * facet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#facet Monitor#facet}
    */
    readonly facet?: MonitorRuleFacet;
    /**
    * group_by_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#group_by_group Monitor#group_by_group}
    */
    readonly groupByGroup?: MonitorRuleGroupByGroup[] | cdktn.IResolvable;
    /**
    * log block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#log Monitor#log}
    */
    readonly log?: MonitorRuleLog;
    /**
    * promote block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#promote Monitor#promote}
    */
    readonly promote?: MonitorRulePromote;
    /**
    * threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#threshold Monitor#threshold}
    */
    readonly threshold?: MonitorRuleThreshold;
}
export declare function monitorRuleToTerraform(struct?: MonitorRuleOutputReference | MonitorRule): any;
export declare function monitorRuleToHclTerraform(struct?: MonitorRuleOutputReference | MonitorRule): any;
export declare class MonitorRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorRule | undefined;
    set internalValue(value: MonitorRule | undefined);
    private _sourceColumn?;
    get sourceColumn(): string;
    set sourceColumn(value: string);
    resetSourceColumn(): void;
    get sourceColumnInput(): string | undefined;
    private _change;
    get change(): MonitorRuleChangeOutputReference;
    putChange(value: MonitorRuleChange): void;
    resetChange(): void;
    get changeInput(): MonitorRuleChange | undefined;
    private _count;
    get count(): MonitorRuleCountOutputReference;
    putCount(value: MonitorRuleCount): void;
    resetCount(): void;
    get countInput(): MonitorRuleCount | undefined;
    private _facet;
    get facet(): MonitorRuleFacetOutputReference;
    putFacet(value: MonitorRuleFacet): void;
    resetFacet(): void;
    get facetInput(): MonitorRuleFacet | undefined;
    private _groupByGroup;
    get groupByGroup(): MonitorRuleGroupByGroupList;
    putGroupByGroup(value: MonitorRuleGroupByGroup[] | cdktn.IResolvable): void;
    resetGroupByGroup(): void;
    get groupByGroupInput(): cdktn.IResolvable | MonitorRuleGroupByGroup[] | undefined;
    private _log;
    get log(): MonitorRuleLogOutputReference;
    putLog(value: MonitorRuleLog): void;
    resetLog(): void;
    get logInput(): MonitorRuleLog | undefined;
    private _promote;
    get promote(): MonitorRulePromoteOutputReference;
    putPromote(value: MonitorRulePromote): void;
    resetPromote(): void;
    get promoteInput(): MonitorRulePromote | undefined;
    private _threshold;
    get threshold(): MonitorRuleThresholdOutputReference;
    putThreshold(value: MonitorRuleThreshold): void;
    resetThreshold(): void;
    get thresholdInput(): MonitorRuleThreshold | undefined;
}
export interface MonitorStage {
    /**
    * The stage alias is the label by which subsequent stages can refer to the
    * results of this stage.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#alias Monitor#alias}
    */
    readonly alias?: string;
    /**
    * The stage input defines what input should be used as a starting point for
    * the stage pipeline. It must refer to a label contained in `inputs`, or a
    * previous stage `alias`. The stage input can be omitted if `inputs`
    * contains a single element.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#input Monitor#input}
    */
    readonly input?: string;
    /**
    * A boolean flag used to specify the output stage. Should be used only for
    * a stage preceding the last stage. The last stage is an output stage by default.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#output_stage Monitor#output_stage}
    */
    readonly outputStage?: boolean | cdktn.IResolvable;
    /**
    * An OPAL snippet defining a transformation on the selected input.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#pipeline Monitor#pipeline}
    */
    readonly pipeline?: string;
}
export declare function monitorStageToTerraform(struct?: MonitorStage | cdktn.IResolvable): any;
export declare function monitorStageToHclTerraform(struct?: MonitorStage | cdktn.IResolvable): any;
export declare class MonitorStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorStage | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorStage | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    resetInput(): void;
    get inputInput(): string | undefined;
    private _outputStage?;
    get outputStage(): boolean | cdktn.IResolvable;
    set outputStage(value: boolean | cdktn.IResolvable);
    resetOutputStage(): void;
    get outputStageInput(): boolean | cdktn.IResolvable | undefined;
    private _pipeline?;
    get pipeline(): string;
    set pipeline(value: string);
    resetPipeline(): void;
    get pipelineInput(): string | undefined;
}
export declare class MonitorStageList extends cdktn.ComplexList {
    internalValue?: MonitorStage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorStageOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor observe_monitor}
*/
export declare class Monitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_monitor";
    /**
    * Generates CDKTN code for importing a Monitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Monitor to import
    * @param importFromId The id of the existing Monitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Monitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor observe_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MonitorConfig
    */
    constructor(scope: Construct, id: string, config: MonitorConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _definition?;
    get definition(): string;
    set definition(value: string);
    resetDefinition(): void;
    get definitionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _freshness?;
    get freshness(): string;
    set freshness(value: string);
    resetFreshness(): void;
    get freshnessInput(): string | undefined;
    private _iconUrl?;
    get iconUrl(): string;
    set iconUrl(value: string);
    resetIconUrl(): void;
    get iconUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputs?;
    get inputs(): {
        [key: string]: string;
    };
    set inputs(value: {
        [key: string]: string;
    });
    get inputsInput(): {
        [key: string]: string;
    } | undefined;
    private _isTemplate?;
    get isTemplate(): boolean | cdktn.IResolvable;
    set isTemplate(value: boolean | cdktn.IResolvable);
    resetIsTemplate(): void;
    get isTemplateInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _notificationSpec;
    get notificationSpec(): MonitorNotificationSpecOutputReference;
    putNotificationSpec(value: MonitorNotificationSpec): void;
    resetNotificationSpec(): void;
    get notificationSpecInput(): MonitorNotificationSpec | undefined;
    private _rule;
    get rule(): MonitorRuleOutputReference;
    putRule(value: MonitorRule): void;
    get ruleInput(): MonitorRule | undefined;
    private _stage;
    get stage(): MonitorStageList;
    putStage(value: MonitorStage[] | cdktn.IResolvable): void;
    get stageInput(): cdktn.IResolvable | MonitorStage[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
