import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MonitorV2ActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#description MonitorV2Action#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#id MonitorV2Action#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#name MonitorV2Action#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#type MonitorV2Action#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#workspace MonitorV2Action#workspace}
    */
    readonly workspace: string;
    /**
    * email block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#email MonitorV2Action#email}
    */
    readonly email?: MonitorV2ActionEmail;
    /**
    * webhook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#webhook MonitorV2Action#webhook}
    */
    readonly webhook?: MonitorV2ActionWebhook;
}
export interface MonitorV2ActionEmail {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#addresses MonitorV2Action#addresses}
    */
    readonly addresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#body MonitorV2Action#body}
    */
    readonly body?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#fragments MonitorV2Action#fragments}
    */
    readonly fragments?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#subject MonitorV2Action#subject}
    */
    readonly subject: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#users MonitorV2Action#users}
    */
    readonly users?: string[];
}
export declare function monitorV2ActionEmailToTerraform(struct?: MonitorV2ActionEmailOutputReference | MonitorV2ActionEmail): any;
export declare function monitorV2ActionEmailToHclTerraform(struct?: MonitorV2ActionEmailOutputReference | MonitorV2ActionEmail): any;
export declare class MonitorV2ActionEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2ActionEmail | undefined;
    set internalValue(value: MonitorV2ActionEmail | undefined);
    private _addresses?;
    get addresses(): string[];
    set addresses(value: string[]);
    resetAddresses(): void;
    get addressesInput(): string[] | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _fragments?;
    get fragments(): string;
    set fragments(value: string);
    resetFragments(): void;
    get fragmentsInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
    private _users?;
    get users(): string[];
    set users(value: string[]);
    resetUsers(): void;
    get usersInput(): string[] | undefined;
}
export interface MonitorV2ActionWebhookHeaders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#header MonitorV2Action#header}
    */
    readonly header: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#value MonitorV2Action#value}
    */
    readonly value: string;
}
export declare function monitorV2ActionWebhookHeadersToTerraform(struct?: MonitorV2ActionWebhookHeaders | cdktn.IResolvable): any;
export declare function monitorV2ActionWebhookHeadersToHclTerraform(struct?: MonitorV2ActionWebhookHeaders | cdktn.IResolvable): any;
export declare class MonitorV2ActionWebhookHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2ActionWebhookHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2ActionWebhookHeaders | cdktn.IResolvable | undefined);
    private _header?;
    get header(): string;
    set header(value: string);
    get headerInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class MonitorV2ActionWebhookHeadersList extends cdktn.ComplexList {
    internalValue?: MonitorV2ActionWebhookHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2ActionWebhookHeadersOutputReference;
}
export interface MonitorV2ActionWebhook {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#body MonitorV2Action#body}
    */
    readonly body: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#fragments MonitorV2Action#fragments}
    */
    readonly fragments?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#method MonitorV2Action#method}
    */
    readonly method: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#url MonitorV2Action#url}
    */
    readonly url: string;
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#headers MonitorV2Action#headers}
    */
    readonly headers?: MonitorV2ActionWebhookHeaders[] | cdktn.IResolvable;
}
export declare function monitorV2ActionWebhookToTerraform(struct?: MonitorV2ActionWebhookOutputReference | MonitorV2ActionWebhook): any;
export declare function monitorV2ActionWebhookToHclTerraform(struct?: MonitorV2ActionWebhookOutputReference | MonitorV2ActionWebhook): any;
export declare class MonitorV2ActionWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2ActionWebhook | undefined;
    set internalValue(value: MonitorV2ActionWebhook | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    get bodyInput(): string | undefined;
    private _fragments?;
    get fragments(): string;
    set fragments(value: string);
    resetFragments(): void;
    get fragmentsInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    get methodInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _headers;
    get headers(): MonitorV2ActionWebhookHeadersList;
    putHeaders(value: MonitorV2ActionWebhookHeaders[] | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | MonitorV2ActionWebhookHeaders[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action observe_monitor_v2_action}
*/
export declare class MonitorV2Action extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_monitor_v2_action";
    /**
    * Generates CDKTN code for importing a MonitorV2Action resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MonitorV2Action to import
    * @param importFromId The id of the existing MonitorV2Action that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MonitorV2Action to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2_action observe_monitor_v2_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MonitorV2ActionConfig
    */
    constructor(scope: Construct, id: string, config: MonitorV2ActionConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _email;
    get email(): MonitorV2ActionEmailOutputReference;
    putEmail(value: MonitorV2ActionEmail): void;
    resetEmail(): void;
    get emailInput(): MonitorV2ActionEmail | undefined;
    private _webhook;
    get webhook(): MonitorV2ActionWebhookOutputReference;
    putWebhook(value: MonitorV2ActionWebhook): void;
    resetWebhook(): void;
    get webhookInput(): MonitorV2ActionWebhook | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
