import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ReferenceTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * MD5 checksum of the source file.
    * Can be computed using `filemd5("<source_file>")`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#checksum ReferenceTable#checksum}
    */
    readonly checksum: string;
    /**
    * Description for the reference table.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#description ReferenceTable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#id ReferenceTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the reference table name. Must be unique within workspace.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#label ReferenceTable#label}
    */
    readonly label: string;
    /**
    * The field that should be used for the OPAL label.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#label_field ReferenceTable#label_field}
    */
    readonly labelField?: string;
    /**
    * The primary key of the reference table.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#primary_key ReferenceTable#primary_key}
    */
    readonly primaryKey?: string[];
    /**
    * The path to a CSV file containing the reference table data.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#source_file ReferenceTable#source_file}
    */
    readonly sourceFile: string;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#schema ReferenceTable#schema}
    */
    readonly schema?: ReferenceTableSchema[] | cdktn.IResolvable;
}
export interface ReferenceTableSchema {
    /**
    * The name of the column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#name ReferenceTable#name}
    */
    readonly name: string;
    /**
    * The type of the column. See https://docs.observeinc.com/en/latest/content/query-language-reference/OPALUserGuideTypesOperators.html for options.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#type ReferenceTable#type}
    */
    readonly type: string;
}
export declare function referenceTableSchemaToTerraform(struct?: ReferenceTableSchema | cdktn.IResolvable): any;
export declare function referenceTableSchemaToHclTerraform(struct?: ReferenceTableSchema | cdktn.IResolvable): any;
export declare class ReferenceTableSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReferenceTableSchema | cdktn.IResolvable | undefined;
    set internalValue(value: ReferenceTableSchema | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ReferenceTableSchemaList extends cdktn.ComplexList {
    internalValue?: ReferenceTableSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReferenceTableSchemaOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table observe_reference_table}
*/
export declare class ReferenceTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_reference_table";
    /**
    * Generates CDKTN code for importing a ReferenceTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ReferenceTable to import
    * @param importFromId The id of the existing ReferenceTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ReferenceTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/reference_table observe_reference_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ReferenceTableConfig
    */
    constructor(scope: Construct, id: string, config: ReferenceTableConfig);
    private _checksum?;
    get checksum(): string;
    set checksum(value: string);
    get checksumInput(): string | undefined;
    get dataset(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _labelField?;
    get labelField(): string;
    set labelField(value: string);
    resetLabelField(): void;
    get labelFieldInput(): string | undefined;
    get oid(): string;
    private _primaryKey?;
    get primaryKey(): string[];
    set primaryKey(value: string[]);
    resetPrimaryKey(): void;
    get primaryKeyInput(): string[] | undefined;
    private _sourceFile?;
    get sourceFile(): string;
    set sourceFile(value: string);
    get sourceFileInput(): string | undefined;
    private _schema;
    get schema(): ReferenceTableSchemaList;
    putSchema(value: ReferenceTableSchema[] | cdktn.IResolvable): void;
    resetSchema(): void;
    get schemaInput(): cdktn.IResolvable | ReferenceTableSchema[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
