import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GrantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/grant#id Grant#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The role to grant.
    *  Accepted values: `administrator`, `apitoken_creator`, `bookmark_manager`, `dashboard_creator`, `dashboard_editor`, `dashboard_viewer`, `dataset_accelerator`, `dataset_creator`, `dataset_editor`, `dataset_viewer`, `datastream_creator`, `datastream_editor`, `datastream_viewer`, `investigator_global`, `monitor_creator`, `monitor_editor`, `monitor_viewer`, `monitor_action_creator`, `monitor_global_muter`, `reference_table_creator`, `report_manager`, `service_account_creator`, `user_deleter`, `user_inviter`, `worksheet_creator`, `worksheet_editor`, `worksheet_viewer`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/grant#role Grant#role}
    */
    readonly role: string;
    /**
    * OID of the subject. Must be a user or a group.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/grant#subject Grant#subject}
    */
    readonly subject: string;
    /**
    * qualifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/grant#qualifier Grant#qualifier}
    */
    readonly qualifier?: GrantQualifier;
}
export interface GrantQualifier {
    /**
    * OID of the object this grant applies to.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/grant#oid Grant#oid}
    */
    readonly oid?: string;
}
export declare function grantQualifierToTerraform(struct?: GrantQualifierOutputReference | GrantQualifier): any;
export declare function grantQualifierToHclTerraform(struct?: GrantQualifierOutputReference | GrantQualifier): any;
export declare class GrantQualifierOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantQualifier | undefined;
    set internalValue(value: GrantQualifier | undefined);
    private _oid?;
    get oid(): string;
    set oid(value: string);
    resetOid(): void;
    get oidInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/grant observe_grant}
*/
export declare class Grant extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_grant";
    /**
    * Generates CDKTN code for importing a Grant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Grant to import
    * @param importFromId The id of the existing Grant that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/grant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Grant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/grant observe_grant} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GrantConfig
    */
    constructor(scope: Construct, id: string, config: GrantConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get oid(): string;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
    private _qualifier;
    get qualifier(): GrantQualifierOutputReference;
    putQualifier(value: GrantQualifier): void;
    resetQualifier(): void;
    get qualifierInput(): GrantQualifier | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
