import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MonitorV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#custom_variables MonitorV2#custom_variables}
    */
    readonly customVariables?: string;
    /**
    * expresses the minimum time that should elapse before data is considered "good enough" to evaluate. Choosing a delay really depends on the expectations of latency of data and whether data is expected to arrive later than other data and thus would change previously evaluated results.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#data_stabilization_delay MonitorV2#data_stabilization_delay}
    */
    readonly dataStabilizationDelay?: string;
    /**
    * A brief description of the monitor.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#description MonitorV2#description}
    */
    readonly description?: string;
    /**
    * Enable/Disable the monitor (and any underlying transforms).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#disabled MonitorV2#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * URL of the monitor icon.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#icon_url MonitorV2#icon_url}
    */
    readonly iconUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#id MonitorV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The inputs map binds dataset OIDs to labels which can be referenced within
    * stage pipelines.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#inputs MonitorV2#inputs}
    */
    readonly inputs: {
        [key: string]: string;
    };
    /**
    * optionally describes a duration that must be satisfied by this monitor. It applies to all rules, but is only applicable to rule kinds that utilize it.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#lookback_time MonitorV2#lookback_time}
    */
    readonly lookbackTime?: string;
    /**
    * Overrides the default value of max alerts generated in a single hour before the monitor is deactivated for safety. A value of 0 means "no limit". If unset, defaults to 100 (note that we use -1 in the Terraform state to indicate null/unset due to Terraform limitations).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#max_alerts_per_hour MonitorV2#max_alerts_per_hour}
    */
    readonly maxAlertsPerHour?: number;
    /**
    * Monitor name.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
    /**
    * Describes the type of each of the rules in the definition (they must all be the same type).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#rule_kind MonitorV2#rule_kind}
    */
    readonly ruleKind: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#workspace MonitorV2#workspace}
    */
    readonly workspace: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#actions MonitorV2#actions}
    */
    readonly actions?: MonitorV2Actions[] | cdktn.IResolvable;
    /**
    * groupings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#groupings MonitorV2#groupings}
    */
    readonly groupings?: MonitorV2Groupings[] | cdktn.IResolvable;
    /**
    * no_data_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#no_data_rules MonitorV2#no_data_rules}
    */
    readonly noDataRules?: MonitorV2NoDataRules;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#rules MonitorV2#rules}
    */
    readonly rules: MonitorV2Rules[] | cdktn.IResolvable;
    /**
    * scheduling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#scheduling MonitorV2#scheduling}
    */
    readonly scheduling?: MonitorV2Scheduling;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#stage MonitorV2#stage}
    */
    readonly stage: MonitorV2Stage[] | cdktn.IResolvable;
}
export interface MonitorV2ActionsActionEmail {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#addresses MonitorV2#addresses}
    */
    readonly addresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#body MonitorV2#body}
    */
    readonly body?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#fragments MonitorV2#fragments}
    */
    readonly fragments?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#subject MonitorV2#subject}
    */
    readonly subject: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#users MonitorV2#users}
    */
    readonly users?: string[];
}
export declare function monitorV2ActionsActionEmailToTerraform(struct?: MonitorV2ActionsActionEmailOutputReference | MonitorV2ActionsActionEmail): any;
export declare function monitorV2ActionsActionEmailToHclTerraform(struct?: MonitorV2ActionsActionEmailOutputReference | MonitorV2ActionsActionEmail): any;
export declare class MonitorV2ActionsActionEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2ActionsActionEmail | undefined;
    set internalValue(value: MonitorV2ActionsActionEmail | undefined);
    private _addresses?;
    get addresses(): string[];
    set addresses(value: string[]);
    resetAddresses(): void;
    get addressesInput(): string[] | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _fragments?;
    get fragments(): string;
    set fragments(value: string);
    resetFragments(): void;
    get fragmentsInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
    private _users?;
    get users(): string[];
    set users(value: string[]);
    resetUsers(): void;
    get usersInput(): string[] | undefined;
}
export interface MonitorV2ActionsActionWebhookHeaders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#header MonitorV2#header}
    */
    readonly header: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value MonitorV2#value}
    */
    readonly value: string;
}
export declare function monitorV2ActionsActionWebhookHeadersToTerraform(struct?: MonitorV2ActionsActionWebhookHeaders | cdktn.IResolvable): any;
export declare function monitorV2ActionsActionWebhookHeadersToHclTerraform(struct?: MonitorV2ActionsActionWebhookHeaders | cdktn.IResolvable): any;
export declare class MonitorV2ActionsActionWebhookHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2ActionsActionWebhookHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2ActionsActionWebhookHeaders | cdktn.IResolvable | undefined);
    private _header?;
    get header(): string;
    set header(value: string);
    get headerInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class MonitorV2ActionsActionWebhookHeadersList extends cdktn.ComplexList {
    internalValue?: MonitorV2ActionsActionWebhookHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2ActionsActionWebhookHeadersOutputReference;
}
export interface MonitorV2ActionsActionWebhook {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#body MonitorV2#body}
    */
    readonly body: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#fragments MonitorV2#fragments}
    */
    readonly fragments?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#method MonitorV2#method}
    */
    readonly method: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#url MonitorV2#url}
    */
    readonly url: string;
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#headers MonitorV2#headers}
    */
    readonly headers?: MonitorV2ActionsActionWebhookHeaders[] | cdktn.IResolvable;
}
export declare function monitorV2ActionsActionWebhookToTerraform(struct?: MonitorV2ActionsActionWebhookOutputReference | MonitorV2ActionsActionWebhook): any;
export declare function monitorV2ActionsActionWebhookToHclTerraform(struct?: MonitorV2ActionsActionWebhookOutputReference | MonitorV2ActionsActionWebhook): any;
export declare class MonitorV2ActionsActionWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2ActionsActionWebhook | undefined;
    set internalValue(value: MonitorV2ActionsActionWebhook | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    get bodyInput(): string | undefined;
    private _fragments?;
    get fragments(): string;
    set fragments(value: string);
    resetFragments(): void;
    get fragmentsInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    get methodInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _headers;
    get headers(): MonitorV2ActionsActionWebhookHeadersList;
    putHeaders(value: MonitorV2ActionsActionWebhookHeaders[] | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | MonitorV2ActionsActionWebhookHeaders[] | undefined;
}
export interface MonitorV2ActionsAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#description MonitorV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#type MonitorV2#type}
    */
    readonly type: string;
    /**
    * email block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#email MonitorV2#email}
    */
    readonly email?: MonitorV2ActionsActionEmail;
    /**
    * webhook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#webhook MonitorV2#webhook}
    */
    readonly webhook?: MonitorV2ActionsActionWebhook;
}
export declare function monitorV2ActionsActionToTerraform(struct?: MonitorV2ActionsActionOutputReference | MonitorV2ActionsAction): any;
export declare function monitorV2ActionsActionToHclTerraform(struct?: MonitorV2ActionsActionOutputReference | MonitorV2ActionsAction): any;
export declare class MonitorV2ActionsActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2ActionsAction | undefined;
    set internalValue(value: MonitorV2ActionsAction | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _email;
    get email(): MonitorV2ActionsActionEmailOutputReference;
    putEmail(value: MonitorV2ActionsActionEmail): void;
    resetEmail(): void;
    get emailInput(): MonitorV2ActionsActionEmail | undefined;
    private _webhook;
    get webhook(): MonitorV2ActionsActionWebhookOutputReference;
    putWebhook(value: MonitorV2ActionsActionWebhook): void;
    resetWebhook(): void;
    get webhookInput(): MonitorV2ActionsActionWebhook | undefined;
}
export interface MonitorV2ActionsConditionsCompareTermsColumnColumnPath {
    /**
    * The name of the column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
    /**
    * The path of the path, if the name refers to a column with a JSON object.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#path MonitorV2#path}
    */
    readonly path?: string;
}
export declare function monitorV2ActionsConditionsCompareTermsColumnColumnPathToTerraform(struct?: MonitorV2ActionsConditionsCompareTermsColumnColumnPathOutputReference | MonitorV2ActionsConditionsCompareTermsColumnColumnPath): any;
export declare function monitorV2ActionsConditionsCompareTermsColumnColumnPathToHclTerraform(struct?: MonitorV2ActionsConditionsCompareTermsColumnColumnPathOutputReference | MonitorV2ActionsConditionsCompareTermsColumnColumnPath): any;
export declare class MonitorV2ActionsConditionsCompareTermsColumnColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2ActionsConditionsCompareTermsColumnColumnPath | undefined;
    set internalValue(value: MonitorV2ActionsConditionsCompareTermsColumnColumnPath | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface MonitorV2ActionsConditionsCompareTermsColumnLinkColumn {
    /**
    * The name of the link column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
}
export declare function monitorV2ActionsConditionsCompareTermsColumnLinkColumnToTerraform(struct?: MonitorV2ActionsConditionsCompareTermsColumnLinkColumnOutputReference | MonitorV2ActionsConditionsCompareTermsColumnLinkColumn): any;
export declare function monitorV2ActionsConditionsCompareTermsColumnLinkColumnToHclTerraform(struct?: MonitorV2ActionsConditionsCompareTermsColumnLinkColumnOutputReference | MonitorV2ActionsConditionsCompareTermsColumnLinkColumn): any;
export declare class MonitorV2ActionsConditionsCompareTermsColumnLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2ActionsConditionsCompareTermsColumnLinkColumn | undefined;
    set internalValue(value: MonitorV2ActionsConditionsCompareTermsColumnLinkColumn | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface MonitorV2ActionsConditionsCompareTermsColumn {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column_path MonitorV2#column_path}
    */
    readonly columnPath?: MonitorV2ActionsConditionsCompareTermsColumnColumnPath;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#link_column MonitorV2#link_column}
    */
    readonly linkColumn?: MonitorV2ActionsConditionsCompareTermsColumnLinkColumn;
}
export declare function monitorV2ActionsConditionsCompareTermsColumnToTerraform(struct?: MonitorV2ActionsConditionsCompareTermsColumn | cdktn.IResolvable): any;
export declare function monitorV2ActionsConditionsCompareTermsColumnToHclTerraform(struct?: MonitorV2ActionsConditionsCompareTermsColumn | cdktn.IResolvable): any;
export declare class MonitorV2ActionsConditionsCompareTermsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2ActionsConditionsCompareTermsColumn | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2ActionsConditionsCompareTermsColumn | cdktn.IResolvable | undefined);
    private _columnPath;
    get columnPath(): MonitorV2ActionsConditionsCompareTermsColumnColumnPathOutputReference;
    putColumnPath(value: MonitorV2ActionsConditionsCompareTermsColumnColumnPath): void;
    resetColumnPath(): void;
    get columnPathInput(): MonitorV2ActionsConditionsCompareTermsColumnColumnPath | undefined;
    private _linkColumn;
    get linkColumn(): MonitorV2ActionsConditionsCompareTermsColumnLinkColumnOutputReference;
    putLinkColumn(value: MonitorV2ActionsConditionsCompareTermsColumnLinkColumn): void;
    resetLinkColumn(): void;
    get linkColumnInput(): MonitorV2ActionsConditionsCompareTermsColumnLinkColumn | undefined;
}
export declare class MonitorV2ActionsConditionsCompareTermsColumnList extends cdktn.ComplexList {
    internalValue?: MonitorV2ActionsConditionsCompareTermsColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2ActionsConditionsCompareTermsColumnOutputReference;
}
export interface MonitorV2ActionsConditionsCompareTermsComparison {
    /**
    * the type of comparison (greater, less, equal, etc.)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_fn MonitorV2#compare_fn}
    */
    readonly compareFn: string;
    /**
    * list of size <=1 consisting of a boolean value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_bool MonitorV2#value_bool}
    */
    readonly valueBool?: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    /**
    * list of size <=1 consisting of a duration value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_duration MonitorV2#value_duration}
    */
    readonly valueDuration?: string[];
    /**
    * list of size <=1 consisting of a float value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_float64 MonitorV2#value_float64}
    */
    readonly valueFloat64?: number[];
    /**
    * list of size <=1 consisting of an integer value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_int64 MonitorV2#value_int64}
    */
    readonly valueInt64?: number[];
    /**
    * list of size <=1 consisting of a string value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_string MonitorV2#value_string}
    */
    readonly valueString?: string[];
    /**
    * list of size <=1 consisting of a timestamp value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_timestamp MonitorV2#value_timestamp}
    */
    readonly valueTimestamp?: string[];
}
export declare function monitorV2ActionsConditionsCompareTermsComparisonToTerraform(struct?: MonitorV2ActionsConditionsCompareTermsComparison | cdktn.IResolvable): any;
export declare function monitorV2ActionsConditionsCompareTermsComparisonToHclTerraform(struct?: MonitorV2ActionsConditionsCompareTermsComparison | cdktn.IResolvable): any;
export declare class MonitorV2ActionsConditionsCompareTermsComparisonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2ActionsConditionsCompareTermsComparison | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2ActionsConditionsCompareTermsComparison | cdktn.IResolvable | undefined);
    private _compareFn?;
    get compareFn(): string;
    set compareFn(value: string);
    get compareFnInput(): string | undefined;
    private _valueBool?;
    get valueBool(): Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    set valueBool(value: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable);
    resetValueBool(): void;
    get valueBoolInput(): cdktn.IResolvable | (boolean | cdktn.IResolvable)[] | undefined;
    private _valueDuration?;
    get valueDuration(): string[];
    set valueDuration(value: string[]);
    resetValueDuration(): void;
    get valueDurationInput(): string[] | undefined;
    private _valueFloat64?;
    get valueFloat64(): number[];
    set valueFloat64(value: number[]);
    resetValueFloat64(): void;
    get valueFloat64Input(): number[] | undefined;
    private _valueInt64?;
    get valueInt64(): number[];
    set valueInt64(value: number[]);
    resetValueInt64(): void;
    get valueInt64Input(): number[] | undefined;
    private _valueString?;
    get valueString(): string[];
    set valueString(value: string[]);
    resetValueString(): void;
    get valueStringInput(): string[] | undefined;
    private _valueTimestamp?;
    get valueTimestamp(): string[];
    set valueTimestamp(value: string[]);
    resetValueTimestamp(): void;
    get valueTimestampInput(): string[] | undefined;
}
export declare class MonitorV2ActionsConditionsCompareTermsComparisonList extends cdktn.ComplexList {
    internalValue?: MonitorV2ActionsConditionsCompareTermsComparison[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2ActionsConditionsCompareTermsComparisonOutputReference;
}
export interface MonitorV2ActionsConditionsCompareTerms {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column MonitorV2#column}
    */
    readonly column: MonitorV2ActionsConditionsCompareTermsColumn[] | cdktn.IResolvable;
    /**
    * comparison block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#comparison MonitorV2#comparison}
    */
    readonly comparison: MonitorV2ActionsConditionsCompareTermsComparison[] | cdktn.IResolvable;
}
export declare function monitorV2ActionsConditionsCompareTermsToTerraform(struct?: MonitorV2ActionsConditionsCompareTerms | cdktn.IResolvable): any;
export declare function monitorV2ActionsConditionsCompareTermsToHclTerraform(struct?: MonitorV2ActionsConditionsCompareTerms | cdktn.IResolvable): any;
export declare class MonitorV2ActionsConditionsCompareTermsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2ActionsConditionsCompareTerms | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2ActionsConditionsCompareTerms | cdktn.IResolvable | undefined);
    private _column;
    get column(): MonitorV2ActionsConditionsCompareTermsColumnList;
    putColumn(value: MonitorV2ActionsConditionsCompareTermsColumn[] | cdktn.IResolvable): void;
    get columnInput(): cdktn.IResolvable | MonitorV2ActionsConditionsCompareTermsColumn[] | undefined;
    private _comparison;
    get comparison(): MonitorV2ActionsConditionsCompareTermsComparisonList;
    putComparison(value: MonitorV2ActionsConditionsCompareTermsComparison[] | cdktn.IResolvable): void;
    get comparisonInput(): cdktn.IResolvable | MonitorV2ActionsConditionsCompareTermsComparison[] | undefined;
}
export declare class MonitorV2ActionsConditionsCompareTermsList extends cdktn.ComplexList {
    internalValue?: MonitorV2ActionsConditionsCompareTerms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2ActionsConditionsCompareTermsOutputReference;
}
export interface MonitorV2ActionsConditions {
    /**
    * Boolean operator to combine the list of compare terms. Can be "and" (default) or "or".
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#operator MonitorV2#operator}
    */
    readonly operator?: string;
    /**
    * compare_terms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_terms MonitorV2#compare_terms}
    */
    readonly compareTerms: MonitorV2ActionsConditionsCompareTerms[] | cdktn.IResolvable;
}
export declare function monitorV2ActionsConditionsToTerraform(struct?: MonitorV2ActionsConditionsOutputReference | MonitorV2ActionsConditions): any;
export declare function monitorV2ActionsConditionsToHclTerraform(struct?: MonitorV2ActionsConditionsOutputReference | MonitorV2ActionsConditions): any;
export declare class MonitorV2ActionsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2ActionsConditions | undefined;
    set internalValue(value: MonitorV2ActionsConditions | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _compareTerms;
    get compareTerms(): MonitorV2ActionsConditionsCompareTermsList;
    putCompareTerms(value: MonitorV2ActionsConditionsCompareTerms[] | cdktn.IResolvable): void;
    get compareTermsInput(): cdktn.IResolvable | MonitorV2ActionsConditionsCompareTerms[] | undefined;
}
export interface MonitorV2Actions {
    /**
    * The alarm level(s) at which this monitor should trigger this shared action.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#levels MonitorV2#levels}
    */
    readonly levels?: string[];
    /**
    * The OID of this shared action. This should be used for existing shared actions.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#oid MonitorV2#oid}
    */
    readonly oid?: string;
    /**
    * If true, notifications will be sent if the monitor stops triggering.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#send_end_notifications MonitorV2#send_end_notifications}
    */
    readonly sendEndNotifications?: boolean | cdktn.IResolvable;
    /**
    * Determines how frequently you will be reminded of an ongoing alert.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#send_reminders_interval MonitorV2#send_reminders_interval}
    */
    readonly sendRemindersInterval?: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#action MonitorV2#action}
    */
    readonly action?: MonitorV2ActionsAction;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#conditions MonitorV2#conditions}
    */
    readonly conditions?: MonitorV2ActionsConditions;
}
export declare function monitorV2ActionsToTerraform(struct?: MonitorV2Actions | cdktn.IResolvable): any;
export declare function monitorV2ActionsToHclTerraform(struct?: MonitorV2Actions | cdktn.IResolvable): any;
export declare class MonitorV2ActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2Actions | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2Actions | cdktn.IResolvable | undefined);
    private _levels?;
    get levels(): string[];
    set levels(value: string[]);
    resetLevels(): void;
    get levelsInput(): string[] | undefined;
    private _oid?;
    get oid(): string;
    set oid(value: string);
    resetOid(): void;
    get oidInput(): string | undefined;
    private _sendEndNotifications?;
    get sendEndNotifications(): boolean | cdktn.IResolvable;
    set sendEndNotifications(value: boolean | cdktn.IResolvable);
    resetSendEndNotifications(): void;
    get sendEndNotificationsInput(): boolean | cdktn.IResolvable | undefined;
    private _sendRemindersInterval?;
    get sendRemindersInterval(): string;
    set sendRemindersInterval(value: string);
    resetSendRemindersInterval(): void;
    get sendRemindersIntervalInput(): string | undefined;
    private _action;
    get action(): MonitorV2ActionsActionOutputReference;
    putAction(value: MonitorV2ActionsAction): void;
    resetAction(): void;
    get actionInput(): MonitorV2ActionsAction | undefined;
    private _conditions;
    get conditions(): MonitorV2ActionsConditionsOutputReference;
    putConditions(value: MonitorV2ActionsConditions): void;
    resetConditions(): void;
    get conditionsInput(): MonitorV2ActionsConditions | undefined;
}
export declare class MonitorV2ActionsList extends cdktn.ComplexList {
    internalValue?: MonitorV2Actions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2ActionsOutputReference;
}
export interface MonitorV2GroupingsColumnPath {
    /**
    * The name of the column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
    /**
    * The path of the path, if the name refers to a column with a JSON object.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#path MonitorV2#path}
    */
    readonly path?: string;
}
export declare function monitorV2GroupingsColumnPathToTerraform(struct?: MonitorV2GroupingsColumnPathOutputReference | MonitorV2GroupingsColumnPath): any;
export declare function monitorV2GroupingsColumnPathToHclTerraform(struct?: MonitorV2GroupingsColumnPathOutputReference | MonitorV2GroupingsColumnPath): any;
export declare class MonitorV2GroupingsColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2GroupingsColumnPath | undefined;
    set internalValue(value: MonitorV2GroupingsColumnPath | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface MonitorV2GroupingsLinkColumn {
    /**
    * The name of the link column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
}
export declare function monitorV2GroupingsLinkColumnToTerraform(struct?: MonitorV2GroupingsLinkColumnOutputReference | MonitorV2GroupingsLinkColumn): any;
export declare function monitorV2GroupingsLinkColumnToHclTerraform(struct?: MonitorV2GroupingsLinkColumnOutputReference | MonitorV2GroupingsLinkColumn): any;
export declare class MonitorV2GroupingsLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2GroupingsLinkColumn | undefined;
    set internalValue(value: MonitorV2GroupingsLinkColumn | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface MonitorV2Groupings {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column_path MonitorV2#column_path}
    */
    readonly columnPath?: MonitorV2GroupingsColumnPath;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#link_column MonitorV2#link_column}
    */
    readonly linkColumn?: MonitorV2GroupingsLinkColumn;
}
export declare function monitorV2GroupingsToTerraform(struct?: MonitorV2Groupings | cdktn.IResolvable): any;
export declare function monitorV2GroupingsToHclTerraform(struct?: MonitorV2Groupings | cdktn.IResolvable): any;
export declare class MonitorV2GroupingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2Groupings | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2Groupings | cdktn.IResolvable | undefined);
    private _columnPath;
    get columnPath(): MonitorV2GroupingsColumnPathOutputReference;
    putColumnPath(value: MonitorV2GroupingsColumnPath): void;
    resetColumnPath(): void;
    get columnPathInput(): MonitorV2GroupingsColumnPath | undefined;
    private _linkColumn;
    get linkColumn(): MonitorV2GroupingsLinkColumnOutputReference;
    putLinkColumn(value: MonitorV2GroupingsLinkColumn): void;
    resetLinkColumn(): void;
    get linkColumnInput(): MonitorV2GroupingsLinkColumn | undefined;
}
export declare class MonitorV2GroupingsList extends cdktn.ComplexList {
    internalValue?: MonitorV2Groupings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2GroupingsOutputReference;
}
export interface MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath {
    /**
    * The name of the column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
    /**
    * The path of the path, if the name refers to a column with a JSON object.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#path MonitorV2#path}
    */
    readonly path?: string;
}
export declare function monitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathToTerraform(struct?: MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathOutputReference | MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath): any;
export declare function monitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathToHclTerraform(struct?: MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathOutputReference | MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath): any;
export declare class MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath | undefined;
    set internalValue(value: MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn {
    /**
    * The name of the link column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
}
export declare function monitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnToTerraform(struct?: MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnOutputReference | MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn): any;
export declare function monitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnToHclTerraform(struct?: MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnOutputReference | MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn): any;
export declare class MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn | undefined;
    set internalValue(value: MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface MonitorV2NoDataRulesThresholdCompareGroupsColumn {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column_path MonitorV2#column_path}
    */
    readonly columnPath?: MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#link_column MonitorV2#link_column}
    */
    readonly linkColumn?: MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn;
}
export declare function monitorV2NoDataRulesThresholdCompareGroupsColumnToTerraform(struct?: MonitorV2NoDataRulesThresholdCompareGroupsColumnOutputReference | MonitorV2NoDataRulesThresholdCompareGroupsColumn): any;
export declare function monitorV2NoDataRulesThresholdCompareGroupsColumnToHclTerraform(struct?: MonitorV2NoDataRulesThresholdCompareGroupsColumnOutputReference | MonitorV2NoDataRulesThresholdCompareGroupsColumn): any;
export declare class MonitorV2NoDataRulesThresholdCompareGroupsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2NoDataRulesThresholdCompareGroupsColumn | undefined;
    set internalValue(value: MonitorV2NoDataRulesThresholdCompareGroupsColumn | undefined);
    private _columnPath;
    get columnPath(): MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathOutputReference;
    putColumnPath(value: MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath): void;
    resetColumnPath(): void;
    get columnPathInput(): MonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath | undefined;
    private _linkColumn;
    get linkColumn(): MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnOutputReference;
    putLinkColumn(value: MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn): void;
    resetLinkColumn(): void;
    get linkColumnInput(): MonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn | undefined;
}
export interface MonitorV2NoDataRulesThresholdCompareGroupsCompareValues {
    /**
    * the type of comparison (greater, less, equal, etc.)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_fn MonitorV2#compare_fn}
    */
    readonly compareFn: string;
    /**
    * list of size <=1 consisting of a boolean value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_bool MonitorV2#value_bool}
    */
    readonly valueBool?: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    /**
    * list of size <=1 consisting of a duration value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_duration MonitorV2#value_duration}
    */
    readonly valueDuration?: string[];
    /**
    * list of size <=1 consisting of a float value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_float64 MonitorV2#value_float64}
    */
    readonly valueFloat64?: number[];
    /**
    * list of size <=1 consisting of an integer value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_int64 MonitorV2#value_int64}
    */
    readonly valueInt64?: number[];
    /**
    * list of size <=1 consisting of a string value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_string MonitorV2#value_string}
    */
    readonly valueString?: string[];
    /**
    * list of size <=1 consisting of a timestamp value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_timestamp MonitorV2#value_timestamp}
    */
    readonly valueTimestamp?: string[];
}
export declare function monitorV2NoDataRulesThresholdCompareGroupsCompareValuesToTerraform(struct?: MonitorV2NoDataRulesThresholdCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare function monitorV2NoDataRulesThresholdCompareGroupsCompareValuesToHclTerraform(struct?: MonitorV2NoDataRulesThresholdCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare class MonitorV2NoDataRulesThresholdCompareGroupsCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2NoDataRulesThresholdCompareGroupsCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2NoDataRulesThresholdCompareGroupsCompareValues | cdktn.IResolvable | undefined);
    private _compareFn?;
    get compareFn(): string;
    set compareFn(value: string);
    get compareFnInput(): string | undefined;
    private _valueBool?;
    get valueBool(): Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    set valueBool(value: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable);
    resetValueBool(): void;
    get valueBoolInput(): cdktn.IResolvable | (boolean | cdktn.IResolvable)[] | undefined;
    private _valueDuration?;
    get valueDuration(): string[];
    set valueDuration(value: string[]);
    resetValueDuration(): void;
    get valueDurationInput(): string[] | undefined;
    private _valueFloat64?;
    get valueFloat64(): number[];
    set valueFloat64(value: number[]);
    resetValueFloat64(): void;
    get valueFloat64Input(): number[] | undefined;
    private _valueInt64?;
    get valueInt64(): number[];
    set valueInt64(value: number[]);
    resetValueInt64(): void;
    get valueInt64Input(): number[] | undefined;
    private _valueString?;
    get valueString(): string[];
    set valueString(value: string[]);
    resetValueString(): void;
    get valueStringInput(): string[] | undefined;
    private _valueTimestamp?;
    get valueTimestamp(): string[];
    set valueTimestamp(value: string[]);
    resetValueTimestamp(): void;
    get valueTimestampInput(): string[] | undefined;
}
export declare class MonitorV2NoDataRulesThresholdCompareGroupsCompareValuesList extends cdktn.ComplexList {
    internalValue?: MonitorV2NoDataRulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2NoDataRulesThresholdCompareGroupsCompareValuesOutputReference;
}
export interface MonitorV2NoDataRulesThresholdCompareGroups {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column MonitorV2#column}
    */
    readonly column: MonitorV2NoDataRulesThresholdCompareGroupsColumn;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_values MonitorV2#compare_values}
    */
    readonly compareValues: MonitorV2NoDataRulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable;
}
export declare function monitorV2NoDataRulesThresholdCompareGroupsToTerraform(struct?: MonitorV2NoDataRulesThresholdCompareGroups | cdktn.IResolvable): any;
export declare function monitorV2NoDataRulesThresholdCompareGroupsToHclTerraform(struct?: MonitorV2NoDataRulesThresholdCompareGroups | cdktn.IResolvable): any;
export declare class MonitorV2NoDataRulesThresholdCompareGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2NoDataRulesThresholdCompareGroups | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2NoDataRulesThresholdCompareGroups | cdktn.IResolvable | undefined);
    private _column;
    get column(): MonitorV2NoDataRulesThresholdCompareGroupsColumnOutputReference;
    putColumn(value: MonitorV2NoDataRulesThresholdCompareGroupsColumn): void;
    get columnInput(): MonitorV2NoDataRulesThresholdCompareGroupsColumn | undefined;
    private _compareValues;
    get compareValues(): MonitorV2NoDataRulesThresholdCompareGroupsCompareValuesList;
    putCompareValues(value: MonitorV2NoDataRulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable): void;
    get compareValuesInput(): cdktn.IResolvable | MonitorV2NoDataRulesThresholdCompareGroupsCompareValues[] | undefined;
}
export declare class MonitorV2NoDataRulesThresholdCompareGroupsList extends cdktn.ComplexList {
    internalValue?: MonitorV2NoDataRulesThresholdCompareGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2NoDataRulesThresholdCompareGroupsOutputReference;
}
export interface MonitorV2NoDataRulesThresholdCompareValues {
    /**
    * the type of comparison (greater, less, equal, etc.)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_fn MonitorV2#compare_fn}
    */
    readonly compareFn: string;
    /**
    * list of size <=1 consisting of a boolean value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_bool MonitorV2#value_bool}
    */
    readonly valueBool?: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    /**
    * list of size <=1 consisting of a duration value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_duration MonitorV2#value_duration}
    */
    readonly valueDuration?: string[];
    /**
    * list of size <=1 consisting of a float value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_float64 MonitorV2#value_float64}
    */
    readonly valueFloat64?: number[];
    /**
    * list of size <=1 consisting of an integer value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_int64 MonitorV2#value_int64}
    */
    readonly valueInt64?: number[];
    /**
    * list of size <=1 consisting of a string value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_string MonitorV2#value_string}
    */
    readonly valueString?: string[];
    /**
    * list of size <=1 consisting of a timestamp value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_timestamp MonitorV2#value_timestamp}
    */
    readonly valueTimestamp?: string[];
}
export declare function monitorV2NoDataRulesThresholdCompareValuesToTerraform(struct?: MonitorV2NoDataRulesThresholdCompareValues | cdktn.IResolvable): any;
export declare function monitorV2NoDataRulesThresholdCompareValuesToHclTerraform(struct?: MonitorV2NoDataRulesThresholdCompareValues | cdktn.IResolvable): any;
export declare class MonitorV2NoDataRulesThresholdCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2NoDataRulesThresholdCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2NoDataRulesThresholdCompareValues | cdktn.IResolvable | undefined);
    private _compareFn?;
    get compareFn(): string;
    set compareFn(value: string);
    get compareFnInput(): string | undefined;
    private _valueBool?;
    get valueBool(): Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    set valueBool(value: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable);
    resetValueBool(): void;
    get valueBoolInput(): cdktn.IResolvable | (boolean | cdktn.IResolvable)[] | undefined;
    private _valueDuration?;
    get valueDuration(): string[];
    set valueDuration(value: string[]);
    resetValueDuration(): void;
    get valueDurationInput(): string[] | undefined;
    private _valueFloat64?;
    get valueFloat64(): number[];
    set valueFloat64(value: number[]);
    resetValueFloat64(): void;
    get valueFloat64Input(): number[] | undefined;
    private _valueInt64?;
    get valueInt64(): number[];
    set valueInt64(value: number[]);
    resetValueInt64(): void;
    get valueInt64Input(): number[] | undefined;
    private _valueString?;
    get valueString(): string[];
    set valueString(value: string[]);
    resetValueString(): void;
    get valueStringInput(): string[] | undefined;
    private _valueTimestamp?;
    get valueTimestamp(): string[];
    set valueTimestamp(value: string[]);
    resetValueTimestamp(): void;
    get valueTimestampInput(): string[] | undefined;
}
export declare class MonitorV2NoDataRulesThresholdCompareValuesList extends cdktn.ComplexList {
    internalValue?: MonitorV2NoDataRulesThresholdCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2NoDataRulesThresholdCompareValuesOutputReference;
}
export interface MonitorV2NoDataRulesThreshold {
    /**
    * The query aggregator (AllOf, AnyOf, AvgOf, Max, Min, SumOf) for the value monitor type.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#aggregation MonitorV2#aggregation}
    */
    readonly aggregation: string;
    /**
    * Indicates which column in the input query has the value to apply the aggregation.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_column_name MonitorV2#value_column_name}
    */
    readonly valueColumnName: string;
    /**
    * compare_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_groups MonitorV2#compare_groups}
    */
    readonly compareGroups?: MonitorV2NoDataRulesThresholdCompareGroups[] | cdktn.IResolvable;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_values MonitorV2#compare_values}
    */
    readonly compareValues?: MonitorV2NoDataRulesThresholdCompareValues[] | cdktn.IResolvable;
}
export declare function monitorV2NoDataRulesThresholdToTerraform(struct?: MonitorV2NoDataRulesThresholdOutputReference | MonitorV2NoDataRulesThreshold): any;
export declare function monitorV2NoDataRulesThresholdToHclTerraform(struct?: MonitorV2NoDataRulesThresholdOutputReference | MonitorV2NoDataRulesThreshold): any;
export declare class MonitorV2NoDataRulesThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2NoDataRulesThreshold | undefined;
    set internalValue(value: MonitorV2NoDataRulesThreshold | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _valueColumnName?;
    get valueColumnName(): string;
    set valueColumnName(value: string);
    get valueColumnNameInput(): string | undefined;
    private _compareGroups;
    get compareGroups(): MonitorV2NoDataRulesThresholdCompareGroupsList;
    putCompareGroups(value: MonitorV2NoDataRulesThresholdCompareGroups[] | cdktn.IResolvable): void;
    resetCompareGroups(): void;
    get compareGroupsInput(): cdktn.IResolvable | MonitorV2NoDataRulesThresholdCompareGroups[] | undefined;
    private _compareValues;
    get compareValues(): MonitorV2NoDataRulesThresholdCompareValuesList;
    putCompareValues(value: MonitorV2NoDataRulesThresholdCompareValues[] | cdktn.IResolvable): void;
    resetCompareValues(): void;
    get compareValuesInput(): cdktn.IResolvable | MonitorV2NoDataRulesThresholdCompareValues[] | undefined;
}
export interface MonitorV2NoDataRules {
    /**
    * Allows for the user to specify how long they'd like the missing data alert to persist for before it resolves by itself. If not provided, the default expiration time will be set to 24 hours. The expiration must be identical across all rules.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#expiration MonitorV2#expiration}
    */
    readonly expiration?: string;
    /**
    * threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#threshold MonitorV2#threshold}
    */
    readonly threshold?: MonitorV2NoDataRulesThreshold;
}
export declare function monitorV2NoDataRulesToTerraform(struct?: MonitorV2NoDataRulesOutputReference | MonitorV2NoDataRules): any;
export declare function monitorV2NoDataRulesToHclTerraform(struct?: MonitorV2NoDataRulesOutputReference | MonitorV2NoDataRules): any;
export declare class MonitorV2NoDataRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2NoDataRules | undefined;
    set internalValue(value: MonitorV2NoDataRules | undefined);
    private _expiration?;
    get expiration(): string;
    set expiration(value: string);
    resetExpiration(): void;
    get expirationInput(): string | undefined;
    private _threshold;
    get threshold(): MonitorV2NoDataRulesThresholdOutputReference;
    putThreshold(value: MonitorV2NoDataRulesThreshold): void;
    resetThreshold(): void;
    get thresholdInput(): MonitorV2NoDataRulesThreshold | undefined;
}
export interface MonitorV2RulesCountCompareGroupsColumnColumnPath {
    /**
    * The name of the column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
    /**
    * The path of the path, if the name refers to a column with a JSON object.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#path MonitorV2#path}
    */
    readonly path?: string;
}
export declare function monitorV2RulesCountCompareGroupsColumnColumnPathToTerraform(struct?: MonitorV2RulesCountCompareGroupsColumnColumnPathOutputReference | MonitorV2RulesCountCompareGroupsColumnColumnPath): any;
export declare function monitorV2RulesCountCompareGroupsColumnColumnPathToHclTerraform(struct?: MonitorV2RulesCountCompareGroupsColumnColumnPathOutputReference | MonitorV2RulesCountCompareGroupsColumnColumnPath): any;
export declare class MonitorV2RulesCountCompareGroupsColumnColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesCountCompareGroupsColumnColumnPath | undefined;
    set internalValue(value: MonitorV2RulesCountCompareGroupsColumnColumnPath | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface MonitorV2RulesCountCompareGroupsColumnLinkColumn {
    /**
    * The name of the link column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
}
export declare function monitorV2RulesCountCompareGroupsColumnLinkColumnToTerraform(struct?: MonitorV2RulesCountCompareGroupsColumnLinkColumnOutputReference | MonitorV2RulesCountCompareGroupsColumnLinkColumn): any;
export declare function monitorV2RulesCountCompareGroupsColumnLinkColumnToHclTerraform(struct?: MonitorV2RulesCountCompareGroupsColumnLinkColumnOutputReference | MonitorV2RulesCountCompareGroupsColumnLinkColumn): any;
export declare class MonitorV2RulesCountCompareGroupsColumnLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesCountCompareGroupsColumnLinkColumn | undefined;
    set internalValue(value: MonitorV2RulesCountCompareGroupsColumnLinkColumn | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface MonitorV2RulesCountCompareGroupsColumn {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column_path MonitorV2#column_path}
    */
    readonly columnPath?: MonitorV2RulesCountCompareGroupsColumnColumnPath;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#link_column MonitorV2#link_column}
    */
    readonly linkColumn?: MonitorV2RulesCountCompareGroupsColumnLinkColumn;
}
export declare function monitorV2RulesCountCompareGroupsColumnToTerraform(struct?: MonitorV2RulesCountCompareGroupsColumnOutputReference | MonitorV2RulesCountCompareGroupsColumn): any;
export declare function monitorV2RulesCountCompareGroupsColumnToHclTerraform(struct?: MonitorV2RulesCountCompareGroupsColumnOutputReference | MonitorV2RulesCountCompareGroupsColumn): any;
export declare class MonitorV2RulesCountCompareGroupsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesCountCompareGroupsColumn | undefined;
    set internalValue(value: MonitorV2RulesCountCompareGroupsColumn | undefined);
    private _columnPath;
    get columnPath(): MonitorV2RulesCountCompareGroupsColumnColumnPathOutputReference;
    putColumnPath(value: MonitorV2RulesCountCompareGroupsColumnColumnPath): void;
    resetColumnPath(): void;
    get columnPathInput(): MonitorV2RulesCountCompareGroupsColumnColumnPath | undefined;
    private _linkColumn;
    get linkColumn(): MonitorV2RulesCountCompareGroupsColumnLinkColumnOutputReference;
    putLinkColumn(value: MonitorV2RulesCountCompareGroupsColumnLinkColumn): void;
    resetLinkColumn(): void;
    get linkColumnInput(): MonitorV2RulesCountCompareGroupsColumnLinkColumn | undefined;
}
export interface MonitorV2RulesCountCompareGroupsCompareValues {
    /**
    * the type of comparison (greater, less, equal, etc.)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_fn MonitorV2#compare_fn}
    */
    readonly compareFn: string;
    /**
    * list of size <=1 consisting of a boolean value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_bool MonitorV2#value_bool}
    */
    readonly valueBool?: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    /**
    * list of size <=1 consisting of a duration value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_duration MonitorV2#value_duration}
    */
    readonly valueDuration?: string[];
    /**
    * list of size <=1 consisting of a float value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_float64 MonitorV2#value_float64}
    */
    readonly valueFloat64?: number[];
    /**
    * list of size <=1 consisting of an integer value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_int64 MonitorV2#value_int64}
    */
    readonly valueInt64?: number[];
    /**
    * list of size <=1 consisting of a string value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_string MonitorV2#value_string}
    */
    readonly valueString?: string[];
    /**
    * list of size <=1 consisting of a timestamp value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_timestamp MonitorV2#value_timestamp}
    */
    readonly valueTimestamp?: string[];
}
export declare function monitorV2RulesCountCompareGroupsCompareValuesToTerraform(struct?: MonitorV2RulesCountCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare function monitorV2RulesCountCompareGroupsCompareValuesToHclTerraform(struct?: MonitorV2RulesCountCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare class MonitorV2RulesCountCompareGroupsCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2RulesCountCompareGroupsCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2RulesCountCompareGroupsCompareValues | cdktn.IResolvable | undefined);
    private _compareFn?;
    get compareFn(): string;
    set compareFn(value: string);
    get compareFnInput(): string | undefined;
    private _valueBool?;
    get valueBool(): Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    set valueBool(value: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable);
    resetValueBool(): void;
    get valueBoolInput(): cdktn.IResolvable | (boolean | cdktn.IResolvable)[] | undefined;
    private _valueDuration?;
    get valueDuration(): string[];
    set valueDuration(value: string[]);
    resetValueDuration(): void;
    get valueDurationInput(): string[] | undefined;
    private _valueFloat64?;
    get valueFloat64(): number[];
    set valueFloat64(value: number[]);
    resetValueFloat64(): void;
    get valueFloat64Input(): number[] | undefined;
    private _valueInt64?;
    get valueInt64(): number[];
    set valueInt64(value: number[]);
    resetValueInt64(): void;
    get valueInt64Input(): number[] | undefined;
    private _valueString?;
    get valueString(): string[];
    set valueString(value: string[]);
    resetValueString(): void;
    get valueStringInput(): string[] | undefined;
    private _valueTimestamp?;
    get valueTimestamp(): string[];
    set valueTimestamp(value: string[]);
    resetValueTimestamp(): void;
    get valueTimestampInput(): string[] | undefined;
}
export declare class MonitorV2RulesCountCompareGroupsCompareValuesList extends cdktn.ComplexList {
    internalValue?: MonitorV2RulesCountCompareGroupsCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2RulesCountCompareGroupsCompareValuesOutputReference;
}
export interface MonitorV2RulesCountCompareGroups {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column MonitorV2#column}
    */
    readonly column: MonitorV2RulesCountCompareGroupsColumn;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_values MonitorV2#compare_values}
    */
    readonly compareValues: MonitorV2RulesCountCompareGroupsCompareValues[] | cdktn.IResolvable;
}
export declare function monitorV2RulesCountCompareGroupsToTerraform(struct?: MonitorV2RulesCountCompareGroups | cdktn.IResolvable): any;
export declare function monitorV2RulesCountCompareGroupsToHclTerraform(struct?: MonitorV2RulesCountCompareGroups | cdktn.IResolvable): any;
export declare class MonitorV2RulesCountCompareGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2RulesCountCompareGroups | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2RulesCountCompareGroups | cdktn.IResolvable | undefined);
    private _column;
    get column(): MonitorV2RulesCountCompareGroupsColumnOutputReference;
    putColumn(value: MonitorV2RulesCountCompareGroupsColumn): void;
    get columnInput(): MonitorV2RulesCountCompareGroupsColumn | undefined;
    private _compareValues;
    get compareValues(): MonitorV2RulesCountCompareGroupsCompareValuesList;
    putCompareValues(value: MonitorV2RulesCountCompareGroupsCompareValues[] | cdktn.IResolvable): void;
    get compareValuesInput(): cdktn.IResolvable | MonitorV2RulesCountCompareGroupsCompareValues[] | undefined;
}
export declare class MonitorV2RulesCountCompareGroupsList extends cdktn.ComplexList {
    internalValue?: MonitorV2RulesCountCompareGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2RulesCountCompareGroupsOutputReference;
}
export interface MonitorV2RulesCountCompareValues {
    /**
    * the type of comparison (greater, less, equal, etc.)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_fn MonitorV2#compare_fn}
    */
    readonly compareFn: string;
    /**
    * list of size <=1 consisting of a boolean value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_bool MonitorV2#value_bool}
    */
    readonly valueBool?: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    /**
    * list of size <=1 consisting of a duration value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_duration MonitorV2#value_duration}
    */
    readonly valueDuration?: string[];
    /**
    * list of size <=1 consisting of a float value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_float64 MonitorV2#value_float64}
    */
    readonly valueFloat64?: number[];
    /**
    * list of size <=1 consisting of an integer value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_int64 MonitorV2#value_int64}
    */
    readonly valueInt64?: number[];
    /**
    * list of size <=1 consisting of a string value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_string MonitorV2#value_string}
    */
    readonly valueString?: string[];
    /**
    * list of size <=1 consisting of a timestamp value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_timestamp MonitorV2#value_timestamp}
    */
    readonly valueTimestamp?: string[];
}
export declare function monitorV2RulesCountCompareValuesToTerraform(struct?: MonitorV2RulesCountCompareValues | cdktn.IResolvable): any;
export declare function monitorV2RulesCountCompareValuesToHclTerraform(struct?: MonitorV2RulesCountCompareValues | cdktn.IResolvable): any;
export declare class MonitorV2RulesCountCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2RulesCountCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2RulesCountCompareValues | cdktn.IResolvable | undefined);
    private _compareFn?;
    get compareFn(): string;
    set compareFn(value: string);
    get compareFnInput(): string | undefined;
    private _valueBool?;
    get valueBool(): Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    set valueBool(value: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable);
    resetValueBool(): void;
    get valueBoolInput(): cdktn.IResolvable | (boolean | cdktn.IResolvable)[] | undefined;
    private _valueDuration?;
    get valueDuration(): string[];
    set valueDuration(value: string[]);
    resetValueDuration(): void;
    get valueDurationInput(): string[] | undefined;
    private _valueFloat64?;
    get valueFloat64(): number[];
    set valueFloat64(value: number[]);
    resetValueFloat64(): void;
    get valueFloat64Input(): number[] | undefined;
    private _valueInt64?;
    get valueInt64(): number[];
    set valueInt64(value: number[]);
    resetValueInt64(): void;
    get valueInt64Input(): number[] | undefined;
    private _valueString?;
    get valueString(): string[];
    set valueString(value: string[]);
    resetValueString(): void;
    get valueStringInput(): string[] | undefined;
    private _valueTimestamp?;
    get valueTimestamp(): string[];
    set valueTimestamp(value: string[]);
    resetValueTimestamp(): void;
    get valueTimestampInput(): string[] | undefined;
}
export declare class MonitorV2RulesCountCompareValuesList extends cdktn.ComplexList {
    internalValue?: MonitorV2RulesCountCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2RulesCountCompareValuesOutputReference;
}
export interface MonitorV2RulesCount {
    /**
    * compare_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_groups MonitorV2#compare_groups}
    */
    readonly compareGroups?: MonitorV2RulesCountCompareGroups[] | cdktn.IResolvable;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_values MonitorV2#compare_values}
    */
    readonly compareValues: MonitorV2RulesCountCompareValues[] | cdktn.IResolvable;
}
export declare function monitorV2RulesCountToTerraform(struct?: MonitorV2RulesCountOutputReference | MonitorV2RulesCount): any;
export declare function monitorV2RulesCountToHclTerraform(struct?: MonitorV2RulesCountOutputReference | MonitorV2RulesCount): any;
export declare class MonitorV2RulesCountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesCount | undefined;
    set internalValue(value: MonitorV2RulesCount | undefined);
    private _compareGroups;
    get compareGroups(): MonitorV2RulesCountCompareGroupsList;
    putCompareGroups(value: MonitorV2RulesCountCompareGroups[] | cdktn.IResolvable): void;
    resetCompareGroups(): void;
    get compareGroupsInput(): cdktn.IResolvable | MonitorV2RulesCountCompareGroups[] | undefined;
    private _compareValues;
    get compareValues(): MonitorV2RulesCountCompareValuesList;
    putCompareValues(value: MonitorV2RulesCountCompareValues[] | cdktn.IResolvable): void;
    get compareValuesInput(): cdktn.IResolvable | MonitorV2RulesCountCompareValues[] | undefined;
}
export interface MonitorV2RulesPromoteCompareColumnsColumnColumnPath {
    /**
    * The name of the column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
    /**
    * The path of the path, if the name refers to a column with a JSON object.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#path MonitorV2#path}
    */
    readonly path?: string;
}
export declare function monitorV2RulesPromoteCompareColumnsColumnColumnPathToTerraform(struct?: MonitorV2RulesPromoteCompareColumnsColumnColumnPathOutputReference | MonitorV2RulesPromoteCompareColumnsColumnColumnPath): any;
export declare function monitorV2RulesPromoteCompareColumnsColumnColumnPathToHclTerraform(struct?: MonitorV2RulesPromoteCompareColumnsColumnColumnPathOutputReference | MonitorV2RulesPromoteCompareColumnsColumnColumnPath): any;
export declare class MonitorV2RulesPromoteCompareColumnsColumnColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesPromoteCompareColumnsColumnColumnPath | undefined;
    set internalValue(value: MonitorV2RulesPromoteCompareColumnsColumnColumnPath | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface MonitorV2RulesPromoteCompareColumnsColumnLinkColumn {
    /**
    * The name of the link column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
}
export declare function monitorV2RulesPromoteCompareColumnsColumnLinkColumnToTerraform(struct?: MonitorV2RulesPromoteCompareColumnsColumnLinkColumnOutputReference | MonitorV2RulesPromoteCompareColumnsColumnLinkColumn): any;
export declare function monitorV2RulesPromoteCompareColumnsColumnLinkColumnToHclTerraform(struct?: MonitorV2RulesPromoteCompareColumnsColumnLinkColumnOutputReference | MonitorV2RulesPromoteCompareColumnsColumnLinkColumn): any;
export declare class MonitorV2RulesPromoteCompareColumnsColumnLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesPromoteCompareColumnsColumnLinkColumn | undefined;
    set internalValue(value: MonitorV2RulesPromoteCompareColumnsColumnLinkColumn | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface MonitorV2RulesPromoteCompareColumnsColumn {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column_path MonitorV2#column_path}
    */
    readonly columnPath?: MonitorV2RulesPromoteCompareColumnsColumnColumnPath;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#link_column MonitorV2#link_column}
    */
    readonly linkColumn?: MonitorV2RulesPromoteCompareColumnsColumnLinkColumn;
}
export declare function monitorV2RulesPromoteCompareColumnsColumnToTerraform(struct?: MonitorV2RulesPromoteCompareColumnsColumnOutputReference | MonitorV2RulesPromoteCompareColumnsColumn): any;
export declare function monitorV2RulesPromoteCompareColumnsColumnToHclTerraform(struct?: MonitorV2RulesPromoteCompareColumnsColumnOutputReference | MonitorV2RulesPromoteCompareColumnsColumn): any;
export declare class MonitorV2RulesPromoteCompareColumnsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesPromoteCompareColumnsColumn | undefined;
    set internalValue(value: MonitorV2RulesPromoteCompareColumnsColumn | undefined);
    private _columnPath;
    get columnPath(): MonitorV2RulesPromoteCompareColumnsColumnColumnPathOutputReference;
    putColumnPath(value: MonitorV2RulesPromoteCompareColumnsColumnColumnPath): void;
    resetColumnPath(): void;
    get columnPathInput(): MonitorV2RulesPromoteCompareColumnsColumnColumnPath | undefined;
    private _linkColumn;
    get linkColumn(): MonitorV2RulesPromoteCompareColumnsColumnLinkColumnOutputReference;
    putLinkColumn(value: MonitorV2RulesPromoteCompareColumnsColumnLinkColumn): void;
    resetLinkColumn(): void;
    get linkColumnInput(): MonitorV2RulesPromoteCompareColumnsColumnLinkColumn | undefined;
}
export interface MonitorV2RulesPromoteCompareColumnsCompareValues {
    /**
    * the type of comparison (greater, less, equal, etc.)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_fn MonitorV2#compare_fn}
    */
    readonly compareFn: string;
    /**
    * list of size <=1 consisting of a boolean value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_bool MonitorV2#value_bool}
    */
    readonly valueBool?: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    /**
    * list of size <=1 consisting of a duration value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_duration MonitorV2#value_duration}
    */
    readonly valueDuration?: string[];
    /**
    * list of size <=1 consisting of a float value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_float64 MonitorV2#value_float64}
    */
    readonly valueFloat64?: number[];
    /**
    * list of size <=1 consisting of an integer value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_int64 MonitorV2#value_int64}
    */
    readonly valueInt64?: number[];
    /**
    * list of size <=1 consisting of a string value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_string MonitorV2#value_string}
    */
    readonly valueString?: string[];
    /**
    * list of size <=1 consisting of a timestamp value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_timestamp MonitorV2#value_timestamp}
    */
    readonly valueTimestamp?: string[];
}
export declare function monitorV2RulesPromoteCompareColumnsCompareValuesToTerraform(struct?: MonitorV2RulesPromoteCompareColumnsCompareValues | cdktn.IResolvable): any;
export declare function monitorV2RulesPromoteCompareColumnsCompareValuesToHclTerraform(struct?: MonitorV2RulesPromoteCompareColumnsCompareValues | cdktn.IResolvable): any;
export declare class MonitorV2RulesPromoteCompareColumnsCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2RulesPromoteCompareColumnsCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2RulesPromoteCompareColumnsCompareValues | cdktn.IResolvable | undefined);
    private _compareFn?;
    get compareFn(): string;
    set compareFn(value: string);
    get compareFnInput(): string | undefined;
    private _valueBool?;
    get valueBool(): Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    set valueBool(value: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable);
    resetValueBool(): void;
    get valueBoolInput(): cdktn.IResolvable | (boolean | cdktn.IResolvable)[] | undefined;
    private _valueDuration?;
    get valueDuration(): string[];
    set valueDuration(value: string[]);
    resetValueDuration(): void;
    get valueDurationInput(): string[] | undefined;
    private _valueFloat64?;
    get valueFloat64(): number[];
    set valueFloat64(value: number[]);
    resetValueFloat64(): void;
    get valueFloat64Input(): number[] | undefined;
    private _valueInt64?;
    get valueInt64(): number[];
    set valueInt64(value: number[]);
    resetValueInt64(): void;
    get valueInt64Input(): number[] | undefined;
    private _valueString?;
    get valueString(): string[];
    set valueString(value: string[]);
    resetValueString(): void;
    get valueStringInput(): string[] | undefined;
    private _valueTimestamp?;
    get valueTimestamp(): string[];
    set valueTimestamp(value: string[]);
    resetValueTimestamp(): void;
    get valueTimestampInput(): string[] | undefined;
}
export declare class MonitorV2RulesPromoteCompareColumnsCompareValuesList extends cdktn.ComplexList {
    internalValue?: MonitorV2RulesPromoteCompareColumnsCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2RulesPromoteCompareColumnsCompareValuesOutputReference;
}
export interface MonitorV2RulesPromoteCompareColumns {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column MonitorV2#column}
    */
    readonly column: MonitorV2RulesPromoteCompareColumnsColumn;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_values MonitorV2#compare_values}
    */
    readonly compareValues: MonitorV2RulesPromoteCompareColumnsCompareValues[] | cdktn.IResolvable;
}
export declare function monitorV2RulesPromoteCompareColumnsToTerraform(struct?: MonitorV2RulesPromoteCompareColumns | cdktn.IResolvable): any;
export declare function monitorV2RulesPromoteCompareColumnsToHclTerraform(struct?: MonitorV2RulesPromoteCompareColumns | cdktn.IResolvable): any;
export declare class MonitorV2RulesPromoteCompareColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2RulesPromoteCompareColumns | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2RulesPromoteCompareColumns | cdktn.IResolvable | undefined);
    private _column;
    get column(): MonitorV2RulesPromoteCompareColumnsColumnOutputReference;
    putColumn(value: MonitorV2RulesPromoteCompareColumnsColumn): void;
    get columnInput(): MonitorV2RulesPromoteCompareColumnsColumn | undefined;
    private _compareValues;
    get compareValues(): MonitorV2RulesPromoteCompareColumnsCompareValuesList;
    putCompareValues(value: MonitorV2RulesPromoteCompareColumnsCompareValues[] | cdktn.IResolvable): void;
    get compareValuesInput(): cdktn.IResolvable | MonitorV2RulesPromoteCompareColumnsCompareValues[] | undefined;
}
export declare class MonitorV2RulesPromoteCompareColumnsList extends cdktn.ComplexList {
    internalValue?: MonitorV2RulesPromoteCompareColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2RulesPromoteCompareColumnsOutputReference;
}
export interface MonitorV2RulesPromote {
    /**
    * compare_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_columns MonitorV2#compare_columns}
    */
    readonly compareColumns?: MonitorV2RulesPromoteCompareColumns[] | cdktn.IResolvable;
}
export declare function monitorV2RulesPromoteToTerraform(struct?: MonitorV2RulesPromoteOutputReference | MonitorV2RulesPromote): any;
export declare function monitorV2RulesPromoteToHclTerraform(struct?: MonitorV2RulesPromoteOutputReference | MonitorV2RulesPromote): any;
export declare class MonitorV2RulesPromoteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesPromote | undefined;
    set internalValue(value: MonitorV2RulesPromote | undefined);
    private _compareColumns;
    get compareColumns(): MonitorV2RulesPromoteCompareColumnsList;
    putCompareColumns(value: MonitorV2RulesPromoteCompareColumns[] | cdktn.IResolvable): void;
    resetCompareColumns(): void;
    get compareColumnsInput(): cdktn.IResolvable | MonitorV2RulesPromoteCompareColumns[] | undefined;
}
export interface MonitorV2RulesThresholdCompareGroupsColumnColumnPath {
    /**
    * The name of the column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
    /**
    * The path of the path, if the name refers to a column with a JSON object.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#path MonitorV2#path}
    */
    readonly path?: string;
}
export declare function monitorV2RulesThresholdCompareGroupsColumnColumnPathToTerraform(struct?: MonitorV2RulesThresholdCompareGroupsColumnColumnPathOutputReference | MonitorV2RulesThresholdCompareGroupsColumnColumnPath): any;
export declare function monitorV2RulesThresholdCompareGroupsColumnColumnPathToHclTerraform(struct?: MonitorV2RulesThresholdCompareGroupsColumnColumnPathOutputReference | MonitorV2RulesThresholdCompareGroupsColumnColumnPath): any;
export declare class MonitorV2RulesThresholdCompareGroupsColumnColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesThresholdCompareGroupsColumnColumnPath | undefined;
    set internalValue(value: MonitorV2RulesThresholdCompareGroupsColumnColumnPath | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface MonitorV2RulesThresholdCompareGroupsColumnLinkColumn {
    /**
    * The name of the link column.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#name MonitorV2#name}
    */
    readonly name: string;
}
export declare function monitorV2RulesThresholdCompareGroupsColumnLinkColumnToTerraform(struct?: MonitorV2RulesThresholdCompareGroupsColumnLinkColumnOutputReference | MonitorV2RulesThresholdCompareGroupsColumnLinkColumn): any;
export declare function monitorV2RulesThresholdCompareGroupsColumnLinkColumnToHclTerraform(struct?: MonitorV2RulesThresholdCompareGroupsColumnLinkColumnOutputReference | MonitorV2RulesThresholdCompareGroupsColumnLinkColumn): any;
export declare class MonitorV2RulesThresholdCompareGroupsColumnLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesThresholdCompareGroupsColumnLinkColumn | undefined;
    set internalValue(value: MonitorV2RulesThresholdCompareGroupsColumnLinkColumn | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface MonitorV2RulesThresholdCompareGroupsColumn {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column_path MonitorV2#column_path}
    */
    readonly columnPath?: MonitorV2RulesThresholdCompareGroupsColumnColumnPath;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#link_column MonitorV2#link_column}
    */
    readonly linkColumn?: MonitorV2RulesThresholdCompareGroupsColumnLinkColumn;
}
export declare function monitorV2RulesThresholdCompareGroupsColumnToTerraform(struct?: MonitorV2RulesThresholdCompareGroupsColumnOutputReference | MonitorV2RulesThresholdCompareGroupsColumn): any;
export declare function monitorV2RulesThresholdCompareGroupsColumnToHclTerraform(struct?: MonitorV2RulesThresholdCompareGroupsColumnOutputReference | MonitorV2RulesThresholdCompareGroupsColumn): any;
export declare class MonitorV2RulesThresholdCompareGroupsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesThresholdCompareGroupsColumn | undefined;
    set internalValue(value: MonitorV2RulesThresholdCompareGroupsColumn | undefined);
    private _columnPath;
    get columnPath(): MonitorV2RulesThresholdCompareGroupsColumnColumnPathOutputReference;
    putColumnPath(value: MonitorV2RulesThresholdCompareGroupsColumnColumnPath): void;
    resetColumnPath(): void;
    get columnPathInput(): MonitorV2RulesThresholdCompareGroupsColumnColumnPath | undefined;
    private _linkColumn;
    get linkColumn(): MonitorV2RulesThresholdCompareGroupsColumnLinkColumnOutputReference;
    putLinkColumn(value: MonitorV2RulesThresholdCompareGroupsColumnLinkColumn): void;
    resetLinkColumn(): void;
    get linkColumnInput(): MonitorV2RulesThresholdCompareGroupsColumnLinkColumn | undefined;
}
export interface MonitorV2RulesThresholdCompareGroupsCompareValues {
    /**
    * the type of comparison (greater, less, equal, etc.)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_fn MonitorV2#compare_fn}
    */
    readonly compareFn: string;
    /**
    * list of size <=1 consisting of a boolean value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_bool MonitorV2#value_bool}
    */
    readonly valueBool?: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    /**
    * list of size <=1 consisting of a duration value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_duration MonitorV2#value_duration}
    */
    readonly valueDuration?: string[];
    /**
    * list of size <=1 consisting of a float value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_float64 MonitorV2#value_float64}
    */
    readonly valueFloat64?: number[];
    /**
    * list of size <=1 consisting of an integer value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_int64 MonitorV2#value_int64}
    */
    readonly valueInt64?: number[];
    /**
    * list of size <=1 consisting of a string value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_string MonitorV2#value_string}
    */
    readonly valueString?: string[];
    /**
    * list of size <=1 consisting of a timestamp value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_timestamp MonitorV2#value_timestamp}
    */
    readonly valueTimestamp?: string[];
}
export declare function monitorV2RulesThresholdCompareGroupsCompareValuesToTerraform(struct?: MonitorV2RulesThresholdCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare function monitorV2RulesThresholdCompareGroupsCompareValuesToHclTerraform(struct?: MonitorV2RulesThresholdCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare class MonitorV2RulesThresholdCompareGroupsCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2RulesThresholdCompareGroupsCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2RulesThresholdCompareGroupsCompareValues | cdktn.IResolvable | undefined);
    private _compareFn?;
    get compareFn(): string;
    set compareFn(value: string);
    get compareFnInput(): string | undefined;
    private _valueBool?;
    get valueBool(): Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    set valueBool(value: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable);
    resetValueBool(): void;
    get valueBoolInput(): cdktn.IResolvable | (boolean | cdktn.IResolvable)[] | undefined;
    private _valueDuration?;
    get valueDuration(): string[];
    set valueDuration(value: string[]);
    resetValueDuration(): void;
    get valueDurationInput(): string[] | undefined;
    private _valueFloat64?;
    get valueFloat64(): number[];
    set valueFloat64(value: number[]);
    resetValueFloat64(): void;
    get valueFloat64Input(): number[] | undefined;
    private _valueInt64?;
    get valueInt64(): number[];
    set valueInt64(value: number[]);
    resetValueInt64(): void;
    get valueInt64Input(): number[] | undefined;
    private _valueString?;
    get valueString(): string[];
    set valueString(value: string[]);
    resetValueString(): void;
    get valueStringInput(): string[] | undefined;
    private _valueTimestamp?;
    get valueTimestamp(): string[];
    set valueTimestamp(value: string[]);
    resetValueTimestamp(): void;
    get valueTimestampInput(): string[] | undefined;
}
export declare class MonitorV2RulesThresholdCompareGroupsCompareValuesList extends cdktn.ComplexList {
    internalValue?: MonitorV2RulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2RulesThresholdCompareGroupsCompareValuesOutputReference;
}
export interface MonitorV2RulesThresholdCompareGroups {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#column MonitorV2#column}
    */
    readonly column: MonitorV2RulesThresholdCompareGroupsColumn;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_values MonitorV2#compare_values}
    */
    readonly compareValues: MonitorV2RulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable;
}
export declare function monitorV2RulesThresholdCompareGroupsToTerraform(struct?: MonitorV2RulesThresholdCompareGroups | cdktn.IResolvable): any;
export declare function monitorV2RulesThresholdCompareGroupsToHclTerraform(struct?: MonitorV2RulesThresholdCompareGroups | cdktn.IResolvable): any;
export declare class MonitorV2RulesThresholdCompareGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2RulesThresholdCompareGroups | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2RulesThresholdCompareGroups | cdktn.IResolvable | undefined);
    private _column;
    get column(): MonitorV2RulesThresholdCompareGroupsColumnOutputReference;
    putColumn(value: MonitorV2RulesThresholdCompareGroupsColumn): void;
    get columnInput(): MonitorV2RulesThresholdCompareGroupsColumn | undefined;
    private _compareValues;
    get compareValues(): MonitorV2RulesThresholdCompareGroupsCompareValuesList;
    putCompareValues(value: MonitorV2RulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable): void;
    get compareValuesInput(): cdktn.IResolvable | MonitorV2RulesThresholdCompareGroupsCompareValues[] | undefined;
}
export declare class MonitorV2RulesThresholdCompareGroupsList extends cdktn.ComplexList {
    internalValue?: MonitorV2RulesThresholdCompareGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2RulesThresholdCompareGroupsOutputReference;
}
export interface MonitorV2RulesThresholdCompareValues {
    /**
    * the type of comparison (greater, less, equal, etc.)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_fn MonitorV2#compare_fn}
    */
    readonly compareFn: string;
    /**
    * list of size <=1 consisting of a boolean value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_bool MonitorV2#value_bool}
    */
    readonly valueBool?: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    /**
    * list of size <=1 consisting of a duration value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_duration MonitorV2#value_duration}
    */
    readonly valueDuration?: string[];
    /**
    * list of size <=1 consisting of a float value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_float64 MonitorV2#value_float64}
    */
    readonly valueFloat64?: number[];
    /**
    * list of size <=1 consisting of an integer value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_int64 MonitorV2#value_int64}
    */
    readonly valueInt64?: number[];
    /**
    * list of size <=1 consisting of a string value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_string MonitorV2#value_string}
    */
    readonly valueString?: string[];
    /**
    * list of size <=1 consisting of a timestamp value.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_timestamp MonitorV2#value_timestamp}
    */
    readonly valueTimestamp?: string[];
}
export declare function monitorV2RulesThresholdCompareValuesToTerraform(struct?: MonitorV2RulesThresholdCompareValues | cdktn.IResolvable): any;
export declare function monitorV2RulesThresholdCompareValuesToHclTerraform(struct?: MonitorV2RulesThresholdCompareValues | cdktn.IResolvable): any;
export declare class MonitorV2RulesThresholdCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2RulesThresholdCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2RulesThresholdCompareValues | cdktn.IResolvable | undefined);
    private _compareFn?;
    get compareFn(): string;
    set compareFn(value: string);
    get compareFnInput(): string | undefined;
    private _valueBool?;
    get valueBool(): Array<boolean | cdktn.IResolvable> | cdktn.IResolvable;
    set valueBool(value: Array<boolean | cdktn.IResolvable> | cdktn.IResolvable);
    resetValueBool(): void;
    get valueBoolInput(): cdktn.IResolvable | (boolean | cdktn.IResolvable)[] | undefined;
    private _valueDuration?;
    get valueDuration(): string[];
    set valueDuration(value: string[]);
    resetValueDuration(): void;
    get valueDurationInput(): string[] | undefined;
    private _valueFloat64?;
    get valueFloat64(): number[];
    set valueFloat64(value: number[]);
    resetValueFloat64(): void;
    get valueFloat64Input(): number[] | undefined;
    private _valueInt64?;
    get valueInt64(): number[];
    set valueInt64(value: number[]);
    resetValueInt64(): void;
    get valueInt64Input(): number[] | undefined;
    private _valueString?;
    get valueString(): string[];
    set valueString(value: string[]);
    resetValueString(): void;
    get valueStringInput(): string[] | undefined;
    private _valueTimestamp?;
    get valueTimestamp(): string[];
    set valueTimestamp(value: string[]);
    resetValueTimestamp(): void;
    get valueTimestampInput(): string[] | undefined;
}
export declare class MonitorV2RulesThresholdCompareValuesList extends cdktn.ComplexList {
    internalValue?: MonitorV2RulesThresholdCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2RulesThresholdCompareValuesOutputReference;
}
export interface MonitorV2RulesThreshold {
    /**
    * The query aggregator (AllOf, AnyOf, AvgOf, Max, Min, SumOf) for the value monitor type.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#aggregation MonitorV2#aggregation}
    */
    readonly aggregation: string;
    /**
    * Indicates which column in the input query has the value to apply the aggregation.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#value_column_name MonitorV2#value_column_name}
    */
    readonly valueColumnName: string;
    /**
    * compare_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_groups MonitorV2#compare_groups}
    */
    readonly compareGroups?: MonitorV2RulesThresholdCompareGroups[] | cdktn.IResolvable;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#compare_values MonitorV2#compare_values}
    */
    readonly compareValues?: MonitorV2RulesThresholdCompareValues[] | cdktn.IResolvable;
}
export declare function monitorV2RulesThresholdToTerraform(struct?: MonitorV2RulesThresholdOutputReference | MonitorV2RulesThreshold): any;
export declare function monitorV2RulesThresholdToHclTerraform(struct?: MonitorV2RulesThresholdOutputReference | MonitorV2RulesThreshold): any;
export declare class MonitorV2RulesThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2RulesThreshold | undefined;
    set internalValue(value: MonitorV2RulesThreshold | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _valueColumnName?;
    get valueColumnName(): string;
    set valueColumnName(value: string);
    get valueColumnNameInput(): string | undefined;
    private _compareGroups;
    get compareGroups(): MonitorV2RulesThresholdCompareGroupsList;
    putCompareGroups(value: MonitorV2RulesThresholdCompareGroups[] | cdktn.IResolvable): void;
    resetCompareGroups(): void;
    get compareGroupsInput(): cdktn.IResolvable | MonitorV2RulesThresholdCompareGroups[] | undefined;
    private _compareValues;
    get compareValues(): MonitorV2RulesThresholdCompareValuesList;
    putCompareValues(value: MonitorV2RulesThresholdCompareValues[] | cdktn.IResolvable): void;
    resetCompareValues(): void;
    get compareValuesInput(): cdktn.IResolvable | MonitorV2RulesThresholdCompareValues[] | undefined;
}
export interface MonitorV2Rules {
    /**
    * The alarm level (Critical, Error, Informational, None, Warning).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#level MonitorV2#level}
    */
    readonly level: string;
    /**
    * count block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#count MonitorV2#count}
    */
    readonly count?: MonitorV2RulesCount;
    /**
    * promote block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#promote MonitorV2#promote}
    */
    readonly promote?: MonitorV2RulesPromote;
    /**
    * threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#threshold MonitorV2#threshold}
    */
    readonly threshold?: MonitorV2RulesThreshold;
}
export declare function monitorV2RulesToTerraform(struct?: MonitorV2Rules | cdktn.IResolvable): any;
export declare function monitorV2RulesToHclTerraform(struct?: MonitorV2Rules | cdktn.IResolvable): any;
export declare class MonitorV2RulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2Rules | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2Rules | cdktn.IResolvable | undefined);
    private _level?;
    get level(): string;
    set level(value: string);
    get levelInput(): string | undefined;
    private _count;
    get count(): MonitorV2RulesCountOutputReference;
    putCount(value: MonitorV2RulesCount): void;
    resetCount(): void;
    get countInput(): MonitorV2RulesCount | undefined;
    private _promote;
    get promote(): MonitorV2RulesPromoteOutputReference;
    putPromote(value: MonitorV2RulesPromote): void;
    resetPromote(): void;
    get promoteInput(): MonitorV2RulesPromote | undefined;
    private _threshold;
    get threshold(): MonitorV2RulesThresholdOutputReference;
    putThreshold(value: MonitorV2RulesThreshold): void;
    resetThreshold(): void;
    get thresholdInput(): MonitorV2RulesThreshold | undefined;
}
export declare class MonitorV2RulesList extends cdktn.ComplexList {
    internalValue?: MonitorV2Rules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2RulesOutputReference;
}
export interface MonitorV2SchedulingInterval {
    /**
    * How often the monitor should attempt to run.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#interval MonitorV2#interval}
    */
    readonly interval: string;
    /**
    * A maximum +/- to apply to the interval to avoid things like harmonics and work stacking up in parallel.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#randomize MonitorV2#randomize}
    */
    readonly randomize: string;
}
export declare function monitorV2SchedulingIntervalToTerraform(struct?: MonitorV2SchedulingIntervalOutputReference | MonitorV2SchedulingInterval): any;
export declare function monitorV2SchedulingIntervalToHclTerraform(struct?: MonitorV2SchedulingIntervalOutputReference | MonitorV2SchedulingInterval): any;
export declare class MonitorV2SchedulingIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2SchedulingInterval | undefined;
    set internalValue(value: MonitorV2SchedulingInterval | undefined);
    private _interval?;
    get interval(): string;
    set interval(value: string);
    get intervalInput(): string | undefined;
    private _randomize?;
    get randomize(): string;
    set randomize(value: string);
    get randomizeInput(): string | undefined;
}
export interface MonitorV2SchedulingScheduled {
    /**
    * If specified, the raw cron is a crontab configuration to use to drive the scheduling.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#raw_cron MonitorV2#raw_cron}
    */
    readonly rawCron?: string;
    /**
    * A timezone is required to ensure that interpretation of scheduling on the wall-clock
    * is done relative to the desired timezone.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#timezone MonitorV2#timezone}
    */
    readonly timezone: string;
}
export declare function monitorV2SchedulingScheduledToTerraform(struct?: MonitorV2SchedulingScheduledOutputReference | MonitorV2SchedulingScheduled): any;
export declare function monitorV2SchedulingScheduledToHclTerraform(struct?: MonitorV2SchedulingScheduledOutputReference | MonitorV2SchedulingScheduled): any;
export declare class MonitorV2SchedulingScheduledOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2SchedulingScheduled | undefined;
    set internalValue(value: MonitorV2SchedulingScheduled | undefined);
    private _rawCron?;
    get rawCron(): string;
    set rawCron(value: string);
    resetRawCron(): void;
    get rawCronInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    get timezoneInput(): string | undefined;
}
export interface MonitorV2SchedulingTransform {
    /**
    * The freshness goal.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#freshness_goal MonitorV2#freshness_goal}
    */
    readonly freshnessGoal: string;
}
export declare function monitorV2SchedulingTransformToTerraform(struct?: MonitorV2SchedulingTransformOutputReference | MonitorV2SchedulingTransform): any;
export declare function monitorV2SchedulingTransformToHclTerraform(struct?: MonitorV2SchedulingTransformOutputReference | MonitorV2SchedulingTransform): any;
export declare class MonitorV2SchedulingTransformOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2SchedulingTransform | undefined;
    set internalValue(value: MonitorV2SchedulingTransform | undefined);
    private _freshnessGoal?;
    get freshnessGoal(): string;
    set freshnessGoal(value: string);
    get freshnessGoalInput(): string | undefined;
}
export interface MonitorV2Scheduling {
    /**
    * interval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#interval MonitorV2#interval}
    */
    readonly interval?: MonitorV2SchedulingInterval;
    /**
    * scheduled block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#scheduled MonitorV2#scheduled}
    */
    readonly scheduled?: MonitorV2SchedulingScheduled;
    /**
    * transform block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#transform MonitorV2#transform}
    */
    readonly transform?: MonitorV2SchedulingTransform;
}
export declare function monitorV2SchedulingToTerraform(struct?: MonitorV2SchedulingOutputReference | MonitorV2Scheduling): any;
export declare function monitorV2SchedulingToHclTerraform(struct?: MonitorV2SchedulingOutputReference | MonitorV2Scheduling): any;
export declare class MonitorV2SchedulingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorV2Scheduling | undefined;
    set internalValue(value: MonitorV2Scheduling | undefined);
    private _interval;
    get interval(): MonitorV2SchedulingIntervalOutputReference;
    putInterval(value: MonitorV2SchedulingInterval): void;
    resetInterval(): void;
    get intervalInput(): MonitorV2SchedulingInterval | undefined;
    private _scheduled;
    get scheduled(): MonitorV2SchedulingScheduledOutputReference;
    putScheduled(value: MonitorV2SchedulingScheduled): void;
    resetScheduled(): void;
    get scheduledInput(): MonitorV2SchedulingScheduled | undefined;
    private _transform;
    get transform(): MonitorV2SchedulingTransformOutputReference;
    putTransform(value: MonitorV2SchedulingTransform): void;
    resetTransform(): void;
    get transformInput(): MonitorV2SchedulingTransform | undefined;
}
export interface MonitorV2Stage {
    /**
    * The stage alias is the label by which subsequent stages can refer to the
    * results of this stage.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#alias MonitorV2#alias}
    */
    readonly alias?: string;
    /**
    * The stage input defines what input should be used as a starting point for
    * the stage pipeline. It must refer to a label contained in `inputs`, or a
    * previous stage `alias`. The stage input can be omitted if `inputs`
    * contains a single element.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#input MonitorV2#input}
    */
    readonly input?: string;
    /**
    * A boolean flag used to specify the output stage. Should be used only for
    * a stage preceding the last stage. The last stage is an output stage by default.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#output_stage MonitorV2#output_stage}
    */
    readonly outputStage?: boolean | cdktn.IResolvable;
    /**
    * An OPAL snippet defining a transformation on the selected input.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#pipeline MonitorV2#pipeline}
    */
    readonly pipeline?: string;
}
export declare function monitorV2StageToTerraform(struct?: MonitorV2Stage | cdktn.IResolvable): any;
export declare function monitorV2StageToHclTerraform(struct?: MonitorV2Stage | cdktn.IResolvable): any;
export declare class MonitorV2StageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorV2Stage | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorV2Stage | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    resetInput(): void;
    get inputInput(): string | undefined;
    private _outputStage?;
    get outputStage(): boolean | cdktn.IResolvable;
    set outputStage(value: boolean | cdktn.IResolvable);
    resetOutputStage(): void;
    get outputStageInput(): boolean | cdktn.IResolvable | undefined;
    private _pipeline?;
    get pipeline(): string;
    set pipeline(value: string);
    resetPipeline(): void;
    get pipelineInput(): string | undefined;
}
export declare class MonitorV2StageList extends cdktn.ComplexList {
    internalValue?: MonitorV2Stage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorV2StageOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2 observe_monitor_v2}
*/
export declare class MonitorV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_monitor_v2";
    /**
    * Generates CDKTN code for importing a MonitorV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MonitorV2 to import
    * @param importFromId The id of the existing MonitorV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MonitorV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/monitor_v2 observe_monitor_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MonitorV2Config
    */
    constructor(scope: Construct, id: string, config: MonitorV2Config);
    private _customVariables?;
    get customVariables(): string;
    set customVariables(value: string);
    resetCustomVariables(): void;
    get customVariablesInput(): string | undefined;
    private _dataStabilizationDelay?;
    get dataStabilizationDelay(): string;
    set dataStabilizationDelay(value: string);
    resetDataStabilizationDelay(): void;
    get dataStabilizationDelayInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _iconUrl?;
    get iconUrl(): string;
    set iconUrl(value: string);
    resetIconUrl(): void;
    get iconUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputs?;
    get inputs(): {
        [key: string]: string;
    };
    set inputs(value: {
        [key: string]: string;
    });
    get inputsInput(): {
        [key: string]: string;
    } | undefined;
    private _lookbackTime?;
    get lookbackTime(): string;
    set lookbackTime(value: string);
    resetLookbackTime(): void;
    get lookbackTimeInput(): string | undefined;
    private _maxAlertsPerHour?;
    get maxAlertsPerHour(): number;
    set maxAlertsPerHour(value: number);
    resetMaxAlertsPerHour(): void;
    get maxAlertsPerHourInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _ruleKind?;
    get ruleKind(): string;
    set ruleKind(value: string);
    get ruleKindInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _actions;
    get actions(): MonitorV2ActionsList;
    putActions(value: MonitorV2Actions[] | cdktn.IResolvable): void;
    resetActions(): void;
    get actionsInput(): cdktn.IResolvable | MonitorV2Actions[] | undefined;
    private _groupings;
    get groupings(): MonitorV2GroupingsList;
    putGroupings(value: MonitorV2Groupings[] | cdktn.IResolvable): void;
    resetGroupings(): void;
    get groupingsInput(): cdktn.IResolvable | MonitorV2Groupings[] | undefined;
    private _noDataRules;
    get noDataRules(): MonitorV2NoDataRulesOutputReference;
    putNoDataRules(value: MonitorV2NoDataRules): void;
    resetNoDataRules(): void;
    get noDataRulesInput(): MonitorV2NoDataRules | undefined;
    private _rules;
    get rules(): MonitorV2RulesList;
    putRules(value: MonitorV2Rules[] | cdktn.IResolvable): void;
    get rulesInput(): cdktn.IResolvable | MonitorV2Rules[] | undefined;
    private _scheduling;
    get scheduling(): MonitorV2SchedulingOutputReference;
    putScheduling(value: MonitorV2Scheduling): void;
    resetScheduling(): void;
    get schedulingInput(): MonitorV2Scheduling | undefined;
    private _stage;
    get stage(): MonitorV2StageList;
    putStage(value: MonitorV2Stage[] | cdktn.IResolvable): void;
    get stageInput(): cdktn.IResolvable | MonitorV2Stage[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
