import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataObserveAppVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/app_version#id DataObserveAppVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to include prerelease versions in the version search. Defaults to false (don't include).
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/app_version#include_prerelease DataObserveAppVersion#include_prerelease}
    */
    readonly includePrerelease?: boolean | cdktn.IResolvable;
    /**
    * The app module name.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/app_version#module_id DataObserveAppVersion#module_id}
    */
    readonly moduleId: string;
    /**
    * The version constraint rules which are used to find the newest acceptable version.  Multiple constraints should be comma separated.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/app_version#version_constraint DataObserveAppVersion#version_constraint}
    */
    readonly versionConstraint: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/app_version observe_app_version}
*/
export declare class DataObserveAppVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "observe_app_version";
    /**
    * Generates CDKTN code for importing a DataObserveAppVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveAppVersion to import
    * @param importFromId The id of the existing DataObserveAppVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/app_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveAppVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/app_version observe_app_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveAppVersionConfig
    */
    constructor(scope: Construct, id: string, config: DataObserveAppVersionConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includePrerelease?;
    get includePrerelease(): boolean | cdktn.IResolvable;
    set includePrerelease(value: boolean | cdktn.IResolvable);
    resetIncludePrerelease(): void;
    get includePrereleaseInput(): boolean | cdktn.IResolvable | undefined;
    private _moduleId?;
    get moduleId(): string;
    set moduleId(value: string);
    get moduleIdInput(): string | undefined;
    get version(): string;
    private _versionConstraint?;
    get versionConstraint(): string;
    set versionConstraint(value: string);
    get versionConstraintInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
