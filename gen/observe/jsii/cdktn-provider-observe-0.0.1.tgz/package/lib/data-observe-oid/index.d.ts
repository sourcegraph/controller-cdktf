import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataObserveOidConfig extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID for this object.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/oid#id DataObserveOid#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * OID (Observe ID) for this object. This is the canonical identifier that
    * should be used when referring to this object in terraform manifests.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/oid#oid DataObserveOid#oid}
    */
    readonly oid?: string;
    /**
    * Resource type for this object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/oid#type DataObserveOid#type}
    */
    readonly type?: string;
    /**
    * Resource version for this object.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/oid#version DataObserveOid#version}
    */
    readonly version?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/oid observe_oid}
*/
export declare class DataObserveOid extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "observe_oid";
    /**
    * Generates CDKTN code for importing a DataObserveOid resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveOid to import
    * @param importFromId The id of the existing DataObserveOid that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/oid#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveOid to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/oid observe_oid} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveOidConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveOidConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _oid?;
    get oid(): string;
    set oid(value: string);
    resetOid(): void;
    get oidInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
