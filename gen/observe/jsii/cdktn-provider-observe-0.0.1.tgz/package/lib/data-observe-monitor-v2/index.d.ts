import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataObserveMonitorV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID for this object.
    * One of `name` or `id` must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#id DataObserveMonitorV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Monitor name.
    * One of `name` or `id` must be set. If `name` is provided, `workspace` must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#name DataObserveMonitorV2#name}
    */
    readonly name?: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#workspace DataObserveMonitorV2#workspace}
    */
    readonly workspace?: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#actions DataObserveMonitorV2#actions}
    */
    readonly actions?: DataObserveMonitorV2Actions[] | cdktn.IResolvable;
    /**
    * groupings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#groupings DataObserveMonitorV2#groupings}
    */
    readonly groupings?: DataObserveMonitorV2Groupings[] | cdktn.IResolvable;
    /**
    * no_data_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#no_data_rules DataObserveMonitorV2#no_data_rules}
    */
    readonly noDataRules?: DataObserveMonitorV2NoDataRules[] | cdktn.IResolvable;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#rules DataObserveMonitorV2#rules}
    */
    readonly rules?: DataObserveMonitorV2Rules[] | cdktn.IResolvable;
    /**
    * scheduling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#scheduling DataObserveMonitorV2#scheduling}
    */
    readonly scheduling?: DataObserveMonitorV2Scheduling[] | cdktn.IResolvable;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#stage DataObserveMonitorV2#stage}
    */
    readonly stage?: DataObserveMonitorV2Stage[] | cdktn.IResolvable;
}
export interface DataObserveMonitorV2ActionsActionEmail {
}
export declare function dataObserveMonitorV2ActionsActionEmailToTerraform(struct?: DataObserveMonitorV2ActionsActionEmail | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsActionEmailToHclTerraform(struct?: DataObserveMonitorV2ActionsActionEmail | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsActionEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionsActionEmail | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionsActionEmail | cdktn.IResolvable | undefined);
    get addresses(): string[];
    get body(): string;
    get fragments(): string;
    get subject(): string;
    get users(): string[];
}
export declare class DataObserveMonitorV2ActionsActionEmailList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionsActionEmail[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsActionEmailOutputReference;
}
export interface DataObserveMonitorV2ActionsActionWebhookHeaders {
}
export declare function dataObserveMonitorV2ActionsActionWebhookHeadersToTerraform(struct?: DataObserveMonitorV2ActionsActionWebhookHeaders | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsActionWebhookHeadersToHclTerraform(struct?: DataObserveMonitorV2ActionsActionWebhookHeaders | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsActionWebhookHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionsActionWebhookHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionsActionWebhookHeaders | cdktn.IResolvable | undefined);
    get header(): string;
    get value(): string;
}
export declare class DataObserveMonitorV2ActionsActionWebhookHeadersList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionsActionWebhookHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsActionWebhookHeadersOutputReference;
}
export interface DataObserveMonitorV2ActionsActionWebhook {
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#headers DataObserveMonitorV2#headers}
    */
    readonly headers?: DataObserveMonitorV2ActionsActionWebhookHeaders[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2ActionsActionWebhookToTerraform(struct?: DataObserveMonitorV2ActionsActionWebhook | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsActionWebhookToHclTerraform(struct?: DataObserveMonitorV2ActionsActionWebhook | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsActionWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionsActionWebhook | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionsActionWebhook | cdktn.IResolvable | undefined);
    get body(): string;
    get fragments(): string;
    get method(): string;
    get url(): string;
    private _headers;
    get headers(): DataObserveMonitorV2ActionsActionWebhookHeadersList;
    putHeaders(value: DataObserveMonitorV2ActionsActionWebhookHeaders[] | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | DataObserveMonitorV2ActionsActionWebhookHeaders[] | undefined;
}
export declare class DataObserveMonitorV2ActionsActionWebhookList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionsActionWebhook[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsActionWebhookOutputReference;
}
export interface DataObserveMonitorV2ActionsAction {
    /**
    * email block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#email DataObserveMonitorV2#email}
    */
    readonly email?: DataObserveMonitorV2ActionsActionEmail[] | cdktn.IResolvable;
    /**
    * webhook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#webhook DataObserveMonitorV2#webhook}
    */
    readonly webhook?: DataObserveMonitorV2ActionsActionWebhook[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2ActionsActionToTerraform(struct?: DataObserveMonitorV2ActionsAction | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsActionToHclTerraform(struct?: DataObserveMonitorV2ActionsAction | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionsAction | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionsAction | cdktn.IResolvable | undefined);
    get description(): string;
    get type(): string;
    private _email;
    get email(): DataObserveMonitorV2ActionsActionEmailList;
    putEmail(value: DataObserveMonitorV2ActionsActionEmail[] | cdktn.IResolvable): void;
    resetEmail(): void;
    get emailInput(): cdktn.IResolvable | DataObserveMonitorV2ActionsActionEmail[] | undefined;
    private _webhook;
    get webhook(): DataObserveMonitorV2ActionsActionWebhookList;
    putWebhook(value: DataObserveMonitorV2ActionsActionWebhook[] | cdktn.IResolvable): void;
    resetWebhook(): void;
    get webhookInput(): cdktn.IResolvable | DataObserveMonitorV2ActionsActionWebhook[] | undefined;
}
export declare class DataObserveMonitorV2ActionsActionList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionsAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsActionOutputReference;
}
export interface DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPath {
}
export declare function dataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPathToTerraform(struct?: DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPath | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPathToHclTerraform(struct?: DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPath | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPath | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPath | cdktn.IResolvable | undefined);
    get name(): string;
    get path(): string;
}
export declare class DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPathList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPathOutputReference;
}
export interface DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumn {
}
export declare function dataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumnToTerraform(struct?: DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumnToHclTerraform(struct?: DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumn | cdktn.IResolvable | undefined);
    get name(): string;
}
export declare class DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumnOutputReference;
}
export interface DataObserveMonitorV2ActionsConditionsCompareTermsColumn {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column_path DataObserveMonitorV2#column_path}
    */
    readonly columnPath?: DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPath[] | cdktn.IResolvable;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#link_column DataObserveMonitorV2#link_column}
    */
    readonly linkColumn?: DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumn[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2ActionsConditionsCompareTermsColumnToTerraform(struct?: DataObserveMonitorV2ActionsConditionsCompareTermsColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsConditionsCompareTermsColumnToHclTerraform(struct?: DataObserveMonitorV2ActionsConditionsCompareTermsColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsConditionsCompareTermsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionsConditionsCompareTermsColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionsConditionsCompareTermsColumn | cdktn.IResolvable | undefined);
    private _columnPath;
    get columnPath(): DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPathList;
    putColumnPath(value: DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPath[] | cdktn.IResolvable): void;
    resetColumnPath(): void;
    get columnPathInput(): cdktn.IResolvable | DataObserveMonitorV2ActionsConditionsCompareTermsColumnColumnPath[] | undefined;
    private _linkColumn;
    get linkColumn(): DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumnList;
    putLinkColumn(value: DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumn[] | cdktn.IResolvable): void;
    resetLinkColumn(): void;
    get linkColumnInput(): cdktn.IResolvable | DataObserveMonitorV2ActionsConditionsCompareTermsColumnLinkColumn[] | undefined;
}
export declare class DataObserveMonitorV2ActionsConditionsCompareTermsColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionsConditionsCompareTermsColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsConditionsCompareTermsColumnOutputReference;
}
export interface DataObserveMonitorV2ActionsConditionsCompareTermsComparison {
}
export declare function dataObserveMonitorV2ActionsConditionsCompareTermsComparisonToTerraform(struct?: DataObserveMonitorV2ActionsConditionsCompareTermsComparison | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsConditionsCompareTermsComparisonToHclTerraform(struct?: DataObserveMonitorV2ActionsConditionsCompareTermsComparison | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsConditionsCompareTermsComparisonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionsConditionsCompareTermsComparison | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionsConditionsCompareTermsComparison | cdktn.IResolvable | undefined);
    get compareFn(): string;
    private _valueBool;
    get valueBool(): cdktn.BooleanList;
    get valueDuration(): string[];
    get valueFloat64(): number[];
    get valueInt64(): number[];
    get valueString(): string[];
    get valueTimestamp(): string[];
}
export declare class DataObserveMonitorV2ActionsConditionsCompareTermsComparisonList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionsConditionsCompareTermsComparison[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsConditionsCompareTermsComparisonOutputReference;
}
export interface DataObserveMonitorV2ActionsConditionsCompareTerms {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column DataObserveMonitorV2#column}
    */
    readonly column?: DataObserveMonitorV2ActionsConditionsCompareTermsColumn[] | cdktn.IResolvable;
    /**
    * comparison block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#comparison DataObserveMonitorV2#comparison}
    */
    readonly comparison?: DataObserveMonitorV2ActionsConditionsCompareTermsComparison[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2ActionsConditionsCompareTermsToTerraform(struct?: DataObserveMonitorV2ActionsConditionsCompareTerms | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsConditionsCompareTermsToHclTerraform(struct?: DataObserveMonitorV2ActionsConditionsCompareTerms | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsConditionsCompareTermsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionsConditionsCompareTerms | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionsConditionsCompareTerms | cdktn.IResolvable | undefined);
    private _column;
    get column(): DataObserveMonitorV2ActionsConditionsCompareTermsColumnList;
    putColumn(value: DataObserveMonitorV2ActionsConditionsCompareTermsColumn[] | cdktn.IResolvable): void;
    resetColumn(): void;
    get columnInput(): cdktn.IResolvable | DataObserveMonitorV2ActionsConditionsCompareTermsColumn[] | undefined;
    private _comparison;
    get comparison(): DataObserveMonitorV2ActionsConditionsCompareTermsComparisonList;
    putComparison(value: DataObserveMonitorV2ActionsConditionsCompareTermsComparison[] | cdktn.IResolvable): void;
    resetComparison(): void;
    get comparisonInput(): cdktn.IResolvable | DataObserveMonitorV2ActionsConditionsCompareTermsComparison[] | undefined;
}
export declare class DataObserveMonitorV2ActionsConditionsCompareTermsList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionsConditionsCompareTerms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsConditionsCompareTermsOutputReference;
}
export interface DataObserveMonitorV2ActionsConditions {
    /**
    * compare_terms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_terms DataObserveMonitorV2#compare_terms}
    */
    readonly compareTerms?: DataObserveMonitorV2ActionsConditionsCompareTerms[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2ActionsConditionsToTerraform(struct?: DataObserveMonitorV2ActionsConditions | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsConditionsToHclTerraform(struct?: DataObserveMonitorV2ActionsConditions | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionsConditions | cdktn.IResolvable | undefined);
    get operator(): string;
    private _compareTerms;
    get compareTerms(): DataObserveMonitorV2ActionsConditionsCompareTermsList;
    putCompareTerms(value: DataObserveMonitorV2ActionsConditionsCompareTerms[] | cdktn.IResolvable): void;
    resetCompareTerms(): void;
    get compareTermsInput(): cdktn.IResolvable | DataObserveMonitorV2ActionsConditionsCompareTerms[] | undefined;
}
export declare class DataObserveMonitorV2ActionsConditionsList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsConditionsOutputReference;
}
export interface DataObserveMonitorV2Actions {
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#action DataObserveMonitorV2#action}
    */
    readonly action?: DataObserveMonitorV2ActionsAction[] | cdktn.IResolvable;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#conditions DataObserveMonitorV2#conditions}
    */
    readonly conditions?: DataObserveMonitorV2ActionsConditions[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2ActionsToTerraform(struct?: DataObserveMonitorV2Actions | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionsToHclTerraform(struct?: DataObserveMonitorV2Actions | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2Actions | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2Actions | cdktn.IResolvable | undefined);
    get levels(): string[];
    get oid(): string;
    get sendEndNotifications(): cdktn.IResolvable;
    get sendRemindersInterval(): string;
    private _action;
    get action(): DataObserveMonitorV2ActionsActionList;
    putAction(value: DataObserveMonitorV2ActionsAction[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | DataObserveMonitorV2ActionsAction[] | undefined;
    private _conditions;
    get conditions(): DataObserveMonitorV2ActionsConditionsList;
    putConditions(value: DataObserveMonitorV2ActionsConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | DataObserveMonitorV2ActionsConditions[] | undefined;
}
export declare class DataObserveMonitorV2ActionsList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2Actions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionsOutputReference;
}
export interface DataObserveMonitorV2GroupingsColumnPath {
}
export declare function dataObserveMonitorV2GroupingsColumnPathToTerraform(struct?: DataObserveMonitorV2GroupingsColumnPath | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2GroupingsColumnPathToHclTerraform(struct?: DataObserveMonitorV2GroupingsColumnPath | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2GroupingsColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2GroupingsColumnPath | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2GroupingsColumnPath | cdktn.IResolvable | undefined);
    get name(): string;
    get path(): string;
}
export declare class DataObserveMonitorV2GroupingsColumnPathList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2GroupingsColumnPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2GroupingsColumnPathOutputReference;
}
export interface DataObserveMonitorV2GroupingsLinkColumn {
}
export declare function dataObserveMonitorV2GroupingsLinkColumnToTerraform(struct?: DataObserveMonitorV2GroupingsLinkColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2GroupingsLinkColumnToHclTerraform(struct?: DataObserveMonitorV2GroupingsLinkColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2GroupingsLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2GroupingsLinkColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2GroupingsLinkColumn | cdktn.IResolvable | undefined);
    get name(): string;
}
export declare class DataObserveMonitorV2GroupingsLinkColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2GroupingsLinkColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2GroupingsLinkColumnOutputReference;
}
export interface DataObserveMonitorV2Groupings {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column_path DataObserveMonitorV2#column_path}
    */
    readonly columnPath?: DataObserveMonitorV2GroupingsColumnPath[] | cdktn.IResolvable;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#link_column DataObserveMonitorV2#link_column}
    */
    readonly linkColumn?: DataObserveMonitorV2GroupingsLinkColumn[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2GroupingsToTerraform(struct?: DataObserveMonitorV2Groupings | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2GroupingsToHclTerraform(struct?: DataObserveMonitorV2Groupings | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2GroupingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2Groupings | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2Groupings | cdktn.IResolvable | undefined);
    private _columnPath;
    get columnPath(): DataObserveMonitorV2GroupingsColumnPathList;
    putColumnPath(value: DataObserveMonitorV2GroupingsColumnPath[] | cdktn.IResolvable): void;
    resetColumnPath(): void;
    get columnPathInput(): cdktn.IResolvable | DataObserveMonitorV2GroupingsColumnPath[] | undefined;
    private _linkColumn;
    get linkColumn(): DataObserveMonitorV2GroupingsLinkColumnList;
    putLinkColumn(value: DataObserveMonitorV2GroupingsLinkColumn[] | cdktn.IResolvable): void;
    resetLinkColumn(): void;
    get linkColumnInput(): cdktn.IResolvable | DataObserveMonitorV2GroupingsLinkColumn[] | undefined;
}
export declare class DataObserveMonitorV2GroupingsList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2Groupings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2GroupingsOutputReference;
}
export interface DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath {
}
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathToTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathToHclTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath | cdktn.IResolvable | undefined);
    get name(): string;
    get path(): string;
}
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathOutputReference;
}
export interface DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn {
}
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnToTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnToHclTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn | cdktn.IResolvable | undefined);
    get name(): string;
}
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnOutputReference;
}
export interface DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumn {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column_path DataObserveMonitorV2#column_path}
    */
    readonly columnPath?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath[] | cdktn.IResolvable;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#link_column DataObserveMonitorV2#link_column}
    */
    readonly linkColumn?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnToTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnToHclTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumn | cdktn.IResolvable | undefined);
    private _columnPath;
    get columnPath(): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPathList;
    putColumnPath(value: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath[] | cdktn.IResolvable): void;
    resetColumnPath(): void;
    get columnPathInput(): cdktn.IResolvable | DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnColumnPath[] | undefined;
    private _linkColumn;
    get linkColumn(): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumnList;
    putLinkColumn(value: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn[] | cdktn.IResolvable): void;
    resetLinkColumn(): void;
    get linkColumnInput(): cdktn.IResolvable | DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnLinkColumn[] | undefined;
}
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnOutputReference;
}
export interface DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValues {
}
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValuesToTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValuesToHclTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValues | cdktn.IResolvable | undefined);
    get compareFn(): string;
    private _valueBool;
    get valueBool(): cdktn.BooleanList;
    get valueDuration(): string[];
    get valueFloat64(): number[];
    get valueInt64(): number[];
    get valueString(): string[];
    get valueTimestamp(): string[];
}
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValuesList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValuesOutputReference;
}
export interface DataObserveMonitorV2NoDataRulesThresholdCompareGroups {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column DataObserveMonitorV2#column}
    */
    readonly column?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumn[] | cdktn.IResolvable;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_values DataObserveMonitorV2#compare_values}
    */
    readonly compareValues?: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareGroupsToTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareGroups | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareGroupsToHclTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareGroups | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2NoDataRulesThresholdCompareGroups | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2NoDataRulesThresholdCompareGroups | cdktn.IResolvable | undefined);
    private _column;
    get column(): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumnList;
    putColumn(value: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumn[] | cdktn.IResolvable): void;
    resetColumn(): void;
    get columnInput(): cdktn.IResolvable | DataObserveMonitorV2NoDataRulesThresholdCompareGroupsColumn[] | undefined;
    private _compareValues;
    get compareValues(): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValuesList;
    putCompareValues(value: DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable): void;
    resetCompareValues(): void;
    get compareValuesInput(): cdktn.IResolvable | DataObserveMonitorV2NoDataRulesThresholdCompareGroupsCompareValues[] | undefined;
}
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareGroupsList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2NoDataRulesThresholdCompareGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsOutputReference;
}
export interface DataObserveMonitorV2NoDataRulesThresholdCompareValues {
}
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareValuesToTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareValues | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2NoDataRulesThresholdCompareValuesToHclTerraform(struct?: DataObserveMonitorV2NoDataRulesThresholdCompareValues | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2NoDataRulesThresholdCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2NoDataRulesThresholdCompareValues | cdktn.IResolvable | undefined);
    get compareFn(): string;
    private _valueBool;
    get valueBool(): cdktn.BooleanList;
    get valueDuration(): string[];
    get valueFloat64(): number[];
    get valueInt64(): number[];
    get valueString(): string[];
    get valueTimestamp(): string[];
}
export declare class DataObserveMonitorV2NoDataRulesThresholdCompareValuesList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2NoDataRulesThresholdCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2NoDataRulesThresholdCompareValuesOutputReference;
}
export interface DataObserveMonitorV2NoDataRulesThreshold {
    /**
    * compare_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_groups DataObserveMonitorV2#compare_groups}
    */
    readonly compareGroups?: DataObserveMonitorV2NoDataRulesThresholdCompareGroups[] | cdktn.IResolvable;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_values DataObserveMonitorV2#compare_values}
    */
    readonly compareValues?: DataObserveMonitorV2NoDataRulesThresholdCompareValues[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2NoDataRulesThresholdToTerraform(struct?: DataObserveMonitorV2NoDataRulesThreshold | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2NoDataRulesThresholdToHclTerraform(struct?: DataObserveMonitorV2NoDataRulesThreshold | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2NoDataRulesThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2NoDataRulesThreshold | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2NoDataRulesThreshold | cdktn.IResolvable | undefined);
    get aggregation(): string;
    get valueColumnName(): string;
    private _compareGroups;
    get compareGroups(): DataObserveMonitorV2NoDataRulesThresholdCompareGroupsList;
    putCompareGroups(value: DataObserveMonitorV2NoDataRulesThresholdCompareGroups[] | cdktn.IResolvable): void;
    resetCompareGroups(): void;
    get compareGroupsInput(): cdktn.IResolvable | DataObserveMonitorV2NoDataRulesThresholdCompareGroups[] | undefined;
    private _compareValues;
    get compareValues(): DataObserveMonitorV2NoDataRulesThresholdCompareValuesList;
    putCompareValues(value: DataObserveMonitorV2NoDataRulesThresholdCompareValues[] | cdktn.IResolvable): void;
    resetCompareValues(): void;
    get compareValuesInput(): cdktn.IResolvable | DataObserveMonitorV2NoDataRulesThresholdCompareValues[] | undefined;
}
export declare class DataObserveMonitorV2NoDataRulesThresholdList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2NoDataRulesThreshold[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2NoDataRulesThresholdOutputReference;
}
export interface DataObserveMonitorV2NoDataRules {
    /**
    * threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#threshold DataObserveMonitorV2#threshold}
    */
    readonly threshold?: DataObserveMonitorV2NoDataRulesThreshold[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2NoDataRulesToTerraform(struct?: DataObserveMonitorV2NoDataRules | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2NoDataRulesToHclTerraform(struct?: DataObserveMonitorV2NoDataRules | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2NoDataRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2NoDataRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2NoDataRules | cdktn.IResolvable | undefined);
    get expiration(): string;
    private _threshold;
    get threshold(): DataObserveMonitorV2NoDataRulesThresholdList;
    putThreshold(value: DataObserveMonitorV2NoDataRulesThreshold[] | cdktn.IResolvable): void;
    resetThreshold(): void;
    get thresholdInput(): cdktn.IResolvable | DataObserveMonitorV2NoDataRulesThreshold[] | undefined;
}
export declare class DataObserveMonitorV2NoDataRulesList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2NoDataRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2NoDataRulesOutputReference;
}
export interface DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPath {
}
export declare function dataObserveMonitorV2RulesCountCompareGroupsColumnColumnPathToTerraform(struct?: DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPath | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesCountCompareGroupsColumnColumnPathToHclTerraform(struct?: DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPath | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPath | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPath | cdktn.IResolvable | undefined);
    get name(): string;
    get path(): string;
}
export declare class DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPathList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPathOutputReference;
}
export interface DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumn {
}
export declare function dataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumnToTerraform(struct?: DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumnToHclTerraform(struct?: DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumn | cdktn.IResolvable | undefined);
    get name(): string;
}
export declare class DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumnOutputReference;
}
export interface DataObserveMonitorV2RulesCountCompareGroupsColumn {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column_path DataObserveMonitorV2#column_path}
    */
    readonly columnPath?: DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPath[] | cdktn.IResolvable;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#link_column DataObserveMonitorV2#link_column}
    */
    readonly linkColumn?: DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumn[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2RulesCountCompareGroupsColumnToTerraform(struct?: DataObserveMonitorV2RulesCountCompareGroupsColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesCountCompareGroupsColumnToHclTerraform(struct?: DataObserveMonitorV2RulesCountCompareGroupsColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesCountCompareGroupsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesCountCompareGroupsColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesCountCompareGroupsColumn | cdktn.IResolvable | undefined);
    private _columnPath;
    get columnPath(): DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPathList;
    putColumnPath(value: DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPath[] | cdktn.IResolvable): void;
    resetColumnPath(): void;
    get columnPathInput(): cdktn.IResolvable | DataObserveMonitorV2RulesCountCompareGroupsColumnColumnPath[] | undefined;
    private _linkColumn;
    get linkColumn(): DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumnList;
    putLinkColumn(value: DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumn[] | cdktn.IResolvable): void;
    resetLinkColumn(): void;
    get linkColumnInput(): cdktn.IResolvable | DataObserveMonitorV2RulesCountCompareGroupsColumnLinkColumn[] | undefined;
}
export declare class DataObserveMonitorV2RulesCountCompareGroupsColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesCountCompareGroupsColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesCountCompareGroupsColumnOutputReference;
}
export interface DataObserveMonitorV2RulesCountCompareGroupsCompareValues {
}
export declare function dataObserveMonitorV2RulesCountCompareGroupsCompareValuesToTerraform(struct?: DataObserveMonitorV2RulesCountCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesCountCompareGroupsCompareValuesToHclTerraform(struct?: DataObserveMonitorV2RulesCountCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesCountCompareGroupsCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesCountCompareGroupsCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesCountCompareGroupsCompareValues | cdktn.IResolvable | undefined);
    get compareFn(): string;
    private _valueBool;
    get valueBool(): cdktn.BooleanList;
    get valueDuration(): string[];
    get valueFloat64(): number[];
    get valueInt64(): number[];
    get valueString(): string[];
    get valueTimestamp(): string[];
}
export declare class DataObserveMonitorV2RulesCountCompareGroupsCompareValuesList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesCountCompareGroupsCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesCountCompareGroupsCompareValuesOutputReference;
}
export interface DataObserveMonitorV2RulesCountCompareGroups {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column DataObserveMonitorV2#column}
    */
    readonly column?: DataObserveMonitorV2RulesCountCompareGroupsColumn[] | cdktn.IResolvable;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_values DataObserveMonitorV2#compare_values}
    */
    readonly compareValues?: DataObserveMonitorV2RulesCountCompareGroupsCompareValues[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2RulesCountCompareGroupsToTerraform(struct?: DataObserveMonitorV2RulesCountCompareGroups | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesCountCompareGroupsToHclTerraform(struct?: DataObserveMonitorV2RulesCountCompareGroups | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesCountCompareGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesCountCompareGroups | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesCountCompareGroups | cdktn.IResolvable | undefined);
    private _column;
    get column(): DataObserveMonitorV2RulesCountCompareGroupsColumnList;
    putColumn(value: DataObserveMonitorV2RulesCountCompareGroupsColumn[] | cdktn.IResolvable): void;
    resetColumn(): void;
    get columnInput(): cdktn.IResolvable | DataObserveMonitorV2RulesCountCompareGroupsColumn[] | undefined;
    private _compareValues;
    get compareValues(): DataObserveMonitorV2RulesCountCompareGroupsCompareValuesList;
    putCompareValues(value: DataObserveMonitorV2RulesCountCompareGroupsCompareValues[] | cdktn.IResolvable): void;
    resetCompareValues(): void;
    get compareValuesInput(): cdktn.IResolvable | DataObserveMonitorV2RulesCountCompareGroupsCompareValues[] | undefined;
}
export declare class DataObserveMonitorV2RulesCountCompareGroupsList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesCountCompareGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesCountCompareGroupsOutputReference;
}
export interface DataObserveMonitorV2RulesCountCompareValues {
}
export declare function dataObserveMonitorV2RulesCountCompareValuesToTerraform(struct?: DataObserveMonitorV2RulesCountCompareValues | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesCountCompareValuesToHclTerraform(struct?: DataObserveMonitorV2RulesCountCompareValues | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesCountCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesCountCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesCountCompareValues | cdktn.IResolvable | undefined);
    get compareFn(): string;
    private _valueBool;
    get valueBool(): cdktn.BooleanList;
    get valueDuration(): string[];
    get valueFloat64(): number[];
    get valueInt64(): number[];
    get valueString(): string[];
    get valueTimestamp(): string[];
}
export declare class DataObserveMonitorV2RulesCountCompareValuesList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesCountCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesCountCompareValuesOutputReference;
}
export interface DataObserveMonitorV2RulesCount {
    /**
    * compare_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_groups DataObserveMonitorV2#compare_groups}
    */
    readonly compareGroups?: DataObserveMonitorV2RulesCountCompareGroups[] | cdktn.IResolvable;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_values DataObserveMonitorV2#compare_values}
    */
    readonly compareValues?: DataObserveMonitorV2RulesCountCompareValues[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2RulesCountToTerraform(struct?: DataObserveMonitorV2RulesCount | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesCountToHclTerraform(struct?: DataObserveMonitorV2RulesCount | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesCountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesCount | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesCount | cdktn.IResolvable | undefined);
    private _compareGroups;
    get compareGroups(): DataObserveMonitorV2RulesCountCompareGroupsList;
    putCompareGroups(value: DataObserveMonitorV2RulesCountCompareGroups[] | cdktn.IResolvable): void;
    resetCompareGroups(): void;
    get compareGroupsInput(): cdktn.IResolvable | DataObserveMonitorV2RulesCountCompareGroups[] | undefined;
    private _compareValues;
    get compareValues(): DataObserveMonitorV2RulesCountCompareValuesList;
    putCompareValues(value: DataObserveMonitorV2RulesCountCompareValues[] | cdktn.IResolvable): void;
    resetCompareValues(): void;
    get compareValuesInput(): cdktn.IResolvable | DataObserveMonitorV2RulesCountCompareValues[] | undefined;
}
export declare class DataObserveMonitorV2RulesCountList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesCount[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesCountOutputReference;
}
export interface DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPath {
}
export declare function dataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPathToTerraform(struct?: DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPath | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPathToHclTerraform(struct?: DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPath | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPath | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPath | cdktn.IResolvable | undefined);
    get name(): string;
    get path(): string;
}
export declare class DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPathList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPathOutputReference;
}
export interface DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumn {
}
export declare function dataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumnToTerraform(struct?: DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumnToHclTerraform(struct?: DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumn | cdktn.IResolvable | undefined);
    get name(): string;
}
export declare class DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumnOutputReference;
}
export interface DataObserveMonitorV2RulesPromoteCompareColumnsColumn {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column_path DataObserveMonitorV2#column_path}
    */
    readonly columnPath?: DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPath[] | cdktn.IResolvable;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#link_column DataObserveMonitorV2#link_column}
    */
    readonly linkColumn?: DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumn[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2RulesPromoteCompareColumnsColumnToTerraform(struct?: DataObserveMonitorV2RulesPromoteCompareColumnsColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesPromoteCompareColumnsColumnToHclTerraform(struct?: DataObserveMonitorV2RulesPromoteCompareColumnsColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesPromoteCompareColumnsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesPromoteCompareColumnsColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesPromoteCompareColumnsColumn | cdktn.IResolvable | undefined);
    private _columnPath;
    get columnPath(): DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPathList;
    putColumnPath(value: DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPath[] | cdktn.IResolvable): void;
    resetColumnPath(): void;
    get columnPathInput(): cdktn.IResolvable | DataObserveMonitorV2RulesPromoteCompareColumnsColumnColumnPath[] | undefined;
    private _linkColumn;
    get linkColumn(): DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumnList;
    putLinkColumn(value: DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumn[] | cdktn.IResolvable): void;
    resetLinkColumn(): void;
    get linkColumnInput(): cdktn.IResolvable | DataObserveMonitorV2RulesPromoteCompareColumnsColumnLinkColumn[] | undefined;
}
export declare class DataObserveMonitorV2RulesPromoteCompareColumnsColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesPromoteCompareColumnsColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesPromoteCompareColumnsColumnOutputReference;
}
export interface DataObserveMonitorV2RulesPromoteCompareColumnsCompareValues {
}
export declare function dataObserveMonitorV2RulesPromoteCompareColumnsCompareValuesToTerraform(struct?: DataObserveMonitorV2RulesPromoteCompareColumnsCompareValues | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesPromoteCompareColumnsCompareValuesToHclTerraform(struct?: DataObserveMonitorV2RulesPromoteCompareColumnsCompareValues | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesPromoteCompareColumnsCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesPromoteCompareColumnsCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesPromoteCompareColumnsCompareValues | cdktn.IResolvable | undefined);
    get compareFn(): string;
    private _valueBool;
    get valueBool(): cdktn.BooleanList;
    get valueDuration(): string[];
    get valueFloat64(): number[];
    get valueInt64(): number[];
    get valueString(): string[];
    get valueTimestamp(): string[];
}
export declare class DataObserveMonitorV2RulesPromoteCompareColumnsCompareValuesList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesPromoteCompareColumnsCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesPromoteCompareColumnsCompareValuesOutputReference;
}
export interface DataObserveMonitorV2RulesPromoteCompareColumns {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column DataObserveMonitorV2#column}
    */
    readonly column?: DataObserveMonitorV2RulesPromoteCompareColumnsColumn[] | cdktn.IResolvable;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_values DataObserveMonitorV2#compare_values}
    */
    readonly compareValues?: DataObserveMonitorV2RulesPromoteCompareColumnsCompareValues[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2RulesPromoteCompareColumnsToTerraform(struct?: DataObserveMonitorV2RulesPromoteCompareColumns | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesPromoteCompareColumnsToHclTerraform(struct?: DataObserveMonitorV2RulesPromoteCompareColumns | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesPromoteCompareColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesPromoteCompareColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesPromoteCompareColumns | cdktn.IResolvable | undefined);
    private _column;
    get column(): DataObserveMonitorV2RulesPromoteCompareColumnsColumnList;
    putColumn(value: DataObserveMonitorV2RulesPromoteCompareColumnsColumn[] | cdktn.IResolvable): void;
    resetColumn(): void;
    get columnInput(): cdktn.IResolvable | DataObserveMonitorV2RulesPromoteCompareColumnsColumn[] | undefined;
    private _compareValues;
    get compareValues(): DataObserveMonitorV2RulesPromoteCompareColumnsCompareValuesList;
    putCompareValues(value: DataObserveMonitorV2RulesPromoteCompareColumnsCompareValues[] | cdktn.IResolvable): void;
    resetCompareValues(): void;
    get compareValuesInput(): cdktn.IResolvable | DataObserveMonitorV2RulesPromoteCompareColumnsCompareValues[] | undefined;
}
export declare class DataObserveMonitorV2RulesPromoteCompareColumnsList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesPromoteCompareColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesPromoteCompareColumnsOutputReference;
}
export interface DataObserveMonitorV2RulesPromote {
    /**
    * compare_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_columns DataObserveMonitorV2#compare_columns}
    */
    readonly compareColumns?: DataObserveMonitorV2RulesPromoteCompareColumns[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2RulesPromoteToTerraform(struct?: DataObserveMonitorV2RulesPromote | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesPromoteToHclTerraform(struct?: DataObserveMonitorV2RulesPromote | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesPromoteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesPromote | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesPromote | cdktn.IResolvable | undefined);
    private _compareColumns;
    get compareColumns(): DataObserveMonitorV2RulesPromoteCompareColumnsList;
    putCompareColumns(value: DataObserveMonitorV2RulesPromoteCompareColumns[] | cdktn.IResolvable): void;
    resetCompareColumns(): void;
    get compareColumnsInput(): cdktn.IResolvable | DataObserveMonitorV2RulesPromoteCompareColumns[] | undefined;
}
export declare class DataObserveMonitorV2RulesPromoteList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesPromote[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesPromoteOutputReference;
}
export interface DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPath {
}
export declare function dataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPathToTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPath | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPathToHclTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPath | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPath | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPath | cdktn.IResolvable | undefined);
    get name(): string;
    get path(): string;
}
export declare class DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPathList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPathOutputReference;
}
export interface DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumn {
}
export declare function dataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumnToTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumnToHclTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumn | cdktn.IResolvable | undefined);
    get name(): string;
}
export declare class DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumnOutputReference;
}
export interface DataObserveMonitorV2RulesThresholdCompareGroupsColumn {
    /**
    * column_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column_path DataObserveMonitorV2#column_path}
    */
    readonly columnPath?: DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPath[] | cdktn.IResolvable;
    /**
    * link_column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#link_column DataObserveMonitorV2#link_column}
    */
    readonly linkColumn?: DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumn[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2RulesThresholdCompareGroupsColumnToTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareGroupsColumn | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesThresholdCompareGroupsColumnToHclTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareGroupsColumn | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesThresholdCompareGroupsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesThresholdCompareGroupsColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesThresholdCompareGroupsColumn | cdktn.IResolvable | undefined);
    private _columnPath;
    get columnPath(): DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPathList;
    putColumnPath(value: DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPath[] | cdktn.IResolvable): void;
    resetColumnPath(): void;
    get columnPathInput(): cdktn.IResolvable | DataObserveMonitorV2RulesThresholdCompareGroupsColumnColumnPath[] | undefined;
    private _linkColumn;
    get linkColumn(): DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumnList;
    putLinkColumn(value: DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumn[] | cdktn.IResolvable): void;
    resetLinkColumn(): void;
    get linkColumnInput(): cdktn.IResolvable | DataObserveMonitorV2RulesThresholdCompareGroupsColumnLinkColumn[] | undefined;
}
export declare class DataObserveMonitorV2RulesThresholdCompareGroupsColumnList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesThresholdCompareGroupsColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesThresholdCompareGroupsColumnOutputReference;
}
export interface DataObserveMonitorV2RulesThresholdCompareGroupsCompareValues {
}
export declare function dataObserveMonitorV2RulesThresholdCompareGroupsCompareValuesToTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesThresholdCompareGroupsCompareValuesToHclTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareGroupsCompareValues | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesThresholdCompareGroupsCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesThresholdCompareGroupsCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesThresholdCompareGroupsCompareValues | cdktn.IResolvable | undefined);
    get compareFn(): string;
    private _valueBool;
    get valueBool(): cdktn.BooleanList;
    get valueDuration(): string[];
    get valueFloat64(): number[];
    get valueInt64(): number[];
    get valueString(): string[];
    get valueTimestamp(): string[];
}
export declare class DataObserveMonitorV2RulesThresholdCompareGroupsCompareValuesList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesThresholdCompareGroupsCompareValuesOutputReference;
}
export interface DataObserveMonitorV2RulesThresholdCompareGroups {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#column DataObserveMonitorV2#column}
    */
    readonly column?: DataObserveMonitorV2RulesThresholdCompareGroupsColumn[] | cdktn.IResolvable;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_values DataObserveMonitorV2#compare_values}
    */
    readonly compareValues?: DataObserveMonitorV2RulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2RulesThresholdCompareGroupsToTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareGroups | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesThresholdCompareGroupsToHclTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareGroups | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesThresholdCompareGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesThresholdCompareGroups | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesThresholdCompareGroups | cdktn.IResolvable | undefined);
    private _column;
    get column(): DataObserveMonitorV2RulesThresholdCompareGroupsColumnList;
    putColumn(value: DataObserveMonitorV2RulesThresholdCompareGroupsColumn[] | cdktn.IResolvable): void;
    resetColumn(): void;
    get columnInput(): cdktn.IResolvable | DataObserveMonitorV2RulesThresholdCompareGroupsColumn[] | undefined;
    private _compareValues;
    get compareValues(): DataObserveMonitorV2RulesThresholdCompareGroupsCompareValuesList;
    putCompareValues(value: DataObserveMonitorV2RulesThresholdCompareGroupsCompareValues[] | cdktn.IResolvable): void;
    resetCompareValues(): void;
    get compareValuesInput(): cdktn.IResolvable | DataObserveMonitorV2RulesThresholdCompareGroupsCompareValues[] | undefined;
}
export declare class DataObserveMonitorV2RulesThresholdCompareGroupsList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesThresholdCompareGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesThresholdCompareGroupsOutputReference;
}
export interface DataObserveMonitorV2RulesThresholdCompareValues {
}
export declare function dataObserveMonitorV2RulesThresholdCompareValuesToTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareValues | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesThresholdCompareValuesToHclTerraform(struct?: DataObserveMonitorV2RulesThresholdCompareValues | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesThresholdCompareValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesThresholdCompareValues | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesThresholdCompareValues | cdktn.IResolvable | undefined);
    get compareFn(): string;
    private _valueBool;
    get valueBool(): cdktn.BooleanList;
    get valueDuration(): string[];
    get valueFloat64(): number[];
    get valueInt64(): number[];
    get valueString(): string[];
    get valueTimestamp(): string[];
}
export declare class DataObserveMonitorV2RulesThresholdCompareValuesList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesThresholdCompareValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesThresholdCompareValuesOutputReference;
}
export interface DataObserveMonitorV2RulesThreshold {
    /**
    * compare_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_groups DataObserveMonitorV2#compare_groups}
    */
    readonly compareGroups?: DataObserveMonitorV2RulesThresholdCompareGroups[] | cdktn.IResolvable;
    /**
    * compare_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#compare_values DataObserveMonitorV2#compare_values}
    */
    readonly compareValues?: DataObserveMonitorV2RulesThresholdCompareValues[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2RulesThresholdToTerraform(struct?: DataObserveMonitorV2RulesThreshold | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesThresholdToHclTerraform(struct?: DataObserveMonitorV2RulesThreshold | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2RulesThreshold | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2RulesThreshold | cdktn.IResolvable | undefined);
    get aggregation(): string;
    get valueColumnName(): string;
    private _compareGroups;
    get compareGroups(): DataObserveMonitorV2RulesThresholdCompareGroupsList;
    putCompareGroups(value: DataObserveMonitorV2RulesThresholdCompareGroups[] | cdktn.IResolvable): void;
    resetCompareGroups(): void;
    get compareGroupsInput(): cdktn.IResolvable | DataObserveMonitorV2RulesThresholdCompareGroups[] | undefined;
    private _compareValues;
    get compareValues(): DataObserveMonitorV2RulesThresholdCompareValuesList;
    putCompareValues(value: DataObserveMonitorV2RulesThresholdCompareValues[] | cdktn.IResolvable): void;
    resetCompareValues(): void;
    get compareValuesInput(): cdktn.IResolvable | DataObserveMonitorV2RulesThresholdCompareValues[] | undefined;
}
export declare class DataObserveMonitorV2RulesThresholdList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2RulesThreshold[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesThresholdOutputReference;
}
export interface DataObserveMonitorV2Rules {
    /**
    * count block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#count DataObserveMonitorV2#count}
    */
    readonly count?: DataObserveMonitorV2RulesCount[] | cdktn.IResolvable;
    /**
    * promote block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#promote DataObserveMonitorV2#promote}
    */
    readonly promote?: DataObserveMonitorV2RulesPromote[] | cdktn.IResolvable;
    /**
    * threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#threshold DataObserveMonitorV2#threshold}
    */
    readonly threshold?: DataObserveMonitorV2RulesThreshold[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2RulesToTerraform(struct?: DataObserveMonitorV2Rules | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2RulesToHclTerraform(struct?: DataObserveMonitorV2Rules | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2RulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2Rules | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2Rules | cdktn.IResolvable | undefined);
    get level(): string;
    private _count;
    get count(): DataObserveMonitorV2RulesCountList;
    putCount(value: DataObserveMonitorV2RulesCount[] | cdktn.IResolvable): void;
    resetCount(): void;
    get countInput(): cdktn.IResolvable | DataObserveMonitorV2RulesCount[] | undefined;
    private _promote;
    get promote(): DataObserveMonitorV2RulesPromoteList;
    putPromote(value: DataObserveMonitorV2RulesPromote[] | cdktn.IResolvable): void;
    resetPromote(): void;
    get promoteInput(): cdktn.IResolvable | DataObserveMonitorV2RulesPromote[] | undefined;
    private _threshold;
    get threshold(): DataObserveMonitorV2RulesThresholdList;
    putThreshold(value: DataObserveMonitorV2RulesThreshold[] | cdktn.IResolvable): void;
    resetThreshold(): void;
    get thresholdInput(): cdktn.IResolvable | DataObserveMonitorV2RulesThreshold[] | undefined;
}
export declare class DataObserveMonitorV2RulesList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2Rules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2RulesOutputReference;
}
export interface DataObserveMonitorV2SchedulingInterval {
}
export declare function dataObserveMonitorV2SchedulingIntervalToTerraform(struct?: DataObserveMonitorV2SchedulingInterval | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2SchedulingIntervalToHclTerraform(struct?: DataObserveMonitorV2SchedulingInterval | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2SchedulingIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2SchedulingInterval | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2SchedulingInterval | cdktn.IResolvable | undefined);
    get interval(): string;
    get randomize(): string;
}
export declare class DataObserveMonitorV2SchedulingIntervalList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2SchedulingInterval[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2SchedulingIntervalOutputReference;
}
export interface DataObserveMonitorV2SchedulingScheduled {
    /**
    * A timezone is required to ensure that interpretation of scheduling on the wall-clock
    * is done relative to the desired timezone.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#timezone DataObserveMonitorV2#timezone}
    */
    readonly timezone: string;
}
export declare function dataObserveMonitorV2SchedulingScheduledToTerraform(struct?: DataObserveMonitorV2SchedulingScheduled | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2SchedulingScheduledToHclTerraform(struct?: DataObserveMonitorV2SchedulingScheduled | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2SchedulingScheduledOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2SchedulingScheduled | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2SchedulingScheduled | cdktn.IResolvable | undefined);
    get rawCron(): string;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    get timezoneInput(): string | undefined;
}
export declare class DataObserveMonitorV2SchedulingScheduledList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2SchedulingScheduled[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2SchedulingScheduledOutputReference;
}
export interface DataObserveMonitorV2SchedulingTransform {
}
export declare function dataObserveMonitorV2SchedulingTransformToTerraform(struct?: DataObserveMonitorV2SchedulingTransform | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2SchedulingTransformToHclTerraform(struct?: DataObserveMonitorV2SchedulingTransform | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2SchedulingTransformOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2SchedulingTransform | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2SchedulingTransform | cdktn.IResolvable | undefined);
    get freshnessGoal(): string;
}
export declare class DataObserveMonitorV2SchedulingTransformList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2SchedulingTransform[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2SchedulingTransformOutputReference;
}
export interface DataObserveMonitorV2Scheduling {
    /**
    * interval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#interval DataObserveMonitorV2#interval}
    */
    readonly interval?: DataObserveMonitorV2SchedulingInterval[] | cdktn.IResolvable;
    /**
    * scheduled block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#scheduled DataObserveMonitorV2#scheduled}
    */
    readonly scheduled?: DataObserveMonitorV2SchedulingScheduled[] | cdktn.IResolvable;
    /**
    * transform block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#transform DataObserveMonitorV2#transform}
    */
    readonly transform?: DataObserveMonitorV2SchedulingTransform[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2SchedulingToTerraform(struct?: DataObserveMonitorV2Scheduling | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2SchedulingToHclTerraform(struct?: DataObserveMonitorV2Scheduling | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2SchedulingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2Scheduling | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2Scheduling | cdktn.IResolvable | undefined);
    private _interval;
    get interval(): DataObserveMonitorV2SchedulingIntervalList;
    putInterval(value: DataObserveMonitorV2SchedulingInterval[] | cdktn.IResolvable): void;
    resetInterval(): void;
    get intervalInput(): cdktn.IResolvable | DataObserveMonitorV2SchedulingInterval[] | undefined;
    private _scheduled;
    get scheduled(): DataObserveMonitorV2SchedulingScheduledList;
    putScheduled(value: DataObserveMonitorV2SchedulingScheduled[] | cdktn.IResolvable): void;
    resetScheduled(): void;
    get scheduledInput(): cdktn.IResolvable | DataObserveMonitorV2SchedulingScheduled[] | undefined;
    private _transform;
    get transform(): DataObserveMonitorV2SchedulingTransformList;
    putTransform(value: DataObserveMonitorV2SchedulingTransform[] | cdktn.IResolvable): void;
    resetTransform(): void;
    get transformInput(): cdktn.IResolvable | DataObserveMonitorV2SchedulingTransform[] | undefined;
}
export declare class DataObserveMonitorV2SchedulingList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2Scheduling[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2SchedulingOutputReference;
}
export interface DataObserveMonitorV2Stage {
}
export declare function dataObserveMonitorV2StageToTerraform(struct?: DataObserveMonitorV2Stage | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2StageToHclTerraform(struct?: DataObserveMonitorV2Stage | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2StageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2Stage | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2Stage | cdktn.IResolvable | undefined);
    get alias(): string;
    get input(): string;
    get outputStage(): cdktn.IResolvable;
    get pipeline(): string;
}
export declare class DataObserveMonitorV2StageList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2Stage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2StageOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2 observe_monitor_v2}
*/
export declare class DataObserveMonitorV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "observe_monitor_v2";
    /**
    * Generates CDKTN code for importing a DataObserveMonitorV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveMonitorV2 to import
    * @param importFromId The id of the existing DataObserveMonitorV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveMonitorV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2 observe_monitor_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveMonitorV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveMonitorV2Config);
    get bindings(): string;
    get customVariables(): string;
    get dataStabilizationDelay(): string;
    get description(): string;
    get disabled(): cdktn.IResolvable;
    get iconUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputs;
    get inputs(): cdktn.StringMap;
    get lookbackTime(): string;
    get maxAlertsPerHour(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get oid(): string;
    get ruleKind(): string;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
    private _actions;
    get actions(): DataObserveMonitorV2ActionsList;
    putActions(value: DataObserveMonitorV2Actions[] | cdktn.IResolvable): void;
    resetActions(): void;
    get actionsInput(): cdktn.IResolvable | DataObserveMonitorV2Actions[] | undefined;
    private _groupings;
    get groupings(): DataObserveMonitorV2GroupingsList;
    putGroupings(value: DataObserveMonitorV2Groupings[] | cdktn.IResolvable): void;
    resetGroupings(): void;
    get groupingsInput(): cdktn.IResolvable | DataObserveMonitorV2Groupings[] | undefined;
    private _noDataRules;
    get noDataRules(): DataObserveMonitorV2NoDataRulesList;
    putNoDataRules(value: DataObserveMonitorV2NoDataRules[] | cdktn.IResolvable): void;
    resetNoDataRules(): void;
    get noDataRulesInput(): cdktn.IResolvable | DataObserveMonitorV2NoDataRules[] | undefined;
    private _rules;
    get rules(): DataObserveMonitorV2RulesList;
    putRules(value: DataObserveMonitorV2Rules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | DataObserveMonitorV2Rules[] | undefined;
    private _scheduling;
    get scheduling(): DataObserveMonitorV2SchedulingList;
    putScheduling(value: DataObserveMonitorV2Scheduling[] | cdktn.IResolvable): void;
    resetScheduling(): void;
    get schedulingInput(): cdktn.IResolvable | DataObserveMonitorV2Scheduling[] | undefined;
    private _stage;
    get stage(): DataObserveMonitorV2StageList;
    putStage(value: DataObserveMonitorV2Stage[] | cdktn.IResolvable): void;
    resetStage(): void;
    get stageInput(): cdktn.IResolvable | DataObserveMonitorV2Stage[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
