import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataObserveCloudInfoConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/cloud_info#id DataObserveCloudInfo#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/cloud_info observe_cloud_info}
*/
export declare class DataObserveCloudInfo extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "observe_cloud_info";
    /**
    * Generates CDKTN code for importing a DataObserveCloudInfo resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveCloudInfo to import
    * @param importFromId The id of the existing DataObserveCloudInfo that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/cloud_info#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveCloudInfo to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/cloud_info observe_cloud_info} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveCloudInfoConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveCloudInfoConfig);
    get accountId(): string;
    get cloudProvider(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get region(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
