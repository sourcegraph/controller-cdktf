import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DropFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The percentage of matched observations to drop specified as a floating point number between 0.0 and 1.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/drop_filter#drop_rate DropFilter#drop_rate}
    */
    readonly dropRate: number;
    /**
    * When true the drop filter will drop data, and when false the drop filter will not drop data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/drop_filter#enabled DropFilter#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/drop_filter#id DropFilter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the drop filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/drop_filter#name DropFilter#name}
    */
    readonly name: string;
    /**
    * The opal that defines the drop filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/drop_filter#pipeline DropFilter#pipeline}
    */
    readonly pipeline: string;
    /**
    * The source dataset that the drop filter should apply to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/drop_filter#source_dataset DropFilter#source_dataset}
    */
    readonly sourceDataset: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/drop_filter#workspace DropFilter#workspace}
    */
    readonly workspace: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/drop_filter observe_drop_filter}
*/
export declare class DropFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_drop_filter";
    /**
    * Generates CDKTN code for importing a DropFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DropFilter to import
    * @param importFromId The id of the existing DropFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/drop_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DropFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/drop_filter observe_drop_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DropFilterConfig
    */
    constructor(scope: Construct, id: string, config: DropFilterConfig);
    private _dropRate?;
    get dropRate(): number;
    set dropRate(value: number);
    get dropRateInput(): number | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _pipeline?;
    get pipeline(): string;
    set pipeline(value: string);
    get pipelineInput(): string | undefined;
    private _sourceDataset?;
    get sourceDataset(): string;
    set sourceDataset(value: string);
    get sourceDatasetInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
