import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataObserveReferenceTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID for this object.
    * One of `label` or `id` must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/reference_table#id DataObserveReferenceTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the reference table name. Must be unique within workspace.
    * One of `label` or `id` must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/reference_table#label DataObserveReferenceTable#label}
    */
    readonly label?: string;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/reference_table#schema DataObserveReferenceTable#schema}
    */
    readonly schema?: DataObserveReferenceTableSchema[] | cdktn.IResolvable;
}
export interface DataObserveReferenceTableSchema {
}
export declare function dataObserveReferenceTableSchemaToTerraform(struct?: DataObserveReferenceTableSchema | cdktn.IResolvable): any;
export declare function dataObserveReferenceTableSchemaToHclTerraform(struct?: DataObserveReferenceTableSchema | cdktn.IResolvable): any;
export declare class DataObserveReferenceTableSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveReferenceTableSchema | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveReferenceTableSchema | cdktn.IResolvable | undefined);
    get name(): string;
    get type(): string;
}
export declare class DataObserveReferenceTableSchemaList extends cdktn.ComplexList {
    internalValue?: DataObserveReferenceTableSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveReferenceTableSchemaOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/reference_table observe_reference_table}
*/
export declare class DataObserveReferenceTable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "observe_reference_table";
    /**
    * Generates CDKTN code for importing a DataObserveReferenceTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveReferenceTable to import
    * @param importFromId The id of the existing DataObserveReferenceTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/reference_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveReferenceTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/reference_table observe_reference_table} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveReferenceTableConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveReferenceTableConfig);
    get checksum(): string;
    get dataset(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    get oid(): string;
    private _schema;
    get schema(): DataObserveReferenceTableSchemaList;
    putSchema(value: DataObserveReferenceTableSchema[] | cdktn.IResolvable): void;
    resetSchema(): void;
    get schemaInput(): cdktn.IResolvable | DataObserveReferenceTableSchema[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
