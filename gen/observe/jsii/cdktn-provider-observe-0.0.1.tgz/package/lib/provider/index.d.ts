import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ObserveProviderConfig {
    /**
    * An Observe API Token. Used for authenticating requests to API in the absence of `user_email` and `user_password`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#api_token ObserveProvider#api_token}
    */
    readonly apiToken?: string;
    /**
    * Your Observe Customer ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#customer ObserveProvider#customer}
    */
    readonly customer: string;
    /**
    * Default rematerialization mode for datasets (internal use).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#default_rematerialization_mode ObserveProvider#default_rematerialization_mode}
    */
    readonly defaultRematerializationMode?: string;
    /**
    * Observe API domain. Defaults to `observeinc.com`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#domain ObserveProvider#domain}
    */
    readonly domain?: string;
    /**
    * Enable generating object ID-name bindings for cross-tenant export/import (internal use).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#export_object_bindings ObserveProvider#export_object_bindings}
    */
    readonly exportObjectBindings?: boolean | cdktn.IResolvable;
    /**
    * Toggle experimental features.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#flags ObserveProvider#flags}
    */
    readonly flags?: string;
    /**
    * HTTP client timeout. Defaults to 2m.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#http_client_timeout ObserveProvider#http_client_timeout}
    */
    readonly httpClientTimeout?: string;
    /**
    * Skip TLS certificate validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#insecure ObserveProvider#insecure}
    */
    readonly insecure?: boolean | cdktn.IResolvable;
    /**
    * ID of an Observe object that serves as the parent (managing) object for all resources created by the provider (internal use).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#managing_object_id ObserveProvider#managing_object_id}
    */
    readonly managingObjectId?: string;
    /**
    * Maximum number of retries on temporary network failures. Defaults to 3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#retry_count ObserveProvider#retry_count}
    */
    readonly retryCount?: number;
    /**
    * Time between retries. Defaults to 3s.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#retry_wait ObserveProvider#retry_wait}
    */
    readonly retryWait?: string;
    /**
    * Skip making dry run API requests for dataset changes during the plan stage (for validation). This can speed up plan time, but means that certain classes of errors will not be detected until applying the changes (such as invalid OPAL).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#skip_dataset_dry_runs ObserveProvider#skip_dataset_dry_runs}
    */
    readonly skipDatasetDryRuns?: boolean | cdktn.IResolvable;
    /**
    * Source identifier comment. If null, fallback to `user_email`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#source_comment ObserveProvider#source_comment}
    */
    readonly sourceComment?: string;
    /**
    * Source identifier format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#source_format ObserveProvider#source_format}
    */
    readonly sourceFormat?: string;
    /**
    * User email. If supplied, `user_password` is also required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#user_email ObserveProvider#user_email}
    */
    readonly userEmail?: string;
    /**
    * Password for provided `user_email`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#user_password ObserveProvider#user_password}
    */
    readonly userPassword?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#alias ObserveProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs observe}
*/
export declare class ObserveProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "observe";
    /**
    * Generates CDKTN code for importing a ObserveProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObserveProvider to import
    * @param importFromId The id of the existing ObserveProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObserveProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs observe} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObserveProviderConfig
    */
    constructor(scope: Construct, id: string, config: ObserveProviderConfig);
    private _apiToken?;
    get apiToken(): string | undefined;
    set apiToken(value: string | undefined);
    resetApiToken(): void;
    get apiTokenInput(): string | undefined;
    private _customer?;
    get customer(): string | undefined;
    set customer(value: string | undefined);
    get customerInput(): string | undefined;
    private _defaultRematerializationMode?;
    get defaultRematerializationMode(): string | undefined;
    set defaultRematerializationMode(value: string | undefined);
    resetDefaultRematerializationMode(): void;
    get defaultRematerializationModeInput(): string | undefined;
    private _domain?;
    get domain(): string | undefined;
    set domain(value: string | undefined);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _exportObjectBindings?;
    get exportObjectBindings(): boolean | cdktn.IResolvable | undefined;
    set exportObjectBindings(value: boolean | cdktn.IResolvable | undefined);
    resetExportObjectBindings(): void;
    get exportObjectBindingsInput(): boolean | cdktn.IResolvable | undefined;
    private _flags?;
    get flags(): string | undefined;
    set flags(value: string | undefined);
    resetFlags(): void;
    get flagsInput(): string | undefined;
    private _httpClientTimeout?;
    get httpClientTimeout(): string | undefined;
    set httpClientTimeout(value: string | undefined);
    resetHttpClientTimeout(): void;
    get httpClientTimeoutInput(): string | undefined;
    private _insecure?;
    get insecure(): boolean | cdktn.IResolvable | undefined;
    set insecure(value: boolean | cdktn.IResolvable | undefined);
    resetInsecure(): void;
    get insecureInput(): boolean | cdktn.IResolvable | undefined;
    private _managingObjectId?;
    get managingObjectId(): string | undefined;
    set managingObjectId(value: string | undefined);
    resetManagingObjectId(): void;
    get managingObjectIdInput(): string | undefined;
    private _retryCount?;
    get retryCount(): number | undefined;
    set retryCount(value: number | undefined);
    resetRetryCount(): void;
    get retryCountInput(): number | undefined;
    private _retryWait?;
    get retryWait(): string | undefined;
    set retryWait(value: string | undefined);
    resetRetryWait(): void;
    get retryWaitInput(): string | undefined;
    private _skipDatasetDryRuns?;
    get skipDatasetDryRuns(): boolean | cdktn.IResolvable | undefined;
    set skipDatasetDryRuns(value: boolean | cdktn.IResolvable | undefined);
    resetSkipDatasetDryRuns(): void;
    get skipDatasetDryRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceComment?;
    get sourceComment(): string | undefined;
    set sourceComment(value: string | undefined);
    resetSourceComment(): void;
    get sourceCommentInput(): string | undefined;
    private _sourceFormat?;
    get sourceFormat(): string | undefined;
    set sourceFormat(value: string | undefined);
    resetSourceFormat(): void;
    get sourceFormatInput(): string | undefined;
    private _userEmail?;
    get userEmail(): string | undefined;
    set userEmail(value: string | undefined);
    resetUserEmail(): void;
    get userEmailInput(): string | undefined;
    private _userPassword?;
    get userPassword(): string | undefined;
    set userPassword(value: string | undefined);
    resetUserPassword(): void;
    get userPasswordInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
