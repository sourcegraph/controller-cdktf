import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataObserveRbacGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * RbacGroup ID. Either `name` or `id` must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/rbac_group#id DataObserveRbacGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * RbacGroup Name. Either `name` or `id` must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/rbac_group#name DataObserveRbacGroup#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/rbac_group observe_rbac_group}
*/
export declare class DataObserveRbacGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "observe_rbac_group";
    /**
    * Generates CDKTN code for importing a DataObserveRbacGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveRbacGroup to import
    * @param importFromId The id of the existing DataObserveRbacGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/rbac_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveRbacGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/rbac_group observe_rbac_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveRbacGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveRbacGroupConfig);
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get oid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
