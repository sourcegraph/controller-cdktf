import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatasetQueryFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The OID of the dataset this query filter applies to.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_query_filter#dataset DatasetQueryFilter#dataset}
    */
    readonly dataset: string;
    /**
    * Long-form description of the filter.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_query_filter#description DatasetQueryFilter#description}
    */
    readonly description?: string;
    /**
    * Whether the filter is disabled by the user.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_query_filter#disabled DatasetQueryFilter#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * OPAL boolean expression string for the filter. For example, `body ~ "phoneNumber"`.
    * This is an exclusion filter, so all observations matching the filter will be filtered out.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_query_filter#filter DatasetQueryFilter#filter}
    */
    readonly filter: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_query_filter#id DatasetQueryFilter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Human-readable name for the filter.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_query_filter#label DatasetQueryFilter#label}
    */
    readonly label: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_query_filter observe_dataset_query_filter}
*/
export declare class DatasetQueryFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_dataset_query_filter";
    /**
    * Generates CDKTN code for importing a DatasetQueryFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatasetQueryFilter to import
    * @param importFromId The id of the existing DatasetQueryFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_query_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatasetQueryFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_query_filter observe_dataset_query_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatasetQueryFilterConfig
    */
    constructor(scope: Construct, id: string, config: DatasetQueryFilterConfig);
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    get datasetInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    get errors(): string[];
    private _filter?;
    get filter(): string;
    set filter(value: string);
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    get oid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
