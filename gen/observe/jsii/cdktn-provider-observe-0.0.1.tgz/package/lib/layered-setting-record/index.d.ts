import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LayeredSettingRecordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#id LayeredSettingRecord#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#name LayeredSettingRecord#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#setting LayeredSettingRecord#setting}
    */
    readonly setting: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#target LayeredSettingRecord#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#value_bool LayeredSettingRecord#value_bool}
    */
    readonly valueBool?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#value_duration LayeredSettingRecord#value_duration}
    */
    readonly valueDuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#value_float64 LayeredSettingRecord#value_float64}
    */
    readonly valueFloat64?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#value_int64 LayeredSettingRecord#value_int64}
    */
    readonly valueInt64?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#value_string LayeredSettingRecord#value_string}
    */
    readonly valueString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#value_timestamp LayeredSettingRecord#value_timestamp}
    */
    readonly valueTimestamp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#workspace LayeredSettingRecord#workspace}
    */
    readonly workspace: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record observe_layered_setting_record}
*/
export declare class LayeredSettingRecord extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_layered_setting_record";
    /**
    * Generates CDKTN code for importing a LayeredSettingRecord resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LayeredSettingRecord to import
    * @param importFromId The id of the existing LayeredSettingRecord that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LayeredSettingRecord to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/layered_setting_record observe_layered_setting_record} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LayeredSettingRecordConfig
    */
    constructor(scope: Construct, id: string, config: LayeredSettingRecordConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _setting?;
    get setting(): string;
    set setting(value: string);
    get settingInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _valueBool?;
    get valueBool(): boolean | cdktn.IResolvable;
    set valueBool(value: boolean | cdktn.IResolvable);
    resetValueBool(): void;
    get valueBoolInput(): boolean | cdktn.IResolvable | undefined;
    private _valueDuration?;
    get valueDuration(): string;
    set valueDuration(value: string);
    resetValueDuration(): void;
    get valueDurationInput(): string | undefined;
    private _valueFloat64?;
    get valueFloat64(): number;
    set valueFloat64(value: number);
    resetValueFloat64(): void;
    get valueFloat64Input(): number | undefined;
    private _valueInt64?;
    get valueInt64(): number;
    set valueInt64(value: number);
    resetValueInt64(): void;
    get valueInt64Input(): number | undefined;
    private _valueString?;
    get valueString(): string;
    set valueString(value: string);
    resetValueString(): void;
    get valueStringInput(): string | undefined;
    private _valueTimestamp?;
    get valueTimestamp(): string;
    set valueTimestamp(value: string);
    resetValueTimestamp(): void;
    get valueTimestampInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
