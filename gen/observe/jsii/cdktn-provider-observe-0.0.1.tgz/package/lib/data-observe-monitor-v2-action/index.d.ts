import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataObserveMonitorV2ActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID for this object.
    *  One of either `id` or `name` must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2_action#id DataObserveMonitorV2Action#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the monitor v2 action.
    *  One of either `id` or `name` must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2_action#name DataObserveMonitorV2Action#name}
    */
    readonly name?: string;
    /**
    * OID of the workspace this object is contained in.
    *  Must be specified if looking up by name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2_action#workspace DataObserveMonitorV2Action#workspace}
    */
    readonly workspace?: string;
    /**
    * email block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2_action#email DataObserveMonitorV2Action#email}
    */
    readonly email?: DataObserveMonitorV2ActionEmail[] | cdktn.IResolvable;
    /**
    * webhook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2_action#webhook DataObserveMonitorV2Action#webhook}
    */
    readonly webhook?: DataObserveMonitorV2ActionWebhook[] | cdktn.IResolvable;
}
export interface DataObserveMonitorV2ActionEmail {
}
export declare function dataObserveMonitorV2ActionEmailToTerraform(struct?: DataObserveMonitorV2ActionEmail | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionEmailToHclTerraform(struct?: DataObserveMonitorV2ActionEmail | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionEmail | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionEmail | cdktn.IResolvable | undefined);
    get addresses(): string[];
    get body(): string;
    get fragments(): string;
    get subject(): string;
    get users(): string[];
}
export declare class DataObserveMonitorV2ActionEmailList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionEmail[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionEmailOutputReference;
}
export interface DataObserveMonitorV2ActionWebhookHeaders {
}
export declare function dataObserveMonitorV2ActionWebhookHeadersToTerraform(struct?: DataObserveMonitorV2ActionWebhookHeaders | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionWebhookHeadersToHclTerraform(struct?: DataObserveMonitorV2ActionWebhookHeaders | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionWebhookHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionWebhookHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionWebhookHeaders | cdktn.IResolvable | undefined);
    get header(): string;
    get value(): string;
}
export declare class DataObserveMonitorV2ActionWebhookHeadersList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionWebhookHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionWebhookHeadersOutputReference;
}
export interface DataObserveMonitorV2ActionWebhook {
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2_action#headers DataObserveMonitorV2Action#headers}
    */
    readonly headers?: DataObserveMonitorV2ActionWebhookHeaders[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorV2ActionWebhookToTerraform(struct?: DataObserveMonitorV2ActionWebhook | cdktn.IResolvable): any;
export declare function dataObserveMonitorV2ActionWebhookToHclTerraform(struct?: DataObserveMonitorV2ActionWebhook | cdktn.IResolvable): any;
export declare class DataObserveMonitorV2ActionWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorV2ActionWebhook | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorV2ActionWebhook | cdktn.IResolvable | undefined);
    get body(): string;
    get fragments(): string;
    get method(): string;
    get url(): string;
    private _headers;
    get headers(): DataObserveMonitorV2ActionWebhookHeadersList;
    putHeaders(value: DataObserveMonitorV2ActionWebhookHeaders[] | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | DataObserveMonitorV2ActionWebhookHeaders[] | undefined;
}
export declare class DataObserveMonitorV2ActionWebhookList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorV2ActionWebhook[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorV2ActionWebhookOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2_action observe_monitor_v2_action}
*/
export declare class DataObserveMonitorV2Action extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "observe_monitor_v2_action";
    /**
    * Generates CDKTN code for importing a DataObserveMonitorV2Action resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveMonitorV2Action to import
    * @param importFromId The id of the existing DataObserveMonitorV2Action that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveMonitorV2Action to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_v2_action observe_monitor_v2_action} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveMonitorV2ActionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveMonitorV2ActionConfig);
    get description(): string;
    get destination(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get oid(): string;
    get type(): string;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
    private _email;
    get email(): DataObserveMonitorV2ActionEmailList;
    putEmail(value: DataObserveMonitorV2ActionEmail[] | cdktn.IResolvable): void;
    resetEmail(): void;
    get emailInput(): cdktn.IResolvable | DataObserveMonitorV2ActionEmail[] | undefined;
    private _webhook;
    get webhook(): DataObserveMonitorV2ActionWebhookList;
    putWebhook(value: DataObserveMonitorV2ActionWebhook[] | cdktn.IResolvable): void;
    resetWebhook(): void;
    get webhookInput(): cdktn.IResolvable | DataObserveMonitorV2ActionWebhook[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
