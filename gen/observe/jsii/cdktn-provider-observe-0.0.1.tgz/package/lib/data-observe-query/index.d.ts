import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataObserveQueryConfig extends cdktn.TerraformMetaArguments {
    /**
    * End timestamp. If omitted, query will be periodically re-run until results are returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#end DataObserveQuery#end}
    */
    readonly end?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#id DataObserveQuery#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#inputs DataObserveQuery#inputs}
    */
    readonly inputs: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#limit DataObserveQuery#limit}
    */
    readonly limit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#start DataObserveQuery#start}
    */
    readonly start?: string;
    /**
    * assert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#assert DataObserveQuery#assert}
    */
    readonly assert?: DataObserveQueryAssert;
    /**
    * poll block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#poll DataObserveQuery#poll}
    */
    readonly poll?: DataObserveQueryPoll;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#stage DataObserveQuery#stage}
    */
    readonly stage: DataObserveQueryStage[] | cdktn.IResolvable;
}
export interface DataObserveQueryAssert {
    /**
    * Filename containing expected query output.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#golden_file DataObserveQuery#golden_file}
    */
    readonly goldenFile: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#update DataObserveQuery#update}
    */
    readonly update?: boolean | cdktn.IResolvable;
}
export declare function dataObserveQueryAssertToTerraform(struct?: DataObserveQueryAssertOutputReference | DataObserveQueryAssert): any;
export declare function dataObserveQueryAssertToHclTerraform(struct?: DataObserveQueryAssertOutputReference | DataObserveQueryAssert): any;
export declare class DataObserveQueryAssertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataObserveQueryAssert | undefined;
    set internalValue(value: DataObserveQueryAssert | undefined);
    private _goldenFile?;
    get goldenFile(): string;
    set goldenFile(value: string);
    get goldenFileInput(): string | undefined;
    private _update?;
    get update(): boolean | cdktn.IResolvable;
    set update(value: boolean | cdktn.IResolvable);
    resetUpdate(): void;
    get updateInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataObserveQueryPoll {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#interval DataObserveQuery#interval}
    */
    readonly interval?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#timeout DataObserveQuery#timeout}
    */
    readonly timeout?: string;
}
export declare function dataObserveQueryPollToTerraform(struct?: DataObserveQueryPollOutputReference | DataObserveQueryPoll): any;
export declare function dataObserveQueryPollToHclTerraform(struct?: DataObserveQueryPollOutputReference | DataObserveQueryPoll): any;
export declare class DataObserveQueryPollOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataObserveQueryPoll | undefined;
    set internalValue(value: DataObserveQueryPoll | undefined);
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    private _timeout?;
    get timeout(): string;
    set timeout(value: string);
    resetTimeout(): void;
    get timeoutInput(): string | undefined;
}
export interface DataObserveQueryStage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#alias DataObserveQuery#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#input DataObserveQuery#input}
    */
    readonly input?: string;
    /**
    * A boolean flag used to specify the output stage. Should be used only for
    * a stage preceding the last stage. The last stage is an output stage by default.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#output_stage DataObserveQuery#output_stage}
    */
    readonly outputStage?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#pipeline DataObserveQuery#pipeline}
    */
    readonly pipeline?: string;
}
export declare function dataObserveQueryStageToTerraform(struct?: DataObserveQueryStage | cdktn.IResolvable): any;
export declare function dataObserveQueryStageToHclTerraform(struct?: DataObserveQueryStage | cdktn.IResolvable): any;
export declare class DataObserveQueryStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveQueryStage | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveQueryStage | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    resetInput(): void;
    get inputInput(): string | undefined;
    private _outputStage?;
    get outputStage(): boolean | cdktn.IResolvable;
    set outputStage(value: boolean | cdktn.IResolvable);
    resetOutputStage(): void;
    get outputStageInput(): boolean | cdktn.IResolvable | undefined;
    private _pipeline?;
    get pipeline(): string;
    set pipeline(value: string);
    resetPipeline(): void;
    get pipelineInput(): string | undefined;
}
export declare class DataObserveQueryStageList extends cdktn.ComplexList {
    internalValue?: DataObserveQueryStage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveQueryStageOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query observe_query}
*/
export declare class DataObserveQuery extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "observe_query";
    /**
    * Generates CDKTN code for importing a DataObserveQuery resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveQuery to import
    * @param importFromId The id of the existing DataObserveQuery that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveQuery to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/query observe_query} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveQueryConfig
    */
    constructor(scope: Construct, id: string, config: DataObserveQueryConfig);
    private _end?;
    get end(): string;
    set end(value: string);
    resetEnd(): void;
    get endInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputs?;
    get inputs(): {
        [key: string]: string;
    };
    set inputs(value: {
        [key: string]: string;
    });
    get inputsInput(): {
        [key: string]: string;
    } | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    get result(): string;
    private _start?;
    get start(): string;
    set start(value: string);
    resetStart(): void;
    get startInput(): string | undefined;
    private _assert;
    get assert(): DataObserveQueryAssertOutputReference;
    putAssert(value: DataObserveQueryAssert): void;
    resetAssert(): void;
    get assertInput(): DataObserveQueryAssert | undefined;
    private _poll;
    get poll(): DataObserveQueryPollOutputReference;
    putPoll(value: DataObserveQueryPoll): void;
    resetPoll(): void;
    get pollInput(): DataObserveQueryPoll | undefined;
    private _stage;
    get stage(): DataObserveQueryStageList;
    putStage(value: DataObserveQueryStage[] | cdktn.IResolvable): void;
    get stageInput(): cdktn.IResolvable | DataObserveQueryStage[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
