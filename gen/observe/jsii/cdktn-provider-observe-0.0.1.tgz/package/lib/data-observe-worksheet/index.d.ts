import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataObserveWorksheetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Worksheet ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/worksheet#id DataObserveWorksheet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * OID of workspace worksheet is contained in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/worksheet#workspace DataObserveWorksheet#workspace}
    */
    readonly workspace: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/worksheet observe_worksheet}
*/
export declare class DataObserveWorksheet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "observe_worksheet";
    /**
    * Generates CDKTN code for importing a DataObserveWorksheet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveWorksheet to import
    * @param importFromId The id of the existing DataObserveWorksheet that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/worksheet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveWorksheet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/worksheet observe_worksheet} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveWorksheetConfig
    */
    constructor(scope: Construct, id: string, config: DataObserveWorksheetConfig);
    get iconUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    get oid(): string;
    get queries(): string;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
