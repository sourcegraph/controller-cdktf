import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataObserveMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Resource ID for this object.
    * One of `id` or `name` must be provided
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#id DataObserveMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Monitor name. Must be unique within workspace.
    * One of `name` or `id` must be set. If `name` is provided, `workspace` must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#name DataObserveMonitor#name}
    */
    readonly name?: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#workspace DataObserveMonitor#workspace}
    */
    readonly workspace?: string;
    /**
    * notification_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#notification_spec DataObserveMonitor#notification_spec}
    */
    readonly notificationSpec?: DataObserveMonitorNotificationSpec[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#rule DataObserveMonitor#rule}
    */
    readonly rule?: DataObserveMonitorRule[] | cdktn.IResolvable;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#stage DataObserveMonitor#stage}
    */
    readonly stage?: DataObserveMonitorStage[] | cdktn.IResolvable;
}
export interface DataObserveMonitorNotificationSpec {
}
export declare function dataObserveMonitorNotificationSpecToTerraform(struct?: DataObserveMonitorNotificationSpec | cdktn.IResolvable): any;
export declare function dataObserveMonitorNotificationSpecToHclTerraform(struct?: DataObserveMonitorNotificationSpec | cdktn.IResolvable): any;
export declare class DataObserveMonitorNotificationSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorNotificationSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorNotificationSpec | cdktn.IResolvable | undefined);
    get importance(): string;
    get merge(): string;
    get notifyOnClose(): cdktn.IResolvable;
    get notifyOnReminder(): cdktn.IResolvable;
    get reminderFrequency(): string;
}
export declare class DataObserveMonitorNotificationSpecList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorNotificationSpec[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorNotificationSpecOutputReference;
}
export interface DataObserveMonitorRuleChange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#compare_function DataObserveMonitor#compare_function}
    */
    readonly compareFunction: string;
}
export declare function dataObserveMonitorRuleChangeToTerraform(struct?: DataObserveMonitorRuleChange | cdktn.IResolvable): any;
export declare function dataObserveMonitorRuleChangeToHclTerraform(struct?: DataObserveMonitorRuleChange | cdktn.IResolvable): any;
export declare class DataObserveMonitorRuleChangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleChange | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleChange | cdktn.IResolvable | undefined);
    get aggregateFunction(): string;
    get baselineTime(): string;
    get changeType(): string;
    private _compareFunction?;
    get compareFunction(): string;
    set compareFunction(value: string);
    get compareFunctionInput(): string | undefined;
    get compareValues(): number[];
    get lookbackTime(): string;
}
export declare class DataObserveMonitorRuleChangeList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorRuleChange[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleChangeOutputReference;
}
export interface DataObserveMonitorRuleCount {
}
export declare function dataObserveMonitorRuleCountToTerraform(struct?: DataObserveMonitorRuleCount | cdktn.IResolvable): any;
export declare function dataObserveMonitorRuleCountToHclTerraform(struct?: DataObserveMonitorRuleCount | cdktn.IResolvable): any;
export declare class DataObserveMonitorRuleCountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleCount | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleCount | cdktn.IResolvable | undefined);
    get compareFunction(): string;
    get compareValues(): number[];
    get lookbackTime(): string;
}
export declare class DataObserveMonitorRuleCountList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorRuleCount[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleCountOutputReference;
}
export interface DataObserveMonitorRuleFacet {
}
export declare function dataObserveMonitorRuleFacetToTerraform(struct?: DataObserveMonitorRuleFacet | cdktn.IResolvable): any;
export declare function dataObserveMonitorRuleFacetToHclTerraform(struct?: DataObserveMonitorRuleFacet | cdktn.IResolvable): any;
export declare class DataObserveMonitorRuleFacetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleFacet | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleFacet | cdktn.IResolvable | undefined);
    get facetFunction(): string;
    get facetValues(): string[];
    get lookbackTime(): string;
    get timeFunction(): string;
    get timeValue(): number;
}
export declare class DataObserveMonitorRuleFacetList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorRuleFacet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleFacetOutputReference;
}
export interface DataObserveMonitorRuleGroupByGroup {
}
export declare function dataObserveMonitorRuleGroupByGroupToTerraform(struct?: DataObserveMonitorRuleGroupByGroup | cdktn.IResolvable): any;
export declare function dataObserveMonitorRuleGroupByGroupToHclTerraform(struct?: DataObserveMonitorRuleGroupByGroup | cdktn.IResolvable): any;
export declare class DataObserveMonitorRuleGroupByGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleGroupByGroup | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleGroupByGroup | cdktn.IResolvable | undefined);
    get columns(): string[];
    get groupName(): string;
}
export declare class DataObserveMonitorRuleGroupByGroupList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorRuleGroupByGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleGroupByGroupOutputReference;
}
export interface DataObserveMonitorRuleLog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#compare_values DataObserveMonitor#compare_values}
    */
    readonly compareValues?: number[];
    /**
    * Short summary or comment of how the data for monitor is queried.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#expression_summary DataObserveMonitor#expression_summary}
    */
    readonly expressionSummary?: string;
    /**
    * An id of the stage that is used to generate logs for preview. This is usually a stage before aggregation.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#log_stage_id DataObserveMonitor#log_stage_id}
    */
    readonly logStageId?: string;
    /**
    * ID of the dataset that contains logs for preview.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#source_log_dataset DataObserveMonitor#source_log_dataset}
    */
    readonly sourceLogDataset?: string;
}
export declare function dataObserveMonitorRuleLogToTerraform(struct?: DataObserveMonitorRuleLog | cdktn.IResolvable): any;
export declare function dataObserveMonitorRuleLogToHclTerraform(struct?: DataObserveMonitorRuleLog | cdktn.IResolvable): any;
export declare class DataObserveMonitorRuleLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleLog | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleLog | cdktn.IResolvable | undefined);
    get compareFunction(): string;
    private _compareValues?;
    get compareValues(): number[];
    set compareValues(value: number[]);
    resetCompareValues(): void;
    get compareValuesInput(): number[] | undefined;
    private _expressionSummary?;
    get expressionSummary(): string;
    set expressionSummary(value: string);
    resetExpressionSummary(): void;
    get expressionSummaryInput(): string | undefined;
    private _logStageId?;
    get logStageId(): string;
    set logStageId(value: string);
    resetLogStageId(): void;
    get logStageIdInput(): string | undefined;
    get lookbackTime(): string;
    private _sourceLogDataset?;
    get sourceLogDataset(): string;
    set sourceLogDataset(value: string);
    resetSourceLogDataset(): void;
    get sourceLogDatasetInput(): string | undefined;
}
export declare class DataObserveMonitorRuleLogList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorRuleLog[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleLogOutputReference;
}
export interface DataObserveMonitorRulePromote {
}
export declare function dataObserveMonitorRulePromoteToTerraform(struct?: DataObserveMonitorRulePromote | cdktn.IResolvable): any;
export declare function dataObserveMonitorRulePromoteToHclTerraform(struct?: DataObserveMonitorRulePromote | cdktn.IResolvable): any;
export declare class DataObserveMonitorRulePromoteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRulePromote | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRulePromote | cdktn.IResolvable | undefined);
    get descriptionField(): string;
    get kindField(): string;
    get primaryKey(): string[];
}
export declare class DataObserveMonitorRulePromoteList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorRulePromote[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRulePromoteOutputReference;
}
export interface DataObserveMonitorRuleThreshold {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#compare_function DataObserveMonitor#compare_function}
    */
    readonly compareFunction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#compare_values DataObserveMonitor#compare_values}
    */
    readonly compareValues?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#lookback_time DataObserveMonitor#lookback_time}
    */
    readonly lookbackTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#threshold_agg_function DataObserveMonitor#threshold_agg_function}
    */
    readonly thresholdAggFunction?: string;
}
export declare function dataObserveMonitorRuleThresholdToTerraform(struct?: DataObserveMonitorRuleThreshold | cdktn.IResolvable): any;
export declare function dataObserveMonitorRuleThresholdToHclTerraform(struct?: DataObserveMonitorRuleThreshold | cdktn.IResolvable): any;
export declare class DataObserveMonitorRuleThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleThreshold | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleThreshold | cdktn.IResolvable | undefined);
    private _compareFunction?;
    get compareFunction(): string;
    set compareFunction(value: string);
    resetCompareFunction(): void;
    get compareFunctionInput(): string | undefined;
    private _compareValues?;
    get compareValues(): number[];
    set compareValues(value: number[]);
    resetCompareValues(): void;
    get compareValuesInput(): number[] | undefined;
    private _lookbackTime?;
    get lookbackTime(): string;
    set lookbackTime(value: string);
    resetLookbackTime(): void;
    get lookbackTimeInput(): string | undefined;
    private _thresholdAggFunction?;
    get thresholdAggFunction(): string;
    set thresholdAggFunction(value: string);
    resetThresholdAggFunction(): void;
    get thresholdAggFunctionInput(): string | undefined;
}
export declare class DataObserveMonitorRuleThresholdList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorRuleThreshold[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleThresholdOutputReference;
}
export interface DataObserveMonitorRule {
    /**
    * change block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#change DataObserveMonitor#change}
    */
    readonly change?: DataObserveMonitorRuleChange[] | cdktn.IResolvable;
    /**
    * count block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#count DataObserveMonitor#count}
    */
    readonly count?: DataObserveMonitorRuleCount[] | cdktn.IResolvable;
    /**
    * facet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#facet DataObserveMonitor#facet}
    */
    readonly facet?: DataObserveMonitorRuleFacet[] | cdktn.IResolvable;
    /**
    * group_by_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#group_by_group DataObserveMonitor#group_by_group}
    */
    readonly groupByGroup?: DataObserveMonitorRuleGroupByGroup[] | cdktn.IResolvable;
    /**
    * log block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#log DataObserveMonitor#log}
    */
    readonly log?: DataObserveMonitorRuleLog[] | cdktn.IResolvable;
    /**
    * promote block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#promote DataObserveMonitor#promote}
    */
    readonly promote?: DataObserveMonitorRulePromote[] | cdktn.IResolvable;
    /**
    * threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#threshold DataObserveMonitor#threshold}
    */
    readonly threshold?: DataObserveMonitorRuleThreshold[] | cdktn.IResolvable;
}
export declare function dataObserveMonitorRuleToTerraform(struct?: DataObserveMonitorRule | cdktn.IResolvable): any;
export declare function dataObserveMonitorRuleToHclTerraform(struct?: DataObserveMonitorRule | cdktn.IResolvable): any;
export declare class DataObserveMonitorRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRule | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRule | cdktn.IResolvable | undefined);
    get sourceColumn(): string;
    private _change;
    get change(): DataObserveMonitorRuleChangeList;
    putChange(value: DataObserveMonitorRuleChange[] | cdktn.IResolvable): void;
    resetChange(): void;
    get changeInput(): cdktn.IResolvable | DataObserveMonitorRuleChange[] | undefined;
    private _count;
    get count(): DataObserveMonitorRuleCountList;
    putCount(value: DataObserveMonitorRuleCount[] | cdktn.IResolvable): void;
    resetCount(): void;
    get countInput(): cdktn.IResolvable | DataObserveMonitorRuleCount[] | undefined;
    private _facet;
    get facet(): DataObserveMonitorRuleFacetList;
    putFacet(value: DataObserveMonitorRuleFacet[] | cdktn.IResolvable): void;
    resetFacet(): void;
    get facetInput(): cdktn.IResolvable | DataObserveMonitorRuleFacet[] | undefined;
    private _groupByGroup;
    get groupByGroup(): DataObserveMonitorRuleGroupByGroupList;
    putGroupByGroup(value: DataObserveMonitorRuleGroupByGroup[] | cdktn.IResolvable): void;
    resetGroupByGroup(): void;
    get groupByGroupInput(): cdktn.IResolvable | DataObserveMonitorRuleGroupByGroup[] | undefined;
    private _log;
    get log(): DataObserveMonitorRuleLogList;
    putLog(value: DataObserveMonitorRuleLog[] | cdktn.IResolvable): void;
    resetLog(): void;
    get logInput(): cdktn.IResolvable | DataObserveMonitorRuleLog[] | undefined;
    private _promote;
    get promote(): DataObserveMonitorRulePromoteList;
    putPromote(value: DataObserveMonitorRulePromote[] | cdktn.IResolvable): void;
    resetPromote(): void;
    get promoteInput(): cdktn.IResolvable | DataObserveMonitorRulePromote[] | undefined;
    private _threshold;
    get threshold(): DataObserveMonitorRuleThresholdList;
    putThreshold(value: DataObserveMonitorRuleThreshold[] | cdktn.IResolvable): void;
    resetThreshold(): void;
    get thresholdInput(): cdktn.IResolvable | DataObserveMonitorRuleThreshold[] | undefined;
}
export declare class DataObserveMonitorRuleList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleOutputReference;
}
export interface DataObserveMonitorStage {
}
export declare function dataObserveMonitorStageToTerraform(struct?: DataObserveMonitorStage | cdktn.IResolvable): any;
export declare function dataObserveMonitorStageToHclTerraform(struct?: DataObserveMonitorStage | cdktn.IResolvable): any;
export declare class DataObserveMonitorStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorStage | cdktn.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorStage | cdktn.IResolvable | undefined);
    get alias(): string;
    get input(): string;
    get outputStage(): cdktn.IResolvable;
    get pipeline(): string;
}
export declare class DataObserveMonitorStageList extends cdktn.ComplexList {
    internalValue?: DataObserveMonitorStage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorStageOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor observe_monitor}
*/
export declare class DataObserveMonitor extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "observe_monitor";
    /**
    * Generates CDKTN code for importing a DataObserveMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveMonitor to import
    * @param importFromId The id of the existing DataObserveMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor observe_monitor} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveMonitorConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveMonitorConfig);
    get bindings(): string;
    get comment(): string;
    get definition(): string;
    get description(): string;
    get disabled(): cdktn.IResolvable;
    get iconUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputs;
    get inputs(): cdktn.StringMap;
    get isTemplate(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get oid(): string;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
    private _notificationSpec;
    get notificationSpec(): DataObserveMonitorNotificationSpecList;
    putNotificationSpec(value: DataObserveMonitorNotificationSpec[] | cdktn.IResolvable): void;
    resetNotificationSpec(): void;
    get notificationSpecInput(): cdktn.IResolvable | DataObserveMonitorNotificationSpec[] | undefined;
    private _rule;
    get rule(): DataObserveMonitorRuleList;
    putRule(value: DataObserveMonitorRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | DataObserveMonitorRule[] | undefined;
    private _stage;
    get stage(): DataObserveMonitorStageList;
    putStage(value: DataObserveMonitorStage[] | cdktn.IResolvable): void;
    resetStage(): void;
    get stageInput(): cdktn.IResolvable | DataObserveMonitorStage[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
