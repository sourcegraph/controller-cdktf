import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DefaultDashboardConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/default_dashboard#dashboard DefaultDashboard#dashboard}
    */
    readonly dashboard: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/default_dashboard#dataset DefaultDashboard#dataset}
    */
    readonly dataset: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/default_dashboard#id DefaultDashboard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/default_dashboard observe_default_dashboard}
*/
export declare class DefaultDashboard extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_default_dashboard";
    /**
    * Generates CDKTN code for importing a DefaultDashboard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DefaultDashboard to import
    * @param importFromId The id of the existing DefaultDashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/default_dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DefaultDashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/default_dashboard observe_default_dashboard} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DefaultDashboardConfig
    */
    constructor(scope: Construct, id: string, config: DefaultDashboardConfig);
    private _dashboard?;
    get dashboard(): string;
    set dashboard(value: string);
    get dashboardInput(): string | undefined;
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    get datasetInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
