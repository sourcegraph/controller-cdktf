import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SourceDatasetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#batch_seq_field SourceDataset#batch_seq_field}
    */
    readonly batchSeqField?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#description SourceDataset#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#freshness SourceDataset#freshness}
    */
    readonly freshness?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#icon_url SourceDataset#icon_url}
    */
    readonly iconUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#id SourceDataset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#is_insert_only SourceDataset#is_insert_only}
    */
    readonly isInsertOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#name SourceDataset#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#schema SourceDataset#schema}
    */
    readonly schema: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#source_update_table_name SourceDataset#source_update_table_name}
    */
    readonly sourceUpdateTableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#table_name SourceDataset#table_name}
    */
    readonly tableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#valid_from_field SourceDataset#valid_from_field}
    */
    readonly validFromField: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#workspace SourceDataset#workspace}
    */
    readonly workspace: string;
    /**
    * field block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#field SourceDataset#field}
    */
    readonly field: SourceDatasetField[] | cdktn.IResolvable;
}
export interface SourceDatasetField {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#is_const SourceDataset#is_const}
    */
    readonly isConst?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#is_enum SourceDataset#is_enum}
    */
    readonly isEnum?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#is_hidden SourceDataset#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#is_metric SourceDataset#is_metric}
    */
    readonly isMetric?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#is_searchable SourceDataset#is_searchable}
    */
    readonly isSearchable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#name SourceDataset#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#sql_type SourceDataset#sql_type}
    */
    readonly sqlType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#type SourceDataset#type}
    */
    readonly type: string;
}
export declare function sourceDatasetFieldToTerraform(struct?: SourceDatasetField | cdktn.IResolvable): any;
export declare function sourceDatasetFieldToHclTerraform(struct?: SourceDatasetField | cdktn.IResolvable): any;
export declare class SourceDatasetFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SourceDatasetField | cdktn.IResolvable | undefined;
    set internalValue(value: SourceDatasetField | cdktn.IResolvable | undefined);
    private _isConst?;
    get isConst(): boolean | cdktn.IResolvable;
    set isConst(value: boolean | cdktn.IResolvable);
    resetIsConst(): void;
    get isConstInput(): boolean | cdktn.IResolvable | undefined;
    private _isEnum?;
    get isEnum(): boolean | cdktn.IResolvable;
    set isEnum(value: boolean | cdktn.IResolvable);
    resetIsEnum(): void;
    get isEnumInput(): boolean | cdktn.IResolvable | undefined;
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _isMetric?;
    get isMetric(): boolean | cdktn.IResolvable;
    set isMetric(value: boolean | cdktn.IResolvable);
    resetIsMetric(): void;
    get isMetricInput(): boolean | cdktn.IResolvable | undefined;
    private _isSearchable?;
    get isSearchable(): boolean | cdktn.IResolvable;
    set isSearchable(value: boolean | cdktn.IResolvable);
    resetIsSearchable(): void;
    get isSearchableInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sqlType?;
    get sqlType(): string;
    set sqlType(value: string);
    get sqlTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SourceDatasetFieldList extends cdktn.ComplexList {
    internalValue?: SourceDatasetField[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SourceDatasetFieldOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset observe_source_dataset}
*/
export declare class SourceDataset extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_source_dataset";
    /**
    * Generates CDKTN code for importing a SourceDataset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SourceDataset to import
    * @param importFromId The id of the existing SourceDataset that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SourceDataset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/source_dataset observe_source_dataset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SourceDatasetConfig
    */
    constructor(scope: Construct, id: string, config: SourceDatasetConfig);
    private _batchSeqField?;
    get batchSeqField(): string;
    set batchSeqField(value: string);
    resetBatchSeqField(): void;
    get batchSeqFieldInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _freshness?;
    get freshness(): string;
    set freshness(value: string);
    resetFreshness(): void;
    get freshnessInput(): string | undefined;
    private _iconUrl?;
    get iconUrl(): string;
    set iconUrl(value: string);
    resetIconUrl(): void;
    get iconUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isInsertOnly?;
    get isInsertOnly(): boolean | cdktn.IResolvable;
    set isInsertOnly(value: boolean | cdktn.IResolvable);
    resetIsInsertOnly(): void;
    get isInsertOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _sourceUpdateTableName?;
    get sourceUpdateTableName(): string;
    set sourceUpdateTableName(value: string);
    get sourceUpdateTableNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _validFromField?;
    get validFromField(): string;
    set validFromField(value: string);
    get validFromFieldInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _field;
    get field(): SourceDatasetFieldList;
    putField(value: SourceDatasetField[] | cdktn.IResolvable): void;
    get fieldInput(): cdktn.IResolvable | SourceDatasetField[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
