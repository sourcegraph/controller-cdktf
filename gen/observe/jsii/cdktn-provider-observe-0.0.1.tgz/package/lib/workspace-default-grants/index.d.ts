import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceDefaultGrantsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/workspace_default_grants#id WorkspaceDefaultGrants#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/workspace_default_grants#group WorkspaceDefaultGrants#group}
    */
    readonly group?: WorkspaceDefaultGrantsGroup[] | cdktn.IResolvable;
}
export interface WorkspaceDefaultGrantsGroup {
    /**
    * Limits which object types this default grant applies to. Must be one of
    * `dashboard`, `datastream`, `monitor`, `referencetable`, or `worksheet`.
    * If not set, this default grant applies to all object types.
    * Note: Datasets are not represented here as they inherit default grants
    * based on their input datasets instead.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/workspace_default_grants#object_types WorkspaceDefaultGrants#object_types}
    */
    readonly objectTypes?: string[];
    /**
    * The Observe ID for the group to grant access to.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/workspace_default_grants#oid WorkspaceDefaultGrants#oid}
    */
    readonly oid: string;
    /**
    * The permission to grant. Must be one of `view` or `edit`.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/workspace_default_grants#permission WorkspaceDefaultGrants#permission}
    */
    readonly permission: string;
}
export declare function workspaceDefaultGrantsGroupToTerraform(struct?: WorkspaceDefaultGrantsGroup | cdktn.IResolvable): any;
export declare function workspaceDefaultGrantsGroupToHclTerraform(struct?: WorkspaceDefaultGrantsGroup | cdktn.IResolvable): any;
export declare class WorkspaceDefaultGrantsGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkspaceDefaultGrantsGroup | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceDefaultGrantsGroup | cdktn.IResolvable | undefined);
    private _objectTypes?;
    get objectTypes(): string[];
    set objectTypes(value: string[]);
    resetObjectTypes(): void;
    get objectTypesInput(): string[] | undefined;
    private _oid?;
    get oid(): string;
    set oid(value: string);
    get oidInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export declare class WorkspaceDefaultGrantsGroupList extends cdktn.ComplexList {
    internalValue?: WorkspaceDefaultGrantsGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkspaceDefaultGrantsGroupOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/workspace_default_grants observe_workspace_default_grants}
*/
export declare class WorkspaceDefaultGrants extends cdktn.TerraformResource {
    static readonly tfResourceType = "observe_workspace_default_grants";
    /**
    * Generates CDKTN code for importing a WorkspaceDefaultGrants resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceDefaultGrants to import
    * @param importFromId The id of the existing WorkspaceDefaultGrants that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/workspace_default_grants#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceDefaultGrants to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/workspace_default_grants observe_workspace_default_grants} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceDefaultGrantsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: WorkspaceDefaultGrantsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _group;
    get group(): WorkspaceDefaultGrantsGroupList;
    putGroup(value: WorkspaceDefaultGrantsGroup[] | cdktn.IResolvable): void;
    resetGroup(): void;
    get groupInput(): cdktn.IResolvable | WorkspaceDefaultGrantsGroup[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
