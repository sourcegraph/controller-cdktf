import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveMonitorActionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Resource ID for this object.
    * One of `id` or `name` must be provided
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_action#id DataObserveMonitorAction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Monitor name. Must be unique within workspace.
    * One of `name` or `id` must be set. If `name` is provided, `workspace` must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_action#name DataObserveMonitorAction#name}
    */
    readonly name?: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_action#workspace DataObserveMonitorAction#workspace}
    */
    readonly workspace?: string;
}
export interface DataObserveMonitorActionEmail {
}
export declare function dataObserveMonitorActionEmailToTerraform(struct?: DataObserveMonitorActionEmail): any;
export declare function dataObserveMonitorActionEmailToHclTerraform(struct?: DataObserveMonitorActionEmail): any;
export declare class DataObserveMonitorActionEmailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorActionEmail | undefined;
    set internalValue(value: DataObserveMonitorActionEmail | undefined);
    get bodyTemplate(): string;
    get isHtml(): cdktf.IResolvable;
    get subjectTemplate(): string;
    get targetAddresses(): string[];
}
export declare class DataObserveMonitorActionEmailList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorActionEmailOutputReference;
}
export interface DataObserveMonitorActionWebhook {
}
export declare function dataObserveMonitorActionWebhookToTerraform(struct?: DataObserveMonitorActionWebhook): any;
export declare function dataObserveMonitorActionWebhookToHclTerraform(struct?: DataObserveMonitorActionWebhook): any;
export declare class DataObserveMonitorActionWebhookOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorActionWebhook | undefined;
    set internalValue(value: DataObserveMonitorActionWebhook | undefined);
    get bodyTemplate(): string;
    private _headers;
    get headers(): cdktf.StringMap;
    get method(): string;
    get urlTemplate(): string;
}
export declare class DataObserveMonitorActionWebhookList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorActionWebhookOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_action observe_monitor_action}
*/
export declare class DataObserveMonitorAction extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_monitor_action";
    /**
    * Generates CDKTF code for importing a DataObserveMonitorAction resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveMonitorAction to import
    * @param importFromId The id of the existing DataObserveMonitorAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveMonitorAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor_action observe_monitor_action} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveMonitorActionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveMonitorActionConfig);
    get description(): string;
    private _email;
    get email(): DataObserveMonitorActionEmailList;
    get iconUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get notifyOnClose(): cdktf.IResolvable;
    get oid(): string;
    get rateLimit(): string;
    private _webhook;
    get webhook(): DataObserveMonitorActionWebhookList;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
