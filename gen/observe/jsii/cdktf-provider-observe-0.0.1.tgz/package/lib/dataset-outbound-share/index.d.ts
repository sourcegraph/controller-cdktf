import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DatasetOutboundShareConfig extends cdktf.TerraformMetaArguments {
    /**
    * If set to true, the shared view will have change tracking enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#change_tracking DatasetOutboundShare#change_tracking}
    */
    readonly changeTracking?: boolean | cdktf.IResolvable;
    /**
    * The OID of the dataset to be shared
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#dataset DatasetOutboundShare#dataset}
    */
    readonly dataset: string;
    /**
    * A description of the dataset sharing configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#description DatasetOutboundShare#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#folder DatasetOutboundShare#folder}
    */
    readonly folder?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#freshness_goal DatasetOutboundShare#freshness_goal}
    */
    readonly freshnessGoal: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#id DatasetOutboundShare#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A descriptive name for the dataset sharing configuration. Displayed within Observe, not used in Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#name DatasetOutboundShare#name}
    */
    readonly name: string;
    /**
    * The OID of the Observe Snowflake outbound share where the dataset will be shared
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#outbound_share DatasetOutboundShare#outbound_share}
    */
    readonly outboundShare: string;
    /**
    * The name of the schema within the shared database where the dataset view will be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#schema_name DatasetOutboundShare#schema_name}
    */
    readonly schemaName: string;
    /**
    * The name of the view that will be created in the shared database, within the specified schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#view_name DatasetOutboundShare#view_name}
    */
    readonly viewName: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#workspace DatasetOutboundShare#workspace}
    */
    readonly workspace: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#timeouts DatasetOutboundShare#timeouts}
    */
    readonly timeouts?: DatasetOutboundShareTimeouts;
}
export interface DatasetOutboundShareTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#create DatasetOutboundShare#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#update DatasetOutboundShare#update}
    */
    readonly update?: string;
}
export declare function datasetOutboundShareTimeoutsToTerraform(struct?: DatasetOutboundShareTimeouts | cdktf.IResolvable): any;
export declare function datasetOutboundShareTimeoutsToHclTerraform(struct?: DatasetOutboundShareTimeouts | cdktf.IResolvable): any;
export declare class DatasetOutboundShareTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatasetOutboundShareTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DatasetOutboundShareTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share observe_dataset_outbound_share}
*/
export declare class DatasetOutboundShare extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_dataset_outbound_share";
    /**
    * Generates CDKTF code for importing a DatasetOutboundShare resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatasetOutboundShare to import
    * @param importFromId The id of the existing DatasetOutboundShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatasetOutboundShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset_outbound_share observe_dataset_outbound_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatasetOutboundShareConfig
    */
    constructor(scope: Construct, id: string, config: DatasetOutboundShareConfig);
    private _changeTracking?;
    get changeTracking(): boolean | cdktf.IResolvable;
    set changeTracking(value: boolean | cdktf.IResolvable);
    resetChangeTracking(): void;
    get changeTrackingInput(): boolean | cdktf.IResolvable | undefined;
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    get datasetInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _folder?;
    get folder(): string;
    set folder(value: string);
    resetFolder(): void;
    get folderInput(): string | undefined;
    private _freshnessGoal?;
    get freshnessGoal(): string;
    set freshnessGoal(value: string);
    get freshnessGoalInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _outboundShare?;
    get outboundShare(): string;
    set outboundShare(value: string);
    get outboundShareInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _viewName?;
    get viewName(): string;
    set viewName(value: string);
    get viewNameInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _timeouts;
    get timeouts(): DatasetOutboundShareTimeoutsOutputReference;
    putTimeouts(value: DatasetOutboundShareTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DatasetOutboundShareTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
