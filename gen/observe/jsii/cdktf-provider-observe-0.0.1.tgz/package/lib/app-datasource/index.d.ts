import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AppDatasourceConfig extends cdktf.TerraformMetaArguments {
    /**
    * OID of the app to attach the datasource to
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/app_datasource#app AppDatasource#app}
    */
    readonly app: string;
    /**
    * AppDataSource description.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/app_datasource#description AppDatasource#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/app_datasource#id AppDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Instructions on how to connect the app to the data producer using the datasource.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/app_datasource#instructions AppDatasource#instructions}
    */
    readonly instructions: string;
    /**
    * Name of the AppDataSource.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/app_datasource#name AppDatasource#name}
    */
    readonly name: string;
    /**
    * Terraform SourceUrl for the datasource.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/app_datasource#source_url AppDatasource#source_url}
    */
    readonly sourceUrl: string;
    /**
    * Input options to use while creating the datasource.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/app_datasource#variables AppDatasource#variables}
    */
    readonly variables: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/app_datasource observe_app_datasource}
*/
export declare class AppDatasource extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_app_datasource";
    /**
    * Generates CDKTF code for importing a AppDatasource resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppDatasource to import
    * @param importFromId The id of the existing AppDatasource that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/app_datasource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppDatasource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/app_datasource observe_app_datasource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppDatasourceConfig
    */
    constructor(scope: Construct, id: string, config: AppDatasourceConfig);
    private _app?;
    get app(): string;
    set app(value: string);
    get appInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instructions?;
    get instructions(): string;
    set instructions(value: string);
    get instructionsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _sourceUrl?;
    get sourceUrl(): string;
    set sourceUrl(value: string);
    get sourceUrlInput(): string | undefined;
    private _variables?;
    get variables(): {
        [key: string]: string;
    };
    set variables(value: {
        [key: string]: string;
    });
    get variablesInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
