import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveDefaultDashboardConfig extends cdktf.TerraformMetaArguments {
    /**
    * The OID of the dataset that the default dashboard is being set for.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/default_dashboard#dataset DataObserveDefaultDashboard#dataset}
    */
    readonly dataset: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/default_dashboard#id DataObserveDefaultDashboard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/default_dashboard observe_default_dashboard}
*/
export declare class DataObserveDefaultDashboard extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_default_dashboard";
    /**
    * Generates CDKTF code for importing a DataObserveDefaultDashboard resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveDefaultDashboard to import
    * @param importFromId The id of the existing DataObserveDefaultDashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/default_dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveDefaultDashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/default_dashboard observe_default_dashboard} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveDefaultDashboardConfig
    */
    constructor(scope: Construct, id: string, config: DataObserveDefaultDashboardConfig);
    get dashboard(): string;
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    get datasetInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
