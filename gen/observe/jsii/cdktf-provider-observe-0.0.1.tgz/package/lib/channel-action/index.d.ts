import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ChannelActionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#channels ChannelAction#channels}
    */
    readonly channels?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#description ChannelAction#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#icon_url ChannelAction#icon_url}
    */
    readonly iconUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#id ChannelAction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#name ChannelAction#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#notify_on_close ChannelAction#notify_on_close}
    */
    readonly notifyOnClose?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#rate_limit ChannelAction#rate_limit}
    */
    readonly rateLimit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#workspace ChannelAction#workspace}
    */
    readonly workspace: string;
    /**
    * email block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#email ChannelAction#email}
    */
    readonly email?: ChannelActionEmail;
    /**
    * webhook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#webhook ChannelAction#webhook}
    */
    readonly webhook?: ChannelActionWebhook;
}
export interface ChannelActionEmail {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#body ChannelAction#body}
    */
    readonly body: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#is_html ChannelAction#is_html}
    */
    readonly isHtml?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#subject ChannelAction#subject}
    */
    readonly subject: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#to ChannelAction#to}
    */
    readonly to: string[];
}
export declare function channelActionEmailToTerraform(struct?: ChannelActionEmailOutputReference | ChannelActionEmail): any;
export declare function channelActionEmailToHclTerraform(struct?: ChannelActionEmailOutputReference | ChannelActionEmail): any;
export declare class ChannelActionEmailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChannelActionEmail | undefined;
    set internalValue(value: ChannelActionEmail | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    get bodyInput(): string | undefined;
    private _isHtml?;
    get isHtml(): boolean | cdktf.IResolvable;
    set isHtml(value: boolean | cdktf.IResolvable);
    resetIsHtml(): void;
    get isHtmlInput(): boolean | cdktf.IResolvable | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
    private _to?;
    get to(): string[];
    set to(value: string[]);
    get toInput(): string[] | undefined;
}
export interface ChannelActionWebhook {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#body ChannelAction#body}
    */
    readonly body: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#headers ChannelAction#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#method ChannelAction#method}
    */
    readonly method?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#url ChannelAction#url}
    */
    readonly url: string;
}
export declare function channelActionWebhookToTerraform(struct?: ChannelActionWebhookOutputReference | ChannelActionWebhook): any;
export declare function channelActionWebhookToHclTerraform(struct?: ChannelActionWebhookOutputReference | ChannelActionWebhook): any;
export declare class ChannelActionWebhookOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChannelActionWebhook | undefined;
    set internalValue(value: ChannelActionWebhook | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    get bodyInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action observe_channel_action}
*/
export declare class ChannelAction extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_channel_action";
    /**
    * Generates CDKTF code for importing a ChannelAction resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChannelAction to import
    * @param importFromId The id of the existing ChannelAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChannelAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/channel_action observe_channel_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChannelActionConfig
    */
    constructor(scope: Construct, id: string, config: ChannelActionConfig);
    private _channels?;
    get channels(): string[];
    set channels(value: string[]);
    resetChannels(): void;
    get channelsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _iconUrl?;
    get iconUrl(): string;
    set iconUrl(value: string);
    resetIconUrl(): void;
    get iconUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notifyOnClose?;
    get notifyOnClose(): boolean | cdktf.IResolvable;
    set notifyOnClose(value: boolean | cdktf.IResolvable);
    resetNotifyOnClose(): void;
    get notifyOnCloseInput(): boolean | cdktf.IResolvable | undefined;
    get oid(): string;
    private _rateLimit?;
    get rateLimit(): string;
    set rateLimit(value: string);
    resetRateLimit(): void;
    get rateLimitInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _email;
    get email(): ChannelActionEmailOutputReference;
    putEmail(value: ChannelActionEmail): void;
    resetEmail(): void;
    get emailInput(): ChannelActionEmail | undefined;
    private _webhook;
    get webhook(): ChannelActionWebhookOutputReference;
    putWebhook(value: ChannelActionWebhook): void;
    resetWebhook(): void;
    get webhookInput(): ChannelActionWebhook | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
