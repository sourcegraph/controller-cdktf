import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveReportConfig extends cdktf.TerraformMetaArguments {
    /**
    * A list of e-mail bcc addresses that will receive the report.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report#email_bcc_recipients DataObserveReport#email_bcc_recipients}
    */
    readonly emailBccRecipients?: string[];
    /**
    * A list of e-mail addresses that will receive the report.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report#email_recipients DataObserveReport#email_recipients}
    */
    readonly emailRecipients?: string[];
    /**
    * Resource ID for this object.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report#id DataObserveReport#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * created_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report#created_by DataObserveReport#created_by}
    */
    readonly createdBy?: DataObserveReportCreatedBy[] | cdktf.IResolvable;
    /**
    * dashboard block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report#dashboard DataObserveReport#dashboard}
    */
    readonly dashboard?: DataObserveReportDashboard[] | cdktf.IResolvable;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report#schedule DataObserveReport#schedule}
    */
    readonly schedule?: DataObserveReportSchedule[] | cdktf.IResolvable;
    /**
    * updated_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report#updated_by DataObserveReport#updated_by}
    */
    readonly updatedBy?: DataObserveReportUpdatedBy[] | cdktf.IResolvable;
}
export interface DataObserveReportCreatedBy {
}
export declare function dataObserveReportCreatedByToTerraform(struct?: DataObserveReportCreatedBy | cdktf.IResolvable): any;
export declare function dataObserveReportCreatedByToHclTerraform(struct?: DataObserveReportCreatedBy | cdktf.IResolvable): any;
export declare class DataObserveReportCreatedByOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveReportCreatedBy | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveReportCreatedBy | cdktf.IResolvable | undefined);
    get id(): string;
    get label(): string;
}
export declare class DataObserveReportCreatedByList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveReportCreatedBy[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveReportCreatedByOutputReference;
}
export interface DataObserveReportDashboardParameters {
}
export declare function dataObserveReportDashboardParametersToTerraform(struct?: DataObserveReportDashboardParameters | cdktf.IResolvable): any;
export declare function dataObserveReportDashboardParametersToHclTerraform(struct?: DataObserveReportDashboardParameters | cdktf.IResolvable): any;
export declare class DataObserveReportDashboardParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveReportDashboardParameters | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveReportDashboardParameters | cdktf.IResolvable | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataObserveReportDashboardParametersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveReportDashboardParameters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveReportDashboardParametersOutputReference;
}
export interface DataObserveReportDashboard {
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report#parameters DataObserveReport#parameters}
    */
    readonly parameters?: DataObserveReportDashboardParameters[] | cdktf.IResolvable;
}
export declare function dataObserveReportDashboardToTerraform(struct?: DataObserveReportDashboard | cdktf.IResolvable): any;
export declare function dataObserveReportDashboardToHclTerraform(struct?: DataObserveReportDashboard | cdktf.IResolvable): any;
export declare class DataObserveReportDashboardOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveReportDashboard | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveReportDashboard | cdktf.IResolvable | undefined);
    get id(): string;
    get label(): string;
    get queryWindowDurationMinutes(): number;
    private _parameters;
    get parameters(): DataObserveReportDashboardParametersList;
    putParameters(value: DataObserveReportDashboardParameters[] | cdktf.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktf.IResolvable | DataObserveReportDashboardParameters[] | undefined;
}
export declare class DataObserveReportDashboardList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveReportDashboard[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveReportDashboardOutputReference;
}
export interface DataObserveReportSchedule {
}
export declare function dataObserveReportScheduleToTerraform(struct?: DataObserveReportSchedule | cdktf.IResolvable): any;
export declare function dataObserveReportScheduleToHclTerraform(struct?: DataObserveReportSchedule | cdktf.IResolvable): any;
export declare class DataObserveReportScheduleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveReportSchedule | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveReportSchedule | cdktf.IResolvable | undefined);
    get dayOfTheMonth(): number;
    get dayOfTheWeek(): string;
    get every(): number;
    get frequency(): string;
    get generationDelayMinutes(): number;
    get timeOfDay(): string;
    get timezone(): string;
}
export declare class DataObserveReportScheduleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveReportSchedule[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveReportScheduleOutputReference;
}
export interface DataObserveReportUpdatedBy {
}
export declare function dataObserveReportUpdatedByToTerraform(struct?: DataObserveReportUpdatedBy | cdktf.IResolvable): any;
export declare function dataObserveReportUpdatedByToHclTerraform(struct?: DataObserveReportUpdatedBy | cdktf.IResolvable): any;
export declare class DataObserveReportUpdatedByOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveReportUpdatedBy | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveReportUpdatedBy | cdktf.IResolvable | undefined);
    get id(): string;
    get label(): string;
}
export declare class DataObserveReportUpdatedByList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveReportUpdatedBy[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveReportUpdatedByOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report observe_report}
*/
export declare class DataObserveReport extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_report";
    /**
    * Generates CDKTF code for importing a DataObserveReport resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveReport to import
    * @param importFromId The id of the existing DataObserveReport that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveReport to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/report observe_report} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveReportConfig
    */
    constructor(scope: Construct, id: string, config: DataObserveReportConfig);
    get createdAt(): string;
    private _emailBccRecipients?;
    get emailBccRecipients(): string[];
    set emailBccRecipients(value: string[]);
    resetEmailBccRecipients(): void;
    get emailBccRecipientsInput(): string[] | undefined;
    get emailBody(): string;
    private _emailRecipients?;
    get emailRecipients(): string[];
    set emailRecipients(value: string[]);
    resetEmailRecipients(): void;
    get emailRecipientsInput(): string[] | undefined;
    get emailSubject(): string;
    get enabled(): cdktf.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get label(): string;
    get lastRunError(): string;
    get lastRunStatus(): string;
    get lastRunTime(): string;
    get nextScheduledTime(): string;
    get updatedAt(): string;
    private _createdBy;
    get createdBy(): DataObserveReportCreatedByList;
    putCreatedBy(value: DataObserveReportCreatedBy[] | cdktf.IResolvable): void;
    resetCreatedBy(): void;
    get createdByInput(): cdktf.IResolvable | DataObserveReportCreatedBy[] | undefined;
    private _dashboard;
    get dashboard(): DataObserveReportDashboardList;
    putDashboard(value: DataObserveReportDashboard[] | cdktf.IResolvable): void;
    resetDashboard(): void;
    get dashboardInput(): cdktf.IResolvable | DataObserveReportDashboard[] | undefined;
    private _schedule;
    get schedule(): DataObserveReportScheduleList;
    putSchedule(value: DataObserveReportSchedule[] | cdktf.IResolvable): void;
    resetSchedule(): void;
    get scheduleInput(): cdktf.IResolvable | DataObserveReportSchedule[] | undefined;
    private _updatedBy;
    get updatedBy(): DataObserveReportUpdatedByList;
    putUpdatedBy(value: DataObserveReportUpdatedBy[] | cdktf.IResolvable): void;
    resetUpdatedBy(): void;
    get updatedByInput(): cdktf.IResolvable | DataObserveReportUpdatedBy[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
