import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DatasetConfig extends cdktf.TerraformMetaArguments {
    /**
    * Disables periodic materialization of the dataset
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#acceleration_disabled Dataset#acceleration_disabled}
    */
    readonly accelerationDisabled?: boolean | cdktf.IResolvable;
    /**
    * Source of disabled materialization
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#acceleration_disabled_source Dataset#acceleration_disabled_source}
    */
    readonly accelerationDisabledSource?: string;
    /**
    * JSON representation of state used for dataset formatting in the UI. Not intended to be configured by hand, please use export functionality.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#data_table_view_state Dataset#data_table_view_state}
    */
    readonly dataTableViewState?: string;
    /**
    * Dataset description.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#description Dataset#description}
    */
    readonly description?: string;
    /**
    * Target freshness for results. Tighten the freshness to increase the
    * frequency with which queries are run, which incurs higher transform costs.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#freshness Dataset#freshness}
    */
    readonly freshness?: string;
    /**
    * Icon to be displayed for this object. Icons are sourced from the [fluency-filled](https://icons8.com/icons/fluency-systems-filled) icon set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#icon_url Dataset#icon_url}
    */
    readonly iconUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#id Dataset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The inputs map binds dataset OIDs to labels which can be referenced within
    * stage pipelines.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#inputs Dataset#inputs}
    */
    readonly inputs: {
        [key: string]: string;
    };
    /**
    * Dataset name. Must be unique within workspace.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#name Dataset#name}
    */
    readonly name: string;
    /**
    * The maximum on-demand materialization length for the dataset.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#on_demand_materialization_length Dataset#on_demand_materialization_length}
    */
    readonly onDemandMaterializationLength?: string;
    /**
    * Path cost incurred by this dataset when computing graph link. Increasing
    * this value will reduce the preference for using this dataset when computing
    * paths between two datasets.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#path_cost Dataset#path_cost}
    */
    readonly pathCost?: number;
    /**
    * Specifies rematerialization mode when updating a dataset. Options include
    * "rematerialize" (default), "skip_rematerialization", and "must_skip_rematerialization".
    * "skip_rematerialization" will skip rematerialization if certain conditions are met, will rematerialize otherwise.
    * "must_skip_rematerialization" will never rematerialize, update will fail if skipping rematerialization is not possible.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#rematerialization_mode Dataset#rematerialization_mode}
    */
    readonly rematerializationMode?: string;
    /**
    * The ID of the storage integration associated with this dataset.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#storage_integration Dataset#storage_integration}
    */
    readonly storageIntegration?: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#workspace Dataset#workspace}
    */
    readonly workspace: string;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#stage Dataset#stage}
    */
    readonly stage: DatasetStage[] | cdktf.IResolvable;
}
export interface DatasetStage {
    /**
    * The stage alias is the label by which subsequent stages can refer to the
    * results of this stage.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#alias Dataset#alias}
    */
    readonly alias?: string;
    /**
    * The stage input defines what input should be used as a starting point for
    * the stage pipeline. It must refer to a label contained in `inputs`, or a
    * previous stage `alias`. The stage input can be omitted if `inputs`
    * contains a single element.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#input Dataset#input}
    */
    readonly input?: string;
    /**
    * A boolean flag used to specify the output stage. Should be used only for
    * a stage preceding the last stage. The last stage is an output stage by default.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#output_stage Dataset#output_stage}
    */
    readonly outputStage?: boolean | cdktf.IResolvable;
    /**
    * An OPAL snippet defining a transformation on the selected input.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#pipeline Dataset#pipeline}
    */
    readonly pipeline?: string;
}
export declare function datasetStageToTerraform(struct?: DatasetStage | cdktf.IResolvable): any;
export declare function datasetStageToHclTerraform(struct?: DatasetStage | cdktf.IResolvable): any;
export declare class DatasetStageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatasetStage | cdktf.IResolvable | undefined;
    set internalValue(value: DatasetStage | cdktf.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    resetInput(): void;
    get inputInput(): string | undefined;
    private _outputStage?;
    get outputStage(): boolean | cdktf.IResolvable;
    set outputStage(value: boolean | cdktf.IResolvable);
    resetOutputStage(): void;
    get outputStageInput(): boolean | cdktf.IResolvable | undefined;
    private _pipeline?;
    get pipeline(): string;
    set pipeline(value: string);
    resetPipeline(): void;
    get pipelineInput(): string | undefined;
}
export declare class DatasetStageList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DatasetStage[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatasetStageOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset observe_dataset}
*/
export declare class Dataset extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_dataset";
    /**
    * Generates CDKTF code for importing a Dataset resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Dataset to import
    * @param importFromId The id of the existing Dataset that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Dataset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dataset observe_dataset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatasetConfig
    */
    constructor(scope: Construct, id: string, config: DatasetConfig);
    private _accelerationDisabled?;
    get accelerationDisabled(): boolean | cdktf.IResolvable;
    set accelerationDisabled(value: boolean | cdktf.IResolvable);
    resetAccelerationDisabled(): void;
    get accelerationDisabledInput(): boolean | cdktf.IResolvable | undefined;
    private _accelerationDisabledSource?;
    get accelerationDisabledSource(): string;
    set accelerationDisabledSource(value: string);
    resetAccelerationDisabledSource(): void;
    get accelerationDisabledSourceInput(): string | undefined;
    private _dataTableViewState?;
    get dataTableViewState(): string;
    set dataTableViewState(value: string);
    resetDataTableViewState(): void;
    get dataTableViewStateInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _freshness?;
    get freshness(): string;
    set freshness(value: string);
    resetFreshness(): void;
    get freshnessInput(): string | undefined;
    private _iconUrl?;
    get iconUrl(): string;
    set iconUrl(value: string);
    resetIconUrl(): void;
    get iconUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputs?;
    get inputs(): {
        [key: string]: string;
    };
    set inputs(value: {
        [key: string]: string;
    });
    get inputsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _onDemandMaterializationLength?;
    get onDemandMaterializationLength(): string;
    set onDemandMaterializationLength(value: string);
    resetOnDemandMaterializationLength(): void;
    get onDemandMaterializationLengthInput(): string | undefined;
    private _pathCost?;
    get pathCost(): number;
    set pathCost(value: number);
    resetPathCost(): void;
    get pathCostInput(): number | undefined;
    private _rematerializationMode?;
    get rematerializationMode(): string;
    set rematerializationMode(value: string);
    resetRematerializationMode(): void;
    get rematerializationModeInput(): string | undefined;
    private _storageIntegration?;
    get storageIntegration(): string;
    set storageIntegration(value: string);
    resetStorageIntegration(): void;
    get storageIntegrationInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _stage;
    get stage(): DatasetStageList;
    putStage(value: DatasetStage[] | cdktf.IResolvable): void;
    get stageInput(): cdktf.IResolvable | DatasetStage[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
