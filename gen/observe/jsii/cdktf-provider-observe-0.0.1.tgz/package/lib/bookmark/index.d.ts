import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface BookmarkConfig extends cdktf.TerraformMetaArguments {
    /**
    * The target page for your bookmark. An appropriate default will be used if not set.
    *  Accepted values: `dataset`, `dashboard`, `log_explorer`, `metric_explorer`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark#bookmark_kind Bookmark#bookmark_kind}
    */
    readonly bookmarkKind?: string;
    /**
    * OID of the bookmark group used to organize the bookmark
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark#group Bookmark#group}
    */
    readonly group: string;
    /**
    * Icon to be displayed for this object. Icons are sourced from the [fluency-filled](https://icons8.com/icons/fluency-systems-filled) icon set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark#icon_url Bookmark#icon_url}
    */
    readonly iconUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark#id Bookmark#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the bookmark
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark#name Bookmark#name}
    */
    readonly name: string;
    /**
    * The OID of the resource to bookmark. Datasets and dashboards are currently supported
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark#target Bookmark#target}
    */
    readonly target: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark observe_bookmark}
*/
export declare class Bookmark extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_bookmark";
    /**
    * Generates CDKTF code for importing a Bookmark resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Bookmark to import
    * @param importFromId The id of the existing Bookmark that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Bookmark to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark observe_bookmark} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BookmarkConfig
    */
    constructor(scope: Construct, id: string, config: BookmarkConfig);
    private _bookmarkKind?;
    get bookmarkKind(): string;
    set bookmarkKind(value: string);
    resetBookmarkKind(): void;
    get bookmarkKindInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _iconUrl?;
    get iconUrl(): string;
    set iconUrl(value: string);
    resetIconUrl(): void;
    get iconUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
