import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveMonitorConfig extends cdktf.TerraformMetaArguments {
    /**
    * Resource ID for this object.
    * One of `id` or `name` must be provided
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#id DataObserveMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Monitor name. Must be unique within workspace.
    * One of `name` or `id` must be set. If `name` is provided, `workspace` must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#name DataObserveMonitor#name}
    */
    readonly name?: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#workspace DataObserveMonitor#workspace}
    */
    readonly workspace?: string;
    /**
    * notification_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#notification_spec DataObserveMonitor#notification_spec}
    */
    readonly notificationSpec?: DataObserveMonitorNotificationSpec[] | cdktf.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#rule DataObserveMonitor#rule}
    */
    readonly rule?: DataObserveMonitorRule[] | cdktf.IResolvable;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#stage DataObserveMonitor#stage}
    */
    readonly stage?: DataObserveMonitorStage[] | cdktf.IResolvable;
}
export interface DataObserveMonitorNotificationSpec {
}
export declare function dataObserveMonitorNotificationSpecToTerraform(struct?: DataObserveMonitorNotificationSpec | cdktf.IResolvable): any;
export declare function dataObserveMonitorNotificationSpecToHclTerraform(struct?: DataObserveMonitorNotificationSpec | cdktf.IResolvable): any;
export declare class DataObserveMonitorNotificationSpecOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorNotificationSpec | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorNotificationSpec | cdktf.IResolvable | undefined);
    get importance(): string;
    get merge(): string;
    get notifyOnClose(): cdktf.IResolvable;
    get notifyOnReminder(): cdktf.IResolvable;
    get reminderFrequency(): string;
}
export declare class DataObserveMonitorNotificationSpecList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveMonitorNotificationSpec[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorNotificationSpecOutputReference;
}
export interface DataObserveMonitorRuleChange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#compare_function DataObserveMonitor#compare_function}
    */
    readonly compareFunction: string;
}
export declare function dataObserveMonitorRuleChangeToTerraform(struct?: DataObserveMonitorRuleChange | cdktf.IResolvable): any;
export declare function dataObserveMonitorRuleChangeToHclTerraform(struct?: DataObserveMonitorRuleChange | cdktf.IResolvable): any;
export declare class DataObserveMonitorRuleChangeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleChange | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleChange | cdktf.IResolvable | undefined);
    get aggregateFunction(): string;
    get baselineTime(): string;
    get changeType(): string;
    private _compareFunction?;
    get compareFunction(): string;
    set compareFunction(value: string);
    get compareFunctionInput(): string | undefined;
    get compareValues(): number[];
    get lookbackTime(): string;
}
export declare class DataObserveMonitorRuleChangeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveMonitorRuleChange[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleChangeOutputReference;
}
export interface DataObserveMonitorRuleCount {
}
export declare function dataObserveMonitorRuleCountToTerraform(struct?: DataObserveMonitorRuleCount | cdktf.IResolvable): any;
export declare function dataObserveMonitorRuleCountToHclTerraform(struct?: DataObserveMonitorRuleCount | cdktf.IResolvable): any;
export declare class DataObserveMonitorRuleCountOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleCount | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleCount | cdktf.IResolvable | undefined);
    get compareFunction(): string;
    get compareValues(): number[];
    get lookbackTime(): string;
}
export declare class DataObserveMonitorRuleCountList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveMonitorRuleCount[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleCountOutputReference;
}
export interface DataObserveMonitorRuleFacet {
}
export declare function dataObserveMonitorRuleFacetToTerraform(struct?: DataObserveMonitorRuleFacet | cdktf.IResolvable): any;
export declare function dataObserveMonitorRuleFacetToHclTerraform(struct?: DataObserveMonitorRuleFacet | cdktf.IResolvable): any;
export declare class DataObserveMonitorRuleFacetOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleFacet | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleFacet | cdktf.IResolvable | undefined);
    get facetFunction(): string;
    get facetValues(): string[];
    get lookbackTime(): string;
    get timeFunction(): string;
    get timeValue(): number;
}
export declare class DataObserveMonitorRuleFacetList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveMonitorRuleFacet[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleFacetOutputReference;
}
export interface DataObserveMonitorRuleGroupByGroup {
}
export declare function dataObserveMonitorRuleGroupByGroupToTerraform(struct?: DataObserveMonitorRuleGroupByGroup | cdktf.IResolvable): any;
export declare function dataObserveMonitorRuleGroupByGroupToHclTerraform(struct?: DataObserveMonitorRuleGroupByGroup | cdktf.IResolvable): any;
export declare class DataObserveMonitorRuleGroupByGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleGroupByGroup | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleGroupByGroup | cdktf.IResolvable | undefined);
    get columns(): string[];
    get groupName(): string;
}
export declare class DataObserveMonitorRuleGroupByGroupList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveMonitorRuleGroupByGroup[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleGroupByGroupOutputReference;
}
export interface DataObserveMonitorRuleLog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#compare_values DataObserveMonitor#compare_values}
    */
    readonly compareValues?: number[];
    /**
    * Short summary or comment of how the data for monitor is queried.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#expression_summary DataObserveMonitor#expression_summary}
    */
    readonly expressionSummary?: string;
    /**
    * An id of the stage that is used to generate logs for preview. This is usually a stage before aggregation.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#log_stage_id DataObserveMonitor#log_stage_id}
    */
    readonly logStageId?: string;
    /**
    * ID of the dataset that contains logs for preview.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#source_log_dataset DataObserveMonitor#source_log_dataset}
    */
    readonly sourceLogDataset?: string;
}
export declare function dataObserveMonitorRuleLogToTerraform(struct?: DataObserveMonitorRuleLog | cdktf.IResolvable): any;
export declare function dataObserveMonitorRuleLogToHclTerraform(struct?: DataObserveMonitorRuleLog | cdktf.IResolvable): any;
export declare class DataObserveMonitorRuleLogOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleLog | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleLog | cdktf.IResolvable | undefined);
    get compareFunction(): string;
    private _compareValues?;
    get compareValues(): number[];
    set compareValues(value: number[]);
    resetCompareValues(): void;
    get compareValuesInput(): number[] | undefined;
    private _expressionSummary?;
    get expressionSummary(): string;
    set expressionSummary(value: string);
    resetExpressionSummary(): void;
    get expressionSummaryInput(): string | undefined;
    private _logStageId?;
    get logStageId(): string;
    set logStageId(value: string);
    resetLogStageId(): void;
    get logStageIdInput(): string | undefined;
    get lookbackTime(): string;
    private _sourceLogDataset?;
    get sourceLogDataset(): string;
    set sourceLogDataset(value: string);
    resetSourceLogDataset(): void;
    get sourceLogDatasetInput(): string | undefined;
}
export declare class DataObserveMonitorRuleLogList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveMonitorRuleLog[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleLogOutputReference;
}
export interface DataObserveMonitorRulePromote {
}
export declare function dataObserveMonitorRulePromoteToTerraform(struct?: DataObserveMonitorRulePromote | cdktf.IResolvable): any;
export declare function dataObserveMonitorRulePromoteToHclTerraform(struct?: DataObserveMonitorRulePromote | cdktf.IResolvable): any;
export declare class DataObserveMonitorRulePromoteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRulePromote | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRulePromote | cdktf.IResolvable | undefined);
    get descriptionField(): string;
    get kindField(): string;
    get primaryKey(): string[];
}
export declare class DataObserveMonitorRulePromoteList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveMonitorRulePromote[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRulePromoteOutputReference;
}
export interface DataObserveMonitorRuleThreshold {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#compare_function DataObserveMonitor#compare_function}
    */
    readonly compareFunction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#compare_values DataObserveMonitor#compare_values}
    */
    readonly compareValues?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#lookback_time DataObserveMonitor#lookback_time}
    */
    readonly lookbackTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#threshold_agg_function DataObserveMonitor#threshold_agg_function}
    */
    readonly thresholdAggFunction?: string;
}
export declare function dataObserveMonitorRuleThresholdToTerraform(struct?: DataObserveMonitorRuleThreshold | cdktf.IResolvable): any;
export declare function dataObserveMonitorRuleThresholdToHclTerraform(struct?: DataObserveMonitorRuleThreshold | cdktf.IResolvable): any;
export declare class DataObserveMonitorRuleThresholdOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRuleThreshold | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRuleThreshold | cdktf.IResolvable | undefined);
    private _compareFunction?;
    get compareFunction(): string;
    set compareFunction(value: string);
    resetCompareFunction(): void;
    get compareFunctionInput(): string | undefined;
    private _compareValues?;
    get compareValues(): number[];
    set compareValues(value: number[]);
    resetCompareValues(): void;
    get compareValuesInput(): number[] | undefined;
    private _lookbackTime?;
    get lookbackTime(): string;
    set lookbackTime(value: string);
    resetLookbackTime(): void;
    get lookbackTimeInput(): string | undefined;
    private _thresholdAggFunction?;
    get thresholdAggFunction(): string;
    set thresholdAggFunction(value: string);
    resetThresholdAggFunction(): void;
    get thresholdAggFunctionInput(): string | undefined;
}
export declare class DataObserveMonitorRuleThresholdList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveMonitorRuleThreshold[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleThresholdOutputReference;
}
export interface DataObserveMonitorRule {
    /**
    * change block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#change DataObserveMonitor#change}
    */
    readonly change?: DataObserveMonitorRuleChange[] | cdktf.IResolvable;
    /**
    * count block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#count DataObserveMonitor#count}
    */
    readonly count?: DataObserveMonitorRuleCount[] | cdktf.IResolvable;
    /**
    * facet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#facet DataObserveMonitor#facet}
    */
    readonly facet?: DataObserveMonitorRuleFacet[] | cdktf.IResolvable;
    /**
    * group_by_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#group_by_group DataObserveMonitor#group_by_group}
    */
    readonly groupByGroup?: DataObserveMonitorRuleGroupByGroup[] | cdktf.IResolvable;
    /**
    * log block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#log DataObserveMonitor#log}
    */
    readonly log?: DataObserveMonitorRuleLog[] | cdktf.IResolvable;
    /**
    * promote block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#promote DataObserveMonitor#promote}
    */
    readonly promote?: DataObserveMonitorRulePromote[] | cdktf.IResolvable;
    /**
    * threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#threshold DataObserveMonitor#threshold}
    */
    readonly threshold?: DataObserveMonitorRuleThreshold[] | cdktf.IResolvable;
}
export declare function dataObserveMonitorRuleToTerraform(struct?: DataObserveMonitorRule | cdktf.IResolvable): any;
export declare function dataObserveMonitorRuleToHclTerraform(struct?: DataObserveMonitorRule | cdktf.IResolvable): any;
export declare class DataObserveMonitorRuleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorRule | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorRule | cdktf.IResolvable | undefined);
    get sourceColumn(): string;
    private _change;
    get change(): DataObserveMonitorRuleChangeList;
    putChange(value: DataObserveMonitorRuleChange[] | cdktf.IResolvable): void;
    resetChange(): void;
    get changeInput(): cdktf.IResolvable | DataObserveMonitorRuleChange[] | undefined;
    private _count;
    get count(): DataObserveMonitorRuleCountList;
    putCount(value: DataObserveMonitorRuleCount[] | cdktf.IResolvable): void;
    resetCount(): void;
    get countInput(): cdktf.IResolvable | DataObserveMonitorRuleCount[] | undefined;
    private _facet;
    get facet(): DataObserveMonitorRuleFacetList;
    putFacet(value: DataObserveMonitorRuleFacet[] | cdktf.IResolvable): void;
    resetFacet(): void;
    get facetInput(): cdktf.IResolvable | DataObserveMonitorRuleFacet[] | undefined;
    private _groupByGroup;
    get groupByGroup(): DataObserveMonitorRuleGroupByGroupList;
    putGroupByGroup(value: DataObserveMonitorRuleGroupByGroup[] | cdktf.IResolvable): void;
    resetGroupByGroup(): void;
    get groupByGroupInput(): cdktf.IResolvable | DataObserveMonitorRuleGroupByGroup[] | undefined;
    private _log;
    get log(): DataObserveMonitorRuleLogList;
    putLog(value: DataObserveMonitorRuleLog[] | cdktf.IResolvable): void;
    resetLog(): void;
    get logInput(): cdktf.IResolvable | DataObserveMonitorRuleLog[] | undefined;
    private _promote;
    get promote(): DataObserveMonitorRulePromoteList;
    putPromote(value: DataObserveMonitorRulePromote[] | cdktf.IResolvable): void;
    resetPromote(): void;
    get promoteInput(): cdktf.IResolvable | DataObserveMonitorRulePromote[] | undefined;
    private _threshold;
    get threshold(): DataObserveMonitorRuleThresholdList;
    putThreshold(value: DataObserveMonitorRuleThreshold[] | cdktf.IResolvable): void;
    resetThreshold(): void;
    get thresholdInput(): cdktf.IResolvable | DataObserveMonitorRuleThreshold[] | undefined;
}
export declare class DataObserveMonitorRuleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveMonitorRule[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorRuleOutputReference;
}
export interface DataObserveMonitorStage {
}
export declare function dataObserveMonitorStageToTerraform(struct?: DataObserveMonitorStage | cdktf.IResolvable): any;
export declare function dataObserveMonitorStageToHclTerraform(struct?: DataObserveMonitorStage | cdktf.IResolvable): any;
export declare class DataObserveMonitorStageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveMonitorStage | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveMonitorStage | cdktf.IResolvable | undefined);
    get alias(): string;
    get input(): string;
    get outputStage(): cdktf.IResolvable;
    get pipeline(): string;
}
export declare class DataObserveMonitorStageList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveMonitorStage[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveMonitorStageOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor observe_monitor}
*/
export declare class DataObserveMonitor extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_monitor";
    /**
    * Generates CDKTF code for importing a DataObserveMonitor resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveMonitor to import
    * @param importFromId The id of the existing DataObserveMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/monitor observe_monitor} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveMonitorConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveMonitorConfig);
    get bindings(): string;
    get comment(): string;
    get definition(): string;
    get description(): string;
    get disabled(): cdktf.IResolvable;
    get iconUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputs;
    get inputs(): cdktf.StringMap;
    get isTemplate(): cdktf.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get oid(): string;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
    private _notificationSpec;
    get notificationSpec(): DataObserveMonitorNotificationSpecList;
    putNotificationSpec(value: DataObserveMonitorNotificationSpec[] | cdktf.IResolvable): void;
    resetNotificationSpec(): void;
    get notificationSpecInput(): cdktf.IResolvable | DataObserveMonitorNotificationSpec[] | undefined;
    private _rule;
    get rule(): DataObserveMonitorRuleList;
    putRule(value: DataObserveMonitorRule[] | cdktf.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktf.IResolvable | DataObserveMonitorRule[] | undefined;
    private _stage;
    get stage(): DataObserveMonitorStageList;
    putStage(value: DataObserveMonitorStage[] | cdktf.IResolvable): void;
    resetStage(): void;
    get stageInput(): cdktf.IResolvable | DataObserveMonitorStage[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
