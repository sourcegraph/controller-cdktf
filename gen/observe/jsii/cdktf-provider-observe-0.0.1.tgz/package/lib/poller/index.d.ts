import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PollerConfig extends cdktf.TerraformMetaArguments {
    /**
    * Datastream where poller will deliver data.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#datastream Poller#datastream}
    */
    readonly datastream?: string;
    /**
    * Whether to disable poller.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#disabled Poller#disabled}
    */
    readonly disabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#id Poller#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Interval between poller runs. Only applicable to periodic poller kinds.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#interval Poller#interval}
    */
    readonly interval?: string;
    /**
    * Poller name. Must be unique within workspace.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#name Poller#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#retries Poller#retries}
    */
    readonly retries?: number;
    /**
    * Skips validating any provided external API credentials against their external APIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#skip_external_validation Poller#skip_external_validation}
    */
    readonly skipExternalValidation?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#tags Poller#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#workspace Poller#workspace}
    */
    readonly workspace: string;
    /**
    * aws_snapshot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#aws_snapshot Poller#aws_snapshot}
    */
    readonly awsSnapshot?: PollerAwsSnapshot;
    /**
    * chunk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#chunk Poller#chunk}
    */
    readonly chunk?: PollerChunk;
    /**
    * cloudwatch_metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#cloudwatch_metrics Poller#cloudwatch_metrics}
    */
    readonly cloudwatchMetrics?: PollerCloudwatchMetrics;
    /**
    * gcp_monitoring block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#gcp_monitoring Poller#gcp_monitoring}
    */
    readonly gcpMonitoring?: PollerGcpMonitoring;
    /**
    * http block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#http Poller#http}
    */
    readonly http?: PollerHttp;
    /**
    * mongodbatlas block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#mongodbatlas Poller#mongodbatlas}
    */
    readonly mongodbatlas?: PollerMongodbatlas;
    /**
    * pubsub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#pubsub Poller#pubsub}
    */
    readonly pubsub?: PollerPubsub;
}
export interface PollerAwsSnapshot {
    /**
    * AWS role to assume when scraping AWS API. External ID will be set to datastream ID.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#assume_role_arn Poller#assume_role_arn}
    */
    readonly assumeRoleArn: string;
    /**
    * Set of AWS API actions poller is allowed to execute.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#include_actions Poller#include_actions}
    */
    readonly includeActions: string[];
    /**
    * AWS Region to scrape from.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#region Poller#region}
    */
    readonly region: string;
}
export declare function pollerAwsSnapshotToTerraform(struct?: PollerAwsSnapshotOutputReference | PollerAwsSnapshot): any;
export declare function pollerAwsSnapshotToHclTerraform(struct?: PollerAwsSnapshotOutputReference | PollerAwsSnapshot): any;
export declare class PollerAwsSnapshotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PollerAwsSnapshot | undefined;
    set internalValue(value: PollerAwsSnapshot | undefined);
    private _assumeRoleArn?;
    get assumeRoleArn(): string;
    set assumeRoleArn(value: string);
    get assumeRoleArnInput(): string | undefined;
    private _includeActions?;
    get includeActions(): string[];
    set includeActions(value: string[]);
    get includeActionsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export interface PollerChunk {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#enabled Poller#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#size Poller#size}
    */
    readonly size?: number;
}
export declare function pollerChunkToTerraform(struct?: PollerChunkOutputReference | PollerChunk): any;
export declare function pollerChunkToHclTerraform(struct?: PollerChunkOutputReference | PollerChunk): any;
export declare class PollerChunkOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PollerChunk | undefined;
    set internalValue(value: PollerChunk | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export interface PollerCloudwatchMetricsQueryDimension {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#name Poller#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#value Poller#value}
    */
    readonly value?: string;
}
export declare function pollerCloudwatchMetricsQueryDimensionToTerraform(struct?: PollerCloudwatchMetricsQueryDimension | cdktf.IResolvable): any;
export declare function pollerCloudwatchMetricsQueryDimensionToHclTerraform(struct?: PollerCloudwatchMetricsQueryDimension | cdktf.IResolvable): any;
export declare class PollerCloudwatchMetricsQueryDimensionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PollerCloudwatchMetricsQueryDimension | cdktf.IResolvable | undefined;
    set internalValue(value: PollerCloudwatchMetricsQueryDimension | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class PollerCloudwatchMetricsQueryDimensionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PollerCloudwatchMetricsQueryDimension[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PollerCloudwatchMetricsQueryDimensionOutputReference;
}
export interface PollerCloudwatchMetricsQueryResourceFilterTagFilter {
    /**
    * Tag key.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#key Poller#key}
    */
    readonly key: string;
    /**
    * Set of acceptable tag values. Exact matches only.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#values Poller#values}
    */
    readonly values?: string[];
}
export declare function pollerCloudwatchMetricsQueryResourceFilterTagFilterToTerraform(struct?: PollerCloudwatchMetricsQueryResourceFilterTagFilter | cdktf.IResolvable): any;
export declare function pollerCloudwatchMetricsQueryResourceFilterTagFilterToHclTerraform(struct?: PollerCloudwatchMetricsQueryResourceFilterTagFilter | cdktf.IResolvable): any;
export declare class PollerCloudwatchMetricsQueryResourceFilterTagFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PollerCloudwatchMetricsQueryResourceFilterTagFilter | cdktf.IResolvable | undefined;
    set internalValue(value: PollerCloudwatchMetricsQueryResourceFilterTagFilter | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class PollerCloudwatchMetricsQueryResourceFilterTagFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PollerCloudwatchMetricsQueryResourceFilterTagFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PollerCloudwatchMetricsQueryResourceFilterTagFilterOutputReference;
}
export interface PollerCloudwatchMetricsQueryResourceFilter {
    /**
    * Metric dimension name for resource identifier.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#dimension_name Poller#dimension_name}
    */
    readonly dimensionName?: string;
    /**
    * Regular expression for extracting identifier out of resource ARN.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#pattern Poller#pattern}
    */
    readonly pattern?: string;
    /**
    * Resource type to filter for as supported by `aws resourcegroupstaggingapi get-resources`, e.g. `ec2:instance`.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#resource_type Poller#resource_type}
    */
    readonly resourceType?: string;
    /**
    * tag_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#tag_filter Poller#tag_filter}
    */
    readonly tagFilter: PollerCloudwatchMetricsQueryResourceFilterTagFilter[] | cdktf.IResolvable;
}
export declare function pollerCloudwatchMetricsQueryResourceFilterToTerraform(struct?: PollerCloudwatchMetricsQueryResourceFilter | cdktf.IResolvable): any;
export declare function pollerCloudwatchMetricsQueryResourceFilterToHclTerraform(struct?: PollerCloudwatchMetricsQueryResourceFilter | cdktf.IResolvable): any;
export declare class PollerCloudwatchMetricsQueryResourceFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PollerCloudwatchMetricsQueryResourceFilter | cdktf.IResolvable | undefined;
    set internalValue(value: PollerCloudwatchMetricsQueryResourceFilter | cdktf.IResolvable | undefined);
    private _dimensionName?;
    get dimensionName(): string;
    set dimensionName(value: string);
    resetDimensionName(): void;
    get dimensionNameInput(): string | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _tagFilter;
    get tagFilter(): PollerCloudwatchMetricsQueryResourceFilterTagFilterList;
    putTagFilter(value: PollerCloudwatchMetricsQueryResourceFilterTagFilter[] | cdktf.IResolvable): void;
    get tagFilterInput(): cdktf.IResolvable | PollerCloudwatchMetricsQueryResourceFilterTagFilter[] | undefined;
}
export declare class PollerCloudwatchMetricsQueryResourceFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PollerCloudwatchMetricsQueryResourceFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PollerCloudwatchMetricsQueryResourceFilterOutputReference;
}
export interface PollerCloudwatchMetricsQuery {
    /**
    * Metric names to filter down to. If more than one metric name is provided, `ListMetrics` will be called with no filter on metric names.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#metric_names Poller#metric_names}
    */
    readonly metricNames?: string[];
    /**
    * AWS Metric Namespace to query.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#namespace Poller#namespace}
    */
    readonly namespace: string;
    /**
    * dimension block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#dimension Poller#dimension}
    */
    readonly dimension?: PollerCloudwatchMetricsQueryDimension[] | cdktf.IResolvable;
    /**
    * resource_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#resource_filter Poller#resource_filter}
    */
    readonly resourceFilter?: PollerCloudwatchMetricsQueryResourceFilter[] | cdktf.IResolvable;
}
export declare function pollerCloudwatchMetricsQueryToTerraform(struct?: PollerCloudwatchMetricsQuery | cdktf.IResolvable): any;
export declare function pollerCloudwatchMetricsQueryToHclTerraform(struct?: PollerCloudwatchMetricsQuery | cdktf.IResolvable): any;
export declare class PollerCloudwatchMetricsQueryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PollerCloudwatchMetricsQuery | cdktf.IResolvable | undefined;
    set internalValue(value: PollerCloudwatchMetricsQuery | cdktf.IResolvable | undefined);
    private _metricNames?;
    get metricNames(): string[];
    set metricNames(value: string[]);
    resetMetricNames(): void;
    get metricNamesInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _dimension;
    get dimension(): PollerCloudwatchMetricsQueryDimensionList;
    putDimension(value: PollerCloudwatchMetricsQueryDimension[] | cdktf.IResolvable): void;
    resetDimension(): void;
    get dimensionInput(): cdktf.IResolvable | PollerCloudwatchMetricsQueryDimension[] | undefined;
    private _resourceFilter;
    get resourceFilter(): PollerCloudwatchMetricsQueryResourceFilterList;
    putResourceFilter(value: PollerCloudwatchMetricsQueryResourceFilter[] | cdktf.IResolvable): void;
    resetResourceFilter(): void;
    get resourceFilterInput(): cdktf.IResolvable | PollerCloudwatchMetricsQueryResourceFilter[] | undefined;
}
export declare class PollerCloudwatchMetricsQueryList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PollerCloudwatchMetricsQuery[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PollerCloudwatchMetricsQueryOutputReference;
}
export interface PollerCloudwatchMetrics {
    /**
    * AWS role to assume when scraping AWS CloudWatch Metrics. External ID will be set to datastream ID.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#assume_role_arn Poller#assume_role_arn}
    */
    readonly assumeRoleArn: string;
    /**
    * Collection delay. Must account for metrics availability via CloudWatch API.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#delay Poller#delay}
    */
    readonly delay?: string;
    /**
    * Metric resolution. Must be a multiple of 60s. When omitted, poller interval will be used.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#period Poller#period}
    */
    readonly period?: string;
    /**
    * AWS Region to scrape from.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#region Poller#region}
    */
    readonly region: string;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#query Poller#query}
    */
    readonly query: PollerCloudwatchMetricsQuery[] | cdktf.IResolvable;
}
export declare function pollerCloudwatchMetricsToTerraform(struct?: PollerCloudwatchMetricsOutputReference | PollerCloudwatchMetrics): any;
export declare function pollerCloudwatchMetricsToHclTerraform(struct?: PollerCloudwatchMetricsOutputReference | PollerCloudwatchMetrics): any;
export declare class PollerCloudwatchMetricsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PollerCloudwatchMetrics | undefined;
    set internalValue(value: PollerCloudwatchMetrics | undefined);
    private _assumeRoleArn?;
    get assumeRoleArn(): string;
    set assumeRoleArn(value: string);
    get assumeRoleArnInput(): string | undefined;
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    resetPeriod(): void;
    get periodInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _query;
    get query(): PollerCloudwatchMetricsQueryList;
    putQuery(value: PollerCloudwatchMetricsQuery[] | cdktf.IResolvable): void;
    get queryInput(): cdktf.IResolvable | PollerCloudwatchMetricsQuery[] | undefined;
}
export interface PollerGcpMonitoring {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#exclude_metric_type_prefixes Poller#exclude_metric_type_prefixes}
    */
    readonly excludeMetricTypePrefixes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#include_metric_type_prefixes Poller#include_metric_type_prefixes}
    */
    readonly includeMetricTypePrefixes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#json_key Poller#json_key}
    */
    readonly jsonKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#project_id Poller#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#rate_limit Poller#rate_limit}
    */
    readonly rateLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#total_limit Poller#total_limit}
    */
    readonly totalLimit?: number;
}
export declare function pollerGcpMonitoringToTerraform(struct?: PollerGcpMonitoringOutputReference | PollerGcpMonitoring): any;
export declare function pollerGcpMonitoringToHclTerraform(struct?: PollerGcpMonitoringOutputReference | PollerGcpMonitoring): any;
export declare class PollerGcpMonitoringOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PollerGcpMonitoring | undefined;
    set internalValue(value: PollerGcpMonitoring | undefined);
    private _excludeMetricTypePrefixes?;
    get excludeMetricTypePrefixes(): string[];
    set excludeMetricTypePrefixes(value: string[]);
    resetExcludeMetricTypePrefixes(): void;
    get excludeMetricTypePrefixesInput(): string[] | undefined;
    private _includeMetricTypePrefixes?;
    get includeMetricTypePrefixes(): string[];
    set includeMetricTypePrefixes(value: string[]);
    resetIncludeMetricTypePrefixes(): void;
    get includeMetricTypePrefixesInput(): string[] | undefined;
    private _jsonKey?;
    get jsonKey(): string;
    set jsonKey(value: string);
    get jsonKeyInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _rateLimit?;
    get rateLimit(): number;
    set rateLimit(value: number);
    resetRateLimit(): void;
    get rateLimitInput(): number | undefined;
    private _totalLimit?;
    get totalLimit(): number;
    set totalLimit(value: number);
    resetTotalLimit(): void;
    get totalLimitInput(): number | undefined;
}
export interface PollerHttpRequest {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#auth_scheme Poller#auth_scheme}
    */
    readonly authScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#body Poller#body}
    */
    readonly body?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#headers Poller#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#method Poller#method}
    */
    readonly method?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#params Poller#params}
    */
    readonly params?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#password Poller#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#url Poller#url}
    */
    readonly url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#username Poller#username}
    */
    readonly username?: string;
}
export declare function pollerHttpRequestToTerraform(struct?: PollerHttpRequest | cdktf.IResolvable): any;
export declare function pollerHttpRequestToHclTerraform(struct?: PollerHttpRequest | cdktf.IResolvable): any;
export declare class PollerHttpRequestOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PollerHttpRequest | cdktf.IResolvable | undefined;
    set internalValue(value: PollerHttpRequest | cdktf.IResolvable | undefined);
    private _authScheme?;
    get authScheme(): string;
    set authScheme(value: string);
    resetAuthScheme(): void;
    get authSchemeInput(): string | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _params?;
    get params(): {
        [key: string]: string;
    };
    set params(value: {
        [key: string]: string;
    });
    resetParams(): void;
    get paramsInput(): {
        [key: string]: string;
    } | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export declare class PollerHttpRequestList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PollerHttpRequest[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PollerHttpRequestOutputReference;
}
export interface PollerHttpRuleDecoder {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#type Poller#type}
    */
    readonly type: string;
}
export declare function pollerHttpRuleDecoderToTerraform(struct?: PollerHttpRuleDecoderOutputReference | PollerHttpRuleDecoder): any;
export declare function pollerHttpRuleDecoderToHclTerraform(struct?: PollerHttpRuleDecoderOutputReference | PollerHttpRuleDecoder): any;
export declare class PollerHttpRuleDecoderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PollerHttpRuleDecoder | undefined;
    set internalValue(value: PollerHttpRuleDecoder | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface PollerHttpRuleMatch {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#auth_scheme Poller#auth_scheme}
    */
    readonly authScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#body Poller#body}
    */
    readonly body?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#headers Poller#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#method Poller#method}
    */
    readonly method?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#params Poller#params}
    */
    readonly params?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#password Poller#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#url Poller#url}
    */
    readonly url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#username Poller#username}
    */
    readonly username?: string;
}
export declare function pollerHttpRuleMatchToTerraform(struct?: PollerHttpRuleMatchOutputReference | PollerHttpRuleMatch): any;
export declare function pollerHttpRuleMatchToHclTerraform(struct?: PollerHttpRuleMatchOutputReference | PollerHttpRuleMatch): any;
export declare class PollerHttpRuleMatchOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PollerHttpRuleMatch | undefined;
    set internalValue(value: PollerHttpRuleMatch | undefined);
    private _authScheme?;
    get authScheme(): string;
    set authScheme(value: string);
    resetAuthScheme(): void;
    get authSchemeInput(): string | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _params?;
    get params(): {
        [key: string]: string;
    };
    set params(value: {
        [key: string]: string;
    });
    resetParams(): void;
    get paramsInput(): {
        [key: string]: string;
    } | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface PollerHttpRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#follow Poller#follow}
    */
    readonly follow?: string;
    /**
    * decoder block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#decoder Poller#decoder}
    */
    readonly decoder?: PollerHttpRuleDecoder;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#match Poller#match}
    */
    readonly match: PollerHttpRuleMatch;
}
export declare function pollerHttpRuleToTerraform(struct?: PollerHttpRule | cdktf.IResolvable): any;
export declare function pollerHttpRuleToHclTerraform(struct?: PollerHttpRule | cdktf.IResolvable): any;
export declare class PollerHttpRuleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PollerHttpRule | cdktf.IResolvable | undefined;
    set internalValue(value: PollerHttpRule | cdktf.IResolvable | undefined);
    private _follow?;
    get follow(): string;
    set follow(value: string);
    resetFollow(): void;
    get followInput(): string | undefined;
    private _decoder;
    get decoder(): PollerHttpRuleDecoderOutputReference;
    putDecoder(value: PollerHttpRuleDecoder): void;
    resetDecoder(): void;
    get decoderInput(): PollerHttpRuleDecoder | undefined;
    private _match;
    get match(): PollerHttpRuleMatchOutputReference;
    putMatch(value: PollerHttpRuleMatch): void;
    get matchInput(): PollerHttpRuleMatch | undefined;
}
export declare class PollerHttpRuleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PollerHttpRule[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PollerHttpRuleOutputReference;
}
export interface PollerHttpTemplate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#auth_scheme Poller#auth_scheme}
    */
    readonly authScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#body Poller#body}
    */
    readonly body?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#headers Poller#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#method Poller#method}
    */
    readonly method?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#params Poller#params}
    */
    readonly params?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#password Poller#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#url Poller#url}
    */
    readonly url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#username Poller#username}
    */
    readonly username?: string;
}
export declare function pollerHttpTemplateToTerraform(struct?: PollerHttpTemplateOutputReference | PollerHttpTemplate): any;
export declare function pollerHttpTemplateToHclTerraform(struct?: PollerHttpTemplateOutputReference | PollerHttpTemplate): any;
export declare class PollerHttpTemplateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PollerHttpTemplate | undefined;
    set internalValue(value: PollerHttpTemplate | undefined);
    private _authScheme?;
    get authScheme(): string;
    set authScheme(value: string);
    resetAuthScheme(): void;
    get authSchemeInput(): string | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _params?;
    get params(): {
        [key: string]: string;
    };
    set params(value: {
        [key: string]: string;
    });
    resetParams(): void;
    get paramsInput(): {
        [key: string]: string;
    } | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface PollerHttpTimestamp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#format Poller#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#name Poller#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#offset Poller#offset}
    */
    readonly offset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#source Poller#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#truncate Poller#truncate}
    */
    readonly truncate?: string;
}
export declare function pollerHttpTimestampToTerraform(struct?: PollerHttpTimestamp | cdktf.IResolvable): any;
export declare function pollerHttpTimestampToHclTerraform(struct?: PollerHttpTimestamp | cdktf.IResolvable): any;
export declare class PollerHttpTimestampOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PollerHttpTimestamp | cdktf.IResolvable | undefined;
    set internalValue(value: PollerHttpTimestamp | cdktf.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _truncate?;
    get truncate(): string;
    set truncate(value: string);
    resetTruncate(): void;
    get truncateInput(): string | undefined;
}
export declare class PollerHttpTimestampList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PollerHttpTimestamp[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PollerHttpTimestampOutputReference;
}
export interface PollerHttp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#body Poller#body}
    */
    readonly body?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#content_type Poller#content_type}
    */
    readonly contentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#endpoint Poller#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#headers Poller#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#method Poller#method}
    */
    readonly method?: string;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#request Poller#request}
    */
    readonly request?: PollerHttpRequest[] | cdktf.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#rule Poller#rule}
    */
    readonly rule?: PollerHttpRule[] | cdktf.IResolvable;
    /**
    * template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#template Poller#template}
    */
    readonly template?: PollerHttpTemplate;
    /**
    * timestamp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#timestamp Poller#timestamp}
    */
    readonly timestamp?: PollerHttpTimestamp[] | cdktf.IResolvable;
}
export declare function pollerHttpToTerraform(struct?: PollerHttpOutputReference | PollerHttp): any;
export declare function pollerHttpToHclTerraform(struct?: PollerHttpOutputReference | PollerHttp): any;
export declare class PollerHttpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PollerHttp | undefined;
    set internalValue(value: PollerHttp | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _request;
    get request(): PollerHttpRequestList;
    putRequest(value: PollerHttpRequest[] | cdktf.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktf.IResolvable | PollerHttpRequest[] | undefined;
    private _rule;
    get rule(): PollerHttpRuleList;
    putRule(value: PollerHttpRule[] | cdktf.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktf.IResolvable | PollerHttpRule[] | undefined;
    private _template;
    get template(): PollerHttpTemplateOutputReference;
    putTemplate(value: PollerHttpTemplate): void;
    resetTemplate(): void;
    get templateInput(): PollerHttpTemplate | undefined;
    private _timestamp;
    get timestamp(): PollerHttpTimestampList;
    putTimestamp(value: PollerHttpTimestamp[] | cdktf.IResolvable): void;
    resetTimestamp(): void;
    get timestampInput(): cdktf.IResolvable | PollerHttpTimestamp[] | undefined;
}
export interface PollerMongodbatlas {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#exclude_groups Poller#exclude_groups}
    */
    readonly excludeGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#include_groups Poller#include_groups}
    */
    readonly includeGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#private_key Poller#private_key}
    */
    readonly privateKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#public_key Poller#public_key}
    */
    readonly publicKey: string;
}
export declare function pollerMongodbatlasToTerraform(struct?: PollerMongodbatlasOutputReference | PollerMongodbatlas): any;
export declare function pollerMongodbatlasToHclTerraform(struct?: PollerMongodbatlasOutputReference | PollerMongodbatlas): any;
export declare class PollerMongodbatlasOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PollerMongodbatlas | undefined;
    set internalValue(value: PollerMongodbatlas | undefined);
    private _excludeGroups?;
    get excludeGroups(): string[];
    set excludeGroups(value: string[]);
    resetExcludeGroups(): void;
    get excludeGroupsInput(): string[] | undefined;
    private _includeGroups?;
    get includeGroups(): string[];
    set includeGroups(value: string[]);
    resetIncludeGroups(): void;
    get includeGroupsInput(): string[] | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    get publicKeyInput(): string | undefined;
}
export interface PollerPubsub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#json_key Poller#json_key}
    */
    readonly jsonKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#project_id Poller#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#subscription_id Poller#subscription_id}
    */
    readonly subscriptionId: string;
}
export declare function pollerPubsubToTerraform(struct?: PollerPubsubOutputReference | PollerPubsub): any;
export declare function pollerPubsubToHclTerraform(struct?: PollerPubsubOutputReference | PollerPubsub): any;
export declare class PollerPubsubOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PollerPubsub | undefined;
    set internalValue(value: PollerPubsub | undefined);
    private _jsonKey?;
    get jsonKey(): string;
    set jsonKey(value: string);
    get jsonKeyInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    get subscriptionIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller observe_poller}
*/
export declare class Poller extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_poller";
    /**
    * Generates CDKTF code for importing a Poller resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Poller to import
    * @param importFromId The id of the existing Poller that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Poller to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/poller observe_poller} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PollerConfig
    */
    constructor(scope: Construct, id: string, config: PollerConfig);
    private _datastream?;
    get datastream(): string;
    set datastream(value: string);
    resetDatastream(): void;
    get datastreamInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktf.IResolvable;
    set disabled(value: boolean | cdktf.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    get kind(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _retries?;
    get retries(): number;
    set retries(value: number);
    resetRetries(): void;
    get retriesInput(): number | undefined;
    private _skipExternalValidation?;
    get skipExternalValidation(): boolean | cdktf.IResolvable;
    set skipExternalValidation(value: boolean | cdktf.IResolvable);
    resetSkipExternalValidation(): void;
    get skipExternalValidationInput(): boolean | cdktf.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _awsSnapshot;
    get awsSnapshot(): PollerAwsSnapshotOutputReference;
    putAwsSnapshot(value: PollerAwsSnapshot): void;
    resetAwsSnapshot(): void;
    get awsSnapshotInput(): PollerAwsSnapshot | undefined;
    private _chunk;
    get chunk(): PollerChunkOutputReference;
    putChunk(value: PollerChunk): void;
    resetChunk(): void;
    get chunkInput(): PollerChunk | undefined;
    private _cloudwatchMetrics;
    get cloudwatchMetrics(): PollerCloudwatchMetricsOutputReference;
    putCloudwatchMetrics(value: PollerCloudwatchMetrics): void;
    resetCloudwatchMetrics(): void;
    get cloudwatchMetricsInput(): PollerCloudwatchMetrics | undefined;
    private _gcpMonitoring;
    get gcpMonitoring(): PollerGcpMonitoringOutputReference;
    putGcpMonitoring(value: PollerGcpMonitoring): void;
    resetGcpMonitoring(): void;
    get gcpMonitoringInput(): PollerGcpMonitoring | undefined;
    private _http;
    get http(): PollerHttpOutputReference;
    putHttp(value: PollerHttp): void;
    resetHttp(): void;
    get httpInput(): PollerHttp | undefined;
    private _mongodbatlas;
    get mongodbatlas(): PollerMongodbatlasOutputReference;
    putMongodbatlas(value: PollerMongodbatlas): void;
    resetMongodbatlas(): void;
    get mongodbatlasInput(): PollerMongodbatlas | undefined;
    private _pubsub;
    get pubsub(): PollerPubsubOutputReference;
    putPubsub(value: PollerPubsub): void;
    resetPubsub(): void;
    get pubsubInput(): PollerPubsub | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
