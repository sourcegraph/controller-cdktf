import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface FiledropConfig extends cdktf.TerraformMetaArguments {
    /**
    * The OID of the datastream that the filedrop loads data into.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#datastream Filedrop#datastream}
    */
    readonly datastream: string;
    /**
    * A brief description of the filedrop.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#description Filedrop#description}
    */
    readonly description?: string;
    /**
    * Icon to be displayed for this object. Icons are sourced from the [fluency-filled](https://icons8.com/icons/fluency-systems-filled) icon set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#icon_url Filedrop#icon_url}
    */
    readonly iconUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#id Filedrop#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filedrop name. Must be unique within workspace.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#name Filedrop#name}
    */
    readonly name?: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#workspace Filedrop#workspace}
    */
    readonly workspace: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#config Filedrop#config}
    */
    readonly config: FiledropConfigA;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#timeouts Filedrop#timeouts}
    */
    readonly timeouts?: FiledropTimeouts;
}
export interface FiledropEndpointS3 {
}
export declare function filedropEndpointS3ToTerraform(struct?: FiledropEndpointS3): any;
export declare function filedropEndpointS3ToHclTerraform(struct?: FiledropEndpointS3): any;
export declare class FiledropEndpointS3OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FiledropEndpointS3 | undefined;
    set internalValue(value: FiledropEndpointS3 | undefined);
    get arn(): string;
    get bucket(): string;
    get prefix(): string;
}
export declare class FiledropEndpointS3List extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FiledropEndpointS3OutputReference;
}
export interface FiledropEndpoint {
}
export declare function filedropEndpointToTerraform(struct?: FiledropEndpoint): any;
export declare function filedropEndpointToHclTerraform(struct?: FiledropEndpoint): any;
export declare class FiledropEndpointOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FiledropEndpoint | undefined;
    set internalValue(value: FiledropEndpoint | undefined);
    private _s3;
    get s3(): FiledropEndpointS3List;
}
export declare class FiledropEndpointList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FiledropEndpointOutputReference;
}
export interface FiledropConfigProviderAws {
    /**
    * The region where the role ARN exists that you will be dropping files to.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#region Filedrop#region}
    */
    readonly region: string;
    /**
    * Your IAM role that Observe allows to drop data into the particular filedrop.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#role_arn Filedrop#role_arn}
    */
    readonly roleArn: string;
}
export declare function filedropConfigProviderAwsToTerraform(struct?: FiledropConfigProviderAwsOutputReference | FiledropConfigProviderAws): any;
export declare function filedropConfigProviderAwsToHclTerraform(struct?: FiledropConfigProviderAwsOutputReference | FiledropConfigProviderAws): any;
export declare class FiledropConfigProviderAwsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FiledropConfigProviderAws | undefined;
    set internalValue(value: FiledropConfigProviderAws | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
}
export interface FiledropConfigProvider {
    /**
    * aws block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#aws Filedrop#aws}
    */
    readonly aws: FiledropConfigProviderAws;
}
export declare function filedropConfigProviderToTerraform(struct?: FiledropConfigProviderOutputReference | FiledropConfigProvider): any;
export declare function filedropConfigProviderToHclTerraform(struct?: FiledropConfigProviderOutputReference | FiledropConfigProvider): any;
export declare class FiledropConfigProviderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FiledropConfigProvider | undefined;
    set internalValue(value: FiledropConfigProvider | undefined);
    private _aws;
    get aws(): FiledropConfigProviderAwsOutputReference;
    putAws(value: FiledropConfigProviderAws): void;
    get awsInput(): FiledropConfigProviderAws | undefined;
}
export interface FiledropConfigA {
    /**
    * provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#provider Filedrop#provider}
    */
    readonly provider: FiledropConfigProvider;
}
export declare function filedropConfigAToTerraform(struct?: FiledropConfigAOutputReference | FiledropConfigA): any;
export declare function filedropConfigAToHclTerraform(struct?: FiledropConfigAOutputReference | FiledropConfigA): any;
export declare class FiledropConfigAOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FiledropConfigA | undefined;
    set internalValue(value: FiledropConfigA | undefined);
    private _provider;
    get provider(): FiledropConfigProviderOutputReference;
    putProvider(value: FiledropConfigProvider): void;
    get providerInput(): FiledropConfigProvider | undefined;
}
export interface FiledropTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#create Filedrop#create}
    */
    readonly create?: string;
}
export declare function filedropTimeoutsToTerraform(struct?: FiledropTimeouts | cdktf.IResolvable): any;
export declare function filedropTimeoutsToHclTerraform(struct?: FiledropTimeouts | cdktf.IResolvable): any;
export declare class FiledropTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FiledropTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: FiledropTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop observe_filedrop}
*/
export declare class Filedrop extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_filedrop";
    /**
    * Generates CDKTF code for importing a Filedrop resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Filedrop to import
    * @param importFromId The id of the existing Filedrop that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Filedrop to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/filedrop observe_filedrop} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FiledropConfig
    */
    constructor(scope: Construct, id: string, config: FiledropConfig);
    private _datastream?;
    get datastream(): string;
    set datastream(value: string);
    get datastreamInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _endpoint;
    get endpoint(): FiledropEndpointList;
    private _iconUrl?;
    get iconUrl(): string;
    set iconUrl(value: string);
    resetIconUrl(): void;
    get iconUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get oid(): string;
    get status(): string;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _config;
    get config(): FiledropConfigAOutputReference;
    putConfig(value: FiledropConfigA): void;
    get configInput(): FiledropConfigA | undefined;
    private _timeouts;
    get timeouts(): FiledropTimeoutsOutputReference;
    putTimeouts(value: FiledropTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | FiledropTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
