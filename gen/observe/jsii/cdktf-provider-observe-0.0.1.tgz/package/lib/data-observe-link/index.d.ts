import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveLinkConfig extends cdktf.TerraformMetaArguments {
    /**
    * A collection of field mappings on which to link source and target datasets.
    * Each element of the array can be written as a colon separated string, e.g.
    * `source_column:target_column`. If the source and target fields have the
    * same name, the target field name can be omitted, i.e. `col:col` can be
    * written as `col`.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/link#fields DataObserveLink#fields}
    */
    readonly fields: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/link#id DataObserveLink#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * OID for the source dataset.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/link#source DataObserveLink#source}
    */
    readonly source: string;
    /**
    * OID for the target dataset.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/link#target DataObserveLink#target}
    */
    readonly target: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/link observe_link}
*/
export declare class DataObserveLink extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_link";
    /**
    * Generates CDKTF code for importing a DataObserveLink resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveLink to import
    * @param importFromId The id of the existing DataObserveLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/link observe_link} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveLinkConfig
    */
    constructor(scope: Construct, id: string, config: DataObserveLinkConfig);
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    get fieldsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
