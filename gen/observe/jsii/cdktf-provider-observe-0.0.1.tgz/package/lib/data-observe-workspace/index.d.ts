import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveWorkspaceConfig extends cdktf.TerraformMetaArguments {
    /**
    * Resource ID for this object.
    * One of `id` or `name` must be provided
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/workspace#id DataObserveWorkspace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Workspace name. Must be unique for customer account.
    * One of `id` or `name` must be provided
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/workspace#name DataObserveWorkspace#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/workspace observe_workspace}
*/
export declare class DataObserveWorkspace extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_workspace";
    /**
    * Generates CDKTF code for importing a DataObserveWorkspace resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveWorkspace to import
    * @param importFromId The id of the existing DataObserveWorkspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/workspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveWorkspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/workspace observe_workspace} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveWorkspaceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveWorkspaceConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get oid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
