import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveDatasetConfig extends cdktf.TerraformMetaArguments {
    /**
    * Resource ID for this object.
    * One of `name` or `id` must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dataset#id DataObserveDataset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Dataset name. Must be unique within workspace.
    * One of `name` or `id` must be set. If `name` is provided, `workspace` must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dataset#name DataObserveDataset#name}
    */
    readonly name?: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dataset#workspace DataObserveDataset#workspace}
    */
    readonly workspace?: string;
    /**
    * correlation_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dataset#correlation_tag DataObserveDataset#correlation_tag}
    */
    readonly correlationTag?: DataObserveDatasetCorrelationTag[] | cdktf.IResolvable;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dataset#stage DataObserveDataset#stage}
    */
    readonly stage?: DataObserveDatasetStage[] | cdktf.IResolvable;
}
export interface DataObserveDatasetCorrelationTag {
}
export declare function dataObserveDatasetCorrelationTagToTerraform(struct?: DataObserveDatasetCorrelationTag | cdktf.IResolvable): any;
export declare function dataObserveDatasetCorrelationTagToHclTerraform(struct?: DataObserveDatasetCorrelationTag | cdktf.IResolvable): any;
export declare class DataObserveDatasetCorrelationTagOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveDatasetCorrelationTag | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveDatasetCorrelationTag | cdktf.IResolvable | undefined);
    get column(): string;
    get name(): string;
    get path(): string;
}
export declare class DataObserveDatasetCorrelationTagList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveDatasetCorrelationTag[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveDatasetCorrelationTagOutputReference;
}
export interface DataObserveDatasetStage {
}
export declare function dataObserveDatasetStageToTerraform(struct?: DataObserveDatasetStage | cdktf.IResolvable): any;
export declare function dataObserveDatasetStageToHclTerraform(struct?: DataObserveDatasetStage | cdktf.IResolvable): any;
export declare class DataObserveDatasetStageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataObserveDatasetStage | cdktf.IResolvable | undefined;
    set internalValue(value: DataObserveDatasetStage | cdktf.IResolvable | undefined);
    get alias(): string;
    get input(): string;
    get outputStage(): cdktf.IResolvable;
    get pipeline(): string;
}
export declare class DataObserveDatasetStageList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataObserveDatasetStage[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataObserveDatasetStageOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dataset observe_dataset}
*/
export declare class DataObserveDataset extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_dataset";
    /**
    * Generates CDKTF code for importing a DataObserveDataset resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveDataset to import
    * @param importFromId The id of the existing DataObserveDataset that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dataset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveDataset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dataset observe_dataset} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveDatasetConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveDatasetConfig);
    get accelerationDisabled(): cdktf.IResolvable;
    get accelerationDisabledSource(): string;
    get dataTableViewState(): string;
    get description(): string;
    get freshness(): string;
    get iconUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputs;
    get inputs(): cdktf.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get oid(): string;
    get onDemandMaterializationLength(): string;
    get pathCost(): number;
    get storageIntegration(): string;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
    private _correlationTag;
    get correlationTag(): DataObserveDatasetCorrelationTagList;
    putCorrelationTag(value: DataObserveDatasetCorrelationTag[] | cdktf.IResolvable): void;
    resetCorrelationTag(): void;
    get correlationTagInput(): cdktf.IResolvable | DataObserveDatasetCorrelationTag[] | undefined;
    private _stage;
    get stage(): DataObserveDatasetStageList;
    putStage(value: DataObserveDatasetStage[] | cdktf.IResolvable): void;
    resetStage(): void;
    get stageInput(): cdktf.IResolvable | DataObserveDatasetStage[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
