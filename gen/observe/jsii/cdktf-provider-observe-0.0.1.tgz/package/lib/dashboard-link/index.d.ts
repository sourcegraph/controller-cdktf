import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DashboardLinkConfig extends cdktf.TerraformMetaArguments {
    /**
    * A description for the link.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link#description DashboardLink#description}
    */
    readonly description: string;
    /**
    * Observe folder OID for this object.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link#folder DashboardLink#folder}
    */
    readonly folder?: string;
    /**
    * Name of card to link in originating dashboard.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link#from_card DashboardLink#from_card}
    */
    readonly fromCard?: string;
    /**
    * OID of dashboard to link from.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link#from_dashboard DashboardLink#from_dashboard}
    */
    readonly fromDashboard: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link#id DashboardLink#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The label for the link.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link#link_label DashboardLink#link_label}
    */
    readonly linkLabel: string;
    /**
    * Link name.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link#name DashboardLink#name}
    */
    readonly name: string;
    /**
    * OID of dashboard to link to.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link#to_dashboard DashboardLink#to_dashboard}
    */
    readonly toDashboard: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link#workspace DashboardLink#workspace}
    */
    readonly workspace?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link observe_dashboard_link}
*/
export declare class DashboardLink extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_dashboard_link";
    /**
    * Generates CDKTF code for importing a DashboardLink resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DashboardLink to import
    * @param importFromId The id of the existing DashboardLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DashboardLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/dashboard_link observe_dashboard_link} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DashboardLinkConfig
    */
    constructor(scope: Construct, id: string, config: DashboardLinkConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _folder?;
    get folder(): string;
    set folder(value: string);
    resetFolder(): void;
    get folderInput(): string | undefined;
    private _fromCard?;
    get fromCard(): string;
    set fromCard(value: string);
    resetFromCard(): void;
    get fromCardInput(): string | undefined;
    private _fromDashboard?;
    get fromDashboard(): string;
    set fromDashboard(value: string);
    get fromDashboardInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _linkLabel?;
    get linkLabel(): string;
    set linkLabel(value: string);
    get linkLabelInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _toDashboard?;
    get toDashboard(): string;
    set toDashboard(value: string);
    get toDashboardInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
