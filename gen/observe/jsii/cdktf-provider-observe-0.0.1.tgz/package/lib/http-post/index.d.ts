import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface HttpPostConfig extends cdktf.TerraformMetaArguments {
    /**
    * Content Type for HTTP POST request
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/http_post#content_type HttpPost#content_type}
    */
    readonly contentType?: string;
    /**
    * Data to submit to Observe collector
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/http_post#data HttpPost#data}
    */
    readonly data: string;
    /**
    * Additional HTTP headers
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/http_post#headers HttpPost#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/http_post#id HttpPost#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Key used to tag submitted observations with unique ID. Set to empty string to omit tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/http_post#id_tag HttpPost#id_tag}
    */
    readonly idTag?: string;
    /**
    * Path under which to submit observations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/http_post#path HttpPost#path}
    */
    readonly path?: string;
    /**
    * Tags to set on submitted observations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/http_post#tags HttpPost#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/http_post observe_http_post}
*/
export declare class HttpPost extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_http_post";
    /**
    * Generates CDKTF code for importing a HttpPost resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HttpPost to import
    * @param importFromId The id of the existing HttpPost that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/http_post#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HttpPost to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/http_post observe_http_post} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HttpPostConfig
    */
    constructor(scope: Construct, id: string, config: HttpPostConfig);
    get acked(): string;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _data?;
    get data(): string;
    set data(value: string);
    get dataInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idTag?;
    get idTag(): string;
    set idTag(value: string);
    resetIdTag(): void;
    get idTagInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
