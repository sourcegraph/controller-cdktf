import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface BookmarkGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Description of bookmark group.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark_group#description BookmarkGroup#description}
    */
    readonly description?: string;
    /**
    * Icon used when presenting bookmark group.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark_group#icon_url BookmarkGroup#icon_url}
    */
    readonly iconUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark_group#id BookmarkGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to add this bookmark group to the home page
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark_group#is_home BookmarkGroup#is_home}
    */
    readonly isHome?: boolean | cdktf.IResolvable;
    /**
    * Name of bookmark group.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark_group#name BookmarkGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark_group#presentation BookmarkGroup#presentation}
    */
    readonly presentation?: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark_group#workspace BookmarkGroup#workspace}
    */
    readonly workspace: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark_group observe_bookmark_group}
*/
export declare class BookmarkGroup extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_bookmark_group";
    /**
    * Generates CDKTF code for importing a BookmarkGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BookmarkGroup to import
    * @param importFromId The id of the existing BookmarkGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BookmarkGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/bookmark_group observe_bookmark_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BookmarkGroupConfig
    */
    constructor(scope: Construct, id: string, config: BookmarkGroupConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _iconUrl?;
    get iconUrl(): string;
    set iconUrl(value: string);
    resetIconUrl(): void;
    get iconUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isHome?;
    get isHome(): boolean | cdktf.IResolvable;
    set isHome(value: boolean | cdktf.IResolvable);
    resetIsHome(): void;
    get isHomeInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _presentation?;
    get presentation(): string;
    set presentation(value: string);
    resetPresentation(): void;
    get presentationInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
