import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveDashboardConfig extends cdktf.TerraformMetaArguments {
    /**
    * Dashboard ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dashboard#id DataObserveDashboard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dashboard observe_dashboard}
*/
export declare class DataObserveDashboard extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_dashboard";
    /**
    * Generates CDKTF code for importing a DataObserveDashboard resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveDashboard to import
    * @param importFromId The id of the existing DataObserveDashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveDashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/dashboard observe_dashboard} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveDashboardConfig
    */
    constructor(scope: Construct, id: string, config: DataObserveDashboardConfig);
    get description(): string;
    get iconUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get layout(): string;
    get name(): string;
    get oid(): string;
    get parameterValues(): string;
    get parameters(): string;
    get stages(): string;
    get workspace(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
