import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RbacGroupMemberConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_group_member#description RbacGroupMember#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_group_member#group RbacGroupMember#group}
    */
    readonly group: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_group_member#id RbacGroupMember#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * member block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_group_member#member RbacGroupMember#member}
    */
    readonly member: RbacGroupMemberMember;
}
export interface RbacGroupMemberMember {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_group_member#group RbacGroupMember#group}
    */
    readonly group?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_group_member#user RbacGroupMember#user}
    */
    readonly user?: string;
}
export declare function rbacGroupMemberMemberToTerraform(struct?: RbacGroupMemberMemberOutputReference | RbacGroupMemberMember): any;
export declare function rbacGroupMemberMemberToHclTerraform(struct?: RbacGroupMemberMemberOutputReference | RbacGroupMemberMember): any;
export declare class RbacGroupMemberMemberOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RbacGroupMemberMember | undefined;
    set internalValue(value: RbacGroupMemberMember | undefined);
    private _group?;
    get group(): string;
    set group(value: string);
    resetGroup(): void;
    get groupInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_group_member observe_rbac_group_member}
*/
export declare class RbacGroupMember extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_rbac_group_member";
    /**
    * Generates CDKTF code for importing a RbacGroupMember resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RbacGroupMember to import
    * @param importFromId The id of the existing RbacGroupMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_group_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RbacGroupMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/rbac_group_member observe_rbac_group_member} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RbacGroupMemberConfig
    */
    constructor(scope: Construct, id: string, config: RbacGroupMemberConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get oid(): string;
    private _member;
    get member(): RbacGroupMemberMemberOutputReference;
    putMember(value: RbacGroupMemberMember): void;
    get memberInput(): RbacGroupMemberMember | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
