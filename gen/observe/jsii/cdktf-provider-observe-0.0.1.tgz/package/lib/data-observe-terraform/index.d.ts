import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveTerraformConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/terraform#id DataObserveTerraform#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The OID of the target object, for which Terraform configuration will be generated. This can be a dataset, monitor, or dashboard.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/terraform#target DataObserveTerraform#target}
    */
    readonly target: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/terraform observe_terraform}
*/
export declare class DataObserveTerraform extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_terraform";
    /**
    * Generates CDKTF code for importing a DataObserveTerraform resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveTerraform to import
    * @param importFromId The id of the existing DataObserveTerraform that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/terraform#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveTerraform to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/terraform observe_terraform} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveTerraformConfig
    */
    constructor(scope: Construct, id: string, config: DataObserveTerraformConfig);
    get dataSource(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get importId(): string;
    get importName(): string;
    get resource(): string;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
