import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PreferredPathConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#description PreferredPath#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#folder PreferredPath#folder}
    */
    readonly folder?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#id PreferredPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#name PreferredPath#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#source PreferredPath#source}
    */
    readonly source: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#workspace PreferredPath#workspace}
    */
    readonly workspace?: string;
    /**
    * step block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#step PreferredPath#step}
    */
    readonly step: PreferredPathStep[] | cdktf.IResolvable;
}
export interface PreferredPathStep {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#link PreferredPath#link}
    */
    readonly link?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#link_label PreferredPath#link_label}
    */
    readonly linkLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#reverse PreferredPath#reverse}
    */
    readonly reverse?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#reverse_from PreferredPath#reverse_from}
    */
    readonly reverseFrom?: string;
}
export declare function preferredPathStepToTerraform(struct?: PreferredPathStep | cdktf.IResolvable): any;
export declare function preferredPathStepToHclTerraform(struct?: PreferredPathStep | cdktf.IResolvable): any;
export declare class PreferredPathStepOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PreferredPathStep | cdktf.IResolvable | undefined;
    set internalValue(value: PreferredPathStep | cdktf.IResolvable | undefined);
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _linkLabel?;
    get linkLabel(): string;
    set linkLabel(value: string);
    resetLinkLabel(): void;
    get linkLabelInput(): string | undefined;
    private _reverse?;
    get reverse(): boolean | cdktf.IResolvable;
    set reverse(value: boolean | cdktf.IResolvable);
    resetReverse(): void;
    get reverseInput(): boolean | cdktf.IResolvable | undefined;
    private _reverseFrom?;
    get reverseFrom(): string;
    set reverseFrom(value: string);
    resetReverseFrom(): void;
    get reverseFromInput(): string | undefined;
}
export declare class PreferredPathStepList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PreferredPathStep[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PreferredPathStepOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path observe_preferred_path}
*/
export declare class PreferredPath extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_preferred_path";
    /**
    * Generates CDKTF code for importing a PreferredPath resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PreferredPath to import
    * @param importFromId The id of the existing PreferredPath that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PreferredPath to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/preferred_path observe_preferred_path} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PreferredPathConfig
    */
    constructor(scope: Construct, id: string, config: PreferredPathConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _folder?;
    get folder(): string;
    set folder(value: string);
    resetFolder(): void;
    get folderInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
    private _step;
    get step(): PreferredPathStepList;
    putStep(value: PreferredPathStep[] | cdktf.IResolvable): void;
    get stepInput(): cdktf.IResolvable | PreferredPathStep[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
