import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DatastreamTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * OID of datastream token is contained in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/datastream_token#datastream DatastreamToken#datastream}
    */
    readonly datastream: string;
    /**
    * Datastream description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/datastream_token#description DatastreamToken#description}
    */
    readonly description?: string;
    /**
    * Disable token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/datastream_token#disabled DatastreamToken#disabled}
    */
    readonly disabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/datastream_token#id DatastreamToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Datastream name. Must be unique within workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/datastream_token#name DatastreamToken#name}
    */
    readonly name: string;
    /**
    * Password to be used as part of the token secret
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/datastream_token#password DatastreamToken#password}
    */
    readonly password?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/datastream_token observe_datastream_token}
*/
export declare class DatastreamToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_datastream_token";
    /**
    * Generates CDKTF code for importing a DatastreamToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatastreamToken to import
    * @param importFromId The id of the existing DatastreamToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/datastream_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatastreamToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/datastream_token observe_datastream_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatastreamTokenConfig
    */
    constructor(scope: Construct, id: string, config: DatastreamTokenConfig);
    private _datastream?;
    get datastream(): string;
    set datastream(value: string);
    get datastreamInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktf.IResolvable;
    set disabled(value: boolean | cdktf.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    get secret(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
