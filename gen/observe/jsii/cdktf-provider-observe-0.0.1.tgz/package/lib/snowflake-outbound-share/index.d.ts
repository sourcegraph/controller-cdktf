import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SnowflakeOutboundShareConfig extends cdktf.TerraformMetaArguments {
    /**
    * A description of the share.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/snowflake_outbound_share#description SnowflakeOutboundShare#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/snowflake_outbound_share#id SnowflakeOutboundShare#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A descriptive name for the share. This will be included in the Snowflake share name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/snowflake_outbound_share#name SnowflakeOutboundShare#name}
    */
    readonly name: string;
    /**
    * OID of the workspace this object is contained in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/snowflake_outbound_share#workspace SnowflakeOutboundShare#workspace}
    */
    readonly workspace: string;
    /**
    * account block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/snowflake_outbound_share#account SnowflakeOutboundShare#account}
    */
    readonly account: SnowflakeOutboundShareAccount[] | cdktf.IResolvable;
}
export interface SnowflakeOutboundShareAccount {
    /**
    * The name of the Snowflake account to share with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/snowflake_outbound_share#account SnowflakeOutboundShare#account}
    */
    readonly account: string;
    /**
    * The name of the Snowflake organization to share with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/snowflake_outbound_share#organization SnowflakeOutboundShare#organization}
    */
    readonly organization: string;
}
export declare function snowflakeOutboundShareAccountToTerraform(struct?: SnowflakeOutboundShareAccount | cdktf.IResolvable): any;
export declare function snowflakeOutboundShareAccountToHclTerraform(struct?: SnowflakeOutboundShareAccount | cdktf.IResolvable): any;
export declare class SnowflakeOutboundShareAccountOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SnowflakeOutboundShareAccount | cdktf.IResolvable | undefined;
    set internalValue(value: SnowflakeOutboundShareAccount | cdktf.IResolvable | undefined);
    private _account?;
    get account(): string;
    set account(value: string);
    get accountInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
}
export declare class SnowflakeOutboundShareAccountList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: SnowflakeOutboundShareAccount[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SnowflakeOutboundShareAccountOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/snowflake_outbound_share observe_snowflake_outbound_share}
*/
export declare class SnowflakeOutboundShare extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_snowflake_outbound_share";
    /**
    * Generates CDKTF code for importing a SnowflakeOutboundShare resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SnowflakeOutboundShare to import
    * @param importFromId The id of the existing SnowflakeOutboundShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/snowflake_outbound_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SnowflakeOutboundShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/snowflake_outbound_share observe_snowflake_outbound_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SnowflakeOutboundShareConfig
    */
    constructor(scope: Construct, id: string, config: SnowflakeOutboundShareConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oid(): string;
    get shareName(): string;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    private _account;
    get account(): SnowflakeOutboundShareAccountList;
    putAccount(value: SnowflakeOutboundShareAccount[] | cdktf.IResolvable): void;
    get accountInput(): cdktf.IResolvable | SnowflakeOutboundShareAccount[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
