import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveIngestInfoConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/ingest_info#id DataObserveIngestInfo#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/ingest_info observe_ingest_info}
*/
export declare class DataObserveIngestInfo extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_ingest_info";
    /**
    * Generates CDKTF code for importing a DataObserveIngestInfo resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveIngestInfo to import
    * @param importFromId The id of the existing DataObserveIngestInfo that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/ingest_info#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveIngestInfo to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/ingest_info observe_ingest_info} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveIngestInfoConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataObserveIngestInfoConfig);
    get collectUrl(): string;
    get domain(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get port(): string;
    get scheme(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
