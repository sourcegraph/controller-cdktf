import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CorrelationTagConfig extends cdktf.TerraformMetaArguments {
    /**
    * The column to which the correlation tag should be attached.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/correlation_tag#column CorrelationTag#column}
    */
    readonly column: string;
    /**
    * OID of the dataset to which the correlation tag should be attached.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/correlation_tag#dataset CorrelationTag#dataset}
    */
    readonly dataset: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/correlation_tag#id CorrelationTag#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name to attach.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/correlation_tag#name CorrelationTag#name}
    */
    readonly name: string;
    /**
    * If the column is of type "object", a correlation tag can be attached to a
    * key nested within the object. Standard Javascript notation can be used to specify the path to the key.
    * For example, say the object has the following structure -
    * {
    *   "a": {
    *     "b": {
    *       "c": "value"
    *     }
    *   }
    * }
    * Then the path to the key "c" would be "a.b.c" or "a['b']['c']"
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/correlation_tag#path CorrelationTag#path}
    */
    readonly path?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/correlation_tag observe_correlation_tag}
*/
export declare class CorrelationTag extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_correlation_tag";
    /**
    * Generates CDKTF code for importing a CorrelationTag resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CorrelationTag to import
    * @param importFromId The id of the existing CorrelationTag that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/correlation_tag#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CorrelationTag to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/correlation_tag observe_correlation_tag} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CorrelationTagConfig
    */
    constructor(scope: Construct, id: string, config: CorrelationTagConfig);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    get datasetInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
