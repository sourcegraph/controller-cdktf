import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ResourceGrantsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/resource_grants#id ResourceGrants#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The OID of the resource to manage grants for.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/resource_grants#oid ResourceGrants#oid}
    */
    readonly oid: string;
    /**
    * grant block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/resource_grants#grant ResourceGrants#grant}
    */
    readonly grant?: ResourceGrantsGrant[] | cdktf.IResolvable;
}
export interface ResourceGrantsGrant {
    /**
    * The role to grant.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/resource_grants#role ResourceGrants#role}
    */
    readonly role: string;
    /**
    * OID of the subject. Must be a user or a group.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/resource_grants#subject ResourceGrants#subject}
    */
    readonly subject: string;
}
export declare function resourceGrantsGrantToTerraform(struct?: ResourceGrantsGrant | cdktf.IResolvable): any;
export declare function resourceGrantsGrantToHclTerraform(struct?: ResourceGrantsGrant | cdktf.IResolvable): any;
export declare class ResourceGrantsGrantOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ResourceGrantsGrant | cdktf.IResolvable | undefined;
    set internalValue(value: ResourceGrantsGrant | cdktf.IResolvable | undefined);
    get oid(): string;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class ResourceGrantsGrantList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ResourceGrantsGrant[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ResourceGrantsGrantOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/resource_grants observe_resource_grants}
*/
export declare class ResourceGrants extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_resource_grants";
    /**
    * Generates CDKTF code for importing a ResourceGrants resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ResourceGrants to import
    * @param importFromId The id of the existing ResourceGrants that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/resource_grants#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ResourceGrants to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/resource_grants observe_resource_grants} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ResourceGrantsConfig
    */
    constructor(scope: Construct, id: string, config: ResourceGrantsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _oid?;
    get oid(): string;
    set oid(value: string);
    get oidInput(): string | undefined;
    private _grant;
    get grant(): ResourceGrantsGrantList;
    putGrant(value: ResourceGrantsGrant[] | cdktf.IResolvable): void;
    resetGrant(): void;
    get grantInput(): cdktf.IResolvable | ResourceGrantsGrant[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
