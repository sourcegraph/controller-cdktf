import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ReportConfig extends cdktf.TerraformMetaArguments {
    /**
    * A list of e-mail bcc addresses that will receive the report.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#email_bcc_recipients Report#email_bcc_recipients}
    */
    readonly emailBccRecipients?: string[];
    /**
    * The body of the e-mail that will be sent every time the report runs. This is used to add some context to the email.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#email_body Report#email_body}
    */
    readonly emailBody?: string;
    /**
    * A list of e-mail addresses that will receive the report.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#email_recipients Report#email_recipients}
    */
    readonly emailRecipients: string[];
    /**
    * The subject of the e-mail that will be sent every time the report runs.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#email_subject Report#email_subject}
    */
    readonly emailSubject: string;
    /**
    * Whether the report is enabled or not. A disabled report will not run on the defined schedule.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#enabled Report#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#id Report#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the report.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#label Report#label}
    */
    readonly label: string;
    /**
    * dashboard block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#dashboard Report#dashboard}
    */
    readonly dashboard: ReportDashboard;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#schedule Report#schedule}
    */
    readonly schedule: ReportSchedule;
}
export interface ReportCreatedBy {
}
export declare function reportCreatedByToTerraform(struct?: ReportCreatedBy): any;
export declare function reportCreatedByToHclTerraform(struct?: ReportCreatedBy): any;
export declare class ReportCreatedByOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReportCreatedBy | undefined;
    set internalValue(value: ReportCreatedBy | undefined);
    get id(): string;
    get label(): string;
}
export declare class ReportCreatedByList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReportCreatedByOutputReference;
}
export interface ReportUpdatedBy {
}
export declare function reportUpdatedByToTerraform(struct?: ReportUpdatedBy): any;
export declare function reportUpdatedByToHclTerraform(struct?: ReportUpdatedBy): any;
export declare class ReportUpdatedByOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReportUpdatedBy | undefined;
    set internalValue(value: ReportUpdatedBy | undefined);
    get id(): string;
    get label(): string;
}
export declare class ReportUpdatedByList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReportUpdatedByOutputReference;
}
export interface ReportDashboardParameters {
    /**
    * The name of the parameter.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#key Report#key}
    */
    readonly key: string;
    /**
    * The value of the parameter.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#value Report#value}
    */
    readonly value: string;
}
export declare function reportDashboardParametersToTerraform(struct?: ReportDashboardParameters | cdktf.IResolvable): any;
export declare function reportDashboardParametersToHclTerraform(struct?: ReportDashboardParameters | cdktf.IResolvable): any;
export declare class ReportDashboardParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReportDashboardParameters | cdktf.IResolvable | undefined;
    set internalValue(value: ReportDashboardParameters | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ReportDashboardParametersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ReportDashboardParameters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReportDashboardParametersOutputReference;
}
export interface ReportDashboard {
    /**
    * The ID of the dashboard to be used for the report.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#id Report#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The query window duration that will be used in the dashboard query in minutes.
    * E.g., if we want the report to contain the last day of data, this needs to be set to 1440.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#query_window_duration_minutes Report#query_window_duration_minutes}
    */
    readonly queryWindowDurationMinutes: number;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#parameters Report#parameters}
    */
    readonly parameters?: ReportDashboardParameters[] | cdktf.IResolvable;
}
export declare function reportDashboardToTerraform(struct?: ReportDashboardOutputReference | ReportDashboard): any;
export declare function reportDashboardToHclTerraform(struct?: ReportDashboardOutputReference | ReportDashboard): any;
export declare class ReportDashboardOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReportDashboard | undefined;
    set internalValue(value: ReportDashboard | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get label(): string;
    private _queryWindowDurationMinutes?;
    get queryWindowDurationMinutes(): number;
    set queryWindowDurationMinutes(value: number);
    get queryWindowDurationMinutesInput(): number | undefined;
    private _parameters;
    get parameters(): ReportDashboardParametersList;
    putParameters(value: ReportDashboardParameters[] | cdktf.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktf.IResolvable | ReportDashboardParameters[] | undefined;
}
export interface ReportSchedule {
    /**
    * The day of the month to run this report. Can be either 1 or 15.
    * This is only used if the frequency is "Monthly".
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#day_of_the_month Report#day_of_the_month}
    */
    readonly dayOfTheMonth?: number;
    /**
    * The day of the week to run this report. Can be "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", or "Sunday".
    * This is only used if the frequency is "Weekly".
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#day_of_the_week Report#day_of_the_week}
    */
    readonly dayOfTheWeek?: string;
    /**
    * Every how many days, weeks, or months (based on frequency) should the report run.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#every Report#every}
    */
    readonly every: number;
    /**
    * The frequency of the report. This can be "Hourly", "Daily", "Weekly", or "Monthly".
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#frequency Report#frequency}
    */
    readonly frequency: string;
    /**
    * The delay in minutes before the report is generated after the scheduled time.
    * This is useful if the data is not yet available at the scheduled time.
    * Can be between 0 and 120 minutes. The default value is 30 minutes.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#generation_delay_minutes Report#generation_delay_minutes}
    */
    readonly generationDelayMinutes?: number;
    /**
    * The time of day to run this report in {HH:MM} format
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#time_of_day Report#time_of_day}
    */
    readonly timeOfDay: string;
    /**
    * The IANA timezone to run this report in.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#timezone Report#timezone}
    */
    readonly timezone?: string;
}
export declare function reportScheduleToTerraform(struct?: ReportScheduleOutputReference | ReportSchedule): any;
export declare function reportScheduleToHclTerraform(struct?: ReportScheduleOutputReference | ReportSchedule): any;
export declare class ReportScheduleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReportSchedule | undefined;
    set internalValue(value: ReportSchedule | undefined);
    private _dayOfTheMonth?;
    get dayOfTheMonth(): number;
    set dayOfTheMonth(value: number);
    resetDayOfTheMonth(): void;
    get dayOfTheMonthInput(): number | undefined;
    private _dayOfTheWeek?;
    get dayOfTheWeek(): string;
    set dayOfTheWeek(value: string);
    resetDayOfTheWeek(): void;
    get dayOfTheWeekInput(): string | undefined;
    private _every?;
    get every(): number;
    set every(value: number);
    get everyInput(): number | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    get frequencyInput(): string | undefined;
    private _generationDelayMinutes?;
    get generationDelayMinutes(): number;
    set generationDelayMinutes(value: number);
    resetGenerationDelayMinutes(): void;
    get generationDelayMinutesInput(): number | undefined;
    private _timeOfDay?;
    get timeOfDay(): string;
    set timeOfDay(value: string);
    get timeOfDayInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report observe_report}
*/
export declare class Report extends cdktf.TerraformResource {
    static readonly tfResourceType = "observe_report";
    /**
    * Generates CDKTF code for importing a Report resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Report to import
    * @param importFromId The id of the existing Report that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Report to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/resources/report observe_report} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ReportConfig
    */
    constructor(scope: Construct, id: string, config: ReportConfig);
    get createdAt(): string;
    private _createdBy;
    get createdBy(): ReportCreatedByList;
    private _emailBccRecipients?;
    get emailBccRecipients(): string[];
    set emailBccRecipients(value: string[]);
    resetEmailBccRecipients(): void;
    get emailBccRecipientsInput(): string[] | undefined;
    private _emailBody?;
    get emailBody(): string;
    set emailBody(value: string);
    resetEmailBody(): void;
    get emailBodyInput(): string | undefined;
    private _emailRecipients?;
    get emailRecipients(): string[];
    set emailRecipients(value: string[]);
    get emailRecipientsInput(): string[] | undefined;
    private _emailSubject?;
    get emailSubject(): string;
    set emailSubject(value: string);
    get emailSubjectInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    get lastRunError(): string;
    get lastRunStatus(): string;
    get lastRunTime(): string;
    get nextScheduledTime(): string;
    get oid(): string;
    get updatedAt(): string;
    private _updatedBy;
    get updatedBy(): ReportUpdatedByList;
    private _dashboard;
    get dashboard(): ReportDashboardOutputReference;
    putDashboard(value: ReportDashboard): void;
    get dashboardInput(): ReportDashboard | undefined;
    private _schedule;
    get schedule(): ReportScheduleOutputReference;
    putSchedule(value: ReportSchedule): void;
    get scheduleInput(): ReportSchedule | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
