import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataObserveDatastreamConfig extends cdktf.TerraformMetaArguments {
    /**
    * Datastream ID. Either `name` or `id` must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/datastream#id DataObserveDatastream#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Datastream name. Must be unique within workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/datastream#name DataObserveDatastream#name}
    */
    readonly name?: string;
    /**
    * OID of workspace datastream is contained in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/datastream#workspace DataObserveDatastream#workspace}
    */
    readonly workspace: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/datastream observe_datastream}
*/
export declare class DataObserveDatastream extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "observe_datastream";
    /**
    * Generates CDKTF code for importing a DataObserveDatastream resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataObserveDatastream to import
    * @param importFromId The id of the existing DataObserveDatastream that should be imported. Refer to the {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/datastream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataObserveDatastream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/observeinc/observe/0.14.47/docs/data-sources/datastream observe_datastream} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataObserveDatastreamConfig
    */
    constructor(scope: Construct, id: string, config: DataObserveDatastreamConfig);
    get dataset(): string;
    get description(): string;
    get iconUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get oid(): string;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
