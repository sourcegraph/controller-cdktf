import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface GkeprivateConfig extends TerraformModuleUserConfig {
    /**
    * Create additional firewall rules
    */
    readonly addClusterFirewallRules?: boolean;
    /**
    * Create master_webhook firewall rules for ports defined in `firewall_inbound_ports`
    */
    readonly addMasterWebhookFirewallRules?: boolean;
    /**
    * Create GKE shadow firewall (the same as default firewall rules with firewall logs enabled).
    */
    readonly addShadowFirewallRules?: boolean;
    /**
    * List of _names_ of the additional secondary subnet ip ranges to use for pods
    *
    */
    readonly additionalIpRangePods?: string[];
    /**
    * the configuration for individual additional subnetworks attached to the cluster
    *
    */
    readonly additionalIpRangesConfig?: any[];
    /**
    * This will enable Cloud DNS additive VPC scope. Must provide a domain name that is unique within the VPC. For this to work cluster_dns = `CLOUD_DNS` and cluster_dns_scope = `CLUSTER_SCOPE` must both be set as well.
    */
    readonly additiveVpcScopeDnsDomain?: string;
    /**
    * Allows users to restrict or enable anonymous access to the cluster. Valid values are `ENABLED` and `LIMITED`.
    */
    readonly anonymousAuthenticationConfigMode?: string;
    /**
    * The name of the RBAC security group for use with Google security groups in Kubernetes RBAC. Group name must be in format gke-security-groups@yourdomain.com
    */
    readonly authenticatorSecurityGroup?: string;
    /**
    * The Customer Managed Encryption Key used to encrypt the boot disk attached to each node in the node pool, if not overridden in `node_pools`. This should be of the form projects/[KEY_PROJECT_ID]/locations/[LOCATION]/keyRings/[RING_NAME]/cryptoKeys/[KEY_NAME]. For more information about protecting resources with Cloud KMS Keys please see: https://cloud.google.com/compute/docs/disks/customer-managed-encryption
    */
    readonly bootDiskKmsKey?: string;
    /**
    * (Beta) Enable CloudRun addon
    */
    readonly cloudrun?: boolean;
    /**
    * (Beta) Configure the Cloud Run load balancer type. External by default. Set to `LOAD_BALANCER_TYPE_INTERNAL` to configure as an internal load balancer.
    */
    readonly cloudrunLoadBalancerType?: string;
    /**
    * Cluster autoscaling configuration. See [more details](https://cloud.google.com/kubernetes-engine/docs/reference/rest/v1beta1/projects.locations.clusters#clusterautoscaling)
    */
    readonly clusterAutoscaling?: any;
    /**
    * The suffix used for all cluster service records.
    */
    readonly clusterDnsDomain?: string;
    /**
    * Which in-cluster DNS provider should be used. PROVIDER_UNSPECIFIED (default) or PLATFORM_DEFAULT or CLOUD_DNS.
    * PROVIDER_UNSPECIFIED
    */
    readonly clusterDnsProvider?: string;
    /**
    * The scope of access to cluster DNS records. DNS_SCOPE_UNSPECIFIED (default) or CLUSTER_SCOPE or VPC_SCOPE.
    * DNS_SCOPE_UNSPECIFIED
    */
    readonly clusterDnsScope?: string;
    /**
    * The IP address range of the kubernetes pods in this cluster. Default is an automatically assigned CIDR.
    */
    readonly clusterIpv4Cidr?: string;
    /**
    * The GCE resource labels (a map of key/value pairs) to be applied to the cluster
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly clusterResourceLabels?: {
        [key: string]: string;
    };
    /**
    * Available options include ENABLED, DISABLED, and SYSTEM_ONLY
    */
    readonly clusterTelemetryType?: string;
    /**
    * Whether ConfigConnector is enabled for this cluster.
    */
    readonly configConnector?: boolean;
    /**
    * Enables the installation of ip masquerading, which is usually no longer required when using aliasied IP addresses. IP masquerading uses a kubectl call, so when you have a private cluster, you will need access to the API server.
    */
    readonly configureIpMasq?: boolean;
    /**
    * Defines if service account specified to run nodes should be created.
    * true
    */
    readonly createServiceAccount?: boolean;
    /**
    * Application-layer Secrets Encryption settings. The object format is {state = string, key_name = string}. Valid values of state are: "ENCRYPTED"; "DECRYPTED". key_name is the name of a CloudKMS key.
    * [object Object]
    */
    readonly databaseEncryption?: any[];
    /**
    * The desired datapath provider for this cluster. By default, `DATAPATH_PROVIDER_UNSPECIFIED` enables the IPTables-based kube-proxy implementation. `ADVANCED_DATAPATH` enables Dataplane-V2 feature.
    * DATAPATH_PROVIDER_UNSPECIFIED
    */
    readonly datapathProvider?: string;
    /**
    * The maximum number of pods to schedule per node
    * 110
    */
    readonly defaultMaxPodsPerNode?: number;
    /**
    * Whether or not to allow Terraform to destroy the cluster.
    * true
    */
    readonly deletionProtection?: boolean;
    /**
    * A toggle for Terraform and kubectl to connect to the master's internal IP address during deployment.
    */
    readonly deployUsingPrivateEndpoint?: boolean;
    /**
    * The description of the cluster
    */
    readonly description?: string;
    /**
    * Whether to disable the default SNAT to support the private use of public IP addresses
    */
    readonly disableDefaultSnat?: boolean;
    /**
    * Disable L4 Load Balancer firewall reconciliation
    */
    readonly disableL4LbFirewallReconciliation?: boolean;
    /**
    * Disable the /0.1/ and /v1beta1/ metadata server endpoints on the node. Changing this value will cause all node pools to be recreated.
    * true
    */
    readonly disableLegacyMetadataEndpoints?: boolean;
    /**
    * (Optional) Controls whether external traffic is allowed over the dns endpoint.
    */
    readonly dnsAllowExternalTraffic?: boolean;
    /**
    * The status of the NodeLocal DNSCache addon.
    */
    readonly dnsCache?: boolean;
    /**
    * Enable BinAuthZ Admission controller
    */
    readonly enableBinaryAuthorization?: boolean;
    /**
    * Enable Cilium Cluster Wide Network Policies on the cluster
    */
    readonly enableCiliumClusterwideNetworkPolicy?: boolean;
    /**
    * An optional flag to enable confidential node config.
    */
    readonly enableConfidentialNodes?: boolean;
    /**
    * Enables Cost Allocation Feature and the cluster name and namespace of your GKE workloads appear in the labels field of the billing export to BigQuery
    */
    readonly enableCostAllocation?: boolean;
    /**
    * Whether to enable the default node pools metadata key-value pairs such as `cluster_name` and `node_pool`
    * true
    */
    readonly enableDefaultNodePoolsMetadata?: boolean;
    /**
    * Enable FQDN Network Policies on the cluster
    */
    readonly enableFqdnNetworkPolicy?: boolean;
    /**
    * Enable image streaming on cluster level.
    */
    readonly enableGcfs?: boolean;
    /**
    * (Optional) Enable the Identity Service component, which allows customers to use external identity providers with the K8S API. NOTE: Starting on July 1, 2025, new Google Cloud organizations that you create won't support Identity Service for GKE.
    */
    readonly enableIdentityService?: boolean;
    /**
    * Whether Intra-node visibility is enabled for this cluster. This makes same node pod to pod traffic visible for VPC network
    */
    readonly enableIntranodeVisibility?: boolean;
    /**
    * (Optional) - List of Kubernetes Beta APIs to enable in cluster.
    *
    */
    readonly enableK8SBetaApis?: string[];
    /**
    * Whether to enable Kubernetes Alpha features for this cluster. Note that when this option is enabled, the cluster cannot be upgraded and will be automatically deleted after 30 days.
    */
    readonly enableKubernetesAlpha?: boolean;
    /**
    * Enable L4 ILB Subsetting on the cluster
    */
    readonly enableL4IlbSubsetting?: boolean;
    /**
    * Set it to true for GKE cluster runs a version earlier than 1.33.2-gke.4780000. Allows the Lustre CSI driver to initialize LNet (the virtual network layer for Lustre kernel module) using port 6988. This flag is required to workaround a port conflict with the gke-metadata-server on GKE nodes
    */
    readonly enableLegacyLustrePort?: boolean;
    /**
    * Controls the issuance of workload mTLS certificates. When enabled the GKE Workload Identity Certificates controller and node agent will be deployed in the cluster. Requires Workload Identity.
    */
    readonly enableMeshCertificates?: boolean;
    /**
    * Whether multi-networking is enabled for this cluster
    */
    readonly enableMultiNetworking?: boolean;
    /**
    * Whether to enable network egress metering for this cluster. If enabled, a daemonset will be created in the cluster to meter network egress traffic.
    */
    readonly enableNetworkEgressExport?: boolean;
    /**
    * enabled - Enable the PodSecurityPolicy controller for this cluster. If enabled, pods must be valid under a PodSecurityPolicy to be created. Pod Security Policy was removed from GKE clusters with version >= 1.25.0.
    */
    readonly enablePodSecurityPolicy?: boolean;
    /**
    * Whether the master's internal IP address is used as the cluster endpoint
    */
    readonly enablePrivateEndpoint?: boolean;
    /**
    * Whether nodes have internal IP addresses only
    * true
    */
    readonly enablePrivateNodes?: boolean;
    /**
    * Whether to enable resource consumption metering on this cluster. When enabled, a table will be created in the resource export BigQuery dataset to store resource consumption data. The resulting table can be joined with the resource usage table or with BigQuery billing export.
    * true
    */
    readonly enableResourceConsumptionExport?: boolean;
    /**
    * Enable the Secret Manager add-on for this cluster
    */
    readonly enableSecretManagerAddon?: boolean;
    /**
    * Enable Shielded Nodes features on all nodes in this cluster
    * true
    */
    readonly enableShieldedNodes?: boolean;
    /**
    * Enable Cloud TPU resources in the cluster. WARNING: changing this after cluster creation is destructive!
    */
    readonly enableTpu?: boolean;
    /**
    * Vertical Pod Autoscaling automatically adjusts the resources of pods controlled by it
    */
    readonly enableVerticalPodAutoscaling?: boolean;
    /**
    * (Optional) Enable or disable GKE enterprise. Valid values are STANDARD and ENTERPRISE.
    */
    readonly enterpriseConfig?: string;
    /**
    * The status of the Filestore CSI driver addon, which allows the usage of filestore instance as volumes
    */
    readonly filestoreCsiDriver?: boolean;
    /**
    * List of TCP ports for admission/webhook controllers. Either flag `add_master_webhook_firewall_rules` or `add_cluster_firewall_rules` (also adds egress rules) must be set to `true` for inbound-ports firewall rules to be applied.
    * 8443
    * 9443
    * 15017
    */
    readonly firewallInboundPorts?: string[];
    /**
    * Priority rule for firewall rules
    * 1,000
    */
    readonly firewallPriority?: number;
    /**
    * (Optional) Register the cluster with the fleet in this project.
    */
    readonly fleetProject?: string;
    /**
    * (Optional) Grant the fleet project service identity the `roles/gkehub.serviceAgent` and `roles/gkehub.crossProjectServiceAgent` roles.
    */
    readonly fleetProjectGrantServiceAgent?: boolean;
    /**
    * The gateway api channel of this cluster. Accepted values are `CHANNEL_STANDARD` and `CHANNEL_DISABLED`.
    */
    readonly gatewayApiChannel?: string;
    /**
    * Whether this cluster should enable the Google Compute Engine Persistent Disk Container Storage Interface (CSI) Driver.
    * true
    */
    readonly gcePdCsiDriver?: boolean;
    /**
    * Allow access through Google Cloud public IP addresses
    */
    readonly gcpPublicCidrsAccessEnabled?: boolean;
    /**
    * Whether GCE FUSE CSI driver is enabled for this cluster.
    */
    readonly gcsFuseCsiDriver?: boolean;
    /**
    * The selected auto-upgrade patch type. Accepted values are: `ACCELERATED`: Upgrades to the latest available patch version in a given minor and release channel.
    */
    readonly gkeAutoUpgradeConfigPatchMode?: string;
    /**
    * Whether Backup for GKE agent is enabled for this cluster.
    */
    readonly gkeBackupAgentConfig?: boolean;
    /**
    * Grants created cluster-specific service account storage.objectViewer and artifactregistry.reader roles.
    */
    readonly grantRegistryAccess?: boolean;
    /**
    * Enable horizontal pod autoscaling addon
    * true
    */
    readonly horizontalPodAutoscaling?: boolean;
    /**
    * Enable the Horizontal Pod Autoscaling profile for this cluster. Values are "NONE" and "PERFORMANCE".
    */
    readonly hpaProfile?: string;
    /**
    * Enable httpload balancer addon
    * true
    */
    readonly httpLoadBalancing?: boolean;
    /**
    * The workload pool to attach all Kubernetes service accounts to. (Default value of `enabled` automatically sets project-based pool `[project_id].svc.id.goog`)
    * enabled
    */
    readonly identityNamespace?: string;
    /**
    * Defines the config of in-transit encryption. Valid values are `IN_TRANSIT_ENCRYPTION_DISABLED` and `IN_TRANSIT_ENCRYPTION_INTER_NODE_TRANSPARENT`.
    */
    readonly inTransitEncryptionConfig?: string;
    /**
    * The number of nodes to create in this cluster's default node pool.
    */
    readonly initialNodeCount?: number;
    /**
    * Whether or not to set `insecure_kubelet_readonly_port_enabled` for node pool defaults and autopilot clusters. Note: this can be set at the node pool level separately within `node_pools`.
    */
    readonly insecureKubeletReadonlyPortEnabled?: boolean;
    /**
    * (Optional) Controls whether to allow direct IP access. Defaults to `true`.
    */
    readonly ipEndpointsEnabled?: boolean;
    /**
    * Whether to masquerade traffic to the link-local prefix (169.254.0.0/16).
    */
    readonly ipMasqLinkLocal?: boolean;
    /**
    * The interval at which the agent attempts to sync its ConfigMap file from the disk.
    * 60s
    */
    readonly ipMasqResyncInterval?: string;
    /**
    * The _name_ of the secondary subnet ip range to use for pods
    */
    readonly ipRangePods: string;
    /**
    * The _name_ of the secondary subnet range to use for services. If not provided, the default `34.118.224.0/20` range will be used.
    */
    readonly ipRangeServices?: string;
    /**
    * Issues a client certificate to authenticate to the cluster endpoint. To maximize the security of your cluster, leave this option disabled. Client certificates don't automatically rotate and aren't easily revocable. WARNING: changing this after cluster creation is destructive!
    */
    readonly issueClientCertificate?: boolean;
    /**
    * The Kubernetes version of the masters. If set to 'latest' it will pull latest available version in the selected region.
    * latest
    */
    readonly kubernetesVersion?: string;
    /**
    * List of services to monitor: SYSTEM_COMPONENTS, APISERVER, CONTROLLER_MANAGER, KCP_CONNECTION, KCP_SSHD, KCP_HPA, SCHEDULER, and WORKLOADS. Empty list is default GKE configuration.
    *
    */
    readonly loggingEnabledComponents?: string[];
    /**
    * The logging service that the cluster should write logs to. Available options include logging.googleapis.com, logging.googleapis.com/kubernetes (beta), and none
    * logging.googleapis.com/kubernetes
    */
    readonly loggingService?: string;
    /**
    * (Optional) The type of logging agent that is deployed by default for newly created node pools in the cluster. Valid values include DEFAULT and MAX_THROUGHPUT.
    */
    readonly loggingVariant?: string;
    /**
    * The status of the Lustre CSI driver addon, which allows the usage of a Lustre instances as volumes
    */
    readonly lustreCsiDriver?: boolean;
    /**
    * Time window specified for recurring maintenance operations in RFC3339 format
    */
    readonly maintenanceEndTime?: string;
    /**
    * List of maintenance exclusions. A cluster can have up to three
    *
    */
    readonly maintenanceExclusions?: any[];
    /**
    * Frequency of the recurring maintenance window in RFC5545 format.
    */
    readonly maintenanceRecurrence?: string;
    /**
    * Time window specified for daily or recurring maintenance operations in RFC3339 format
    * 05:00
    */
    readonly maintenanceStartTime?: string;
    /**
    * List of master authorized networks. If none are provided, disallow external access (except the cluster node IPs, which GKE automatically whitelists).
    *
    */
    readonly masterAuthorizedNetworks?: any[];
    /**
    * Whether the cluster master is accessible globally (from any region) or only within the same region as the private endpoint.
    * true
    */
    readonly masterGlobalAccessEnabled?: boolean;
    /**
    * (Optional) The IP range in CIDR notation to use for the hosted master network.
    */
    readonly masterIpv4CidrBlock?: string;
    /**
    * Whether or not to enable GKE Auto-Monitoring. Supported values include: ALL, NONE
    * NONE
    */
    readonly monitoringAutoMonitoringConfigScope?: string;
    /**
    * Configuration for Managed Service for Prometheus. Whether or not the managed collection is enabled.
    */
    readonly monitoringEnableManagedPrometheus?: boolean;
    /**
    * Whether or not the advanced datapath metrics are enabled.
    */
    readonly monitoringEnableObservabilityMetrics?: boolean;
    /**
    * Whether or not the advanced datapath relay is enabled.
    */
    readonly monitoringEnableObservabilityRelay?: boolean;
    /**
    * List of services to monitor: SYSTEM_COMPONENTS, APISERVER, SCHEDULER, CONTROLLER_MANAGER, STORAGE, HPA, POD, DAEMONSET, DEPLOYMENT, STATEFULSET, KUBELET, CADVISOR, DCGM, and JOBSET. In beta provider, WORKLOADS is supported on top of those 12 values. (WORKLOADS is deprecated and removed in GKE 1.24.) KUBELET and CADVISOR are only supported in GKE 1.29.3-gke.1093000 and above. JOBSET is only supported in GKE 1.32.1-gke.1357001 and above. Empty list is default GKE configuration.
    *
    */
    readonly monitoringEnabledComponents?: string[];
    /**
    * The monitoring metrics writer role to assign to the GKE node service account
    * roles/monitoring.metricWriter
    */
    readonly monitoringMetricWriterRole?: string;
    /**
    * The monitoring service that the cluster should write metrics to. Automatically send metrics from pods in the cluster to the Google Cloud Monitoring API. VM metrics will be collected by Google Compute Engine regardless of this setting Available options include monitoring.googleapis.com, monitoring.googleapis.com/kubernetes (beta) and none
    * monitoring.googleapis.com/kubernetes
    */
    readonly monitoringService?: string;
    /**
    * The name of the cluster (required)
    */
    readonly name: string;
    /**
    * The VPC network to host the cluster in (required)
    */
    readonly network: string;
    /**
    * Enable network policy addon
    */
    readonly networkPolicy?: boolean;
    /**
    * The network policy provider.
    * CALICO
    */
    readonly networkPolicyProvider?: string;
    /**
    * The project ID of the shared VPC's host (for shared vpc support)
    */
    readonly networkProjectId?: string;
    /**
    * (Optional) - List of network tags applied to autopilot and auto-provisioned node pools.
    *
    */
    readonly networkTags?: string[];
    /**
    * Network tier configuration for the cluster
    */
    readonly networkTierConfig?: string;
    /**
    * Specifies how node metadata is exposed to the workload running on the node
    * GKE_METADATA
    */
    readonly nodeMetadata?: string;
    /**
    * List of maps containing node pools
    * [object Object]
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePools?: {
        [key: string]: any;
    }[];
    /**
    * Map of strings containing cgroup node config by node-pool name. Note: GKE is removing cgroup v1 support in 1.35.
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsCgroupMode?: {
        [key: string]: string;
    };
    /**
    * Map of strings containing hugepage size 1g config by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsHugepageSize1G?: {
        [key: string]: string;
    };
    /**
    * Map of strings containing hugepage size 2m node config by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsHugepageSize2M?: {
        [key: string]: string;
    };
    /**
    * Map of maps containing node labels by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsLabels?: {
        [key: string]: {
            [key: string]: string;
        };
    };
    /**
    * Map of maps containing linux node config sysctls by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsLinuxNodeConfigsSysctls?: {
        [key: string]: {
            [key: string]: string;
        };
    };
    /**
    * Map of maps containing node metadata by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsMetadata?: {
        [key: string]: {
            [key: string]: string;
        };
    };
    /**
    * Map of lists containing node oauth scopes by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsOauthScopes?: {
        [key: string]: string[];
    };
    /**
    * Map of maps containing resource labels by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsResourceLabels?: {
        [key: string]: {
            [key: string]: string;
        };
    };
    /**
    * Map of maps containing resource manager tags by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsResourceManagerTags?: {
        [key: string]: {
            [key: string]: string;
        };
    };
    /**
    * Map of lists containing node network tags by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsTags?: {
        [key: string]: string[];
    };
    /**
    * Map of lists containing node taints by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsTaints?: {
        [key: string]: any[];
    };
    /**
    * Map of strings containing transparent hugepage defrag node config by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsTransparentHugepageDefrag?: {
        [key: string]: string;
    };
    /**
    * Map of strings containing transparent hugepage enabled node config by node-pool name
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly nodePoolsTransparentHugepageEnabled?: {
        [key: string]: string;
    };
    /**
    * List of strings in CIDR notation that specify the IP address ranges that do not use IP masquerading.
    * 10.0.0.0/8
    * 172.16.0.0/12
    * 192.168.0.0/16
    */
    readonly nonMasqueradeCidrs?: string[];
    /**
    * The desired Pub/Sub topic to which notifications will be sent by GKE. Format is projects/{project}/topics/{topic}.
    */
    readonly notificationConfigTopic?: string;
    /**
    * Choose what type of notifications you want to receive. If no filters are applied, you'll receive all notification types. Can be used to filter what notifications are sent. Accepted values are UPGRADE_AVAILABLE_EVENT, UPGRADE_EVENT, and SECURITY_BULLETIN_EVENT.
    *
    */
    readonly notificationFilterEventType?: string[];
    /**
    * Whether the Parallelstore CSI driver Addon is enabled for this cluster.
    */
    readonly parallelstoreCsiDriver?: boolean;
    /**
    * The subnetwork to use for the hosted master network.
    */
    readonly privateEndpointSubnetwork?: string;
    /**
    * The project ID to host the cluster in (required)
    */
    readonly projectId: string;
    /**
    * The Ray Operator Addon configuration for this cluster.
    */
    readonly rayOperatorConfig?: any;
    /**
    * RBACBindingConfig allows user to restrict ClusterRoleBindings an RoleBindings that can be created.
    */
    readonly rbacBindingConfig?: any;
    /**
    * The region to host the cluster in (optional if zonal cluster / required if regional)
    */
    readonly region?: string;
    /**
    * Whether is a regional cluster (zonal cluster if set false. WARNING: changing this after cluster creation is destructive!)
    * true
    */
    readonly regional?: boolean;
    /**
    * Projects holding Google Container Registries. If empty, we use the cluster project. If a service account is created and the `grant_registry_access` variable is set to `true`, the `storage.objectViewer` and `artifactregsitry.reader` roles are assigned on these projects.
    *
    */
    readonly registryProjectIds?: string[];
    /**
    * The release channel of this cluster. Accepted values are `UNSPECIFIED`, `RAPID`, `REGULAR` and `STABLE`. Defaults to `REGULAR`.
    * REGULAR
    */
    readonly releaseChannel?: string;
    /**
    * Remove default node pool while setting up the cluster
    */
    readonly removeDefaultNodePool?: boolean;
    /**
    * (Optional) - List of resource manager tags applied to autopilot and auto-provisioned node pools. A maximum of 5 tags can be specified. Tags must be in one of these formats: "tagKeys/{tag_key_id}"="tagValues/{tag_value_id}", "{org_id}/{tag_key_name}"="{tag_value_name}", "{project_id}/{tag_key_name}"="{tag_value_name}".
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly resourceManagerTags?: {
        [key: string]: string;
    };
    /**
    * The ID of a BigQuery Dataset for using BigQuery as the destination of resource usage export.
    */
    readonly resourceUsageExportDatasetId?: string;
    /**
    * (Beta) Enable GKE Sandbox (Do not forget to set `image_type` = `COS_CONTAINERD` to use it).
    */
    readonly sandboxEnabled?: boolean;
    /**
    * Security posture mode. Accepted values are `DISABLED` and `BASIC`. Defaults to `DISABLED`.
    * DISABLED
    */
    readonly securityPostureMode?: string;
    /**
    * Security posture vulnerability mode. Accepted values are `VULNERABILITY_DISABLED`, `VULNERABILITY_BASIC`, and `VULNERABILITY_ENTERPRISE`. Defaults to `VULNERABILITY_DISABLED`.
    * VULNERABILITY_DISABLED
    */
    readonly securityPostureVulnerabilityMode?: string;
    /**
    * The service account to run nodes as if not overridden in `node_pools`. The create_service_account variable default value (true) will cause a cluster-specific service account to be created. This service account should already exists and it will be used by the node pools. If you wish to only override the service account name, you can use service_account_name variable.
    */
    readonly serviceAccount?: string;
    /**
    * The name of the service account that will be created if create_service_account is true. If you wish to use an existing service account, use service_account variable.
    */
    readonly serviceAccountName?: string;
    /**
    * Whether external ips specified by a service will be allowed in this cluster
    */
    readonly serviceExternalIps?: boolean;
    /**
    * The log_config for shadow firewall rules. You can set this variable to `null` to disable logging.
    */
    readonly shadowFirewallRulesLogConfig?: any;
    /**
    * The firewall priority of GKE shadow firewall rules. The priority should be less than default firewall, which is 1000.
    * 999
    */
    readonly shadowFirewallRulesPriority?: number;
    /**
    * The stack type to use for this cluster. Either `IPV4` or `IPV4_IPV6`. Defaults to `IPV4`.
    * IPV4
    */
    readonly stackType?: string;
    /**
    * Whether the Stateful HA Addon is enabled for this cluster.
    */
    readonly statefulHa?: boolean;
    /**
    * Map of stub domains and their resolvers to forward DNS queries for a certain domain to an external DNS server
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly stubDomains?: {
        [key: string]: string[];
    };
    /**
    * The subnetwork to host the cluster in (required)
    */
    readonly subnetwork: string;
    /**
    * Timeout for cluster operations.
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly timeouts?: {
        [key: string]: string;
    };
    /**
    * Specifies the total network bandwidth tier for NodePools in the cluster. Valid values are `TIER_UNSPECIFIED` and `TIER_1`. Defaults to `TIER_UNSPECIFIED`.
    */
    readonly totalEgressBandwidthTier?: string;
    /**
    * If specified, the values replace the nameservers taken by default from the node’s /etc/resolv.conf
    *
    */
    readonly upstreamNameservers?: string[];
    /**
    * List of maps containing Windows node pools
    *
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly windowsNodePools?: {
        [key: string]: string;
    }[];
    /**
    * (beta) Sets which mode of auditing should be used for the cluster's workloads. Accepted values are DISABLED, BASIC.
    * DISABLED
    */
    readonly workloadConfigAuditMode?: string;
    /**
    * (beta) Sets which mode to use for Protect workload vulnerability scanning feature. Accepted values are DISABLED, BASIC.
    */
    readonly workloadVulnerabilityMode?: string;
    /**
    * The zones to host the cluster in (optional if regional cluster / required if zonal)
    *
    */
    readonly zones?: string[];
}
/**
* Defines an Gkeprivate based on a Terraform module
*
* Docs at Terraform Registry: {@link https://registry.terraform.io/modules/terraform-google-modules/kubernetes-engine/google/44.1.0/submodules/beta-private-cluster terraform-google-modules/kubernetes-engine/google//modules/beta-private-cluster}
*/
export declare class Gkeprivate extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: GkeprivateConfig);
    get addClusterFirewallRules(): boolean | undefined;
    set addClusterFirewallRules(value: boolean | undefined);
    get addMasterWebhookFirewallRules(): boolean | undefined;
    set addMasterWebhookFirewallRules(value: boolean | undefined);
    get addShadowFirewallRules(): boolean | undefined;
    set addShadowFirewallRules(value: boolean | undefined);
    get additionalIpRangePods(): string[] | undefined;
    set additionalIpRangePods(value: string[] | undefined);
    get additionalIpRangesConfig(): any[] | undefined;
    set additionalIpRangesConfig(value: any[] | undefined);
    get additiveVpcScopeDnsDomain(): string | undefined;
    set additiveVpcScopeDnsDomain(value: string | undefined);
    get anonymousAuthenticationConfigMode(): string | undefined;
    set anonymousAuthenticationConfigMode(value: string | undefined);
    get authenticatorSecurityGroup(): string | undefined;
    set authenticatorSecurityGroup(value: string | undefined);
    get bootDiskKmsKey(): string | undefined;
    set bootDiskKmsKey(value: string | undefined);
    get cloudrun(): boolean | undefined;
    set cloudrun(value: boolean | undefined);
    get cloudrunLoadBalancerType(): string | undefined;
    set cloudrunLoadBalancerType(value: string | undefined);
    get clusterAutoscaling(): any | undefined;
    set clusterAutoscaling(value: any | undefined);
    get clusterDnsDomain(): string | undefined;
    set clusterDnsDomain(value: string | undefined);
    get clusterDnsProvider(): string | undefined;
    set clusterDnsProvider(value: string | undefined);
    get clusterDnsScope(): string | undefined;
    set clusterDnsScope(value: string | undefined);
    get clusterIpv4Cidr(): string | undefined;
    set clusterIpv4Cidr(value: string | undefined);
    get clusterResourceLabels(): {
        [key: string]: string;
    } | undefined;
    set clusterResourceLabels(value: {
        [key: string]: string;
    } | undefined);
    get clusterTelemetryType(): string | undefined;
    set clusterTelemetryType(value: string | undefined);
    get configConnector(): boolean | undefined;
    set configConnector(value: boolean | undefined);
    get configureIpMasq(): boolean | undefined;
    set configureIpMasq(value: boolean | undefined);
    get createServiceAccount(): boolean | undefined;
    set createServiceAccount(value: boolean | undefined);
    get databaseEncryption(): any[] | undefined;
    set databaseEncryption(value: any[] | undefined);
    get datapathProvider(): string | undefined;
    set datapathProvider(value: string | undefined);
    get defaultMaxPodsPerNode(): number | undefined;
    set defaultMaxPodsPerNode(value: number | undefined);
    get deletionProtection(): boolean | undefined;
    set deletionProtection(value: boolean | undefined);
    get deployUsingPrivateEndpoint(): boolean | undefined;
    set deployUsingPrivateEndpoint(value: boolean | undefined);
    get description(): string | undefined;
    set description(value: string | undefined);
    get disableDefaultSnat(): boolean | undefined;
    set disableDefaultSnat(value: boolean | undefined);
    get disableL4LbFirewallReconciliation(): boolean | undefined;
    set disableL4LbFirewallReconciliation(value: boolean | undefined);
    get disableLegacyMetadataEndpoints(): boolean | undefined;
    set disableLegacyMetadataEndpoints(value: boolean | undefined);
    get dnsAllowExternalTraffic(): boolean | undefined;
    set dnsAllowExternalTraffic(value: boolean | undefined);
    get dnsCache(): boolean | undefined;
    set dnsCache(value: boolean | undefined);
    get enableBinaryAuthorization(): boolean | undefined;
    set enableBinaryAuthorization(value: boolean | undefined);
    get enableCiliumClusterwideNetworkPolicy(): boolean | undefined;
    set enableCiliumClusterwideNetworkPolicy(value: boolean | undefined);
    get enableConfidentialNodes(): boolean | undefined;
    set enableConfidentialNodes(value: boolean | undefined);
    get enableCostAllocation(): boolean | undefined;
    set enableCostAllocation(value: boolean | undefined);
    get enableDefaultNodePoolsMetadata(): boolean | undefined;
    set enableDefaultNodePoolsMetadata(value: boolean | undefined);
    get enableFqdnNetworkPolicy(): boolean | undefined;
    set enableFqdnNetworkPolicy(value: boolean | undefined);
    get enableGcfs(): boolean | undefined;
    set enableGcfs(value: boolean | undefined);
    get enableIdentityService(): boolean | undefined;
    set enableIdentityService(value: boolean | undefined);
    get enableIntranodeVisibility(): boolean | undefined;
    set enableIntranodeVisibility(value: boolean | undefined);
    get enableK8SBetaApis(): string[] | undefined;
    set enableK8SBetaApis(value: string[] | undefined);
    get enableKubernetesAlpha(): boolean | undefined;
    set enableKubernetesAlpha(value: boolean | undefined);
    get enableL4IlbSubsetting(): boolean | undefined;
    set enableL4IlbSubsetting(value: boolean | undefined);
    get enableLegacyLustrePort(): boolean | undefined;
    set enableLegacyLustrePort(value: boolean | undefined);
    get enableMeshCertificates(): boolean | undefined;
    set enableMeshCertificates(value: boolean | undefined);
    get enableMultiNetworking(): boolean | undefined;
    set enableMultiNetworking(value: boolean | undefined);
    get enableNetworkEgressExport(): boolean | undefined;
    set enableNetworkEgressExport(value: boolean | undefined);
    get enablePodSecurityPolicy(): boolean | undefined;
    set enablePodSecurityPolicy(value: boolean | undefined);
    get enablePrivateEndpoint(): boolean | undefined;
    set enablePrivateEndpoint(value: boolean | undefined);
    get enablePrivateNodes(): boolean | undefined;
    set enablePrivateNodes(value: boolean | undefined);
    get enableResourceConsumptionExport(): boolean | undefined;
    set enableResourceConsumptionExport(value: boolean | undefined);
    get enableSecretManagerAddon(): boolean | undefined;
    set enableSecretManagerAddon(value: boolean | undefined);
    get enableShieldedNodes(): boolean | undefined;
    set enableShieldedNodes(value: boolean | undefined);
    get enableTpu(): boolean | undefined;
    set enableTpu(value: boolean | undefined);
    get enableVerticalPodAutoscaling(): boolean | undefined;
    set enableVerticalPodAutoscaling(value: boolean | undefined);
    get enterpriseConfig(): string | undefined;
    set enterpriseConfig(value: string | undefined);
    get filestoreCsiDriver(): boolean | undefined;
    set filestoreCsiDriver(value: boolean | undefined);
    get firewallInboundPorts(): string[] | undefined;
    set firewallInboundPorts(value: string[] | undefined);
    get firewallPriority(): number | undefined;
    set firewallPriority(value: number | undefined);
    get fleetProject(): string | undefined;
    set fleetProject(value: string | undefined);
    get fleetProjectGrantServiceAgent(): boolean | undefined;
    set fleetProjectGrantServiceAgent(value: boolean | undefined);
    get gatewayApiChannel(): string | undefined;
    set gatewayApiChannel(value: string | undefined);
    get gcePdCsiDriver(): boolean | undefined;
    set gcePdCsiDriver(value: boolean | undefined);
    get gcpPublicCidrsAccessEnabled(): boolean | undefined;
    set gcpPublicCidrsAccessEnabled(value: boolean | undefined);
    get gcsFuseCsiDriver(): boolean | undefined;
    set gcsFuseCsiDriver(value: boolean | undefined);
    get gkeAutoUpgradeConfigPatchMode(): string | undefined;
    set gkeAutoUpgradeConfigPatchMode(value: string | undefined);
    get gkeBackupAgentConfig(): boolean | undefined;
    set gkeBackupAgentConfig(value: boolean | undefined);
    get grantRegistryAccess(): boolean | undefined;
    set grantRegistryAccess(value: boolean | undefined);
    get horizontalPodAutoscaling(): boolean | undefined;
    set horizontalPodAutoscaling(value: boolean | undefined);
    get hpaProfile(): string | undefined;
    set hpaProfile(value: string | undefined);
    get httpLoadBalancing(): boolean | undefined;
    set httpLoadBalancing(value: boolean | undefined);
    get identityNamespace(): string | undefined;
    set identityNamespace(value: string | undefined);
    get inTransitEncryptionConfig(): string | undefined;
    set inTransitEncryptionConfig(value: string | undefined);
    get initialNodeCount(): number | undefined;
    set initialNodeCount(value: number | undefined);
    get insecureKubeletReadonlyPortEnabled(): boolean | undefined;
    set insecureKubeletReadonlyPortEnabled(value: boolean | undefined);
    get ipEndpointsEnabled(): boolean | undefined;
    set ipEndpointsEnabled(value: boolean | undefined);
    get ipMasqLinkLocal(): boolean | undefined;
    set ipMasqLinkLocal(value: boolean | undefined);
    get ipMasqResyncInterval(): string | undefined;
    set ipMasqResyncInterval(value: string | undefined);
    get ipRangePods(): string;
    set ipRangePods(value: string);
    get ipRangeServices(): string | undefined;
    set ipRangeServices(value: string | undefined);
    get issueClientCertificate(): boolean | undefined;
    set issueClientCertificate(value: boolean | undefined);
    get kubernetesVersion(): string | undefined;
    set kubernetesVersion(value: string | undefined);
    get loggingEnabledComponents(): string[] | undefined;
    set loggingEnabledComponents(value: string[] | undefined);
    get loggingService(): string | undefined;
    set loggingService(value: string | undefined);
    get loggingVariant(): string | undefined;
    set loggingVariant(value: string | undefined);
    get lustreCsiDriver(): boolean | undefined;
    set lustreCsiDriver(value: boolean | undefined);
    get maintenanceEndTime(): string | undefined;
    set maintenanceEndTime(value: string | undefined);
    get maintenanceExclusions(): any[] | undefined;
    set maintenanceExclusions(value: any[] | undefined);
    get maintenanceRecurrence(): string | undefined;
    set maintenanceRecurrence(value: string | undefined);
    get maintenanceStartTime(): string | undefined;
    set maintenanceStartTime(value: string | undefined);
    get masterAuthorizedNetworks(): any[] | undefined;
    set masterAuthorizedNetworks(value: any[] | undefined);
    get masterGlobalAccessEnabled(): boolean | undefined;
    set masterGlobalAccessEnabled(value: boolean | undefined);
    get masterIpv4CidrBlock(): string | undefined;
    set masterIpv4CidrBlock(value: string | undefined);
    get monitoringAutoMonitoringConfigScope(): string | undefined;
    set monitoringAutoMonitoringConfigScope(value: string | undefined);
    get monitoringEnableManagedPrometheus(): boolean | undefined;
    set monitoringEnableManagedPrometheus(value: boolean | undefined);
    get monitoringEnableObservabilityMetrics(): boolean | undefined;
    set monitoringEnableObservabilityMetrics(value: boolean | undefined);
    get monitoringEnableObservabilityRelay(): boolean | undefined;
    set monitoringEnableObservabilityRelay(value: boolean | undefined);
    get monitoringEnabledComponents(): string[] | undefined;
    set monitoringEnabledComponents(value: string[] | undefined);
    get monitoringMetricWriterRole(): string | undefined;
    set monitoringMetricWriterRole(value: string | undefined);
    get monitoringService(): string | undefined;
    set monitoringService(value: string | undefined);
    get name(): string;
    set name(value: string);
    get network(): string;
    set network(value: string);
    get networkPolicy(): boolean | undefined;
    set networkPolicy(value: boolean | undefined);
    get networkPolicyProvider(): string | undefined;
    set networkPolicyProvider(value: string | undefined);
    get networkProjectId(): string | undefined;
    set networkProjectId(value: string | undefined);
    get networkTags(): string[] | undefined;
    set networkTags(value: string[] | undefined);
    get networkTierConfig(): string | undefined;
    set networkTierConfig(value: string | undefined);
    get nodeMetadata(): string | undefined;
    set nodeMetadata(value: string | undefined);
    get nodePools(): {
        [key: string]: any;
    }[] | undefined;
    set nodePools(value: {
        [key: string]: any;
    }[] | undefined);
    get nodePoolsCgroupMode(): {
        [key: string]: string;
    } | undefined;
    set nodePoolsCgroupMode(value: {
        [key: string]: string;
    } | undefined);
    get nodePoolsHugepageSize1G(): {
        [key: string]: string;
    } | undefined;
    set nodePoolsHugepageSize1G(value: {
        [key: string]: string;
    } | undefined);
    get nodePoolsHugepageSize2M(): {
        [key: string]: string;
    } | undefined;
    set nodePoolsHugepageSize2M(value: {
        [key: string]: string;
    } | undefined);
    get nodePoolsLabels(): {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined;
    set nodePoolsLabels(value: {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined);
    get nodePoolsLinuxNodeConfigsSysctls(): {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined;
    set nodePoolsLinuxNodeConfigsSysctls(value: {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined);
    get nodePoolsMetadata(): {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined;
    set nodePoolsMetadata(value: {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined);
    get nodePoolsOauthScopes(): {
        [key: string]: string[];
    } | undefined;
    set nodePoolsOauthScopes(value: {
        [key: string]: string[];
    } | undefined);
    get nodePoolsResourceLabels(): {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined;
    set nodePoolsResourceLabels(value: {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined);
    get nodePoolsResourceManagerTags(): {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined;
    set nodePoolsResourceManagerTags(value: {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined);
    get nodePoolsTags(): {
        [key: string]: string[];
    } | undefined;
    set nodePoolsTags(value: {
        [key: string]: string[];
    } | undefined);
    get nodePoolsTaints(): {
        [key: string]: any[];
    } | undefined;
    set nodePoolsTaints(value: {
        [key: string]: any[];
    } | undefined);
    get nodePoolsTransparentHugepageDefrag(): {
        [key: string]: string;
    } | undefined;
    set nodePoolsTransparentHugepageDefrag(value: {
        [key: string]: string;
    } | undefined);
    get nodePoolsTransparentHugepageEnabled(): {
        [key: string]: string;
    } | undefined;
    set nodePoolsTransparentHugepageEnabled(value: {
        [key: string]: string;
    } | undefined);
    get nonMasqueradeCidrs(): string[] | undefined;
    set nonMasqueradeCidrs(value: string[] | undefined);
    get notificationConfigTopic(): string | undefined;
    set notificationConfigTopic(value: string | undefined);
    get notificationFilterEventType(): string[] | undefined;
    set notificationFilterEventType(value: string[] | undefined);
    get parallelstoreCsiDriver(): boolean | undefined;
    set parallelstoreCsiDriver(value: boolean | undefined);
    get privateEndpointSubnetwork(): string | undefined;
    set privateEndpointSubnetwork(value: string | undefined);
    get projectId(): string;
    set projectId(value: string);
    get rayOperatorConfig(): any | undefined;
    set rayOperatorConfig(value: any | undefined);
    get rbacBindingConfig(): any | undefined;
    set rbacBindingConfig(value: any | undefined);
    get region(): string | undefined;
    set region(value: string | undefined);
    get regional(): boolean | undefined;
    set regional(value: boolean | undefined);
    get registryProjectIds(): string[] | undefined;
    set registryProjectIds(value: string[] | undefined);
    get releaseChannel(): string | undefined;
    set releaseChannel(value: string | undefined);
    get removeDefaultNodePool(): boolean | undefined;
    set removeDefaultNodePool(value: boolean | undefined);
    get resourceManagerTags(): {
        [key: string]: string;
    } | undefined;
    set resourceManagerTags(value: {
        [key: string]: string;
    } | undefined);
    get resourceUsageExportDatasetId(): string | undefined;
    set resourceUsageExportDatasetId(value: string | undefined);
    get sandboxEnabled(): boolean | undefined;
    set sandboxEnabled(value: boolean | undefined);
    get securityPostureMode(): string | undefined;
    set securityPostureMode(value: string | undefined);
    get securityPostureVulnerabilityMode(): string | undefined;
    set securityPostureVulnerabilityMode(value: string | undefined);
    get serviceAccount(): string | undefined;
    set serviceAccount(value: string | undefined);
    get serviceAccountName(): string | undefined;
    set serviceAccountName(value: string | undefined);
    get serviceExternalIps(): boolean | undefined;
    set serviceExternalIps(value: boolean | undefined);
    get shadowFirewallRulesLogConfig(): any | undefined;
    set shadowFirewallRulesLogConfig(value: any | undefined);
    get shadowFirewallRulesPriority(): number | undefined;
    set shadowFirewallRulesPriority(value: number | undefined);
    get stackType(): string | undefined;
    set stackType(value: string | undefined);
    get statefulHa(): boolean | undefined;
    set statefulHa(value: boolean | undefined);
    get stubDomains(): {
        [key: string]: string[];
    } | undefined;
    set stubDomains(value: {
        [key: string]: string[];
    } | undefined);
    get subnetwork(): string;
    set subnetwork(value: string);
    get timeouts(): {
        [key: string]: string;
    } | undefined;
    set timeouts(value: {
        [key: string]: string;
    } | undefined);
    get totalEgressBandwidthTier(): string | undefined;
    set totalEgressBandwidthTier(value: string | undefined);
    get upstreamNameservers(): string[] | undefined;
    set upstreamNameservers(value: string[] | undefined);
    get windowsNodePools(): {
        [key: string]: string;
    }[] | undefined;
    set windowsNodePools(value: {
        [key: string]: string;
    }[] | undefined);
    get workloadConfigAuditMode(): string | undefined;
    set workloadConfigAuditMode(value: string | undefined);
    get workloadVulnerabilityMode(): string | undefined;
    set workloadVulnerabilityMode(value: string | undefined);
    get zones(): string[] | undefined;
    set zones(value: string[] | undefined);
    get caCertificateOutput(): string;
    get cloudrunEnabledOutput(): string;
    get clusterIdOutput(): string;
    get dnsCacheEnabledOutput(): string;
    get endpointOutput(): string;
    get endpointDnsOutput(): string;
    get fleetMembershipOutput(): string;
    get gatewayApiChannelOutput(): string;
    get horizontalPodAutoscalingEnabledOutput(): string;
    get httpLoadBalancingEnabledOutput(): string;
    get identityNamespaceOutput(): string;
    get identityServiceEnabledOutput(): string;
    get instanceGroupUrlsOutput(): string;
    get intranodeVisibilityEnabledOutput(): string;
    get locationOutput(): string;
    get loggingServiceOutput(): string;
    get masterAuthorizedNetworksConfigOutput(): string;
    get masterIpv4CidrBlockOutput(): string;
    get masterVersionOutput(): string;
    get meshCertificatesConfigOutput(): string;
    get minMasterVersionOutput(): string;
    get monitoringServiceOutput(): string;
    get nameOutput(): string;
    get networkPolicyEnabledOutput(): string;
    get nodePoolsNamesOutput(): string;
    get nodePoolsVersionsOutput(): string;
    get peeringNameOutput(): string;
    get podSecurityPolicyEnabledOutput(): string;
    get regionOutput(): string;
    get releaseChannelOutput(): string;
    get secretManagerAddonEnabledOutput(): string;
    get serviceAccountOutput(): string;
    get tpuIpv4CidrBlockOutput(): string;
    get typeOutput(): string;
    get verticalPodAutoscalingEnabledOutput(): string;
    get zonesOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
