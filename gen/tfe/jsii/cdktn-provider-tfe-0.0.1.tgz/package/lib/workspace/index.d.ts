import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#agent_pool_id Workspace#agent_pool_id}
    */
    readonly agentPoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#allow_destroy_plan Workspace#allow_destroy_plan}
    */
    readonly allowDestroyPlan?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#assessments_enabled Workspace#assessments_enabled}
    */
    readonly assessmentsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#auto_apply Workspace#auto_apply}
    */
    readonly autoApply?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#description Workspace#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#execution_mode Workspace#execution_mode}
    */
    readonly executionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#file_triggers_enabled Workspace#file_triggers_enabled}
    */
    readonly fileTriggersEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#force_delete Workspace#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#global_remote_state Workspace#global_remote_state}
    */
    readonly globalRemoteState?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#id Workspace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#name Workspace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#operations Workspace#operations}
    */
    readonly operations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#organization Workspace#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#project_id Workspace#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#queue_all_runs Workspace#queue_all_runs}
    */
    readonly queueAllRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#remote_state_consumer_ids Workspace#remote_state_consumer_ids}
    */
    readonly remoteStateConsumerIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#source_name Workspace#source_name}
    */
    readonly sourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#source_url Workspace#source_url}
    */
    readonly sourceUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#speculative_enabled Workspace#speculative_enabled}
    */
    readonly speculativeEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#ssh_key_id Workspace#ssh_key_id}
    */
    readonly sshKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#structured_run_output_enabled Workspace#structured_run_output_enabled}
    */
    readonly structuredRunOutputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#tag_names Workspace#tag_names}
    */
    readonly tagNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#terraform_version Workspace#terraform_version}
    */
    readonly terraformVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#trigger_patterns Workspace#trigger_patterns}
    */
    readonly triggerPatterns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#trigger_prefixes Workspace#trigger_prefixes}
    */
    readonly triggerPrefixes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#working_directory Workspace#working_directory}
    */
    readonly workingDirectory?: string;
    /**
    * vcs_repo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#vcs_repo Workspace#vcs_repo}
    */
    readonly vcsRepo?: WorkspaceVcsRepo;
}
export interface WorkspaceVcsRepo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#branch Workspace#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#github_app_installation_id Workspace#github_app_installation_id}
    */
    readonly githubAppInstallationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#identifier Workspace#identifier}
    */
    readonly identifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#ingress_submodules Workspace#ingress_submodules}
    */
    readonly ingressSubmodules?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#oauth_token_id Workspace#oauth_token_id}
    */
    readonly oauthTokenId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#tags_regex Workspace#tags_regex}
    */
    readonly tagsRegex?: string;
}
export declare function workspaceVcsRepoToTerraform(struct?: WorkspaceVcsRepoOutputReference | WorkspaceVcsRepo): any;
export declare function workspaceVcsRepoToHclTerraform(struct?: WorkspaceVcsRepoOutputReference | WorkspaceVcsRepo): any;
export declare class WorkspaceVcsRepoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceVcsRepo | undefined;
    set internalValue(value: WorkspaceVcsRepo | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _githubAppInstallationId?;
    get githubAppInstallationId(): string;
    set githubAppInstallationId(value: string);
    resetGithubAppInstallationId(): void;
    get githubAppInstallationIdInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _ingressSubmodules?;
    get ingressSubmodules(): boolean | cdktn.IResolvable;
    set ingressSubmodules(value: boolean | cdktn.IResolvable);
    resetIngressSubmodules(): void;
    get ingressSubmodulesInput(): boolean | cdktn.IResolvable | undefined;
    private _oauthTokenId?;
    get oauthTokenId(): string;
    set oauthTokenId(value: string);
    resetOauthTokenId(): void;
    get oauthTokenIdInput(): string | undefined;
    private _tagsRegex?;
    get tagsRegex(): string;
    set tagsRegex(value: string);
    resetTagsRegex(): void;
    get tagsRegexInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace tfe_workspace}
*/
export declare class Workspace extends cdktn.TerraformResource {
    static readonly tfResourceType = "tfe_workspace";
    /**
    * Generates CDKTN code for importing a Workspace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Workspace to import
    * @param importFromId The id of the existing Workspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Workspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace tfe_workspace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceConfig
    */
    constructor(scope: Construct, id: string, config: WorkspaceConfig);
    private _agentPoolId?;
    get agentPoolId(): string;
    set agentPoolId(value: string);
    resetAgentPoolId(): void;
    get agentPoolIdInput(): string | undefined;
    private _allowDestroyPlan?;
    get allowDestroyPlan(): boolean | cdktn.IResolvable;
    set allowDestroyPlan(value: boolean | cdktn.IResolvable);
    resetAllowDestroyPlan(): void;
    get allowDestroyPlanInput(): boolean | cdktn.IResolvable | undefined;
    private _assessmentsEnabled?;
    get assessmentsEnabled(): boolean | cdktn.IResolvable;
    set assessmentsEnabled(value: boolean | cdktn.IResolvable);
    resetAssessmentsEnabled(): void;
    get assessmentsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _autoApply?;
    get autoApply(): boolean | cdktn.IResolvable;
    set autoApply(value: boolean | cdktn.IResolvable);
    resetAutoApply(): void;
    get autoApplyInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionMode?;
    get executionMode(): string;
    set executionMode(value: string);
    resetExecutionMode(): void;
    get executionModeInput(): string | undefined;
    private _fileTriggersEnabled?;
    get fileTriggersEnabled(): boolean | cdktn.IResolvable;
    set fileTriggersEnabled(value: boolean | cdktn.IResolvable);
    resetFileTriggersEnabled(): void;
    get fileTriggersEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _globalRemoteState?;
    get globalRemoteState(): boolean | cdktn.IResolvable;
    set globalRemoteState(value: boolean | cdktn.IResolvable);
    resetGlobalRemoteState(): void;
    get globalRemoteStateInput(): boolean | cdktn.IResolvable | undefined;
    get htmlUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operations?;
    get operations(): boolean | cdktn.IResolvable;
    set operations(value: boolean | cdktn.IResolvable);
    resetOperations(): void;
    get operationsInput(): boolean | cdktn.IResolvable | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _queueAllRuns?;
    get queueAllRuns(): boolean | cdktn.IResolvable;
    set queueAllRuns(value: boolean | cdktn.IResolvable);
    resetQueueAllRuns(): void;
    get queueAllRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _remoteStateConsumerIds?;
    get remoteStateConsumerIds(): string[];
    set remoteStateConsumerIds(value: string[]);
    resetRemoteStateConsumerIds(): void;
    get remoteStateConsumerIdsInput(): string[] | undefined;
    get resourceCount(): number;
    private _sourceName?;
    get sourceName(): string;
    set sourceName(value: string);
    resetSourceName(): void;
    get sourceNameInput(): string | undefined;
    private _sourceUrl?;
    get sourceUrl(): string;
    set sourceUrl(value: string);
    resetSourceUrl(): void;
    get sourceUrlInput(): string | undefined;
    private _speculativeEnabled?;
    get speculativeEnabled(): boolean | cdktn.IResolvable;
    set speculativeEnabled(value: boolean | cdktn.IResolvable);
    resetSpeculativeEnabled(): void;
    get speculativeEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sshKeyId?;
    get sshKeyId(): string;
    set sshKeyId(value: string);
    resetSshKeyId(): void;
    get sshKeyIdInput(): string | undefined;
    private _structuredRunOutputEnabled?;
    get structuredRunOutputEnabled(): boolean | cdktn.IResolvable;
    set structuredRunOutputEnabled(value: boolean | cdktn.IResolvable);
    resetStructuredRunOutputEnabled(): void;
    get structuredRunOutputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tagNames?;
    get tagNames(): string[];
    set tagNames(value: string[]);
    resetTagNames(): void;
    get tagNamesInput(): string[] | undefined;
    private _terraformVersion?;
    get terraformVersion(): string;
    set terraformVersion(value: string);
    resetTerraformVersion(): void;
    get terraformVersionInput(): string | undefined;
    private _triggerPatterns?;
    get triggerPatterns(): string[];
    set triggerPatterns(value: string[]);
    resetTriggerPatterns(): void;
    get triggerPatternsInput(): string[] | undefined;
    private _triggerPrefixes?;
    get triggerPrefixes(): string[];
    set triggerPrefixes(value: string[]);
    resetTriggerPrefixes(): void;
    get triggerPrefixesInput(): string[] | undefined;
    private _workingDirectory?;
    get workingDirectory(): string;
    set workingDirectory(value: string);
    resetWorkingDirectory(): void;
    get workingDirectoryInput(): string | undefined;
    private _vcsRepo;
    get vcsRepo(): WorkspaceVcsRepoOutputReference;
    putVcsRepo(value: WorkspaceVcsRepo): void;
    resetVcsRepo(): void;
    get vcsRepoInput(): WorkspaceVcsRepo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
