import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfeProviderConfig {
    /**
    * The Terraform Enterprise hostname to connect to. Defaults to app.terraform.io.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs#hostname TfeProvider#hostname}
    */
    readonly hostname?: string;
    /**
    * The organization to apply to a resource if one is not defined on
    * the resource itself
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs#organization TfeProvider#organization}
    */
    readonly organization?: string;
    /**
    * Whether or not to skip certificate verifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs#ssl_skip_verify TfeProvider#ssl_skip_verify}
    */
    readonly sslSkipVerify?: boolean | cdktn.IResolvable;
    /**
    * The token used to authenticate with Terraform Enterprise. We recommend omitting
    * the token which can be set as credentials in the CLI config file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs#token TfeProvider#token}
    */
    readonly token?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs#alias TfeProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs tfe}
*/
export declare class TfeProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "tfe";
    /**
    * Generates CDKTN code for importing a TfeProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfeProvider to import
    * @param importFromId The id of the existing TfeProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfeProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs tfe} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfeProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfeProviderConfig);
    private _hostname?;
    get hostname(): string | undefined;
    set hostname(value: string | undefined);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _organization?;
    get organization(): string | undefined;
    set organization(value: string | undefined);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _sslSkipVerify?;
    get sslSkipVerify(): boolean | cdktn.IResolvable | undefined;
    set sslSkipVerify(value: boolean | cdktn.IResolvable | undefined);
    resetSslSkipVerify(): void;
    get sslSkipVerifyInput(): boolean | cdktn.IResolvable | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
