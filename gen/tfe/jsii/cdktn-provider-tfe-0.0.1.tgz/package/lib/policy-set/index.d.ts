import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PolicySetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#description PolicySet#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#global PolicySet#global}
    */
    readonly global?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#id PolicySet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#kind PolicySet#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#name PolicySet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#organization PolicySet#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#overridable PolicySet#overridable}
    */
    readonly overridable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#policies_path PolicySet#policies_path}
    */
    readonly policiesPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#policy_ids PolicySet#policy_ids}
    */
    readonly policyIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#slug PolicySet#slug}
    */
    readonly slug?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#workspace_ids PolicySet#workspace_ids}
    */
    readonly workspaceIds?: string[];
    /**
    * vcs_repo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#vcs_repo PolicySet#vcs_repo}
    */
    readonly vcsRepo?: PolicySetVcsRepo;
}
export interface PolicySetVcsRepo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#branch PolicySet#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#github_app_installation_id PolicySet#github_app_installation_id}
    */
    readonly githubAppInstallationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#identifier PolicySet#identifier}
    */
    readonly identifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#ingress_submodules PolicySet#ingress_submodules}
    */
    readonly ingressSubmodules?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#oauth_token_id PolicySet#oauth_token_id}
    */
    readonly oauthTokenId?: string;
}
export declare function policySetVcsRepoToTerraform(struct?: PolicySetVcsRepoOutputReference | PolicySetVcsRepo): any;
export declare function policySetVcsRepoToHclTerraform(struct?: PolicySetVcsRepoOutputReference | PolicySetVcsRepo): any;
export declare class PolicySetVcsRepoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicySetVcsRepo | undefined;
    set internalValue(value: PolicySetVcsRepo | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _githubAppInstallationId?;
    get githubAppInstallationId(): string;
    set githubAppInstallationId(value: string);
    resetGithubAppInstallationId(): void;
    get githubAppInstallationIdInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _ingressSubmodules?;
    get ingressSubmodules(): boolean | cdktn.IResolvable;
    set ingressSubmodules(value: boolean | cdktn.IResolvable);
    resetIngressSubmodules(): void;
    get ingressSubmodulesInput(): boolean | cdktn.IResolvable | undefined;
    private _oauthTokenId?;
    get oauthTokenId(): string;
    set oauthTokenId(value: string);
    resetOauthTokenId(): void;
    get oauthTokenIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set tfe_policy_set}
*/
export declare class PolicySet extends cdktn.TerraformResource {
    static readonly tfResourceType = "tfe_policy_set";
    /**
    * Generates CDKTN code for importing a PolicySet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicySet to import
    * @param importFromId The id of the existing PolicySet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicySet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set tfe_policy_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicySetConfig
    */
    constructor(scope: Construct, id: string, config: PolicySetConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _global?;
    get global(): boolean | cdktn.IResolvable;
    set global(value: boolean | cdktn.IResolvable);
    resetGlobal(): void;
    get globalInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _overridable?;
    get overridable(): boolean | cdktn.IResolvable;
    set overridable(value: boolean | cdktn.IResolvable);
    resetOverridable(): void;
    get overridableInput(): boolean | cdktn.IResolvable | undefined;
    private _policiesPath?;
    get policiesPath(): string;
    set policiesPath(value: string);
    resetPoliciesPath(): void;
    get policiesPathInput(): string | undefined;
    private _policyIds?;
    get policyIds(): string[];
    set policyIds(value: string[]);
    resetPolicyIds(): void;
    get policyIdsInput(): string[] | undefined;
    private _slug?;
    get slug(): {
        [key: string]: string;
    };
    set slug(value: {
        [key: string]: string;
    });
    resetSlug(): void;
    get slugInput(): {
        [key: string]: string;
    } | undefined;
    private _workspaceIds?;
    get workspaceIds(): string[];
    set workspaceIds(value: string[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): string[] | undefined;
    private _vcsRepo;
    get vcsRepo(): PolicySetVcsRepoOutputReference;
    putVcsRepo(value: PolicySetVcsRepo): void;
    resetVcsRepo(): void;
    get vcsRepoInput(): PolicySetVcsRepo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
