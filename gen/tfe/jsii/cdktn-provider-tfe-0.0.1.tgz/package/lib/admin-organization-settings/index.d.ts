import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AdminOrganizationSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/admin_organization_settings#access_beta_tools AdminOrganizationSettings#access_beta_tools}
    */
    readonly accessBetaTools?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/admin_organization_settings#global_module_sharing AdminOrganizationSettings#global_module_sharing}
    */
    readonly globalModuleSharing?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/admin_organization_settings#id AdminOrganizationSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/admin_organization_settings#module_sharing_consumer_organizations AdminOrganizationSettings#module_sharing_consumer_organizations}
    */
    readonly moduleSharingConsumerOrganizations?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/admin_organization_settings#organization AdminOrganizationSettings#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/admin_organization_settings#workspace_limit AdminOrganizationSettings#workspace_limit}
    */
    readonly workspaceLimit?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/admin_organization_settings tfe_admin_organization_settings}
*/
export declare class AdminOrganizationSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "tfe_admin_organization_settings";
    /**
    * Generates CDKTN code for importing a AdminOrganizationSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AdminOrganizationSettings to import
    * @param importFromId The id of the existing AdminOrganizationSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/admin_organization_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AdminOrganizationSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/admin_organization_settings tfe_admin_organization_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AdminOrganizationSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AdminOrganizationSettingsConfig);
    private _accessBetaTools?;
    get accessBetaTools(): boolean | cdktn.IResolvable;
    set accessBetaTools(value: boolean | cdktn.IResolvable);
    resetAccessBetaTools(): void;
    get accessBetaToolsInput(): boolean | cdktn.IResolvable | undefined;
    private _globalModuleSharing?;
    get globalModuleSharing(): boolean | cdktn.IResolvable;
    set globalModuleSharing(value: boolean | cdktn.IResolvable);
    resetGlobalModuleSharing(): void;
    get globalModuleSharingInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _moduleSharingConsumerOrganizations?;
    get moduleSharingConsumerOrganizations(): string[];
    set moduleSharingConsumerOrganizations(value: string[]);
    resetModuleSharingConsumerOrganizations(): void;
    get moduleSharingConsumerOrganizationsInput(): string[] | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    get ssoEnabled(): cdktn.IResolvable;
    private _workspaceLimit?;
    get workspaceLimit(): number;
    set workspaceLimit(value: number);
    resetWorkspaceLimit(): void;
    get workspaceLimitInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
