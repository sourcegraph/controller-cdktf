import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfeWorkspaceIdsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace_ids#exclude_tags DataTfeWorkspaceIds#exclude_tags}
    */
    readonly excludeTags?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace_ids#id DataTfeWorkspaceIds#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace_ids#names DataTfeWorkspaceIds#names}
    */
    readonly names?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace_ids#organization DataTfeWorkspaceIds#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace_ids#tag_names DataTfeWorkspaceIds#tag_names}
    */
    readonly tagNames?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace_ids tfe_workspace_ids}
*/
export declare class DataTfeWorkspaceIds extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tfe_workspace_ids";
    /**
    * Generates CDKTN code for importing a DataTfeWorkspaceIds resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeWorkspaceIds to import
    * @param importFromId The id of the existing DataTfeWorkspaceIds that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace_ids#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeWorkspaceIds to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace_ids tfe_workspace_ids} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeWorkspaceIdsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfeWorkspaceIdsConfig);
    private _excludeTags?;
    get excludeTags(): string[];
    set excludeTags(value: string[]);
    resetExcludeTags(): void;
    get excludeTagsInput(): string[] | undefined;
    private _fullNames;
    get fullNames(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids;
    get ids(): cdktn.StringMap;
    private _names?;
    get names(): string[];
    set names(value: string[]);
    resetNames(): void;
    get namesInput(): string[] | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _tagNames?;
    get tagNames(): string[];
    set tagNames(value: string[]);
    resetTagNames(): void;
    get tagNamesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
