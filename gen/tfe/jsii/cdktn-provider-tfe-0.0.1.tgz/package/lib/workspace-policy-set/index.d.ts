import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspacePolicySetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_policy_set#id WorkspacePolicySet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_policy_set#policy_set_id WorkspacePolicySet#policy_set_id}
    */
    readonly policySetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_policy_set#workspace_id WorkspacePolicySet#workspace_id}
    */
    readonly workspaceId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_policy_set tfe_workspace_policy_set}
*/
export declare class WorkspacePolicySet extends cdktn.TerraformResource {
    static readonly tfResourceType = "tfe_workspace_policy_set";
    /**
    * Generates CDKTN code for importing a WorkspacePolicySet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspacePolicySet to import
    * @param importFromId The id of the existing WorkspacePolicySet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_policy_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspacePolicySet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_policy_set tfe_workspace_policy_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspacePolicySetConfig
    */
    constructor(scope: Construct, id: string, config: WorkspacePolicySetConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policySetId?;
    get policySetId(): string;
    set policySetId(value: string);
    get policySetIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
