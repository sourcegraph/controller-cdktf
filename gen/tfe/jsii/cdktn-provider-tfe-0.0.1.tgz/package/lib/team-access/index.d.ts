import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TeamAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#access TeamAccess#access}
    */
    readonly access?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#id TeamAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#team_id TeamAccess#team_id}
    */
    readonly teamId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#workspace_id TeamAccess#workspace_id}
    */
    readonly workspaceId: string;
    /**
    * permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#permissions TeamAccess#permissions}
    */
    readonly permissions?: TeamAccessPermissions[] | cdktn.IResolvable;
}
export interface TeamAccessPermissions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#run_tasks TeamAccess#run_tasks}
    */
    readonly runTasks: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#runs TeamAccess#runs}
    */
    readonly runs: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#sentinel_mocks TeamAccess#sentinel_mocks}
    */
    readonly sentinelMocks: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#state_versions TeamAccess#state_versions}
    */
    readonly stateVersions: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#variables TeamAccess#variables}
    */
    readonly variables: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#workspace_locking TeamAccess#workspace_locking}
    */
    readonly workspaceLocking: boolean | cdktn.IResolvable;
}
export declare function teamAccessPermissionsToTerraform(struct?: TeamAccessPermissions | cdktn.IResolvable): any;
export declare function teamAccessPermissionsToHclTerraform(struct?: TeamAccessPermissions | cdktn.IResolvable): any;
export declare class TeamAccessPermissionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TeamAccessPermissions | cdktn.IResolvable | undefined;
    set internalValue(value: TeamAccessPermissions | cdktn.IResolvable | undefined);
    private _runTasks?;
    get runTasks(): boolean | cdktn.IResolvable;
    set runTasks(value: boolean | cdktn.IResolvable);
    get runTasksInput(): boolean | cdktn.IResolvable | undefined;
    private _runs?;
    get runs(): string;
    set runs(value: string);
    get runsInput(): string | undefined;
    private _sentinelMocks?;
    get sentinelMocks(): string;
    set sentinelMocks(value: string);
    get sentinelMocksInput(): string | undefined;
    private _stateVersions?;
    get stateVersions(): string;
    set stateVersions(value: string);
    get stateVersionsInput(): string | undefined;
    private _variables?;
    get variables(): string;
    set variables(value: string);
    get variablesInput(): string | undefined;
    private _workspaceLocking?;
    get workspaceLocking(): boolean | cdktn.IResolvable;
    set workspaceLocking(value: boolean | cdktn.IResolvable);
    get workspaceLockingInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class TeamAccessPermissionsList extends cdktn.ComplexList {
    internalValue?: TeamAccessPermissions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TeamAccessPermissionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access tfe_team_access}
*/
export declare class TeamAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "tfe_team_access";
    /**
    * Generates CDKTN code for importing a TeamAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamAccess to import
    * @param importFromId The id of the existing TeamAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_access tfe_team_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamAccessConfig
    */
    constructor(scope: Construct, id: string, config: TeamAccessConfig);
    private _access?;
    get access(): string;
    set access(value: string);
    resetAccess(): void;
    get accessInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    private _permissions;
    get permissions(): TeamAccessPermissionsList;
    putPermissions(value: TeamAccessPermissions[] | cdktn.IResolvable): void;
    resetPermissions(): void;
    get permissionsInput(): cdktn.IResolvable | TeamAccessPermissions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
