import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfeWorkspaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace#id DataTfeWorkspace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace#name DataTfeWorkspace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace#organization DataTfeWorkspace#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace#tag_names DataTfeWorkspace#tag_names}
    */
    readonly tagNames?: string[];
}
export interface DataTfeWorkspaceVcsRepo {
}
export declare function dataTfeWorkspaceVcsRepoToTerraform(struct?: DataTfeWorkspaceVcsRepo): any;
export declare function dataTfeWorkspaceVcsRepoToHclTerraform(struct?: DataTfeWorkspaceVcsRepo): any;
export declare class DataTfeWorkspaceVcsRepoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeWorkspaceVcsRepo | undefined;
    set internalValue(value: DataTfeWorkspaceVcsRepo | undefined);
    get branch(): string;
    get githubAppInstallationId(): string;
    get identifier(): string;
    get ingressSubmodules(): cdktn.IResolvable;
    get oauthTokenId(): string;
    get tagsRegex(): string;
}
export declare class DataTfeWorkspaceVcsRepoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeWorkspaceVcsRepoOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace tfe_workspace}
*/
export declare class DataTfeWorkspace extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tfe_workspace";
    /**
    * Generates CDKTN code for importing a DataTfeWorkspace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeWorkspace to import
    * @param importFromId The id of the existing DataTfeWorkspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeWorkspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/workspace tfe_workspace} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeWorkspaceConfig
    */
    constructor(scope: Construct, id: string, config: DataTfeWorkspaceConfig);
    get allowDestroyPlan(): cdktn.IResolvable;
    get assessmentsEnabled(): cdktn.IResolvable;
    get autoApply(): cdktn.IResolvable;
    get description(): string;
    get executionMode(): string;
    get fileTriggersEnabled(): cdktn.IResolvable;
    get globalRemoteState(): cdktn.IResolvable;
    get htmlUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get operations(): cdktn.IResolvable;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    get policyCheckFailures(): number;
    get projectId(): string;
    get queueAllRuns(): cdktn.IResolvable;
    get remoteStateConsumerIds(): string[];
    get resourceCount(): number;
    get runFailures(): number;
    get runsCount(): number;
    get sourceName(): string;
    get sourceUrl(): string;
    get speculativeEnabled(): cdktn.IResolvable;
    get sshKeyId(): string;
    get structuredRunOutputEnabled(): cdktn.IResolvable;
    private _tagNames?;
    get tagNames(): string[];
    set tagNames(value: string[]);
    resetTagNames(): void;
    get tagNamesInput(): string[] | undefined;
    get terraformVersion(): string;
    get triggerPatterns(): string[];
    get triggerPrefixes(): string[];
    private _vcsRepo;
    get vcsRepo(): DataTfeWorkspaceVcsRepoList;
    get workingDirectory(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
