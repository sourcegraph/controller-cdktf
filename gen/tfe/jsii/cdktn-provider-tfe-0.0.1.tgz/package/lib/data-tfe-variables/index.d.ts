import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfeVariablesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variables#id DataTfeVariables#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variables#variable_set_id DataTfeVariables#variable_set_id}
    */
    readonly variableSetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variables#workspace_id DataTfeVariables#workspace_id}
    */
    readonly workspaceId?: string;
}
export interface DataTfeVariablesEnv {
}
export declare function dataTfeVariablesEnvToTerraform(struct?: DataTfeVariablesEnv): any;
export declare function dataTfeVariablesEnvToHclTerraform(struct?: DataTfeVariablesEnv): any;
export declare class DataTfeVariablesEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeVariablesEnv | undefined;
    set internalValue(value: DataTfeVariablesEnv | undefined);
    get category(): string;
    get hcl(): cdktn.IResolvable;
    get id(): string;
    get name(): string;
    get sensitive(): cdktn.IResolvable;
    get value(): string;
}
export declare class DataTfeVariablesEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeVariablesEnvOutputReference;
}
export interface DataTfeVariablesTerraform {
}
export declare function dataTfeVariablesTerraformToTerraform(struct?: DataTfeVariablesTerraform): any;
export declare function dataTfeVariablesTerraformToHclTerraform(struct?: DataTfeVariablesTerraform): any;
export declare class DataTfeVariablesTerraformOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeVariablesTerraform | undefined;
    set internalValue(value: DataTfeVariablesTerraform | undefined);
    get category(): string;
    get hcl(): cdktn.IResolvable;
    get id(): string;
    get name(): string;
    get sensitive(): cdktn.IResolvable;
    get value(): string;
}
export declare class DataTfeVariablesTerraformList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeVariablesTerraformOutputReference;
}
export interface DataTfeVariablesVariables {
}
export declare function dataTfeVariablesVariablesToTerraform(struct?: DataTfeVariablesVariables): any;
export declare function dataTfeVariablesVariablesToHclTerraform(struct?: DataTfeVariablesVariables): any;
export declare class DataTfeVariablesVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeVariablesVariables | undefined;
    set internalValue(value: DataTfeVariablesVariables | undefined);
    get category(): string;
    get hcl(): cdktn.IResolvable;
    get id(): string;
    get name(): string;
    get sensitive(): cdktn.IResolvable;
    get value(): string;
}
export declare class DataTfeVariablesVariablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeVariablesVariablesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variables tfe_variables}
*/
export declare class DataTfeVariables extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tfe_variables";
    /**
    * Generates CDKTN code for importing a DataTfeVariables resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeVariables to import
    * @param importFromId The id of the existing DataTfeVariables that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variables#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeVariables to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variables tfe_variables} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeVariablesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfeVariablesConfig);
    private _env;
    get env(): DataTfeVariablesEnvList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _terraform;
    get terraform(): DataTfeVariablesTerraformList;
    private _variableSetId?;
    get variableSetId(): string;
    set variableSetId(value: string);
    resetVariableSetId(): void;
    get variableSetIdInput(): string | undefined;
    private _variables;
    get variables(): DataTfeVariablesVariablesList;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
