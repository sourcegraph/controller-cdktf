import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfeTeamAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/team_access#id DataTfeTeamAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/team_access#team_id DataTfeTeamAccess#team_id}
    */
    readonly teamId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/team_access#workspace_id DataTfeTeamAccess#workspace_id}
    */
    readonly workspaceId: string;
}
export interface DataTfeTeamAccessPermissions {
}
export declare function dataTfeTeamAccessPermissionsToTerraform(struct?: DataTfeTeamAccessPermissions): any;
export declare function dataTfeTeamAccessPermissionsToHclTerraform(struct?: DataTfeTeamAccessPermissions): any;
export declare class DataTfeTeamAccessPermissionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeTeamAccessPermissions | undefined;
    set internalValue(value: DataTfeTeamAccessPermissions | undefined);
    get runTasks(): cdktn.IResolvable;
    get runs(): string;
    get sentinelMocks(): string;
    get stateVersions(): string;
    get variables(): string;
    get workspaceLocking(): cdktn.IResolvable;
}
export declare class DataTfeTeamAccessPermissionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeTeamAccessPermissionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/team_access tfe_team_access}
*/
export declare class DataTfeTeamAccess extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tfe_team_access";
    /**
    * Generates CDKTN code for importing a DataTfeTeamAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeTeamAccess to import
    * @param importFromId The id of the existing DataTfeTeamAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/team_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeTeamAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/team_access tfe_team_access} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeTeamAccessConfig
    */
    constructor(scope: Construct, id: string, config: DataTfeTeamAccessConfig);
    get access(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _permissions;
    get permissions(): DataTfeTeamAccessPermissionsList;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
