import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfeOutputsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The organization to fetch the remote state from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/outputs#organization DataTfeOutputs#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/outputs#values DataTfeOutputs#values}
    */
    readonly values?: {
        [key: string]: any;
    };
    /**
    * The workspace to fetch the remote state from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/outputs#workspace DataTfeOutputs#workspace}
    */
    readonly workspace: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/outputs tfe_outputs}
*/
export declare class DataTfeOutputs extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tfe_outputs";
    /**
    * Generates CDKTN code for importing a DataTfeOutputs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeOutputs to import
    * @param importFromId The id of the existing DataTfeOutputs that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/outputs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeOutputs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/outputs tfe_outputs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeOutputsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfeOutputsConfig);
    get id(): string;
    private _nonsensitiveValues;
    get nonsensitiveValues(): cdktn.AnyMap;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _values?;
    get values(): {
        [key: string]: any;
    };
    set values(value: {
        [key: string]: any;
    });
    resetValues(): void;
    get valuesInput(): {
        [key: string]: any;
    } | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
