import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PolicySetParameterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set_parameter#id PolicySetParameter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set_parameter#key PolicySetParameter#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set_parameter#policy_set_id PolicySetParameter#policy_set_id}
    */
    readonly policySetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set_parameter#sensitive PolicySetParameter#sensitive}
    */
    readonly sensitive?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set_parameter#value PolicySetParameter#value}
    */
    readonly value?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set_parameter tfe_policy_set_parameter}
*/
export declare class PolicySetParameter extends cdktn.TerraformResource {
    static readonly tfResourceType = "tfe_policy_set_parameter";
    /**
    * Generates CDKTN code for importing a PolicySetParameter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicySetParameter to import
    * @param importFromId The id of the existing PolicySetParameter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set_parameter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicySetParameter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/policy_set_parameter tfe_policy_set_parameter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicySetParameterConfig
    */
    constructor(scope: Construct, id: string, config: PolicySetParameterConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _policySetId?;
    get policySetId(): string;
    set policySetId(value: string);
    get policySetIdInput(): string | undefined;
    private _sensitive?;
    get sensitive(): boolean | cdktn.IResolvable;
    set sensitive(value: boolean | cdktn.IResolvable);
    resetSensitive(): void;
    get sensitiveInput(): boolean | cdktn.IResolvable | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
