import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TeamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#id Team#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#name Team#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#organization Team#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#sso_team_id Team#sso_team_id}
    */
    readonly ssoTeamId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#visibility Team#visibility}
    */
    readonly visibility?: string;
    /**
    * organization_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#organization_access Team#organization_access}
    */
    readonly organizationAccess?: TeamOrganizationAccess;
}
export interface TeamOrganizationAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_modules Team#manage_modules}
    */
    readonly manageModules?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_policies Team#manage_policies}
    */
    readonly managePolicies?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_policy_overrides Team#manage_policy_overrides}
    */
    readonly managePolicyOverrides?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_projects Team#manage_projects}
    */
    readonly manageProjects?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_providers Team#manage_providers}
    */
    readonly manageProviders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_run_tasks Team#manage_run_tasks}
    */
    readonly manageRunTasks?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_vcs_settings Team#manage_vcs_settings}
    */
    readonly manageVcsSettings?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_workspaces Team#manage_workspaces}
    */
    readonly manageWorkspaces?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#read_projects Team#read_projects}
    */
    readonly readProjects?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#read_workspaces Team#read_workspaces}
    */
    readonly readWorkspaces?: boolean | cdktn.IResolvable;
}
export declare function teamOrganizationAccessToTerraform(struct?: TeamOrganizationAccessOutputReference | TeamOrganizationAccess): any;
export declare function teamOrganizationAccessToHclTerraform(struct?: TeamOrganizationAccessOutputReference | TeamOrganizationAccess): any;
export declare class TeamOrganizationAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamOrganizationAccess | undefined;
    set internalValue(value: TeamOrganizationAccess | undefined);
    private _manageModules?;
    get manageModules(): boolean | cdktn.IResolvable;
    set manageModules(value: boolean | cdktn.IResolvable);
    resetManageModules(): void;
    get manageModulesInput(): boolean | cdktn.IResolvable | undefined;
    private _managePolicies?;
    get managePolicies(): boolean | cdktn.IResolvable;
    set managePolicies(value: boolean | cdktn.IResolvable);
    resetManagePolicies(): void;
    get managePoliciesInput(): boolean | cdktn.IResolvable | undefined;
    private _managePolicyOverrides?;
    get managePolicyOverrides(): boolean | cdktn.IResolvable;
    set managePolicyOverrides(value: boolean | cdktn.IResolvable);
    resetManagePolicyOverrides(): void;
    get managePolicyOverridesInput(): boolean | cdktn.IResolvable | undefined;
    private _manageProjects?;
    get manageProjects(): boolean | cdktn.IResolvable;
    set manageProjects(value: boolean | cdktn.IResolvable);
    resetManageProjects(): void;
    get manageProjectsInput(): boolean | cdktn.IResolvable | undefined;
    private _manageProviders?;
    get manageProviders(): boolean | cdktn.IResolvable;
    set manageProviders(value: boolean | cdktn.IResolvable);
    resetManageProviders(): void;
    get manageProvidersInput(): boolean | cdktn.IResolvable | undefined;
    private _manageRunTasks?;
    get manageRunTasks(): boolean | cdktn.IResolvable;
    set manageRunTasks(value: boolean | cdktn.IResolvable);
    resetManageRunTasks(): void;
    get manageRunTasksInput(): boolean | cdktn.IResolvable | undefined;
    private _manageVcsSettings?;
    get manageVcsSettings(): boolean | cdktn.IResolvable;
    set manageVcsSettings(value: boolean | cdktn.IResolvable);
    resetManageVcsSettings(): void;
    get manageVcsSettingsInput(): boolean | cdktn.IResolvable | undefined;
    private _manageWorkspaces?;
    get manageWorkspaces(): boolean | cdktn.IResolvable;
    set manageWorkspaces(value: boolean | cdktn.IResolvable);
    resetManageWorkspaces(): void;
    get manageWorkspacesInput(): boolean | cdktn.IResolvable | undefined;
    private _readProjects?;
    get readProjects(): boolean | cdktn.IResolvable;
    set readProjects(value: boolean | cdktn.IResolvable);
    resetReadProjects(): void;
    get readProjectsInput(): boolean | cdktn.IResolvable | undefined;
    private _readWorkspaces?;
    get readWorkspaces(): boolean | cdktn.IResolvable;
    set readWorkspaces(value: boolean | cdktn.IResolvable);
    resetReadWorkspaces(): void;
    get readWorkspacesInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team tfe_team}
*/
export declare class Team extends cdktn.TerraformResource {
    static readonly tfResourceType = "tfe_team";
    /**
    * Generates CDKTN code for importing a Team resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Team to import
    * @param importFromId The id of the existing Team that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Team to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team tfe_team} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamConfig
    */
    constructor(scope: Construct, id: string, config: TeamConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _ssoTeamId?;
    get ssoTeamId(): string;
    set ssoTeamId(value: string);
    resetSsoTeamId(): void;
    get ssoTeamIdInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
    private _organizationAccess;
    get organizationAccess(): TeamOrganizationAccessOutputReference;
    putOrganizationAccess(value: TeamOrganizationAccess): void;
    resetOrganizationAccess(): void;
    get organizationAccessInput(): TeamOrganizationAccess | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
