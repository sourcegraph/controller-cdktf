# `tfe_notification_configuration`

Refer to the Terraform Registry for docs: [`tfe_notification_configuration`](https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/notification_configuration).
