import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface OrganizationTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization_token#force_regenerate OrganizationToken#force_regenerate}
    */
    readonly forceRegenerate?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization_token#id OrganizationToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization_token#organization OrganizationToken#organization}
    */
    readonly organization?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization_token tfe_organization_token}
*/
export declare class OrganizationToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_organization_token";
    /**
    * Generates CDKTF code for importing a OrganizationToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OrganizationToken to import
    * @param importFromId The id of the existing OrganizationToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OrganizationToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization_token tfe_organization_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrganizationTokenConfig = {}
    */
    constructor(scope: Construct, id: string, config?: OrganizationTokenConfig);
    private _forceRegenerate?;
    get forceRegenerate(): boolean | cdktf.IResolvable;
    set forceRegenerate(value: boolean | cdktf.IResolvable);
    resetForceRegenerate(): void;
    get forceRegenerateInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    get token(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
