import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeVariableSetConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variable_set#id DataTfeVariableSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variable_set#name DataTfeVariableSet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variable_set#organization DataTfeVariableSet#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variable_set#variable_ids DataTfeVariableSet#variable_ids}
    */
    readonly variableIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variable_set#workspace_ids DataTfeVariableSet#workspace_ids}
    */
    readonly workspaceIds?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variable_set tfe_variable_set}
*/
export declare class DataTfeVariableSet extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_variable_set";
    /**
    * Generates CDKTF code for importing a DataTfeVariableSet resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeVariableSet to import
    * @param importFromId The id of the existing DataTfeVariableSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variable_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeVariableSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/variable_set tfe_variable_set} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeVariableSetConfig
    */
    constructor(scope: Construct, id: string, config: DataTfeVariableSetConfig);
    get description(): string;
    get global(): cdktf.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _variableIds?;
    get variableIds(): string[];
    set variableIds(value: string[]);
    resetVariableIds(): void;
    get variableIdsInput(): string[] | undefined;
    private _workspaceIds?;
    get workspaceIds(): string[];
    set workspaceIds(value: string[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
