import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TeamOrganizationMemberConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_member#id TeamOrganizationMember#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_member#organization_membership_id TeamOrganizationMember#organization_membership_id}
    */
    readonly organizationMembershipId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_member#team_id TeamOrganizationMember#team_id}
    */
    readonly teamId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_member tfe_team_organization_member}
*/
export declare class TeamOrganizationMember extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_team_organization_member";
    /**
    * Generates CDKTF code for importing a TeamOrganizationMember resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamOrganizationMember to import
    * @param importFromId The id of the existing TeamOrganizationMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamOrganizationMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_member tfe_team_organization_member} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamOrganizationMemberConfig
    */
    constructor(scope: Construct, id: string, config: TeamOrganizationMemberConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _organizationMembershipId?;
    get organizationMembershipId(): string;
    set organizationMembershipId(value: string);
    get organizationMembershipIdInput(): string | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
