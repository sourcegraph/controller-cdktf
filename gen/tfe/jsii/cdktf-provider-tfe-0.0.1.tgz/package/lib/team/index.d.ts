import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TeamConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#id Team#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#name Team#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#organization Team#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#sso_team_id Team#sso_team_id}
    */
    readonly ssoTeamId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#visibility Team#visibility}
    */
    readonly visibility?: string;
    /**
    * organization_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#organization_access Team#organization_access}
    */
    readonly organizationAccess?: TeamOrganizationAccess;
}
export interface TeamOrganizationAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_modules Team#manage_modules}
    */
    readonly manageModules?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_policies Team#manage_policies}
    */
    readonly managePolicies?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_policy_overrides Team#manage_policy_overrides}
    */
    readonly managePolicyOverrides?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_projects Team#manage_projects}
    */
    readonly manageProjects?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_providers Team#manage_providers}
    */
    readonly manageProviders?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_run_tasks Team#manage_run_tasks}
    */
    readonly manageRunTasks?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_vcs_settings Team#manage_vcs_settings}
    */
    readonly manageVcsSettings?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#manage_workspaces Team#manage_workspaces}
    */
    readonly manageWorkspaces?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#read_projects Team#read_projects}
    */
    readonly readProjects?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#read_workspaces Team#read_workspaces}
    */
    readonly readWorkspaces?: boolean | cdktf.IResolvable;
}
export declare function teamOrganizationAccessToTerraform(struct?: TeamOrganizationAccessOutputReference | TeamOrganizationAccess): any;
export declare function teamOrganizationAccessToHclTerraform(struct?: TeamOrganizationAccessOutputReference | TeamOrganizationAccess): any;
export declare class TeamOrganizationAccessOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamOrganizationAccess | undefined;
    set internalValue(value: TeamOrganizationAccess | undefined);
    private _manageModules?;
    get manageModules(): boolean | cdktf.IResolvable;
    set manageModules(value: boolean | cdktf.IResolvable);
    resetManageModules(): void;
    get manageModulesInput(): boolean | cdktf.IResolvable | undefined;
    private _managePolicies?;
    get managePolicies(): boolean | cdktf.IResolvable;
    set managePolicies(value: boolean | cdktf.IResolvable);
    resetManagePolicies(): void;
    get managePoliciesInput(): boolean | cdktf.IResolvable | undefined;
    private _managePolicyOverrides?;
    get managePolicyOverrides(): boolean | cdktf.IResolvable;
    set managePolicyOverrides(value: boolean | cdktf.IResolvable);
    resetManagePolicyOverrides(): void;
    get managePolicyOverridesInput(): boolean | cdktf.IResolvable | undefined;
    private _manageProjects?;
    get manageProjects(): boolean | cdktf.IResolvable;
    set manageProjects(value: boolean | cdktf.IResolvable);
    resetManageProjects(): void;
    get manageProjectsInput(): boolean | cdktf.IResolvable | undefined;
    private _manageProviders?;
    get manageProviders(): boolean | cdktf.IResolvable;
    set manageProviders(value: boolean | cdktf.IResolvable);
    resetManageProviders(): void;
    get manageProvidersInput(): boolean | cdktf.IResolvable | undefined;
    private _manageRunTasks?;
    get manageRunTasks(): boolean | cdktf.IResolvable;
    set manageRunTasks(value: boolean | cdktf.IResolvable);
    resetManageRunTasks(): void;
    get manageRunTasksInput(): boolean | cdktf.IResolvable | undefined;
    private _manageVcsSettings?;
    get manageVcsSettings(): boolean | cdktf.IResolvable;
    set manageVcsSettings(value: boolean | cdktf.IResolvable);
    resetManageVcsSettings(): void;
    get manageVcsSettingsInput(): boolean | cdktf.IResolvable | undefined;
    private _manageWorkspaces?;
    get manageWorkspaces(): boolean | cdktf.IResolvable;
    set manageWorkspaces(value: boolean | cdktf.IResolvable);
    resetManageWorkspaces(): void;
    get manageWorkspacesInput(): boolean | cdktf.IResolvable | undefined;
    private _readProjects?;
    get readProjects(): boolean | cdktf.IResolvable;
    set readProjects(value: boolean | cdktf.IResolvable);
    resetReadProjects(): void;
    get readProjectsInput(): boolean | cdktf.IResolvable | undefined;
    private _readWorkspaces?;
    get readWorkspaces(): boolean | cdktf.IResolvable;
    set readWorkspaces(value: boolean | cdktf.IResolvable);
    resetReadWorkspaces(): void;
    get readWorkspacesInput(): boolean | cdktf.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team tfe_team}
*/
export declare class Team extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_team";
    /**
    * Generates CDKTF code for importing a Team resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Team to import
    * @param importFromId The id of the existing Team that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Team to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team tfe_team} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamConfig
    */
    constructor(scope: Construct, id: string, config: TeamConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _ssoTeamId?;
    get ssoTeamId(): string;
    set ssoTeamId(value: string);
    resetSsoTeamId(): void;
    get ssoTeamIdInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
    private _organizationAccess;
    get organizationAccess(): TeamOrganizationAccessOutputReference;
    putOrganizationAccess(value: TeamOrganizationAccess): void;
    resetOrganizationAccess(): void;
    get organizationAccessInput(): TeamOrganizationAccess | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
