import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TerraformVersionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version#beta TerraformVersion#beta}
    */
    readonly beta?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version#deprecated TerraformVersion#deprecated}
    */
    readonly deprecated?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version#deprecated_reason TerraformVersion#deprecated_reason}
    */
    readonly deprecatedReason?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version#enabled TerraformVersion#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version#id TerraformVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version#official TerraformVersion#official}
    */
    readonly official?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version#sha TerraformVersion#sha}
    */
    readonly sha: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version#url TerraformVersion#url}
    */
    readonly url: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version#version TerraformVersion#version}
    */
    readonly version: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version tfe_terraform_version}
*/
export declare class TerraformVersion extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_terraform_version";
    /**
    * Generates CDKTF code for importing a TerraformVersion resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TerraformVersion to import
    * @param importFromId The id of the existing TerraformVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TerraformVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/terraform_version tfe_terraform_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TerraformVersionConfig
    */
    constructor(scope: Construct, id: string, config: TerraformVersionConfig);
    private _beta?;
    get beta(): boolean | cdktf.IResolvable;
    set beta(value: boolean | cdktf.IResolvable);
    resetBeta(): void;
    get betaInput(): boolean | cdktf.IResolvable | undefined;
    private _deprecated?;
    get deprecated(): boolean | cdktf.IResolvable;
    set deprecated(value: boolean | cdktf.IResolvable);
    resetDeprecated(): void;
    get deprecatedInput(): boolean | cdktf.IResolvable | undefined;
    private _deprecatedReason?;
    get deprecatedReason(): string;
    set deprecatedReason(value: string);
    resetDeprecatedReason(): void;
    get deprecatedReasonInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _official?;
    get official(): boolean | cdktf.IResolvable;
    set official(value: boolean | cdktf.IResolvable);
    resetOfficial(): void;
    get officialInput(): boolean | cdktf.IResolvable | undefined;
    private _sha?;
    get sha(): string;
    set sha(value: string);
    get shaInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
