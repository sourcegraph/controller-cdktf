import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeOrganizationMembersConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/organization_members#id DataTfeOrganizationMembers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/organization_members#organization DataTfeOrganizationMembers#organization}
    */
    readonly organization?: string;
}
export interface DataTfeOrganizationMembersMembers {
}
export declare function dataTfeOrganizationMembersMembersToTerraform(struct?: DataTfeOrganizationMembersMembers): any;
export declare function dataTfeOrganizationMembersMembersToHclTerraform(struct?: DataTfeOrganizationMembersMembers): any;
export declare class DataTfeOrganizationMembersMembersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeOrganizationMembersMembers | undefined;
    set internalValue(value: DataTfeOrganizationMembersMembers | undefined);
    get organizationMembershipId(): string;
    get userId(): string;
}
export declare class DataTfeOrganizationMembersMembersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeOrganizationMembersMembersOutputReference;
}
export interface DataTfeOrganizationMembersMembersWaiting {
}
export declare function dataTfeOrganizationMembersMembersWaitingToTerraform(struct?: DataTfeOrganizationMembersMembersWaiting): any;
export declare function dataTfeOrganizationMembersMembersWaitingToHclTerraform(struct?: DataTfeOrganizationMembersMembersWaiting): any;
export declare class DataTfeOrganizationMembersMembersWaitingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfeOrganizationMembersMembersWaiting | undefined;
    set internalValue(value: DataTfeOrganizationMembersMembersWaiting | undefined);
    get organizationMembershipId(): string;
    get userId(): string;
}
export declare class DataTfeOrganizationMembersMembersWaitingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfeOrganizationMembersMembersWaitingOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/organization_members tfe_organization_members}
*/
export declare class DataTfeOrganizationMembers extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_organization_members";
    /**
    * Generates CDKTF code for importing a DataTfeOrganizationMembers resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeOrganizationMembers to import
    * @param importFromId The id of the existing DataTfeOrganizationMembers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/organization_members#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeOrganizationMembers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/organization_members tfe_organization_members} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeOrganizationMembersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfeOrganizationMembersConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _members;
    get members(): DataTfeOrganizationMembersMembersList;
    private _membersWaiting;
    get membersWaiting(): DataTfeOrganizationMembersMembersWaitingList;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
