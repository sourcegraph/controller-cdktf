import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RegistryModuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#id RegistryModule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#module_provider RegistryModule#module_provider}
    */
    readonly moduleProvider?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#name RegistryModule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#namespace RegistryModule#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#no_code RegistryModule#no_code}
    */
    readonly noCode?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#organization RegistryModule#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#registry_name RegistryModule#registry_name}
    */
    readonly registryName?: string;
    /**
    * vcs_repo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#vcs_repo RegistryModule#vcs_repo}
    */
    readonly vcsRepo?: RegistryModuleVcsRepo;
}
export interface RegistryModuleVcsRepo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#display_identifier RegistryModule#display_identifier}
    */
    readonly displayIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#github_app_installation_id RegistryModule#github_app_installation_id}
    */
    readonly githubAppInstallationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#identifier RegistryModule#identifier}
    */
    readonly identifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#oauth_token_id RegistryModule#oauth_token_id}
    */
    readonly oauthTokenId?: string;
}
export declare function registryModuleVcsRepoToTerraform(struct?: RegistryModuleVcsRepoOutputReference | RegistryModuleVcsRepo): any;
export declare function registryModuleVcsRepoToHclTerraform(struct?: RegistryModuleVcsRepoOutputReference | RegistryModuleVcsRepo): any;
export declare class RegistryModuleVcsRepoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RegistryModuleVcsRepo | undefined;
    set internalValue(value: RegistryModuleVcsRepo | undefined);
    private _displayIdentifier?;
    get displayIdentifier(): string;
    set displayIdentifier(value: string);
    get displayIdentifierInput(): string | undefined;
    private _githubAppInstallationId?;
    get githubAppInstallationId(): string;
    set githubAppInstallationId(value: string);
    resetGithubAppInstallationId(): void;
    get githubAppInstallationIdInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _oauthTokenId?;
    get oauthTokenId(): string;
    set oauthTokenId(value: string);
    resetOauthTokenId(): void;
    get oauthTokenIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module tfe_registry_module}
*/
export declare class RegistryModule extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_registry_module";
    /**
    * Generates CDKTF code for importing a RegistryModule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RegistryModule to import
    * @param importFromId The id of the existing RegistryModule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RegistryModule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/registry_module tfe_registry_module} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RegistryModuleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: RegistryModuleConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _moduleProvider?;
    get moduleProvider(): string;
    set moduleProvider(value: string);
    resetModuleProvider(): void;
    get moduleProviderInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _noCode?;
    get noCode(): boolean | cdktf.IResolvable;
    set noCode(value: boolean | cdktf.IResolvable);
    resetNoCode(): void;
    get noCodeInput(): boolean | cdktf.IResolvable | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _registryName?;
    get registryName(): string;
    set registryName(value: string);
    resetRegistryName(): void;
    get registryNameInput(): string | undefined;
    private _vcsRepo;
    get vcsRepo(): RegistryModuleVcsRepoOutputReference;
    putVcsRepo(value: RegistryModuleVcsRepo): void;
    resetVcsRepo(): void;
    get vcsRepoInput(): RegistryModuleVcsRepo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
