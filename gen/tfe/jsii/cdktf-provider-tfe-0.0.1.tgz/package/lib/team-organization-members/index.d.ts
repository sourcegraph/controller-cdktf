import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TeamOrganizationMembersConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_members#id TeamOrganizationMembers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_members#organization_membership_ids TeamOrganizationMembers#organization_membership_ids}
    */
    readonly organizationMembershipIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_members#team_id TeamOrganizationMembers#team_id}
    */
    readonly teamId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_members tfe_team_organization_members}
*/
export declare class TeamOrganizationMembers extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_team_organization_members";
    /**
    * Generates CDKTF code for importing a TeamOrganizationMembers resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamOrganizationMembers to import
    * @param importFromId The id of the existing TeamOrganizationMembers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_members#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamOrganizationMembers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/team_organization_members tfe_team_organization_members} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamOrganizationMembersConfig
    */
    constructor(scope: Construct, id: string, config: TeamOrganizationMembersConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _organizationMembershipIds?;
    get organizationMembershipIds(): string[];
    set organizationMembershipIds(value: string[]);
    get organizationMembershipIdsInput(): string[] | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
