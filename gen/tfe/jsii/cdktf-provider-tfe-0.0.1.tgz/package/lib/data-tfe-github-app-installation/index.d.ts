import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeGithubAppInstallationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/github_app_installation#installation_id DataTfeGithubAppInstallation#installation_id}
    */
    readonly installationId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/github_app_installation#name DataTfeGithubAppInstallation#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/github_app_installation tfe_github_app_installation}
*/
export declare class DataTfeGithubAppInstallation extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_github_app_installation";
    /**
    * Generates CDKTF code for importing a DataTfeGithubAppInstallation resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeGithubAppInstallation to import
    * @param importFromId The id of the existing DataTfeGithubAppInstallation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/github_app_installation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeGithubAppInstallation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/github_app_installation tfe_github_app_installation} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeGithubAppInstallationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfeGithubAppInstallationConfig);
    get id(): string;
    private _installationId?;
    get installationId(): number;
    set installationId(value: number);
    resetInstallationId(): void;
    get installationIdInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
