import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfePolicySetConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/policy_set#id DataTfePolicySet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The policy-as-code framework for the policy. Valid values are sentinel and opa
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/policy_set#kind DataTfePolicySet#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/policy_set#name DataTfePolicySet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/policy_set#organization DataTfePolicySet#organization}
    */
    readonly organization?: string;
    /**
    * Whether users can override this policy when it fails during a run. Only valid for OPA policies
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/policy_set#overridable DataTfePolicySet#overridable}
    */
    readonly overridable?: boolean | cdktf.IResolvable;
}
export interface DataTfePolicySetVcsRepo {
}
export declare function dataTfePolicySetVcsRepoToTerraform(struct?: DataTfePolicySetVcsRepo): any;
export declare function dataTfePolicySetVcsRepoToHclTerraform(struct?: DataTfePolicySetVcsRepo): any;
export declare class DataTfePolicySetVcsRepoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTfePolicySetVcsRepo | undefined;
    set internalValue(value: DataTfePolicySetVcsRepo | undefined);
    get branch(): string;
    get githubAppInstallationId(): string;
    get identifier(): string;
    get ingressSubmodules(): cdktf.IResolvable;
    get oauthTokenId(): string;
}
export declare class DataTfePolicySetVcsRepoList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTfePolicySetVcsRepoOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/policy_set tfe_policy_set}
*/
export declare class DataTfePolicySet extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_policy_set";
    /**
    * Generates CDKTF code for importing a DataTfePolicySet resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfePolicySet to import
    * @param importFromId The id of the existing DataTfePolicySet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/policy_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfePolicySet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/policy_set tfe_policy_set} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfePolicySetConfig
    */
    constructor(scope: Construct, id: string, config: DataTfePolicySetConfig);
    get description(): string;
    get global(): cdktf.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _overridable?;
    get overridable(): boolean | cdktf.IResolvable;
    set overridable(value: boolean | cdktf.IResolvable);
    resetOverridable(): void;
    get overridableInput(): boolean | cdktf.IResolvable | undefined;
    get policiesPath(): string;
    get policyIds(): string[];
    private _vcsRepo;
    get vcsRepo(): DataTfePolicySetVcsRepoList;
    get workspaceIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
