import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WorkspaceRunTaskConfig extends cdktf.TerraformMetaArguments {
    /**
    * The enforcement level of the task. Valid values are `advisory` and `mandatory`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_run_task#enforcement_level WorkspaceRunTask#enforcement_level}
    */
    readonly enforcementLevel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_run_task#id WorkspaceRunTask#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The stage to run the task in. Valid values are `pre_plan`, `post_plan` and `pre_apply`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_run_task#stage WorkspaceRunTask#stage}
    */
    readonly stage?: string;
    /**
    * The id of the Run task to associate to the Workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_run_task#task_id WorkspaceRunTask#task_id}
    */
    readonly taskId: string;
    /**
    * The id of the workspace to associate the Run task to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_run_task#workspace_id WorkspaceRunTask#workspace_id}
    */
    readonly workspaceId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_run_task tfe_workspace_run_task}
*/
export declare class WorkspaceRunTask extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_workspace_run_task";
    /**
    * Generates CDKTF code for importing a WorkspaceRunTask resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceRunTask to import
    * @param importFromId The id of the existing WorkspaceRunTask that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_run_task#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceRunTask to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/workspace_run_task tfe_workspace_run_task} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceRunTaskConfig
    */
    constructor(scope: Construct, id: string, config: WorkspaceRunTaskConfig);
    private _enforcementLevel?;
    get enforcementLevel(): string;
    set enforcementLevel(value: string);
    get enforcementLevelInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    resetStage(): void;
    get stageInput(): string | undefined;
    private _taskId?;
    get taskId(): string;
    set taskId(value: string);
    get taskIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
