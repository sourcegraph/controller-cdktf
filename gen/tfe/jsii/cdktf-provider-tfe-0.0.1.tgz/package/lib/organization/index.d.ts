import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface OrganizationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#allow_force_delete_workspaces Organization#allow_force_delete_workspaces}
    */
    readonly allowForceDeleteWorkspaces?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#assessments_enforced Organization#assessments_enforced}
    */
    readonly assessmentsEnforced?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#collaborator_auth_policy Organization#collaborator_auth_policy}
    */
    readonly collaboratorAuthPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#cost_estimation_enabled Organization#cost_estimation_enabled}
    */
    readonly costEstimationEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#email Organization#email}
    */
    readonly email: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#id Organization#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#name Organization#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#owners_team_saml_role_id Organization#owners_team_saml_role_id}
    */
    readonly ownersTeamSamlRoleId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#send_passing_statuses_for_untriggered_speculative_plans Organization#send_passing_statuses_for_untriggered_speculative_plans}
    */
    readonly sendPassingStatusesForUntriggeredSpeculativePlans?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#session_remember_minutes Organization#session_remember_minutes}
    */
    readonly sessionRememberMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#session_timeout_minutes Organization#session_timeout_minutes}
    */
    readonly sessionTimeoutMinutes?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization tfe_organization}
*/
export declare class Organization extends cdktf.TerraformResource {
    static readonly tfResourceType = "tfe_organization";
    /**
    * Generates CDKTF code for importing a Organization resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Organization to import
    * @param importFromId The id of the existing Organization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Organization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/resources/organization tfe_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrganizationConfig
    */
    constructor(scope: Construct, id: string, config: OrganizationConfig);
    private _allowForceDeleteWorkspaces?;
    get allowForceDeleteWorkspaces(): boolean | cdktf.IResolvable;
    set allowForceDeleteWorkspaces(value: boolean | cdktf.IResolvable);
    resetAllowForceDeleteWorkspaces(): void;
    get allowForceDeleteWorkspacesInput(): boolean | cdktf.IResolvable | undefined;
    private _assessmentsEnforced?;
    get assessmentsEnforced(): boolean | cdktf.IResolvable;
    set assessmentsEnforced(value: boolean | cdktf.IResolvable);
    resetAssessmentsEnforced(): void;
    get assessmentsEnforcedInput(): boolean | cdktf.IResolvable | undefined;
    private _collaboratorAuthPolicy?;
    get collaboratorAuthPolicy(): string;
    set collaboratorAuthPolicy(value: string);
    resetCollaboratorAuthPolicy(): void;
    get collaboratorAuthPolicyInput(): string | undefined;
    private _costEstimationEnabled?;
    get costEstimationEnabled(): boolean | cdktf.IResolvable;
    set costEstimationEnabled(value: boolean | cdktf.IResolvable);
    resetCostEstimationEnabled(): void;
    get costEstimationEnabledInput(): boolean | cdktf.IResolvable | undefined;
    get defaultProjectId(): string;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ownersTeamSamlRoleId?;
    get ownersTeamSamlRoleId(): string;
    set ownersTeamSamlRoleId(value: string);
    resetOwnersTeamSamlRoleId(): void;
    get ownersTeamSamlRoleIdInput(): string | undefined;
    private _sendPassingStatusesForUntriggeredSpeculativePlans?;
    get sendPassingStatusesForUntriggeredSpeculativePlans(): boolean | cdktf.IResolvable;
    set sendPassingStatusesForUntriggeredSpeculativePlans(value: boolean | cdktf.IResolvable);
    resetSendPassingStatusesForUntriggeredSpeculativePlans(): void;
    get sendPassingStatusesForUntriggeredSpeculativePlansInput(): boolean | cdktf.IResolvable | undefined;
    private _sessionRememberMinutes?;
    get sessionRememberMinutes(): number;
    set sessionRememberMinutes(value: number);
    resetSessionRememberMinutes(): void;
    get sessionRememberMinutesInput(): number | undefined;
    private _sessionTimeoutMinutes?;
    get sessionTimeoutMinutes(): number;
    set sessionTimeoutMinutes(value: number);
    resetSessionTimeoutMinutes(): void;
    get sessionTimeoutMinutesInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
