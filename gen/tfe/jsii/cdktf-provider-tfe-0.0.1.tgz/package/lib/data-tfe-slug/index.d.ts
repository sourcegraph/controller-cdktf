import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeSlugConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/slug#id DataTfeSlug#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/slug#source_path DataTfeSlug#source_path}
    */
    readonly sourcePath: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/slug tfe_slug}
*/
export declare class DataTfeSlug extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_slug";
    /**
    * Generates CDKTF code for importing a DataTfeSlug resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeSlug to import
    * @param importFromId The id of the existing DataTfeSlug that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/slug#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeSlug to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/slug tfe_slug} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeSlugConfig
    */
    constructor(scope: Construct, id: string, config: DataTfeSlugConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _sourcePath?;
    get sourcePath(): string;
    set sourcePath(value: string);
    get sourcePathInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
