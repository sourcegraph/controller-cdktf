import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataTfeOrganizationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/organization#id DataTfeOrganization#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/organization#name DataTfeOrganization#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/organization tfe_organization}
*/
export declare class DataTfeOrganization extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "tfe_organization";
    /**
    * Generates CDKTF code for importing a DataTfeOrganization resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfeOrganization to import
    * @param importFromId The id of the existing DataTfeOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfeOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tfe/0.43.0/docs/data-sources/organization tfe_organization} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfeOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: DataTfeOrganizationConfig);
    get assessmentsEnforced(): cdktf.IResolvable;
    get collaboratorAuthPolicy(): string;
    get costEstimationEnabled(): cdktf.IResolvable;
    get defaultProjectId(): string;
    get email(): string;
    get externalId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownersTeamSamlRoleId(): string;
    get sendPassingStatusesForUntriggeredSpeculativePlans(): cdktf.IResolvable;
    get twoFactorConformant(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
