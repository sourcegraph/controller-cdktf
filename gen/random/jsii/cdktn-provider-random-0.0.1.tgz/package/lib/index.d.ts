export * as id from './id/index';
export * as integer from './integer/index';
export * as password from './password/index';
export * as pet from './pet/index';
export * as shuffle from './shuffle/index';
export * as stringResource from './string-resource/index';
export * as uuid from './uuid/index';
export * as provider from './provider/index';
