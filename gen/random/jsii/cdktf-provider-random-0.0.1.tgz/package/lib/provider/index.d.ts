import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RandomProviderConfig {
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.5.1/docs#alias RandomProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/random/3.5.1/docs random}
*/
export declare class RandomProvider extends cdktf.TerraformProvider {
    static readonly tfResourceType = "random";
    /**
    * Generates CDKTF code for importing a RandomProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RandomProvider to import
    * @param importFromId The id of the existing RandomProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/random/3.5.1/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RandomProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/random/3.5.1/docs random} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RandomProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: RandomProviderConfig);
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
