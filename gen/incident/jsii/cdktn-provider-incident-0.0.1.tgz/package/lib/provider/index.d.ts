import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IncidentProviderConfig {
    /**
    * API key for incident.io (https://app.incident.io/settings/api-keys). Sourced from the `INCIDENT_API_KEY` environment variable, if set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs#api_key IncidentProvider#api_key}
    */
    readonly apiKey?: string;
    /**
    * URL of the incident.io API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs#endpoint IncidentProvider#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs#alias IncidentProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs incident}
*/
export declare class IncidentProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "incident";
    /**
    * Generates CDKTN code for importing a IncidentProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IncidentProvider to import
    * @param importFromId The id of the existing IncidentProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IncidentProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs incident} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IncidentProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: IncidentProviderConfig);
    private _apiKey?;
    get apiKey(): string | undefined;
    set apiKey(value: string | undefined);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string | undefined;
    set endpoint(value: string | undefined);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
