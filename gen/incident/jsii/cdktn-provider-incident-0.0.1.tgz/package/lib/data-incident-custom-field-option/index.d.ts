import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataIncidentCustomFieldOptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the custom field this option belongs to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/custom_field_option#custom_field_id DataIncidentCustomFieldOption#custom_field_id}
    */
    readonly customFieldId: string;
    /**
    * Sort key used to order the custom field options correctly
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/custom_field_option#sort_key DataIncidentCustomFieldOption#sort_key}
    */
    readonly sortKey?: number;
    /**
    * Human readable name for the custom field option
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/custom_field_option#value DataIncidentCustomFieldOption#value}
    */
    readonly value: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/custom_field_option incident_custom_field_option}
*/
export declare class DataIncidentCustomFieldOption extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "incident_custom_field_option";
    /**
    * Generates CDKTN code for importing a DataIncidentCustomFieldOption resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIncidentCustomFieldOption to import
    * @param importFromId The id of the existing DataIncidentCustomFieldOption that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/custom_field_option#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIncidentCustomFieldOption to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/custom_field_option incident_custom_field_option} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIncidentCustomFieldOptionConfig
    */
    constructor(scope: Construct, id: string, config: DataIncidentCustomFieldOptionConfig);
    private _customFieldId?;
    get customFieldId(): string;
    set customFieldId(value: string);
    get customFieldIdInput(): string | undefined;
    get id(): string;
    private _sortKey?;
    get sortKey(): number;
    set sortKey(value: number);
    resetSortKey(): void;
    get sortKeyInput(): number | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
