import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#holidays_public_config Schedule#holidays_public_config}
    */
    readonly holidaysPublicConfig?: ScheduleHolidaysPublicConfig;
    /**
    * Human readable name synced from external provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#name Schedule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#rotations Schedule#rotations}
    */
    readonly rotations: ScheduleRotations[] | cdktn.IResolvable;
    /**
    * IDs of teams that own this schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#team_ids Schedule#team_ids}
    */
    readonly teamIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#timezone Schedule#timezone}
    */
    readonly timezone: string;
}
export interface ScheduleHolidaysPublicConfig {
    /**
    * ISO 3166-1 alpha-2 country codes for the countries that this schedule is configured to view holidays for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#country_codes Schedule#country_codes}
    */
    readonly countryCodes: string[];
}
export declare function scheduleHolidaysPublicConfigToTerraform(struct?: ScheduleHolidaysPublicConfig | cdktn.IResolvable): any;
export declare function scheduleHolidaysPublicConfigToHclTerraform(struct?: ScheduleHolidaysPublicConfig | cdktn.IResolvable): any;
export declare class ScheduleHolidaysPublicConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ScheduleHolidaysPublicConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ScheduleHolidaysPublicConfig | cdktn.IResolvable | undefined);
    private _countryCodes?;
    get countryCodes(): string[];
    set countryCodes(value: string[]);
    get countryCodesInput(): string[] | undefined;
}
export interface ScheduleRotationsVersionsHandovers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#interval Schedule#interval}
    */
    readonly interval: number;
    /**
    * How often a handover occurs. Possible values are: `hourly`, `daily`, `weekly`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#interval_type Schedule#interval_type}
    */
    readonly intervalType: string;
}
export declare function scheduleRotationsVersionsHandoversToTerraform(struct?: ScheduleRotationsVersionsHandovers | cdktn.IResolvable): any;
export declare function scheduleRotationsVersionsHandoversToHclTerraform(struct?: ScheduleRotationsVersionsHandovers | cdktn.IResolvable): any;
export declare class ScheduleRotationsVersionsHandoversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScheduleRotationsVersionsHandovers | cdktn.IResolvable | undefined;
    set internalValue(value: ScheduleRotationsVersionsHandovers | cdktn.IResolvable | undefined);
    private _interval?;
    get interval(): number;
    set interval(value: number);
    get intervalInput(): number | undefined;
    private _intervalType?;
    get intervalType(): string;
    set intervalType(value: string);
    get intervalTypeInput(): string | undefined;
}
export declare class ScheduleRotationsVersionsHandoversList extends cdktn.ComplexList {
    internalValue?: ScheduleRotationsVersionsHandovers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScheduleRotationsVersionsHandoversOutputReference;
}
export interface ScheduleRotationsVersionsLayers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#id Schedule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#name Schedule#name}
    */
    readonly name: string;
}
export declare function scheduleRotationsVersionsLayersToTerraform(struct?: ScheduleRotationsVersionsLayers | cdktn.IResolvable): any;
export declare function scheduleRotationsVersionsLayersToHclTerraform(struct?: ScheduleRotationsVersionsLayers | cdktn.IResolvable): any;
export declare class ScheduleRotationsVersionsLayersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScheduleRotationsVersionsLayers | cdktn.IResolvable | undefined;
    set internalValue(value: ScheduleRotationsVersionsLayers | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ScheduleRotationsVersionsLayersList extends cdktn.ComplexList {
    internalValue?: ScheduleRotationsVersionsLayers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScheduleRotationsVersionsLayersOutputReference;
}
export interface ScheduleRotationsVersionsWorkingIntervals {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#end_time Schedule#end_time}
    */
    readonly endTime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#start_time Schedule#start_time}
    */
    readonly startTime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#weekday Schedule#weekday}
    */
    readonly weekday: string;
}
export declare function scheduleRotationsVersionsWorkingIntervalsToTerraform(struct?: ScheduleRotationsVersionsWorkingIntervals | cdktn.IResolvable): any;
export declare function scheduleRotationsVersionsWorkingIntervalsToHclTerraform(struct?: ScheduleRotationsVersionsWorkingIntervals | cdktn.IResolvable): any;
export declare class ScheduleRotationsVersionsWorkingIntervalsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScheduleRotationsVersionsWorkingIntervals | cdktn.IResolvable | undefined;
    set internalValue(value: ScheduleRotationsVersionsWorkingIntervals | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    private _weekday?;
    get weekday(): string;
    set weekday(value: string);
    get weekdayInput(): string | undefined;
}
export declare class ScheduleRotationsVersionsWorkingIntervalsList extends cdktn.ComplexList {
    internalValue?: ScheduleRotationsVersionsWorkingIntervals[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScheduleRotationsVersionsWorkingIntervalsOutputReference;
}
export interface ScheduleRotationsVersions {
    /**
    * When this rotation config will be effective from
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#effective_from Schedule#effective_from}
    */
    readonly effectiveFrom?: string;
    /**
    * Defines the next moment we'll trigger a handover
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#handover_start_at Schedule#handover_start_at}
    */
    readonly handoverStartAt: string;
    /**
    * Defines the handover intervals for this rota, in order they should apply
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#handovers Schedule#handovers}
    */
    readonly handovers: ScheduleRotationsVersionsHandovers[] | cdktn.IResolvable;
    /**
    * Controls how many people are on-call concurrently
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#layers Schedule#layers}
    */
    readonly layers: ScheduleRotationsVersionsLayers[] | cdktn.IResolvable;
    /**
    * The incident.io ID of a user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#users Schedule#users}
    */
    readonly users: string[];
    /**
    * Optional restrictions that define when to schedule people for this rota
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#working_intervals Schedule#working_intervals}
    */
    readonly workingIntervals?: ScheduleRotationsVersionsWorkingIntervals[] | cdktn.IResolvable;
}
export declare function scheduleRotationsVersionsToTerraform(struct?: ScheduleRotationsVersions | cdktn.IResolvable): any;
export declare function scheduleRotationsVersionsToHclTerraform(struct?: ScheduleRotationsVersions | cdktn.IResolvable): any;
export declare class ScheduleRotationsVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScheduleRotationsVersions | cdktn.IResolvable | undefined;
    set internalValue(value: ScheduleRotationsVersions | cdktn.IResolvable | undefined);
    private _effectiveFrom?;
    get effectiveFrom(): string;
    set effectiveFrom(value: string);
    resetEffectiveFrom(): void;
    get effectiveFromInput(): string | undefined;
    private _handoverStartAt?;
    get handoverStartAt(): string;
    set handoverStartAt(value: string);
    get handoverStartAtInput(): string | undefined;
    private _handovers;
    get handovers(): ScheduleRotationsVersionsHandoversList;
    putHandovers(value: ScheduleRotationsVersionsHandovers[] | cdktn.IResolvable): void;
    get handoversInput(): cdktn.IResolvable | ScheduleRotationsVersionsHandovers[] | undefined;
    private _layers;
    get layers(): ScheduleRotationsVersionsLayersList;
    putLayers(value: ScheduleRotationsVersionsLayers[] | cdktn.IResolvable): void;
    get layersInput(): cdktn.IResolvable | ScheduleRotationsVersionsLayers[] | undefined;
    private _users?;
    get users(): string[];
    set users(value: string[]);
    get usersInput(): string[] | undefined;
    private _workingIntervals;
    get workingIntervals(): ScheduleRotationsVersionsWorkingIntervalsList;
    putWorkingIntervals(value: ScheduleRotationsVersionsWorkingIntervals[] | cdktn.IResolvable): void;
    resetWorkingIntervals(): void;
    get workingIntervalsInput(): cdktn.IResolvable | ScheduleRotationsVersionsWorkingIntervals[] | undefined;
}
export declare class ScheduleRotationsVersionsList extends cdktn.ComplexList {
    internalValue?: ScheduleRotationsVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScheduleRotationsVersionsOutputReference;
}
export interface ScheduleRotations {
    /**
    * Unique internal ID of the rotation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#id Schedule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Human readable name synced from external provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#name Schedule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#versions Schedule#versions}
    */
    readonly versions: ScheduleRotationsVersions[] | cdktn.IResolvable;
}
export declare function scheduleRotationsToTerraform(struct?: ScheduleRotations | cdktn.IResolvable): any;
export declare function scheduleRotationsToHclTerraform(struct?: ScheduleRotations | cdktn.IResolvable): any;
export declare class ScheduleRotationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScheduleRotations | cdktn.IResolvable | undefined;
    set internalValue(value: ScheduleRotations | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _versions;
    get versions(): ScheduleRotationsVersionsList;
    putVersions(value: ScheduleRotationsVersions[] | cdktn.IResolvable): void;
    get versionsInput(): cdktn.IResolvable | ScheduleRotationsVersions[] | undefined;
}
export declare class ScheduleRotationsList extends cdktn.ComplexList {
    internalValue?: ScheduleRotations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScheduleRotationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule incident_schedule}
*/
export declare class Schedule extends cdktn.TerraformResource {
    static readonly tfResourceType = "incident_schedule";
    /**
    * Generates CDKTN code for importing a Schedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Schedule to import
    * @param importFromId The id of the existing Schedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Schedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/schedule incident_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ScheduleConfig
    */
    constructor(scope: Construct, id: string, config: ScheduleConfig);
    private _holidaysPublicConfig;
    get holidaysPublicConfig(): ScheduleHolidaysPublicConfigOutputReference;
    putHolidaysPublicConfig(value: ScheduleHolidaysPublicConfig): void;
    resetHolidaysPublicConfig(): void;
    get holidaysPublicConfigInput(): cdktn.IResolvable | ScheduleHolidaysPublicConfig | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rotations;
    get rotations(): ScheduleRotationsList;
    putRotations(value: ScheduleRotations[] | cdktn.IResolvable): void;
    get rotationsInput(): cdktn.IResolvable | ScheduleRotations[] | undefined;
    private _teamIds?;
    get teamIds(): string[];
    set teamIds(value: string[]);
    resetTeamIds(): void;
    get teamIdsInput(): string[] | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    get timezoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
