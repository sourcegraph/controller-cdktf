import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Which alert sources should this alert route match?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#alert_sources AlertRoute#alert_sources}
    */
    readonly alertSources: AlertRouteAlertSources[] | cdktn.IResolvable;
    /**
    * The channel configuration for this alert route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#channel_config AlertRoute#channel_config}
    */
    readonly channelConfig?: AlertRouteChannelConfig[] | cdktn.IResolvable;
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteConditionGroups[] | cdktn.IResolvable;
    /**
    * Whether this alert route is enabled or not
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#enabled AlertRoute#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#escalation_config AlertRoute#escalation_config}
    */
    readonly escalationConfig: AlertRouteEscalationConfig;
    /**
    * The expressions to be prepared for use by steps and conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#expressions AlertRoute#expressions}
    */
    readonly expressions: AlertRouteExpressions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#incident_config AlertRoute#incident_config}
    */
    readonly incidentConfig: AlertRouteIncidentConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#incident_template AlertRoute#incident_template}
    */
    readonly incidentTemplate: AlertRouteIncidentTemplate;
    /**
    * Whether this alert route is private. Private alert routes will only create private incidents from alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#is_private AlertRoute#is_private}
    */
    readonly isPrivate: boolean | cdktn.IResolvable;
    /**
    * The name of this alert route config, for the user's reference
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#name AlertRoute#name}
    */
    readonly name: string;
}
export interface AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare class AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteAlertSourcesConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare class AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    internalValue?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteAlertSourcesConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteAlertSourcesConditionGroupsConditionsToTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditions | cdktn.IResolvable): any;
export declare function alertRouteAlertSourcesConditionGroupsConditionsToHclTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditions | cdktn.IResolvable): any;
export declare class AlertRouteAlertSourcesConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteAlertSourcesConditionGroupsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSourcesConditionGroupsConditions | cdktn.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings[] | cdktn.IResolvable): void;
    get paramBindingsInput(): cdktn.IResolvable | AlertRouteAlertSourcesConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteAlertSourcesConditionGroupsConditionsList extends cdktn.ComplexList {
    internalValue?: AlertRouteAlertSourcesConditionGroupsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteAlertSourcesConditionGroupsConditionsOutputReference;
}
export interface AlertRouteAlertSourcesConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteAlertSourcesConditionGroupsConditions[] | cdktn.IResolvable;
}
export declare function alertRouteAlertSourcesConditionGroupsToTerraform(struct?: AlertRouteAlertSourcesConditionGroups | cdktn.IResolvable): any;
export declare function alertRouteAlertSourcesConditionGroupsToHclTerraform(struct?: AlertRouteAlertSourcesConditionGroups | cdktn.IResolvable): any;
export declare class AlertRouteAlertSourcesConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteAlertSourcesConditionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSourcesConditionGroups | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteAlertSourcesConditionGroupsConditionsList;
    putConditions(value: AlertRouteAlertSourcesConditionGroupsConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | AlertRouteAlertSourcesConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteAlertSourcesConditionGroupsList extends cdktn.ComplexList {
    internalValue?: AlertRouteAlertSourcesConditionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteAlertSourcesConditionGroupsOutputReference;
}
export interface AlertRouteAlertSources {
    /**
    * The alert source ID that will match for the route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#alert_source_id AlertRoute#alert_source_id}
    */
    readonly alertSourceId: string;
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteAlertSourcesConditionGroups[] | cdktn.IResolvable;
}
export declare function alertRouteAlertSourcesToTerraform(struct?: AlertRouteAlertSources | cdktn.IResolvable): any;
export declare function alertRouteAlertSourcesToHclTerraform(struct?: AlertRouteAlertSources | cdktn.IResolvable): any;
export declare class AlertRouteAlertSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteAlertSources | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSources | cdktn.IResolvable | undefined);
    private _alertSourceId?;
    get alertSourceId(): string;
    set alertSourceId(value: string);
    get alertSourceIdInput(): string | undefined;
    private _conditionGroups;
    get conditionGroups(): AlertRouteAlertSourcesConditionGroupsList;
    putConditionGroups(value: AlertRouteAlertSourcesConditionGroups[] | cdktn.IResolvable): void;
    get conditionGroupsInput(): cdktn.IResolvable | AlertRouteAlertSourcesConditionGroups[] | undefined;
}
export declare class AlertRouteAlertSourcesList extends cdktn.ComplexList {
    internalValue?: AlertRouteAlertSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteAlertSourcesOutputReference;
}
export interface AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteChannelConfigConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteChannelConfigConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    internalValue?: AlertRouteChannelConfigConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteChannelConfigConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteChannelConfigConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteChannelConfigConditionGroupsConditionsToTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditions | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigConditionGroupsConditionsToHclTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditions | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigConditionGroupsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigConditionGroupsConditions | cdktn.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindings[] | cdktn.IResolvable): void;
    get paramBindingsInput(): cdktn.IResolvable | AlertRouteChannelConfigConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteChannelConfigConditionGroupsConditionsList extends cdktn.ComplexList {
    internalValue?: AlertRouteChannelConfigConditionGroupsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigConditionGroupsConditionsOutputReference;
}
export interface AlertRouteChannelConfigConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteChannelConfigConditionGroupsConditions[] | cdktn.IResolvable;
}
export declare function alertRouteChannelConfigConditionGroupsToTerraform(struct?: AlertRouteChannelConfigConditionGroups | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigConditionGroupsToHclTerraform(struct?: AlertRouteChannelConfigConditionGroups | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigConditionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigConditionGroups | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteChannelConfigConditionGroupsConditionsList;
    putConditions(value: AlertRouteChannelConfigConditionGroupsConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | AlertRouteChannelConfigConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteChannelConfigConditionGroupsList extends cdktn.ComplexList {
    internalValue?: AlertRouteChannelConfigConditionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigConditionGroupsOutputReference;
}
export interface AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigMsTeamsTargetsBindingArrayValueToTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigMsTeamsTargetsBindingArrayValueToHclTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigMsTeamsTargetsBindingArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteChannelConfigMsTeamsTargetsBindingArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigMsTeamsTargetsBindingArrayValueOutputReference;
}
export interface AlertRouteChannelConfigMsTeamsTargetsBindingValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigMsTeamsTargetsBindingValueToTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBindingValue | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigMsTeamsTargetsBindingValueToHclTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBindingValue | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigMsTeamsTargetsBindingValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigMsTeamsTargetsBindingValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigMsTeamsTargetsBindingValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteChannelConfigMsTeamsTargetsBinding {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteChannelConfigMsTeamsTargetsBindingValue;
}
export declare function alertRouteChannelConfigMsTeamsTargetsBindingToTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBinding | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigMsTeamsTargetsBindingToHclTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBinding | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigMsTeamsTargetsBindingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigMsTeamsTargetsBinding | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigMsTeamsTargetsBinding | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteChannelConfigMsTeamsTargetsBindingArrayValueList;
    putArrayValue(value: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteChannelConfigMsTeamsTargetsBindingValueOutputReference;
    putValue(value: AlertRouteChannelConfigMsTeamsTargetsBindingValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteChannelConfigMsTeamsTargetsBindingValue | undefined;
}
export interface AlertRouteChannelConfigMsTeamsTargets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#binding AlertRoute#binding}
    */
    readonly binding: AlertRouteChannelConfigMsTeamsTargetsBinding;
    /**
    * The visibility of the channel
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#channel_visibility AlertRoute#channel_visibility}
    */
    readonly channelVisibility: string;
}
export declare function alertRouteChannelConfigMsTeamsTargetsToTerraform(struct?: AlertRouteChannelConfigMsTeamsTargets | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigMsTeamsTargetsToHclTerraform(struct?: AlertRouteChannelConfigMsTeamsTargets | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigMsTeamsTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigMsTeamsTargets | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigMsTeamsTargets | cdktn.IResolvable | undefined);
    private _binding;
    get binding(): AlertRouteChannelConfigMsTeamsTargetsBindingOutputReference;
    putBinding(value: AlertRouteChannelConfigMsTeamsTargetsBinding): void;
    get bindingInput(): cdktn.IResolvable | AlertRouteChannelConfigMsTeamsTargetsBinding | undefined;
    private _channelVisibility?;
    get channelVisibility(): string;
    set channelVisibility(value: string);
    get channelVisibilityInput(): string | undefined;
}
export interface AlertRouteChannelConfigSlackTargetsBindingArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigSlackTargetsBindingArrayValueToTerraform(struct?: AlertRouteChannelConfigSlackTargetsBindingArrayValue | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigSlackTargetsBindingArrayValueToHclTerraform(struct?: AlertRouteChannelConfigSlackTargetsBindingArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigSlackTargetsBindingArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigSlackTargetsBindingArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigSlackTargetsBindingArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteChannelConfigSlackTargetsBindingArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteChannelConfigSlackTargetsBindingArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigSlackTargetsBindingArrayValueOutputReference;
}
export interface AlertRouteChannelConfigSlackTargetsBindingValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigSlackTargetsBindingValueToTerraform(struct?: AlertRouteChannelConfigSlackTargetsBindingValue | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigSlackTargetsBindingValueToHclTerraform(struct?: AlertRouteChannelConfigSlackTargetsBindingValue | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigSlackTargetsBindingValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigSlackTargetsBindingValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigSlackTargetsBindingValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteChannelConfigSlackTargetsBinding {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteChannelConfigSlackTargetsBindingArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteChannelConfigSlackTargetsBindingValue;
}
export declare function alertRouteChannelConfigSlackTargetsBindingToTerraform(struct?: AlertRouteChannelConfigSlackTargetsBinding | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigSlackTargetsBindingToHclTerraform(struct?: AlertRouteChannelConfigSlackTargetsBinding | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigSlackTargetsBindingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigSlackTargetsBinding | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigSlackTargetsBinding | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteChannelConfigSlackTargetsBindingArrayValueList;
    putArrayValue(value: AlertRouteChannelConfigSlackTargetsBindingArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteChannelConfigSlackTargetsBindingArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteChannelConfigSlackTargetsBindingValueOutputReference;
    putValue(value: AlertRouteChannelConfigSlackTargetsBindingValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteChannelConfigSlackTargetsBindingValue | undefined;
}
export interface AlertRouteChannelConfigSlackTargets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#binding AlertRoute#binding}
    */
    readonly binding: AlertRouteChannelConfigSlackTargetsBinding;
    /**
    * The visibility of the channel
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#channel_visibility AlertRoute#channel_visibility}
    */
    readonly channelVisibility: string;
}
export declare function alertRouteChannelConfigSlackTargetsToTerraform(struct?: AlertRouteChannelConfigSlackTargets | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigSlackTargetsToHclTerraform(struct?: AlertRouteChannelConfigSlackTargets | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigSlackTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigSlackTargets | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigSlackTargets | cdktn.IResolvable | undefined);
    private _binding;
    get binding(): AlertRouteChannelConfigSlackTargetsBindingOutputReference;
    putBinding(value: AlertRouteChannelConfigSlackTargetsBinding): void;
    get bindingInput(): cdktn.IResolvable | AlertRouteChannelConfigSlackTargetsBinding | undefined;
    private _channelVisibility?;
    get channelVisibility(): string;
    set channelVisibility(value: string);
    get channelVisibilityInput(): string | undefined;
}
export interface AlertRouteChannelConfig {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteChannelConfigConditionGroups[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#ms_teams_targets AlertRoute#ms_teams_targets}
    */
    readonly msTeamsTargets?: AlertRouteChannelConfigMsTeamsTargets;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#slack_targets AlertRoute#slack_targets}
    */
    readonly slackTargets?: AlertRouteChannelConfigSlackTargets;
}
export declare function alertRouteChannelConfigToTerraform(struct?: AlertRouteChannelConfig | cdktn.IResolvable): any;
export declare function alertRouteChannelConfigToHclTerraform(struct?: AlertRouteChannelConfig | cdktn.IResolvable): any;
export declare class AlertRouteChannelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfig | cdktn.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): AlertRouteChannelConfigConditionGroupsList;
    putConditionGroups(value: AlertRouteChannelConfigConditionGroups[] | cdktn.IResolvable): void;
    get conditionGroupsInput(): cdktn.IResolvable | AlertRouteChannelConfigConditionGroups[] | undefined;
    private _msTeamsTargets;
    get msTeamsTargets(): AlertRouteChannelConfigMsTeamsTargetsOutputReference;
    putMsTeamsTargets(value: AlertRouteChannelConfigMsTeamsTargets): void;
    resetMsTeamsTargets(): void;
    get msTeamsTargetsInput(): cdktn.IResolvable | AlertRouteChannelConfigMsTeamsTargets | undefined;
    private _slackTargets;
    get slackTargets(): AlertRouteChannelConfigSlackTargetsOutputReference;
    putSlackTargets(value: AlertRouteChannelConfigSlackTargets): void;
    resetSlackTargets(): void;
    get slackTargetsInput(): cdktn.IResolvable | AlertRouteChannelConfigSlackTargets | undefined;
}
export declare class AlertRouteChannelConfigList extends cdktn.ComplexList {
    internalValue?: AlertRouteChannelConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigOutputReference;
}
export interface AlertRouteConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare function alertRouteConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare function alertRouteConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare class AlertRouteConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare function alertRouteConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare class AlertRouteConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    internalValue?: AlertRouteConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteConditionGroupsConditionsToTerraform(struct?: AlertRouteConditionGroupsConditions | cdktn.IResolvable): any;
export declare function alertRouteConditionGroupsConditionsToHclTerraform(struct?: AlertRouteConditionGroupsConditions | cdktn.IResolvable): any;
export declare class AlertRouteConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteConditionGroupsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteConditionGroupsConditions | cdktn.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteConditionGroupsConditionsParamBindings[] | cdktn.IResolvable): void;
    get paramBindingsInput(): cdktn.IResolvable | AlertRouteConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteConditionGroupsConditionsList extends cdktn.ComplexList {
    internalValue?: AlertRouteConditionGroupsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteConditionGroupsConditionsOutputReference;
}
export interface AlertRouteConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteConditionGroupsConditions[] | cdktn.IResolvable;
}
export declare function alertRouteConditionGroupsToTerraform(struct?: AlertRouteConditionGroups | cdktn.IResolvable): any;
export declare function alertRouteConditionGroupsToHclTerraform(struct?: AlertRouteConditionGroups | cdktn.IResolvable): any;
export declare class AlertRouteConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteConditionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteConditionGroups | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteConditionGroupsConditionsList;
    putConditions(value: AlertRouteConditionGroupsConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | AlertRouteConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteConditionGroupsList extends cdktn.ComplexList {
    internalValue?: AlertRouteConditionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteConditionGroupsOutputReference;
}
export interface AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue | cdktn.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueOutputReference;
}
export interface AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsValueToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue | cdktn.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsValueToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue | cdktn.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsEscalationPathsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteEscalationConfigEscalationTargetsEscalationPaths {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue;
}
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPaths | cdktn.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPaths | cdktn.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsEscalationPathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsEscalationPaths | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsEscalationPaths | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueList;
    putArrayValue(value: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteEscalationConfigEscalationTargetsEscalationPathsValueOutputReference;
    putValue(value: AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue | undefined;
}
export interface AlertRouteEscalationConfigEscalationTargetsUsersArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteEscalationConfigEscalationTargetsUsersArrayValueToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue | cdktn.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsUsersArrayValueToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsUsersArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsUsersArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteEscalationConfigEscalationTargetsUsersArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteEscalationConfigEscalationTargetsUsersArrayValueOutputReference;
}
export interface AlertRouteEscalationConfigEscalationTargetsUsersValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteEscalationConfigEscalationTargetsUsersValueToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsersValue | cdktn.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsUsersValueToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsersValue | cdktn.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsUsersValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsUsersValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsUsersValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteEscalationConfigEscalationTargetsUsers {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteEscalationConfigEscalationTargetsUsersValue;
}
export declare function alertRouteEscalationConfigEscalationTargetsUsersToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsers | cdktn.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsUsersToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsers | cdktn.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsUsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsUsers | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsUsers | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteEscalationConfigEscalationTargetsUsersArrayValueList;
    putArrayValue(value: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteEscalationConfigEscalationTargetsUsersArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteEscalationConfigEscalationTargetsUsersValueOutputReference;
    putValue(value: AlertRouteEscalationConfigEscalationTargetsUsersValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteEscalationConfigEscalationTargetsUsersValue | undefined;
}
export interface AlertRouteEscalationConfigEscalationTargets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#escalation_paths AlertRoute#escalation_paths}
    */
    readonly escalationPaths?: AlertRouteEscalationConfigEscalationTargetsEscalationPaths;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#users AlertRoute#users}
    */
    readonly users?: AlertRouteEscalationConfigEscalationTargetsUsers;
}
export declare function alertRouteEscalationConfigEscalationTargetsToTerraform(struct?: AlertRouteEscalationConfigEscalationTargets | cdktn.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargets | cdktn.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteEscalationConfigEscalationTargets | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargets | cdktn.IResolvable | undefined);
    private _escalationPaths;
    get escalationPaths(): AlertRouteEscalationConfigEscalationTargetsEscalationPathsOutputReference;
    putEscalationPaths(value: AlertRouteEscalationConfigEscalationTargetsEscalationPaths): void;
    resetEscalationPaths(): void;
    get escalationPathsInput(): cdktn.IResolvable | AlertRouteEscalationConfigEscalationTargetsEscalationPaths | undefined;
    private _users;
    get users(): AlertRouteEscalationConfigEscalationTargetsUsersOutputReference;
    putUsers(value: AlertRouteEscalationConfigEscalationTargetsUsers): void;
    resetUsers(): void;
    get usersInput(): cdktn.IResolvable | AlertRouteEscalationConfigEscalationTargetsUsers | undefined;
}
export declare class AlertRouteEscalationConfigEscalationTargetsList extends cdktn.ComplexList {
    internalValue?: AlertRouteEscalationConfigEscalationTargets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteEscalationConfigEscalationTargetsOutputReference;
}
export interface AlertRouteEscalationConfig {
    /**
    * Should we auto cancel escalations when all alerts are resolved?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#auto_cancel_escalations AlertRoute#auto_cancel_escalations}
    */
    readonly autoCancelEscalations: boolean | cdktn.IResolvable;
    /**
    * Targets for escalation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#escalation_targets AlertRoute#escalation_targets}
    */
    readonly escalationTargets: AlertRouteEscalationConfigEscalationTargets[] | cdktn.IResolvable;
}
export declare function alertRouteEscalationConfigToTerraform(struct?: AlertRouteEscalationConfig | cdktn.IResolvable): any;
export declare function alertRouteEscalationConfigToHclTerraform(struct?: AlertRouteEscalationConfig | cdktn.IResolvable): any;
export declare class AlertRouteEscalationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteEscalationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfig | cdktn.IResolvable | undefined);
    private _autoCancelEscalations?;
    get autoCancelEscalations(): boolean | cdktn.IResolvable;
    set autoCancelEscalations(value: boolean | cdktn.IResolvable);
    get autoCancelEscalationsInput(): boolean | cdktn.IResolvable | undefined;
    private _escalationTargets;
    get escalationTargets(): AlertRouteEscalationConfigEscalationTargetsList;
    putEscalationTargets(value: AlertRouteEscalationConfigEscalationTargets[] | cdktn.IResolvable): void;
    get escalationTargetsInput(): cdktn.IResolvable | AlertRouteEscalationConfigEscalationTargets[] | undefined;
}
export interface AlertRouteExpressionsElseBranchResultArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsElseBranchResultArrayValueToTerraform(struct?: AlertRouteExpressionsElseBranchResultArrayValue | cdktn.IResolvable): any;
export declare function alertRouteExpressionsElseBranchResultArrayValueToHclTerraform(struct?: AlertRouteExpressionsElseBranchResultArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsElseBranchResultArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsElseBranchResultArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsElseBranchResultArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteExpressionsElseBranchResultArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsElseBranchResultArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsElseBranchResultArrayValueOutputReference;
}
export interface AlertRouteExpressionsElseBranchResultValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsElseBranchResultValueToTerraform(struct?: AlertRouteExpressionsElseBranchResultValue | cdktn.IResolvable): any;
export declare function alertRouteExpressionsElseBranchResultValueToHclTerraform(struct?: AlertRouteExpressionsElseBranchResultValue | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsElseBranchResultValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsElseBranchResultValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsElseBranchResultValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteExpressionsElseBranchResult {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteExpressionsElseBranchResultArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteExpressionsElseBranchResultValue;
}
export declare function alertRouteExpressionsElseBranchResultToTerraform(struct?: AlertRouteExpressionsElseBranchResult | cdktn.IResolvable): any;
export declare function alertRouteExpressionsElseBranchResultToHclTerraform(struct?: AlertRouteExpressionsElseBranchResult | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsElseBranchResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsElseBranchResult | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsElseBranchResult | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteExpressionsElseBranchResultArrayValueList;
    putArrayValue(value: AlertRouteExpressionsElseBranchResultArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteExpressionsElseBranchResultArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteExpressionsElseBranchResultValueOutputReference;
    putValue(value: AlertRouteExpressionsElseBranchResultValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteExpressionsElseBranchResultValue | undefined;
}
export interface AlertRouteExpressionsElseBranch {
    /**
    * The result assumed if the else branch is reached
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#result AlertRoute#result}
    */
    readonly result: AlertRouteExpressionsElseBranchResult;
}
export declare function alertRouteExpressionsElseBranchToTerraform(struct?: AlertRouteExpressionsElseBranch | cdktn.IResolvable): any;
export declare function alertRouteExpressionsElseBranchToHclTerraform(struct?: AlertRouteExpressionsElseBranch | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsElseBranchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsElseBranch | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsElseBranch | cdktn.IResolvable | undefined);
    private _result;
    get result(): AlertRouteExpressionsElseBranchResultOutputReference;
    putResult(value: AlertRouteExpressionsElseBranchResult): void;
    get resultInput(): cdktn.IResolvable | AlertRouteExpressionsElseBranchResult | undefined;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktn.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktn.IResolvable): void;
    get paramBindingsInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktn.IResolvable;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsList;
    putConditions(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesResultArrayValueToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesResultArrayValueToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesResultArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesResultArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesResultArrayValueOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesResultValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesResultValueToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResultValue | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesResultValueToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResultValue | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesResultValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesResultValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesResultValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesResult {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteExpressionsOperationsBranchesBranchesResultValue;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesResultToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResult | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesResultToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResult | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesResult | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesResult | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteExpressionsOperationsBranchesBranchesResultArrayValueList;
    putArrayValue(value: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteExpressionsOperationsBranchesBranchesResultValueOutputReference;
    putValue(value: AlertRouteExpressionsOperationsBranchesBranchesResultValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesResultValue | undefined;
}
export interface AlertRouteExpressionsOperationsBranchesBranches {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups[] | cdktn.IResolvable;
    /**
    * The result assumed if the condition groups are satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#result AlertRoute#result}
    */
    readonly result: AlertRouteExpressionsOperationsBranchesBranchesResult;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranches | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranches | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranches | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranches | cdktn.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsList;
    putConditionGroups(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups[] | cdktn.IResolvable): void;
    get conditionGroupsInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesConditionGroups[] | undefined;
    private _result;
    get result(): AlertRouteExpressionsOperationsBranchesBranchesResultOutputReference;
    putResult(value: AlertRouteExpressionsOperationsBranchesBranchesResult): void;
    get resultInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesResult | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperationsBranchesBranches[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesReturns {
    /**
    * Whether the return value should be single or multi-value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array AlertRoute#array}
    */
    readonly array: boolean | cdktn.IResolvable;
    /**
    * Expected return type of this expression (what to try casting the result to)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#type AlertRoute#type}
    */
    readonly type: string;
}
export declare function alertRouteExpressionsOperationsBranchesReturnsToTerraform(struct?: AlertRouteExpressionsOperationsBranchesReturns | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesReturnsToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesReturns | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesReturnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsBranchesReturns | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesReturns | cdktn.IResolvable | undefined);
    private _array?;
    get array(): boolean | cdktn.IResolvable;
    set array(value: boolean | cdktn.IResolvable);
    get arrayInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsBranches {
    /**
    * The branches to apply for this operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#branches AlertRoute#branches}
    */
    readonly branches: AlertRouteExpressionsOperationsBranchesBranches[] | cdktn.IResolvable;
    /**
    * The return type of an operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#returns AlertRoute#returns}
    */
    readonly returns: AlertRouteExpressionsOperationsBranchesReturns;
}
export declare function alertRouteExpressionsOperationsBranchesToTerraform(struct?: AlertRouteExpressionsOperationsBranches | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesToHclTerraform(struct?: AlertRouteExpressionsOperationsBranches | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsBranches | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranches | cdktn.IResolvable | undefined);
    private _branches;
    get branches(): AlertRouteExpressionsOperationsBranchesBranchesList;
    putBranches(value: AlertRouteExpressionsOperationsBranchesBranches[] | cdktn.IResolvable): void;
    get branchesInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranchesBranches[] | undefined;
    private _returns;
    get returns(): AlertRouteExpressionsOperationsBranchesReturnsOutputReference;
    putReturns(value: AlertRouteExpressionsOperationsBranchesReturns): void;
    get returnsInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranchesReturns | undefined;
}
export interface AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteExpressionsOperationsFilterConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsToTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditions | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsToHclTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditions | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsFilterConditionGroupsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditions | cdktn.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktn.IResolvable): void;
    get paramBindingsInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperationsFilterConditionGroupsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsOutputReference;
}
export interface AlertRouteExpressionsOperationsFilterConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteExpressionsOperationsFilterConditionGroupsConditions[] | cdktn.IResolvable;
}
export declare function alertRouteExpressionsOperationsFilterConditionGroupsToTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroups | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterConditionGroupsToHclTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroups | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsFilterConditionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilterConditionGroups | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsList;
    putConditions(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsFilterConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperationsFilterConditionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsFilterConditionGroupsOutputReference;
}
export interface AlertRouteExpressionsOperationsFilter {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteExpressionsOperationsFilterConditionGroups[] | cdktn.IResolvable;
}
export declare function alertRouteExpressionsOperationsFilterToTerraform(struct?: AlertRouteExpressionsOperationsFilter | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterToHclTerraform(struct?: AlertRouteExpressionsOperationsFilter | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilter | cdktn.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): AlertRouteExpressionsOperationsFilterConditionGroupsList;
    putConditionGroups(value: AlertRouteExpressionsOperationsFilterConditionGroups[] | cdktn.IResolvable): void;
    get conditionGroupsInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsFilterConditionGroups[] | undefined;
}
export interface AlertRouteExpressionsOperationsNavigate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference: string;
}
export declare function alertRouteExpressionsOperationsNavigateToTerraform(struct?: AlertRouteExpressionsOperationsNavigate | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsNavigateToHclTerraform(struct?: AlertRouteExpressionsOperationsNavigate | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsNavigateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsNavigate | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsNavigate | cdktn.IResolvable | undefined);
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsParseReturns {
    /**
    * Whether the return value should be single or multi-value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array AlertRoute#array}
    */
    readonly array: boolean | cdktn.IResolvable;
    /**
    * Expected return type of this expression (what to try casting the result to)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#type AlertRoute#type}
    */
    readonly type: string;
}
export declare function alertRouteExpressionsOperationsParseReturnsToTerraform(struct?: AlertRouteExpressionsOperationsParseReturns | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsParseReturnsToHclTerraform(struct?: AlertRouteExpressionsOperationsParseReturns | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsParseReturnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsParseReturns | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsParseReturns | cdktn.IResolvable | undefined);
    private _array?;
    get array(): boolean | cdktn.IResolvable;
    set array(value: boolean | cdktn.IResolvable);
    get arrayInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsParse {
    /**
    * The return type of an operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#returns AlertRoute#returns}
    */
    readonly returns: AlertRouteExpressionsOperationsParseReturns;
    /**
    * The ES5 Javascript expression to execute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#source AlertRoute#source}
    */
    readonly source: string;
}
export declare function alertRouteExpressionsOperationsParseToTerraform(struct?: AlertRouteExpressionsOperationsParse | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsParseToHclTerraform(struct?: AlertRouteExpressionsOperationsParse | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsParseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsParse | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsParse | cdktn.IResolvable | undefined);
    private _returns;
    get returns(): AlertRouteExpressionsOperationsParseReturnsOutputReference;
    putReturns(value: AlertRouteExpressionsOperationsParseReturns): void;
    get returnsInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsParseReturns | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export interface AlertRouteExpressionsOperations {
    /**
    * An operation type that allows for a value to be set conditionally by a series of logical branches
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#branches AlertRoute#branches}
    */
    readonly branches?: AlertRouteExpressionsOperationsBranches;
    /**
    * An operation type that allows values to be filtered out by conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#filter AlertRoute#filter}
    */
    readonly filter?: AlertRouteExpressionsOperationsFilter;
    /**
    * An operation type that allows attributes of a type to be accessed by reference
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#navigate AlertRoute#navigate}
    */
    readonly navigate?: AlertRouteExpressionsOperationsNavigate;
    /**
    * Indicates which operation type to execute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation_type AlertRoute#operation_type}
    */
    readonly operationType: string;
    /**
    * An operation type that allows a value to parsed from within a JSON object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#parse AlertRoute#parse}
    */
    readonly parse?: AlertRouteExpressionsOperationsParse;
}
export declare function alertRouteExpressionsOperationsToTerraform(struct?: AlertRouteExpressionsOperations | cdktn.IResolvable): any;
export declare function alertRouteExpressionsOperationsToHclTerraform(struct?: AlertRouteExpressionsOperations | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperations | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperations | cdktn.IResolvable | undefined);
    private _branches;
    get branches(): AlertRouteExpressionsOperationsBranchesOutputReference;
    putBranches(value: AlertRouteExpressionsOperationsBranches): void;
    resetBranches(): void;
    get branchesInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsBranches | undefined;
    private _filter;
    get filter(): AlertRouteExpressionsOperationsFilterOutputReference;
    putFilter(value: AlertRouteExpressionsOperationsFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsFilter | undefined;
    private _navigate;
    get navigate(): AlertRouteExpressionsOperationsNavigateOutputReference;
    putNavigate(value: AlertRouteExpressionsOperationsNavigate): void;
    resetNavigate(): void;
    get navigateInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsNavigate | undefined;
    private _operationType?;
    get operationType(): string;
    set operationType(value: string);
    get operationTypeInput(): string | undefined;
    private _parse;
    get parse(): AlertRouteExpressionsOperationsParseOutputReference;
    putParse(value: AlertRouteExpressionsOperationsParse): void;
    resetParse(): void;
    get parseInput(): cdktn.IResolvable | AlertRouteExpressionsOperationsParse | undefined;
}
export declare class AlertRouteExpressionsOperationsList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressionsOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsOutputReference;
}
export interface AlertRouteExpressions {
    /**
    * The else branch to resort to if all operations fail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#else_branch AlertRoute#else_branch}
    */
    readonly elseBranch?: AlertRouteExpressionsElseBranch;
    /**
    * The human readable label of the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#label AlertRoute#label}
    */
    readonly label: string;
    /**
    * The operations to execute in sequence for this expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operations AlertRoute#operations}
    */
    readonly operations: AlertRouteExpressionsOperations[] | cdktn.IResolvable;
    /**
    * A short ID that can be used to reference the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference: string;
    /**
    * The root reference for this expression (i.e. where the expression starts)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#root_reference AlertRoute#root_reference}
    */
    readonly rootReference: string;
}
export declare function alertRouteExpressionsToTerraform(struct?: AlertRouteExpressions | cdktn.IResolvable): any;
export declare function alertRouteExpressionsToHclTerraform(struct?: AlertRouteExpressions | cdktn.IResolvable): any;
export declare class AlertRouteExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressions | cdktn.IResolvable | undefined);
    private _elseBranch;
    get elseBranch(): AlertRouteExpressionsElseBranchOutputReference;
    putElseBranch(value: AlertRouteExpressionsElseBranch): void;
    resetElseBranch(): void;
    get elseBranchInput(): cdktn.IResolvable | AlertRouteExpressionsElseBranch | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _operations;
    get operations(): AlertRouteExpressionsOperationsList;
    putOperations(value: AlertRouteExpressionsOperations[] | cdktn.IResolvable): void;
    get operationsInput(): cdktn.IResolvable | AlertRouteExpressionsOperations[] | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
    private _rootReference?;
    get rootReference(): string;
    set rootReference(value: string);
    get rootReferenceInput(): string | undefined;
}
export declare class AlertRouteExpressionsList extends cdktn.ComplexList {
    internalValue?: AlertRouteExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOutputReference;
}
export interface AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentConfigConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare class AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteIncidentConfigConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteIncidentConfigConditionGroupsConditionsToTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditions | cdktn.IResolvable): any;
export declare function alertRouteIncidentConfigConditionGroupsConditionsToHclTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditions | cdktn.IResolvable): any;
export declare class AlertRouteIncidentConfigConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentConfigConditionGroupsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigConditionGroupsConditions | cdktn.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings[] | cdktn.IResolvable): void;
    get paramBindingsInput(): cdktn.IResolvable | AlertRouteIncidentConfigConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteIncidentConfigConditionGroupsConditionsList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentConfigConditionGroupsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentConfigConditionGroupsConditionsOutputReference;
}
export interface AlertRouteIncidentConfigConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteIncidentConfigConditionGroupsConditions[] | cdktn.IResolvable;
}
export declare function alertRouteIncidentConfigConditionGroupsToTerraform(struct?: AlertRouteIncidentConfigConditionGroups | cdktn.IResolvable): any;
export declare function alertRouteIncidentConfigConditionGroupsToHclTerraform(struct?: AlertRouteIncidentConfigConditionGroups | cdktn.IResolvable): any;
export declare class AlertRouteIncidentConfigConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentConfigConditionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigConditionGroups | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteIncidentConfigConditionGroupsConditionsList;
    putConditions(value: AlertRouteIncidentConfigConditionGroupsConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | AlertRouteIncidentConfigConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteIncidentConfigConditionGroupsList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentConfigConditionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentConfigConditionGroupsOutputReference;
}
export interface AlertRouteIncidentConfigGroupingKeys {
    /**
    * The alert attribute ID to use as a grouping key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference: string;
}
export declare function alertRouteIncidentConfigGroupingKeysToTerraform(struct?: AlertRouteIncidentConfigGroupingKeys | cdktn.IResolvable): any;
export declare function alertRouteIncidentConfigGroupingKeysToHclTerraform(struct?: AlertRouteIncidentConfigGroupingKeys | cdktn.IResolvable): any;
export declare class AlertRouteIncidentConfigGroupingKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentConfigGroupingKeys | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigGroupingKeys | cdktn.IResolvable | undefined);
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentConfigGroupingKeysList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentConfigGroupingKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentConfigGroupingKeysOutputReference;
}
export interface AlertRouteIncidentConfig {
    /**
    * Should triage incidents be declined when alerts are resolved?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#auto_decline_enabled AlertRoute#auto_decline_enabled}
    */
    readonly autoDeclineEnabled: boolean | cdktn.IResolvable;
    /**
    * Should grouped alerts automatically be related to active incidents without confirmation?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#auto_relate_grouped_alerts AlertRoute#auto_relate_grouped_alerts}
    */
    readonly autoRelateGroupedAlerts?: boolean | cdktn.IResolvable;
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteIncidentConfigConditionGroups[] | cdktn.IResolvable;
    /**
    * How long should the escalation defer time be?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#defer_time_seconds AlertRoute#defer_time_seconds}
    */
    readonly deferTimeSeconds: number;
    /**
    * Whether incident creation is enabled for this alert route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#enabled AlertRoute#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Which attributes should this alert route use to group alerts?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#grouping_keys AlertRoute#grouping_keys}
    */
    readonly groupingKeys: AlertRouteIncidentConfigGroupingKeys[] | cdktn.IResolvable;
    /**
    * How large should the grouping window be?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#grouping_window_seconds AlertRoute#grouping_window_seconds}
    */
    readonly groupingWindowSeconds: number;
}
export declare function alertRouteIncidentConfigToTerraform(struct?: AlertRouteIncidentConfig | cdktn.IResolvable): any;
export declare function alertRouteIncidentConfigToHclTerraform(struct?: AlertRouteIncidentConfig | cdktn.IResolvable): any;
export declare class AlertRouteIncidentConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfig | cdktn.IResolvable | undefined);
    private _autoDeclineEnabled?;
    get autoDeclineEnabled(): boolean | cdktn.IResolvable;
    set autoDeclineEnabled(value: boolean | cdktn.IResolvable);
    get autoDeclineEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _autoRelateGroupedAlerts?;
    get autoRelateGroupedAlerts(): boolean | cdktn.IResolvable;
    set autoRelateGroupedAlerts(value: boolean | cdktn.IResolvable);
    resetAutoRelateGroupedAlerts(): void;
    get autoRelateGroupedAlertsInput(): boolean | cdktn.IResolvable | undefined;
    private _conditionGroups;
    get conditionGroups(): AlertRouteIncidentConfigConditionGroupsList;
    putConditionGroups(value: AlertRouteIncidentConfigConditionGroups[] | cdktn.IResolvable): void;
    get conditionGroupsInput(): cdktn.IResolvable | AlertRouteIncidentConfigConditionGroups[] | undefined;
    private _deferTimeSeconds?;
    get deferTimeSeconds(): number;
    set deferTimeSeconds(value: number);
    get deferTimeSecondsInput(): number | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _groupingKeys;
    get groupingKeys(): AlertRouteIncidentConfigGroupingKeysList;
    putGroupingKeys(value: AlertRouteIncidentConfigGroupingKeys[] | cdktn.IResolvable): void;
    get groupingKeysInput(): cdktn.IResolvable | AlertRouteIncidentConfigGroupingKeys[] | undefined;
    private _groupingWindowSeconds?;
    get groupingWindowSeconds(): number;
    set groupingWindowSeconds(value: number);
    get groupingWindowSecondsInput(): number | undefined;
}
export interface AlertRouteIncidentTemplateCustomFieldsBindingArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateCustomFieldsBindingArrayValueToTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateCustomFieldsBindingArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateCustomFieldsBindingArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateCustomFieldsBindingArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateCustomFieldsBindingArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateCustomFieldsBindingArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateCustomFieldsBindingValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateCustomFieldsBindingValueToTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBindingValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateCustomFieldsBindingValueToHclTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBindingValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateCustomFieldsBindingValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateCustomFieldsBindingValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateCustomFieldsBindingValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateCustomFieldsBinding {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateCustomFieldsBindingValue;
}
export declare function alertRouteIncidentTemplateCustomFieldsBindingToTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBinding | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateCustomFieldsBindingToHclTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBinding | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateCustomFieldsBindingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateCustomFieldsBinding | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateCustomFieldsBinding | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateCustomFieldsBindingArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateCustomFieldsBindingArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateCustomFieldsBindingValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateCustomFieldsBindingValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateCustomFieldsBindingValue | undefined;
}
export interface AlertRouteIncidentTemplateCustomFields {
    /**
    * Binding for the custom field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#binding AlertRoute#binding}
    */
    readonly binding: AlertRouteIncidentTemplateCustomFieldsBinding;
    /**
    * ID of the custom field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#custom_field_id AlertRoute#custom_field_id}
    */
    readonly customFieldId: string;
    /**
    * The strategy to use when multiple alerts match this route. Possible values are: `first-wins`, `last-wins`, `append`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#merge_strategy AlertRoute#merge_strategy}
    */
    readonly mergeStrategy: string;
}
export declare function alertRouteIncidentTemplateCustomFieldsToTerraform(struct?: AlertRouteIncidentTemplateCustomFields | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateCustomFieldsToHclTerraform(struct?: AlertRouteIncidentTemplateCustomFields | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateCustomFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateCustomFields | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateCustomFields | cdktn.IResolvable | undefined);
    private _binding;
    get binding(): AlertRouteIncidentTemplateCustomFieldsBindingOutputReference;
    putBinding(value: AlertRouteIncidentTemplateCustomFieldsBinding): void;
    get bindingInput(): cdktn.IResolvable | AlertRouteIncidentTemplateCustomFieldsBinding | undefined;
    private _customFieldId?;
    get customFieldId(): string;
    set customFieldId(value: string);
    get customFieldIdInput(): string | undefined;
    private _mergeStrategy?;
    get mergeStrategy(): string;
    set mergeStrategy(value: string);
    get mergeStrategyInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateCustomFieldsList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentTemplateCustomFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateCustomFieldsOutputReference;
}
export interface AlertRouteIncidentTemplateIncidentModeArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateIncidentModeArrayValueToTerraform(struct?: AlertRouteIncidentTemplateIncidentModeArrayValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentModeArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentModeArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentModeArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateIncidentModeArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentModeArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateIncidentModeArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentTemplateIncidentModeArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateIncidentModeArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateIncidentModeValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateIncidentModeValueToTerraform(struct?: AlertRouteIncidentTemplateIncidentModeValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentModeValueToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentModeValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentModeValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateIncidentModeValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentModeValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateIncidentMode {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateIncidentModeArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateIncidentModeValue;
}
export declare function alertRouteIncidentTemplateIncidentModeToTerraform(struct?: AlertRouteIncidentTemplateIncidentMode | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentModeToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentMode | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateIncidentMode | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentMode | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateIncidentModeArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateIncidentModeArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateIncidentModeArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateIncidentModeValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateIncidentModeValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateIncidentModeValue | undefined;
}
export interface AlertRouteIncidentTemplateIncidentTypeArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateIncidentTypeArrayValueToTerraform(struct?: AlertRouteIncidentTemplateIncidentTypeArrayValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentTypeArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentTypeArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentTypeArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateIncidentTypeArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentTypeArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateIncidentTypeArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentTemplateIncidentTypeArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateIncidentTypeArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateIncidentTypeValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateIncidentTypeValueToTerraform(struct?: AlertRouteIncidentTemplateIncidentTypeValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentTypeValueToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentTypeValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentTypeValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateIncidentTypeValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentTypeValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateIncidentType {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateIncidentTypeArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateIncidentTypeValue;
}
export declare function alertRouteIncidentTemplateIncidentTypeToTerraform(struct?: AlertRouteIncidentTemplateIncidentType | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentTypeToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentType | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateIncidentType | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentType | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateIncidentTypeArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateIncidentTypeArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateIncidentTypeArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateIncidentTypeValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateIncidentTypeValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateIncidentTypeValue | undefined;
}
export interface AlertRouteIncidentTemplateNameArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateNameArrayValueToTerraform(struct?: AlertRouteIncidentTemplateNameArrayValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateNameArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateNameArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateNameArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateNameArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateNameArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateNameArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentTemplateNameArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateNameArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateNameValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateNameValueToTerraform(struct?: AlertRouteIncidentTemplateNameValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateNameValueToHclTerraform(struct?: AlertRouteIncidentTemplateNameValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateNameValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateNameValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateNameValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateName {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateNameArrayValue[] | cdktn.IResolvable;
    /**
    * Whether this attribute should be autogenerated using AI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#autogenerated AlertRoute#autogenerated}
    */
    readonly autogenerated?: boolean | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateNameValue;
}
export declare function alertRouteIncidentTemplateNameToTerraform(struct?: AlertRouteIncidentTemplateName | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateNameToHclTerraform(struct?: AlertRouteIncidentTemplateName | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateName | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateName | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateNameArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateNameArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateNameArrayValue[] | undefined;
    private _autogenerated?;
    get autogenerated(): boolean | cdktn.IResolvable;
    set autogenerated(value: boolean | cdktn.IResolvable);
    resetAutogenerated(): void;
    get autogeneratedInput(): boolean | cdktn.IResolvable | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateNameValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateNameValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateNameValue | undefined;
}
export interface AlertRouteIncidentTemplateSeverityBindingArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateSeverityBindingArrayValueToTerraform(struct?: AlertRouteIncidentTemplateSeverityBindingArrayValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateSeverityBindingArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateSeverityBindingArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateSeverityBindingArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateSeverityBindingArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSeverityBindingArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateSeverityBindingArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentTemplateSeverityBindingArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateSeverityBindingArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateSeverityBindingValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateSeverityBindingValueToTerraform(struct?: AlertRouteIncidentTemplateSeverityBindingValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateSeverityBindingValueToHclTerraform(struct?: AlertRouteIncidentTemplateSeverityBindingValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateSeverityBindingValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateSeverityBindingValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSeverityBindingValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateSeverityBinding {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateSeverityBindingArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateSeverityBindingValue;
}
export declare function alertRouteIncidentTemplateSeverityBindingToTerraform(struct?: AlertRouteIncidentTemplateSeverityBinding | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateSeverityBindingToHclTerraform(struct?: AlertRouteIncidentTemplateSeverityBinding | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateSeverityBindingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateSeverityBinding | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSeverityBinding | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateSeverityBindingArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateSeverityBindingArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateSeverityBindingArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateSeverityBindingValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateSeverityBindingValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateSeverityBindingValue | undefined;
}
export interface AlertRouteIncidentTemplateSeverity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#binding AlertRoute#binding}
    */
    readonly binding?: AlertRouteIncidentTemplateSeverityBinding;
    /**
    * Strategy for merging severity when multiple alerts create/update the same incident. Possible values are: `first-wins`, `max`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#merge_strategy AlertRoute#merge_strategy}
    */
    readonly mergeStrategy: string;
}
export declare function alertRouteIncidentTemplateSeverityToTerraform(struct?: AlertRouteIncidentTemplateSeverity | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateSeverityToHclTerraform(struct?: AlertRouteIncidentTemplateSeverity | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateSeverityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateSeverity | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSeverity | cdktn.IResolvable | undefined);
    private _binding;
    get binding(): AlertRouteIncidentTemplateSeverityBindingOutputReference;
    putBinding(value: AlertRouteIncidentTemplateSeverityBinding): void;
    resetBinding(): void;
    get bindingInput(): cdktn.IResolvable | AlertRouteIncidentTemplateSeverityBinding | undefined;
    private _mergeStrategy?;
    get mergeStrategy(): string;
    set mergeStrategy(value: string);
    get mergeStrategyInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateStartInTriageArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateStartInTriageArrayValueToTerraform(struct?: AlertRouteIncidentTemplateStartInTriageArrayValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateStartInTriageArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateStartInTriageArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateStartInTriageArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateStartInTriageArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateStartInTriageArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateStartInTriageArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentTemplateStartInTriageArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateStartInTriageArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateStartInTriageValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateStartInTriageValueToTerraform(struct?: AlertRouteIncidentTemplateStartInTriageValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateStartInTriageValueToHclTerraform(struct?: AlertRouteIncidentTemplateStartInTriageValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateStartInTriageValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateStartInTriageValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateStartInTriageValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateStartInTriage {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateStartInTriageArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateStartInTriageValue;
}
export declare function alertRouteIncidentTemplateStartInTriageToTerraform(struct?: AlertRouteIncidentTemplateStartInTriage | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateStartInTriageToHclTerraform(struct?: AlertRouteIncidentTemplateStartInTriage | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateStartInTriageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateStartInTriage | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateStartInTriage | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateStartInTriageArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateStartInTriageArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateStartInTriageArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateStartInTriageValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateStartInTriageValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateStartInTriageValue | undefined;
}
export interface AlertRouteIncidentTemplateSummaryArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateSummaryArrayValueToTerraform(struct?: AlertRouteIncidentTemplateSummaryArrayValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateSummaryArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateSummaryArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateSummaryArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateSummaryArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSummaryArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateSummaryArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentTemplateSummaryArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateSummaryArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateSummaryValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateSummaryValueToTerraform(struct?: AlertRouteIncidentTemplateSummaryValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateSummaryValueToHclTerraform(struct?: AlertRouteIncidentTemplateSummaryValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateSummaryValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateSummaryValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSummaryValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateSummary {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateSummaryArrayValue[] | cdktn.IResolvable;
    /**
    * Whether this attribute should be autogenerated using AI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#autogenerated AlertRoute#autogenerated}
    */
    readonly autogenerated?: boolean | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateSummaryValue;
}
export declare function alertRouteIncidentTemplateSummaryToTerraform(struct?: AlertRouteIncidentTemplateSummary | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateSummaryToHclTerraform(struct?: AlertRouteIncidentTemplateSummary | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateSummaryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateSummary | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSummary | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateSummaryArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateSummaryArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateSummaryArrayValue[] | undefined;
    private _autogenerated?;
    get autogenerated(): boolean | cdktn.IResolvable;
    set autogenerated(value: boolean | cdktn.IResolvable);
    resetAutogenerated(): void;
    get autogeneratedInput(): boolean | cdktn.IResolvable | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateSummaryValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateSummaryValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateSummaryValue | undefined;
}
export interface AlertRouteIncidentTemplateWorkspaceArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateWorkspaceArrayValueToTerraform(struct?: AlertRouteIncidentTemplateWorkspaceArrayValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateWorkspaceArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateWorkspaceArrayValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateWorkspaceArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateWorkspaceArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateWorkspaceArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateWorkspaceArrayValueList extends cdktn.ComplexList {
    internalValue?: AlertRouteIncidentTemplateWorkspaceArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateWorkspaceArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateWorkspaceValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateWorkspaceValueToTerraform(struct?: AlertRouteIncidentTemplateWorkspaceValue | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateWorkspaceValueToHclTerraform(struct?: AlertRouteIncidentTemplateWorkspaceValue | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateWorkspaceValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateWorkspaceValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateWorkspaceValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateWorkspace {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateWorkspaceArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateWorkspaceValue;
}
export declare function alertRouteIncidentTemplateWorkspaceToTerraform(struct?: AlertRouteIncidentTemplateWorkspace | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateWorkspaceToHclTerraform(struct?: AlertRouteIncidentTemplateWorkspace | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateWorkspace | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateWorkspaceArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateWorkspaceArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateWorkspaceArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateWorkspaceValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateWorkspaceValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertRouteIncidentTemplateWorkspaceValue | undefined;
}
export interface AlertRouteIncidentTemplate {
    /**
    * Custom fields configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#custom_fields AlertRoute#custom_fields}
    */
    readonly customFields?: AlertRouteIncidentTemplateCustomFields[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#incident_mode AlertRoute#incident_mode}
    */
    readonly incidentMode?: AlertRouteIncidentTemplateIncidentMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#incident_type AlertRoute#incident_type}
    */
    readonly incidentType?: AlertRouteIncidentTemplateIncidentType;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#name AlertRoute#name}
    */
    readonly name: AlertRouteIncidentTemplateName;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#severity AlertRoute#severity}
    */
    readonly severity?: AlertRouteIncidentTemplateSeverity;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#start_in_triage AlertRoute#start_in_triage}
    */
    readonly startInTriage?: AlertRouteIncidentTemplateStartInTriage;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#summary AlertRoute#summary}
    */
    readonly summary: AlertRouteIncidentTemplateSummary;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#workspace AlertRoute#workspace}
    */
    readonly workspace?: AlertRouteIncidentTemplateWorkspace;
}
export declare function alertRouteIncidentTemplateToTerraform(struct?: AlertRouteIncidentTemplate | cdktn.IResolvable): any;
export declare function alertRouteIncidentTemplateToHclTerraform(struct?: AlertRouteIncidentTemplate | cdktn.IResolvable): any;
export declare class AlertRouteIncidentTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplate | cdktn.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplate | cdktn.IResolvable | undefined);
    private _customFields;
    get customFields(): AlertRouteIncidentTemplateCustomFieldsList;
    putCustomFields(value: AlertRouteIncidentTemplateCustomFields[] | cdktn.IResolvable): void;
    resetCustomFields(): void;
    get customFieldsInput(): cdktn.IResolvable | AlertRouteIncidentTemplateCustomFields[] | undefined;
    private _incidentMode;
    get incidentMode(): AlertRouteIncidentTemplateIncidentModeOutputReference;
    putIncidentMode(value: AlertRouteIncidentTemplateIncidentMode): void;
    resetIncidentMode(): void;
    get incidentModeInput(): cdktn.IResolvable | AlertRouteIncidentTemplateIncidentMode | undefined;
    private _incidentType;
    get incidentType(): AlertRouteIncidentTemplateIncidentTypeOutputReference;
    putIncidentType(value: AlertRouteIncidentTemplateIncidentType): void;
    resetIncidentType(): void;
    get incidentTypeInput(): cdktn.IResolvable | AlertRouteIncidentTemplateIncidentType | undefined;
    private _name;
    get name(): AlertRouteIncidentTemplateNameOutputReference;
    putName(value: AlertRouteIncidentTemplateName): void;
    get nameInput(): cdktn.IResolvable | AlertRouteIncidentTemplateName | undefined;
    private _severity;
    get severity(): AlertRouteIncidentTemplateSeverityOutputReference;
    putSeverity(value: AlertRouteIncidentTemplateSeverity): void;
    resetSeverity(): void;
    get severityInput(): cdktn.IResolvable | AlertRouteIncidentTemplateSeverity | undefined;
    private _startInTriage;
    get startInTriage(): AlertRouteIncidentTemplateStartInTriageOutputReference;
    putStartInTriage(value: AlertRouteIncidentTemplateStartInTriage): void;
    resetStartInTriage(): void;
    get startInTriageInput(): cdktn.IResolvable | AlertRouteIncidentTemplateStartInTriage | undefined;
    private _summary;
    get summary(): AlertRouteIncidentTemplateSummaryOutputReference;
    putSummary(value: AlertRouteIncidentTemplateSummary): void;
    get summaryInput(): cdktn.IResolvable | AlertRouteIncidentTemplateSummary | undefined;
    private _workspace;
    get workspace(): AlertRouteIncidentTemplateWorkspaceOutputReference;
    putWorkspace(value: AlertRouteIncidentTemplateWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): cdktn.IResolvable | AlertRouteIncidentTemplateWorkspace | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route incident_alert_route}
*/
export declare class AlertRoute extends cdktn.TerraformResource {
    static readonly tfResourceType = "incident_alert_route";
    /**
    * Generates CDKTN code for importing a AlertRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertRoute to import
    * @param importFromId The id of the existing AlertRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route incident_alert_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertRouteConfig
    */
    constructor(scope: Construct, id: string, config: AlertRouteConfig);
    private _alertSources;
    get alertSources(): AlertRouteAlertSourcesList;
    putAlertSources(value: AlertRouteAlertSources[] | cdktn.IResolvable): void;
    get alertSourcesInput(): cdktn.IResolvable | AlertRouteAlertSources[] | undefined;
    private _channelConfig;
    get channelConfig(): AlertRouteChannelConfigList;
    putChannelConfig(value: AlertRouteChannelConfig[] | cdktn.IResolvable): void;
    resetChannelConfig(): void;
    get channelConfigInput(): cdktn.IResolvable | AlertRouteChannelConfig[] | undefined;
    private _conditionGroups;
    get conditionGroups(): AlertRouteConditionGroupsList;
    putConditionGroups(value: AlertRouteConditionGroups[] | cdktn.IResolvable): void;
    get conditionGroupsInput(): cdktn.IResolvable | AlertRouteConditionGroups[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _escalationConfig;
    get escalationConfig(): AlertRouteEscalationConfigOutputReference;
    putEscalationConfig(value: AlertRouteEscalationConfig): void;
    get escalationConfigInput(): cdktn.IResolvable | AlertRouteEscalationConfig | undefined;
    private _expressions;
    get expressions(): AlertRouteExpressionsList;
    putExpressions(value: AlertRouteExpressions[] | cdktn.IResolvable): void;
    get expressionsInput(): cdktn.IResolvable | AlertRouteExpressions[] | undefined;
    get id(): string;
    private _incidentConfig;
    get incidentConfig(): AlertRouteIncidentConfigOutputReference;
    putIncidentConfig(value: AlertRouteIncidentConfig): void;
    get incidentConfigInput(): cdktn.IResolvable | AlertRouteIncidentConfig | undefined;
    private _incidentTemplate;
    get incidentTemplate(): AlertRouteIncidentTemplateOutputReference;
    putIncidentTemplate(value: AlertRouteIncidentTemplate): void;
    get incidentTemplateInput(): cdktn.IResolvable | AlertRouteIncidentTemplate | undefined;
    private _isPrivate?;
    get isPrivate(): boolean | cdktn.IResolvable;
    set isPrivate(value: boolean | cdktn.IResolvable);
    get isPrivateInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
