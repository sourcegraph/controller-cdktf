import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataIncidentAlertSourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter alert sources by source type (e.g., 'webhook', 'email', 'jira'). If provided, only alert sources of this type will be returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/alert_sources#source_type DataIncidentAlertSources#source_type}
    */
    readonly sourceType?: string;
}
export interface DataIncidentAlertSourcesAlertSourcesJiraOptions {
}
export declare function dataIncidentAlertSourcesAlertSourcesJiraOptionsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesJiraOptions): any;
export declare function dataIncidentAlertSourcesAlertSourcesJiraOptionsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesJiraOptions): any;
export declare class DataIncidentAlertSourcesAlertSourcesJiraOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesJiraOptions | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesJiraOptions | undefined);
    get projectIds(): string[];
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValue {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValueToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValue): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValueToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValue): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValue | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValue | undefined);
    get literal(): string;
    get reference(): string;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValueList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValueOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingValue {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingValueToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingValue): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingValueToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingValue): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingValue | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingValue | undefined);
    get literal(): string;
    get reference(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateAttributesBinding {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateAttributesBinding): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateAttributesBinding): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateAttributesBinding | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateAttributesBinding | undefined);
    private _arrayValue;
    get arrayValue(): DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingArrayValueList;
    private _value;
    get value(): DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingValueOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateAttributes {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateAttributesToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateAttributes): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateAttributesToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateAttributes): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateAttributes | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateAttributes | undefined);
    get alertAttributeId(): string;
    private _binding;
    get binding(): DataIncidentAlertSourcesAlertSourcesTemplateAttributesBindingOutputReference;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateAttributesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateAttributesOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateDescription {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateDescriptionToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateDescription): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateDescriptionToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateDescription): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateDescription | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateDescription | undefined);
    get literal(): string;
    get reference(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValue {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValueToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValue): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValueToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValue): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValue | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValue | undefined);
    get literal(): string;
    get reference(): string;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValueList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValueOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultValue {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultValueToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultValue): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultValueToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultValue): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultValue | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultValue | undefined);
    get literal(): string;
    get reference(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResult {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResult): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResult): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResult | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResult | undefined);
    private _arrayValue;
    get arrayValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultArrayValueList;
    private _value;
    get value(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultValueOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranch {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranch): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranch): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranch | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranch | undefined);
    private _result;
    get result(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchResultOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | undefined);
    get literal(): string;
    get reference(): string;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | undefined);
    get literal(): string;
    get reference(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | undefined);
    private _arrayValue;
    get arrayValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList;
    private _value;
    get value(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions | undefined);
    get operation(): string;
    private _paramBindings;
    get paramBindings(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList;
    get subject(): string;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroups {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroups): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroups): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroups | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroups | undefined);
    private _conditions;
    get conditions(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsList;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValue {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValueToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValue): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValueToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValue): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValue | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValue | undefined);
    get literal(): string;
    get reference(): string;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValueList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValueOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultValue {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultValueToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultValue): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultValueToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultValue): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultValue | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultValue | undefined);
    get literal(): string;
    get reference(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResult {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResult): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResult): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResult | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResult | undefined);
    private _arrayValue;
    get arrayValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultArrayValueList;
    private _value;
    get value(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultValueOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranches {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranches): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranches): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranches | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranches | undefined);
    private _conditionGroups;
    get conditionGroups(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesConditionGroupsList;
    private _result;
    get result(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesResultOutputReference;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesReturns {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesReturnsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesReturns): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesReturnsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesReturns): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesReturnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesReturns | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesReturns | undefined);
    get array(): cdktn.IResolvable;
    get type(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranches {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranches): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranches): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranches | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranches | undefined);
    private _branches;
    get branches(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesBranchesList;
    private _returns;
    get returns(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesReturnsOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | undefined);
    get literal(): string;
    get reference(): string;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | undefined);
    get literal(): string;
    get reference(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings | undefined);
    private _arrayValue;
    get arrayValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList;
    private _value;
    get value(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditions {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditions): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditions): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditions | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditions | undefined);
    get operation(): string;
    private _paramBindings;
    get paramBindings(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList;
    get subject(): string;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroups {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroups): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroups): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroups | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroups | undefined);
    private _conditions;
    get conditions(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsConditionsList;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilter {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilter): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilter): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilter | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilter | undefined);
    private _conditionGroups;
    get conditionGroups(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterConditionGroupsList;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsNavigate {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsNavigateToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsNavigate): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsNavigateToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsNavigate): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsNavigateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsNavigate | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsNavigate | undefined);
    get reference(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseReturns {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseReturnsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseReturns): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseReturnsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseReturns): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseReturnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseReturns | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseReturns | undefined);
    get array(): cdktn.IResolvable;
    get type(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParse {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParse): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParse): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParse | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParse | undefined);
    private _returns;
    get returns(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseReturnsOutputReference;
    get source(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperations {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperations): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperations): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperations | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperations | undefined);
    private _branches;
    get branches(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsBranchesOutputReference;
    private _filter;
    get filter(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsFilterOutputReference;
    private _navigate;
    get navigate(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsNavigateOutputReference;
    get operationType(): string;
    private _parse;
    get parse(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsParseOutputReference;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateExpressions {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressions): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateExpressionsToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateExpressions): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateExpressions | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateExpressions | undefined);
    private _elseBranch;
    get elseBranch(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsElseBranchOutputReference;
    get label(): string;
    private _operations;
    get operations(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOperationsList;
    get reference(): string;
    get rootReference(): string;
}
export declare class DataIncidentAlertSourcesAlertSourcesTemplateExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsOutputReference;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplateTitle {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateTitleToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateTitle): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateTitleToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplateTitle): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplateTitle | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplateTitle | undefined);
    get literal(): string;
    get reference(): string;
}
export interface DataIncidentAlertSourcesAlertSourcesTemplate {
}
export declare function dataIncidentAlertSourcesAlertSourcesTemplateToTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplate): any;
export declare function dataIncidentAlertSourcesAlertSourcesTemplateToHclTerraform(struct?: DataIncidentAlertSourcesAlertSourcesTemplate): any;
export declare class DataIncidentAlertSourcesAlertSourcesTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentAlertSourcesAlertSourcesTemplate | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSourcesTemplate | undefined);
    private _attributes;
    get attributes(): DataIncidentAlertSourcesAlertSourcesTemplateAttributesList;
    private _description;
    get description(): DataIncidentAlertSourcesAlertSourcesTemplateDescriptionOutputReference;
    private _expressions;
    get expressions(): DataIncidentAlertSourcesAlertSourcesTemplateExpressionsList;
    private _title;
    get title(): DataIncidentAlertSourcesAlertSourcesTemplateTitleOutputReference;
}
export interface DataIncidentAlertSourcesAlertSources {
}
export declare function dataIncidentAlertSourcesAlertSourcesToTerraform(struct?: DataIncidentAlertSourcesAlertSources): any;
export declare function dataIncidentAlertSourcesAlertSourcesToHclTerraform(struct?: DataIncidentAlertSourcesAlertSources): any;
export declare class DataIncidentAlertSourcesAlertSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentAlertSourcesAlertSources | undefined;
    set internalValue(value: DataIncidentAlertSourcesAlertSources | undefined);
    get emailAddress(): string;
    get id(): string;
    private _jiraOptions;
    get jiraOptions(): DataIncidentAlertSourcesAlertSourcesJiraOptionsOutputReference;
    get name(): string;
    get secretToken(): string;
    get sourceType(): string;
    private _template;
    get template(): DataIncidentAlertSourcesAlertSourcesTemplateOutputReference;
}
export declare class DataIncidentAlertSourcesAlertSourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentAlertSourcesAlertSourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/alert_sources incident_alert_sources}
*/
export declare class DataIncidentAlertSources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "incident_alert_sources";
    /**
    * Generates CDKTN code for importing a DataIncidentAlertSources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIncidentAlertSources to import
    * @param importFromId The id of the existing DataIncidentAlertSources that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/alert_sources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIncidentAlertSources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/alert_sources incident_alert_sources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIncidentAlertSourcesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIncidentAlertSourcesConfig);
    private _alertSources;
    get alertSources(): DataIncidentAlertSourcesAlertSourcesList;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    resetSourceType(): void;
    get sourceTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
