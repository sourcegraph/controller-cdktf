import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataIncidentAlertAttributeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unique name of this attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/alert_attribute#name DataIncidentAlertAttribute#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/alert_attribute incident_alert_attribute}
*/
export declare class DataIncidentAlertAttribute extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "incident_alert_attribute";
    /**
    * Generates CDKTN code for importing a DataIncidentAlertAttribute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIncidentAlertAttribute to import
    * @param importFromId The id of the existing DataIncidentAlertAttribute that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/alert_attribute#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIncidentAlertAttribute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/alert_attribute incident_alert_attribute} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIncidentAlertAttributeConfig
    */
    constructor(scope: Construct, id: string, config: DataIncidentAlertAttributeConfig);
    get array(): cdktn.IResolvable;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get required(): cdktn.IResolvable;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
