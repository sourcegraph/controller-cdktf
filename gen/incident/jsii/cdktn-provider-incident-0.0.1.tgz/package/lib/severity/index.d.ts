import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SeverityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the severity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/severity#description Severity#description}
    */
    readonly description: string;
    /**
    * Human readable name of the severity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/severity#name Severity#name}
    */
    readonly name: string;
    /**
    * Rank to help sort severities (lower numbers are less severe)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/severity#rank Severity#rank}
    */
    readonly rank?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/severity incident_severity}
*/
export declare class Severity extends cdktn.TerraformResource {
    static readonly tfResourceType = "incident_severity";
    /**
    * Generates CDKTN code for importing a Severity resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Severity to import
    * @param importFromId The id of the existing Severity that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/severity#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Severity to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/severity incident_severity} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SeverityConfig
    */
    constructor(scope: Construct, id: string, config: SeverityConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rank?;
    get rank(): number;
    set rank(value: number);
    resetRank(): void;
    get rankInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
