import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkflowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#condition_groups Workflow#condition_groups}
    */
    readonly conditionGroups: WorkflowConditionGroups[] | cdktn.IResolvable;
    /**
    * Whether to continue executing the workflow if a step fails
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#continue_on_step_error Workflow#continue_on_step_error}
    */
    readonly continueOnStepError: boolean | cdktn.IResolvable;
    /**
    * Configuration controlling workflow delay behaviour
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#delay Workflow#delay}
    */
    readonly delay?: WorkflowDelay;
    /**
    * The expressions to be prepared for use by steps and conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#expressions Workflow#expressions}
    */
    readonly expressions: WorkflowExpressions[] | cdktn.IResolvable;
    /**
    * Folder to display the workflow in
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#folder Workflow#folder}
    */
    readonly folder?: string;
    /**
    * Whether to include private incidents
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#include_private_incidents Workflow#include_private_incidents}
    */
    readonly includePrivateIncidents: boolean | cdktn.IResolvable;
    /**
    * Name provided by the user when creating the workflow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#name Workflow#name}
    */
    readonly name: string;
    /**
    * This workflow will run 'once for' a list of references
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#once_for Workflow#once_for}
    */
    readonly onceFor: string[];
    /**
    * Which incident modes should this workflow run on? By default, workflows only run on standard incidents, but can also be configured to run on test and retrospective incidents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#runs_on_incident_modes Workflow#runs_on_incident_modes}
    */
    readonly runsOnIncidentModes: string[];
    /**
    * Which incidents should the workflow be applied to?. Possible values are: `newly_created`, `newly_created_and_active`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#runs_on_incidents Workflow#runs_on_incidents}
    */
    readonly runsOnIncidents: string;
    /**
    * The shortform used to trigger this workflow (only applicable for manual triggers)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#shortform Workflow#shortform}
    */
    readonly shortform?: string;
    /**
    * What state this workflow is in. Possible values are: `active`, `disabled`, `draft`, `error`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#state Workflow#state}
    */
    readonly state: string;
    /**
    * Steps that are executed as part of the workflow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#steps Workflow#steps}
    */
    readonly steps: WorkflowSteps[] | cdktn.IResolvable;
    /**
    * Unique name of the trigger
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#trigger Workflow#trigger}
    */
    readonly trigger: string;
}
export interface WorkflowConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: WorkflowConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare function workflowConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: WorkflowConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare class WorkflowConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    internalValue?: WorkflowConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface WorkflowConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowConditionGroupsConditionsParamBindingsValueToTerraform(struct?: WorkflowConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare function workflowConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: WorkflowConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare class WorkflowConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowConditionGroupsConditionsParamBindingsValue;
}
export declare function workflowConditionGroupsConditionsParamBindingsToTerraform(struct?: WorkflowConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare function workflowConditionGroupsConditionsParamBindingsToHclTerraform(struct?: WorkflowConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare class WorkflowConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: WorkflowConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | WorkflowConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): WorkflowConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: WorkflowConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | WorkflowConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class WorkflowConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    internalValue?: WorkflowConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowConditionGroupsConditionsParamBindingsOutputReference;
}
export interface WorkflowConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#operation Workflow#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#param_bindings Workflow#param_bindings}
    */
    readonly paramBindings: WorkflowConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#subject Workflow#subject}
    */
    readonly subject: string;
}
export declare function workflowConditionGroupsConditionsToTerraform(struct?: WorkflowConditionGroupsConditions | cdktn.IResolvable): any;
export declare function workflowConditionGroupsConditionsToHclTerraform(struct?: WorkflowConditionGroupsConditions | cdktn.IResolvable): any;
export declare class WorkflowConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowConditionGroupsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowConditionGroupsConditions | cdktn.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): WorkflowConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: WorkflowConditionGroupsConditionsParamBindings[] | cdktn.IResolvable): void;
    get paramBindingsInput(): cdktn.IResolvable | WorkflowConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class WorkflowConditionGroupsConditionsList extends cdktn.ComplexList {
    internalValue?: WorkflowConditionGroupsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowConditionGroupsConditionsOutputReference;
}
export interface WorkflowConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#conditions Workflow#conditions}
    */
    readonly conditions: WorkflowConditionGroupsConditions[] | cdktn.IResolvable;
}
export declare function workflowConditionGroupsToTerraform(struct?: WorkflowConditionGroups | cdktn.IResolvable): any;
export declare function workflowConditionGroupsToHclTerraform(struct?: WorkflowConditionGroups | cdktn.IResolvable): any;
export declare class WorkflowConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowConditionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowConditionGroups | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): WorkflowConditionGroupsConditionsList;
    putConditions(value: WorkflowConditionGroupsConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | WorkflowConditionGroupsConditions[] | undefined;
}
export declare class WorkflowConditionGroupsList extends cdktn.ComplexList {
    internalValue?: WorkflowConditionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowConditionGroupsOutputReference;
}
export interface WorkflowDelay {
    /**
    * If this workflow is delayed, whether the conditions should be rechecked between trigger firing and execution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#conditions_apply_over_delay Workflow#conditions_apply_over_delay}
    */
    readonly conditionsApplyOverDelay: boolean | cdktn.IResolvable;
    /**
    * Delay in seconds between trigger firing and running the workflow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#for_seconds Workflow#for_seconds}
    */
    readonly forSeconds: number;
}
export declare function workflowDelayToTerraform(struct?: WorkflowDelay | cdktn.IResolvable): any;
export declare function workflowDelayToHclTerraform(struct?: WorkflowDelay | cdktn.IResolvable): any;
export declare class WorkflowDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowDelay | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowDelay | cdktn.IResolvable | undefined);
    private _conditionsApplyOverDelay?;
    get conditionsApplyOverDelay(): boolean | cdktn.IResolvable;
    set conditionsApplyOverDelay(value: boolean | cdktn.IResolvable);
    get conditionsApplyOverDelayInput(): boolean | cdktn.IResolvable | undefined;
    private _forSeconds?;
    get forSeconds(): number;
    set forSeconds(value: number);
    get forSecondsInput(): number | undefined;
}
export interface WorkflowExpressionsElseBranchResultArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsElseBranchResultArrayValueToTerraform(struct?: WorkflowExpressionsElseBranchResultArrayValue | cdktn.IResolvable): any;
export declare function workflowExpressionsElseBranchResultArrayValueToHclTerraform(struct?: WorkflowExpressionsElseBranchResultArrayValue | cdktn.IResolvable): any;
export declare class WorkflowExpressionsElseBranchResultArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsElseBranchResultArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsElseBranchResultArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowExpressionsElseBranchResultArrayValueList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsElseBranchResultArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsElseBranchResultArrayValueOutputReference;
}
export interface WorkflowExpressionsElseBranchResultValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsElseBranchResultValueToTerraform(struct?: WorkflowExpressionsElseBranchResultValue | cdktn.IResolvable): any;
export declare function workflowExpressionsElseBranchResultValueToHclTerraform(struct?: WorkflowExpressionsElseBranchResultValue | cdktn.IResolvable): any;
export declare class WorkflowExpressionsElseBranchResultValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsElseBranchResultValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsElseBranchResultValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowExpressionsElseBranchResult {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowExpressionsElseBranchResultArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowExpressionsElseBranchResultValue;
}
export declare function workflowExpressionsElseBranchResultToTerraform(struct?: WorkflowExpressionsElseBranchResult | cdktn.IResolvable): any;
export declare function workflowExpressionsElseBranchResultToHclTerraform(struct?: WorkflowExpressionsElseBranchResult | cdktn.IResolvable): any;
export declare class WorkflowExpressionsElseBranchResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsElseBranchResult | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsElseBranchResult | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowExpressionsElseBranchResultArrayValueList;
    putArrayValue(value: WorkflowExpressionsElseBranchResultArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | WorkflowExpressionsElseBranchResultArrayValue[] | undefined;
    private _value;
    get value(): WorkflowExpressionsElseBranchResultValueOutputReference;
    putValue(value: WorkflowExpressionsElseBranchResultValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | WorkflowExpressionsElseBranchResultValue | undefined;
}
export interface WorkflowExpressionsElseBranch {
    /**
    * The result assumed if the else branch is reached
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#result Workflow#result}
    */
    readonly result: WorkflowExpressionsElseBranchResult;
}
export declare function workflowExpressionsElseBranchToTerraform(struct?: WorkflowExpressionsElseBranch | cdktn.IResolvable): any;
export declare function workflowExpressionsElseBranchToHclTerraform(struct?: WorkflowExpressionsElseBranch | cdktn.IResolvable): any;
export declare class WorkflowExpressionsElseBranchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsElseBranch | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsElseBranch | cdktn.IResolvable | undefined);
    private _result;
    get result(): WorkflowExpressionsElseBranchResultOutputReference;
    putResult(value: WorkflowExpressionsElseBranchResult): void;
    get resultInput(): cdktn.IResolvable | WorkflowExpressionsElseBranchResult | undefined;
}
export interface WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue;
}
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#operation Workflow#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#param_bindings Workflow#param_bindings}
    */
    readonly paramBindings: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#subject Workflow#subject}
    */
    readonly subject: string;
}
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktn.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktn.IResolvable): void;
    get paramBindingsInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesBranchesConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#conditions Workflow#conditions}
    */
    readonly conditions: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktn.IResolvable;
}
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroups | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroups | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroups | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsList;
    putConditions(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperationsBranchesBranchesConditionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesBranchesResultArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsBranchesBranchesResultArrayValueToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesResultArrayValueToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesResultArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesResultArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesResultArrayValueList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesResultArrayValueOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesBranchesResultValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsBranchesBranchesResultValueToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResultValue | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesResultValueToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResultValue | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesResultValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesResultValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesResultValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsBranchesBranchesResult {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowExpressionsOperationsBranchesBranchesResultValue;
}
export declare function workflowExpressionsOperationsBranchesBranchesResultToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResult | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesResultToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResult | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesResult | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesResult | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowExpressionsOperationsBranchesBranchesResultArrayValueList;
    putArrayValue(value: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranchesBranchesResultArrayValue[] | undefined;
    private _value;
    get value(): WorkflowExpressionsOperationsBranchesBranchesResultValueOutputReference;
    putValue(value: WorkflowExpressionsOperationsBranchesBranchesResultValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranchesBranchesResultValue | undefined;
}
export interface WorkflowExpressionsOperationsBranchesBranches {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#condition_groups Workflow#condition_groups}
    */
    readonly conditionGroups: WorkflowExpressionsOperationsBranchesBranchesConditionGroups[] | cdktn.IResolvable;
    /**
    * The result assumed if the condition groups are satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#result Workflow#result}
    */
    readonly result: WorkflowExpressionsOperationsBranchesBranchesResult;
}
export declare function workflowExpressionsOperationsBranchesBranchesToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranches | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranches | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranches | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranches | cdktn.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsList;
    putConditionGroups(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroups[] | cdktn.IResolvable): void;
    get conditionGroupsInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranchesBranchesConditionGroups[] | undefined;
    private _result;
    get result(): WorkflowExpressionsOperationsBranchesBranchesResultOutputReference;
    putResult(value: WorkflowExpressionsOperationsBranchesBranchesResult): void;
    get resultInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranchesBranchesResult | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperationsBranchesBranches[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesReturns {
    /**
    * Whether the return value should be single or multi-value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array Workflow#array}
    */
    readonly array: boolean | cdktn.IResolvable;
    /**
    * Expected return type of this expression (what to try casting the result to)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#type Workflow#type}
    */
    readonly type: string;
}
export declare function workflowExpressionsOperationsBranchesReturnsToTerraform(struct?: WorkflowExpressionsOperationsBranchesReturns | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesReturnsToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesReturns | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesReturnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsBranchesReturns | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesReturns | cdktn.IResolvable | undefined);
    private _array?;
    get array(): boolean | cdktn.IResolvable;
    set array(value: boolean | cdktn.IResolvable);
    get arrayInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsBranches {
    /**
    * The branches to apply for this operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#branches Workflow#branches}
    */
    readonly branches: WorkflowExpressionsOperationsBranchesBranches[] | cdktn.IResolvable;
    /**
    * The return type of an operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#returns Workflow#returns}
    */
    readonly returns: WorkflowExpressionsOperationsBranchesReturns;
}
export declare function workflowExpressionsOperationsBranchesToTerraform(struct?: WorkflowExpressionsOperationsBranches | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesToHclTerraform(struct?: WorkflowExpressionsOperationsBranches | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsBranches | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranches | cdktn.IResolvable | undefined);
    private _branches;
    get branches(): WorkflowExpressionsOperationsBranchesBranchesList;
    putBranches(value: WorkflowExpressionsOperationsBranchesBranches[] | cdktn.IResolvable): void;
    get branchesInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranchesBranches[] | undefined;
    private _returns;
    get returns(): WorkflowExpressionsOperationsBranchesReturnsOutputReference;
    putReturns(value: WorkflowExpressionsOperationsBranchesReturns): void;
    get returnsInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranchesReturns | undefined;
}
export interface WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue;
}
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToHclTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference;
}
export interface WorkflowExpressionsOperationsFilterConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#operation Workflow#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#param_bindings Workflow#param_bindings}
    */
    readonly paramBindings: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktn.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#subject Workflow#subject}
    */
    readonly subject: string;
}
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsToTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditions | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsToHclTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditions | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsFilterConditionGroupsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditions | cdktn.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktn.IResolvable): void;
    get paramBindingsInput(): cdktn.IResolvable | WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperationsFilterConditionGroupsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsFilterConditionGroupsConditionsOutputReference;
}
export interface WorkflowExpressionsOperationsFilterConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#conditions Workflow#conditions}
    */
    readonly conditions: WorkflowExpressionsOperationsFilterConditionGroupsConditions[] | cdktn.IResolvable;
}
export declare function workflowExpressionsOperationsFilterConditionGroupsToTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroups | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsFilterConditionGroupsToHclTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroups | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterConditionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsFilterConditionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilterConditionGroups | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsList;
    putConditions(value: WorkflowExpressionsOperationsFilterConditionGroupsConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | WorkflowExpressionsOperationsFilterConditionGroupsConditions[] | undefined;
}
export declare class WorkflowExpressionsOperationsFilterConditionGroupsList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperationsFilterConditionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsFilterConditionGroupsOutputReference;
}
export interface WorkflowExpressionsOperationsFilter {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#condition_groups Workflow#condition_groups}
    */
    readonly conditionGroups: WorkflowExpressionsOperationsFilterConditionGroups[] | cdktn.IResolvable;
}
export declare function workflowExpressionsOperationsFilterToTerraform(struct?: WorkflowExpressionsOperationsFilter | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsFilterToHclTerraform(struct?: WorkflowExpressionsOperationsFilter | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilter | cdktn.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): WorkflowExpressionsOperationsFilterConditionGroupsList;
    putConditionGroups(value: WorkflowExpressionsOperationsFilterConditionGroups[] | cdktn.IResolvable): void;
    get conditionGroupsInput(): cdktn.IResolvable | WorkflowExpressionsOperationsFilterConditionGroups[] | undefined;
}
export interface WorkflowExpressionsOperationsNavigate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference: string;
}
export declare function workflowExpressionsOperationsNavigateToTerraform(struct?: WorkflowExpressionsOperationsNavigate | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsNavigateToHclTerraform(struct?: WorkflowExpressionsOperationsNavigate | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsNavigateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsNavigate | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsNavigate | cdktn.IResolvable | undefined);
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsParseReturns {
    /**
    * Whether the return value should be single or multi-value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array Workflow#array}
    */
    readonly array: boolean | cdktn.IResolvable;
    /**
    * Expected return type of this expression (what to try casting the result to)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#type Workflow#type}
    */
    readonly type: string;
}
export declare function workflowExpressionsOperationsParseReturnsToTerraform(struct?: WorkflowExpressionsOperationsParseReturns | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsParseReturnsToHclTerraform(struct?: WorkflowExpressionsOperationsParseReturns | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsParseReturnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsParseReturns | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsParseReturns | cdktn.IResolvable | undefined);
    private _array?;
    get array(): boolean | cdktn.IResolvable;
    set array(value: boolean | cdktn.IResolvable);
    get arrayInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsParse {
    /**
    * The return type of an operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#returns Workflow#returns}
    */
    readonly returns: WorkflowExpressionsOperationsParseReturns;
    /**
    * The ES5 Javascript expression to execute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#source Workflow#source}
    */
    readonly source: string;
}
export declare function workflowExpressionsOperationsParseToTerraform(struct?: WorkflowExpressionsOperationsParse | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsParseToHclTerraform(struct?: WorkflowExpressionsOperationsParse | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsParseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsParse | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsParse | cdktn.IResolvable | undefined);
    private _returns;
    get returns(): WorkflowExpressionsOperationsParseReturnsOutputReference;
    putReturns(value: WorkflowExpressionsOperationsParseReturns): void;
    get returnsInput(): cdktn.IResolvable | WorkflowExpressionsOperationsParseReturns | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export interface WorkflowExpressionsOperations {
    /**
    * An operation type that allows for a value to be set conditionally by a series of logical branches
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#branches Workflow#branches}
    */
    readonly branches?: WorkflowExpressionsOperationsBranches;
    /**
    * An operation type that allows values to be filtered out by conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#filter Workflow#filter}
    */
    readonly filter?: WorkflowExpressionsOperationsFilter;
    /**
    * An operation type that allows attributes of a type to be accessed by reference
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#navigate Workflow#navigate}
    */
    readonly navigate?: WorkflowExpressionsOperationsNavigate;
    /**
    * Indicates which operation type to execute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#operation_type Workflow#operation_type}
    */
    readonly operationType: string;
    /**
    * An operation type that allows a value to parsed from within a JSON object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#parse Workflow#parse}
    */
    readonly parse?: WorkflowExpressionsOperationsParse;
}
export declare function workflowExpressionsOperationsToTerraform(struct?: WorkflowExpressionsOperations | cdktn.IResolvable): any;
export declare function workflowExpressionsOperationsToHclTerraform(struct?: WorkflowExpressionsOperations | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperations | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperations | cdktn.IResolvable | undefined);
    private _branches;
    get branches(): WorkflowExpressionsOperationsBranchesOutputReference;
    putBranches(value: WorkflowExpressionsOperationsBranches): void;
    resetBranches(): void;
    get branchesInput(): cdktn.IResolvable | WorkflowExpressionsOperationsBranches | undefined;
    private _filter;
    get filter(): WorkflowExpressionsOperationsFilterOutputReference;
    putFilter(value: WorkflowExpressionsOperationsFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | WorkflowExpressionsOperationsFilter | undefined;
    private _navigate;
    get navigate(): WorkflowExpressionsOperationsNavigateOutputReference;
    putNavigate(value: WorkflowExpressionsOperationsNavigate): void;
    resetNavigate(): void;
    get navigateInput(): cdktn.IResolvable | WorkflowExpressionsOperationsNavigate | undefined;
    private _operationType?;
    get operationType(): string;
    set operationType(value: string);
    get operationTypeInput(): string | undefined;
    private _parse;
    get parse(): WorkflowExpressionsOperationsParseOutputReference;
    putParse(value: WorkflowExpressionsOperationsParse): void;
    resetParse(): void;
    get parseInput(): cdktn.IResolvable | WorkflowExpressionsOperationsParse | undefined;
}
export declare class WorkflowExpressionsOperationsList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressionsOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsOutputReference;
}
export interface WorkflowExpressions {
    /**
    * The else branch to resort to if all operations fail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#else_branch Workflow#else_branch}
    */
    readonly elseBranch?: WorkflowExpressionsElseBranch;
    /**
    * The human readable label of the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#label Workflow#label}
    */
    readonly label: string;
    /**
    * The operations to execute in sequence for this expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#operations Workflow#operations}
    */
    readonly operations: WorkflowExpressionsOperations[] | cdktn.IResolvable;
    /**
    * A short ID that can be used to reference the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference: string;
    /**
    * The root reference for this expression (i.e. where the expression starts)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#root_reference Workflow#root_reference}
    */
    readonly rootReference: string;
}
export declare function workflowExpressionsToTerraform(struct?: WorkflowExpressions | cdktn.IResolvable): any;
export declare function workflowExpressionsToHclTerraform(struct?: WorkflowExpressions | cdktn.IResolvable): any;
export declare class WorkflowExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowExpressions | cdktn.IResolvable | undefined);
    private _elseBranch;
    get elseBranch(): WorkflowExpressionsElseBranchOutputReference;
    putElseBranch(value: WorkflowExpressionsElseBranch): void;
    resetElseBranch(): void;
    get elseBranchInput(): cdktn.IResolvable | WorkflowExpressionsElseBranch | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _operations;
    get operations(): WorkflowExpressionsOperationsList;
    putOperations(value: WorkflowExpressionsOperations[] | cdktn.IResolvable): void;
    get operationsInput(): cdktn.IResolvable | WorkflowExpressionsOperations[] | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
    private _rootReference?;
    get rootReference(): string;
    set rootReference(value: string);
    get rootReferenceInput(): string | undefined;
}
export declare class WorkflowExpressionsList extends cdktn.ComplexList {
    internalValue?: WorkflowExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOutputReference;
}
export interface WorkflowStepsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowStepsParamBindingsArrayValueToTerraform(struct?: WorkflowStepsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare function workflowStepsParamBindingsArrayValueToHclTerraform(struct?: WorkflowStepsParamBindingsArrayValue | cdktn.IResolvable): any;
export declare class WorkflowStepsParamBindingsArrayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowStepsParamBindingsArrayValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowStepsParamBindingsArrayValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowStepsParamBindingsArrayValueList extends cdktn.ComplexList {
    internalValue?: WorkflowStepsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowStepsParamBindingsArrayValueOutputReference;
}
export interface WorkflowStepsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowStepsParamBindingsValueToTerraform(struct?: WorkflowStepsParamBindingsValue | cdktn.IResolvable): any;
export declare function workflowStepsParamBindingsValueToHclTerraform(struct?: WorkflowStepsParamBindingsValue | cdktn.IResolvable): any;
export declare class WorkflowStepsParamBindingsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowStepsParamBindingsValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowStepsParamBindingsValue | cdktn.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowStepsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowStepsParamBindingsArrayValue[] | cdktn.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowStepsParamBindingsValue;
}
export declare function workflowStepsParamBindingsToTerraform(struct?: WorkflowStepsParamBindings | cdktn.IResolvable): any;
export declare function workflowStepsParamBindingsToHclTerraform(struct?: WorkflowStepsParamBindings | cdktn.IResolvable): any;
export declare class WorkflowStepsParamBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowStepsParamBindings | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowStepsParamBindings | cdktn.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowStepsParamBindingsArrayValueList;
    putArrayValue(value: WorkflowStepsParamBindingsArrayValue[] | cdktn.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktn.IResolvable | WorkflowStepsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): WorkflowStepsParamBindingsValueOutputReference;
    putValue(value: WorkflowStepsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | WorkflowStepsParamBindingsValue | undefined;
}
export declare class WorkflowStepsParamBindingsList extends cdktn.ComplexList {
    internalValue?: WorkflowStepsParamBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowStepsParamBindingsOutputReference;
}
export interface WorkflowSteps {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#for_each Workflow#for_each}
    */
    readonly forEach?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#id Workflow#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#name Workflow#name}
    */
    readonly name: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#param_bindings Workflow#param_bindings}
    */
    readonly paramBindings: WorkflowStepsParamBindings[] | cdktn.IResolvable;
}
export declare function workflowStepsToTerraform(struct?: WorkflowSteps | cdktn.IResolvable): any;
export declare function workflowStepsToHclTerraform(struct?: WorkflowSteps | cdktn.IResolvable): any;
export declare class WorkflowStepsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowSteps | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowSteps | cdktn.IResolvable | undefined);
    private _forEach?;
    get forEach(): string;
    set forEach(value: string);
    resetForEach(): void;
    get forEachInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): WorkflowStepsParamBindingsList;
    putParamBindings(value: WorkflowStepsParamBindings[] | cdktn.IResolvable): void;
    get paramBindingsInput(): cdktn.IResolvable | WorkflowStepsParamBindings[] | undefined;
}
export declare class WorkflowStepsList extends cdktn.ComplexList {
    internalValue?: WorkflowSteps[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowStepsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow incident_workflow}
*/
export declare class Workflow extends cdktn.TerraformResource {
    static readonly tfResourceType = "incident_workflow";
    /**
    * Generates CDKTN code for importing a Workflow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Workflow to import
    * @param importFromId The id of the existing Workflow that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Workflow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow incident_workflow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkflowConfig
    */
    constructor(scope: Construct, id: string, config: WorkflowConfig);
    private _conditionGroups;
    get conditionGroups(): WorkflowConditionGroupsList;
    putConditionGroups(value: WorkflowConditionGroups[] | cdktn.IResolvable): void;
    get conditionGroupsInput(): cdktn.IResolvable | WorkflowConditionGroups[] | undefined;
    private _continueOnStepError?;
    get continueOnStepError(): boolean | cdktn.IResolvable;
    set continueOnStepError(value: boolean | cdktn.IResolvable);
    get continueOnStepErrorInput(): boolean | cdktn.IResolvable | undefined;
    private _delay;
    get delay(): WorkflowDelayOutputReference;
    putDelay(value: WorkflowDelay): void;
    resetDelay(): void;
    get delayInput(): cdktn.IResolvable | WorkflowDelay | undefined;
    private _expressions;
    get expressions(): WorkflowExpressionsList;
    putExpressions(value: WorkflowExpressions[] | cdktn.IResolvable): void;
    get expressionsInput(): cdktn.IResolvable | WorkflowExpressions[] | undefined;
    private _folder?;
    get folder(): string;
    set folder(value: string);
    resetFolder(): void;
    get folderInput(): string | undefined;
    get id(): string;
    private _includePrivateIncidents?;
    get includePrivateIncidents(): boolean | cdktn.IResolvable;
    set includePrivateIncidents(value: boolean | cdktn.IResolvable);
    get includePrivateIncidentsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _onceFor?;
    get onceFor(): string[];
    set onceFor(value: string[]);
    get onceForInput(): string[] | undefined;
    private _runsOnIncidentModes?;
    get runsOnIncidentModes(): string[];
    set runsOnIncidentModes(value: string[]);
    get runsOnIncidentModesInput(): string[] | undefined;
    private _runsOnIncidents?;
    get runsOnIncidents(): string;
    set runsOnIncidents(value: string);
    get runsOnIncidentsInput(): string | undefined;
    private _shortform?;
    get shortform(): string;
    set shortform(value: string);
    resetShortform(): void;
    get shortformInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    get stateInput(): string | undefined;
    private _steps;
    get steps(): WorkflowStepsList;
    putSteps(value: WorkflowSteps[] | cdktn.IResolvable): void;
    get stepsInput(): cdktn.IResolvable | WorkflowSteps[] | undefined;
    private _trigger?;
    get trigger(): string;
    set trigger(value: string);
    get triggerInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
