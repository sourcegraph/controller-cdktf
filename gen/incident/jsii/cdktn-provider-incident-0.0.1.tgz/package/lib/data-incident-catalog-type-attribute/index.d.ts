import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataIncidentCatalogTypeAttributeConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of this catalog type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/catalog_type_attribute#catalog_type_id DataIncidentCatalogTypeAttribute#catalog_type_id}
    */
    readonly catalogTypeId: string;
    /**
    * The name of this attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/catalog_type_attribute#name DataIncidentCatalogTypeAttribute#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/catalog_type_attribute incident_catalog_type_attribute}
*/
export declare class DataIncidentCatalogTypeAttribute extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "incident_catalog_type_attribute";
    /**
    * Generates CDKTN code for importing a DataIncidentCatalogTypeAttribute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIncidentCatalogTypeAttribute to import
    * @param importFromId The id of the existing DataIncidentCatalogTypeAttribute that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/catalog_type_attribute#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIncidentCatalogTypeAttribute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/catalog_type_attribute incident_catalog_type_attribute} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIncidentCatalogTypeAttributeConfig
    */
    constructor(scope: Construct, id: string, config: DataIncidentCatalogTypeAttributeConfig);
    get array(): cdktn.IResolvable;
    get backlinkAttribute(): string;
    private _catalogTypeId?;
    get catalogTypeId(): string;
    set catalogTypeId(value: string);
    get catalogTypeIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get path(): string[];
    get schemaOnly(): cdktn.IResolvable;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
