import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataIncidentCustomFieldConfig extends cdktn.TerraformMetaArguments {
    /**
    * Human readable name for the custom field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/custom_field#name DataIncidentCustomField#name}
    */
    readonly name: string;
}
export interface DataIncidentCustomFieldFilterBy {
}
export declare function dataIncidentCustomFieldFilterByToTerraform(struct?: DataIncidentCustomFieldFilterBy): any;
export declare function dataIncidentCustomFieldFilterByToHclTerraform(struct?: DataIncidentCustomFieldFilterBy): any;
export declare class DataIncidentCustomFieldFilterByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIncidentCustomFieldFilterBy | undefined;
    set internalValue(value: DataIncidentCustomFieldFilterBy | undefined);
    get catalogAttributeId(): string;
    get customFieldId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/custom_field incident_custom_field}
*/
export declare class DataIncidentCustomField extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "incident_custom_field";
    /**
    * Generates CDKTN code for importing a DataIncidentCustomField resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIncidentCustomField to import
    * @param importFromId The id of the existing DataIncidentCustomField that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/custom_field#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIncidentCustomField to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/data-sources/custom_field incident_custom_field} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIncidentCustomFieldConfig
    */
    constructor(scope: Construct, id: string, config: DataIncidentCustomFieldConfig);
    get catalogTypeId(): string;
    get description(): string;
    get fieldType(): string;
    private _filterBy;
    get filterBy(): DataIncidentCustomFieldFilterByOutputReference;
    get groupByCatalogAttributeId(): string;
    get helptextCatalogAttributeId(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
