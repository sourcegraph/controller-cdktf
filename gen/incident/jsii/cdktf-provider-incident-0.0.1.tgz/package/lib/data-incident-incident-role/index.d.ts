import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIncidentIncidentRoleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Unique identifier for the role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/incident_role#id DataIncidentIncidentRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/incident_role incident_incident_role}
*/
export declare class DataIncidentIncidentRole extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "incident_incident_role";
    /**
    * Generates CDKTF code for importing a DataIncidentIncidentRole resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIncidentIncidentRole to import
    * @param importFromId The id of the existing DataIncidentIncidentRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/incident_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIncidentIncidentRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/incident_role incident_incident_role} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIncidentIncidentRoleConfig
    */
    constructor(scope: Construct, id: string, config: DataIncidentIncidentRoleConfig);
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get instructions(): string;
    get name(): string;
    get shortform(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
