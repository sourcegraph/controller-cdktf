import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIncidentCatalogTypeConfig extends cdktf.TerraformMetaArguments {
    /**
    * The categories that this type belongs to, to be shown in the web dashboard. Possible values are: `customer`, `issue-tracker`, `product-feature`, `service`, `on-call`, `team`, `user`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_type#categories DataIncidentCatalogType#categories}
    */
    readonly categories?: string[];
    /**
    * Name is the human readable name of this type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_type#name DataIncidentCatalogType#name}
    */
    readonly name?: string;
    /**
    * The type name of this catalog type, to be used when defining attributes. This is immutable once a CatalogType has been created. For non-externally sync types, it must follow the pattern Custom["SomeName"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_type#type_name DataIncidentCatalogType#type_name}
    */
    readonly typeName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_type incident_catalog_type}
*/
export declare class DataIncidentCatalogType extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "incident_catalog_type";
    /**
    * Generates CDKTF code for importing a DataIncidentCatalogType resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIncidentCatalogType to import
    * @param importFromId The id of the existing DataIncidentCatalogType that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIncidentCatalogType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_type incident_catalog_type} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIncidentCatalogTypeConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIncidentCatalogTypeConfig);
    private _categories?;
    get categories(): string[];
    set categories(value: string[]);
    resetCategories(): void;
    get categoriesInput(): string[] | undefined;
    get description(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get sourceRepoUrl(): string;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    resetTypeName(): void;
    get typeNameInput(): string | undefined;
    get useNameAsIdentifier(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
