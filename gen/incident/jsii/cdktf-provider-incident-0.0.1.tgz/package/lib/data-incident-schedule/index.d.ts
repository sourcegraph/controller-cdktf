import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIncidentScheduleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Unique internal ID of the schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/schedule#id DataIncidentSchedule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Human readable name synced from external provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/schedule#name DataIncidentSchedule#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/schedule incident_schedule}
*/
export declare class DataIncidentSchedule extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "incident_schedule";
    /**
    * Generates CDKTF code for importing a DataIncidentSchedule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIncidentSchedule to import
    * @param importFromId The id of the existing DataIncidentSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIncidentSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/schedule incident_schedule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIncidentScheduleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIncidentScheduleConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get teamIds(): string[];
    get timezone(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
