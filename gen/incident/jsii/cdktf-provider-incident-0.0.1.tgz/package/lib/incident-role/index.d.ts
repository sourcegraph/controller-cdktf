import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IncidentRoleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Describes the purpose of the role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/incident_role#description IncidentRole#description}
    */
    readonly description: string;
    /**
    * Provided to whoever is nominated for the role. Note that this will be empty for the 'reporter' role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/incident_role#instructions IncidentRole#instructions}
    */
    readonly instructions: string;
    /**
    * Human readable name of the incident role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/incident_role#name IncidentRole#name}
    */
    readonly name: string;
    /**
    * Short human readable name for Slack. Note that this will be empty for the 'reporter' role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/incident_role#shortform IncidentRole#shortform}
    */
    readonly shortform: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/incident_role incident_incident_role}
*/
export declare class IncidentRole extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_incident_role";
    /**
    * Generates CDKTF code for importing a IncidentRole resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IncidentRole to import
    * @param importFromId The id of the existing IncidentRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/incident_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IncidentRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/incident_role incident_incident_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IncidentRoleConfig
    */
    constructor(scope: Construct, id: string, config: IncidentRoleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instructions?;
    get instructions(): string;
    set instructions(value: string);
    get instructionsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _shortform?;
    get shortform(): string;
    set shortform(value: string);
    get shortformInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
