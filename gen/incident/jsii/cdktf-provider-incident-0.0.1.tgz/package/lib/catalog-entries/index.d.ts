import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CatalogEntriesConfig extends cdktf.TerraformMetaArguments {
    /**
    * Map of external ID to entry in the catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries#entries CatalogEntries#entries}
    */
    readonly entries: {
        [key: string]: CatalogEntriesEntries;
    } | cdktf.IResolvable;
    /**
    * ID of this catalog type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries#id CatalogEntries#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The set of attributes that are managed by this resource. By default, all attributes are managed by this resource.
    *
    * This can be used to allow other attributes of a catalog entry to be managed elsewhere, for example in another Terraform repository or the incident.io web UI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries#managed_attributes CatalogEntries#managed_attributes}
    */
    readonly managedAttributes?: string[];
}
export interface CatalogEntriesEntriesAttributeValues {
    /**
    * The value of this element of the array, in a format suitable for this attribute type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries#array_value CatalogEntries#array_value}
    */
    readonly arrayValue?: string[];
    /**
    * The value of this attribute, in a format suitable for this attribute type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries#value CatalogEntries#value}
    */
    readonly value?: string;
}
export declare function catalogEntriesEntriesAttributeValuesToTerraform(struct?: CatalogEntriesEntriesAttributeValues | cdktf.IResolvable): any;
export declare function catalogEntriesEntriesAttributeValuesToHclTerraform(struct?: CatalogEntriesEntriesAttributeValues | cdktf.IResolvable): any;
export declare class CatalogEntriesEntriesAttributeValuesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): CatalogEntriesEntriesAttributeValues | cdktf.IResolvable | undefined;
    set internalValue(value: CatalogEntriesEntriesAttributeValues | cdktf.IResolvable | undefined);
    private _arrayValue?;
    get arrayValue(): string[];
    set arrayValue(value: string[]);
    resetArrayValue(): void;
    get arrayValueInput(): string[] | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CatalogEntriesEntriesAttributeValuesMap extends cdktf.ComplexMap {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: CatalogEntriesEntriesAttributeValues;
    } | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): CatalogEntriesEntriesAttributeValuesOutputReference;
}
export interface CatalogEntriesEntries {
    /**
    * Optional aliases that can be used to reference this entry
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries#aliases CatalogEntries#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries#attribute_values CatalogEntries#attribute_values}
    */
    readonly attributeValues: {
        [key: string]: CatalogEntriesEntriesAttributeValues;
    } | cdktf.IResolvable;
    /**
    * Name is the human readable name of this entry
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries#name CatalogEntries#name}
    */
    readonly name: string;
    /**
    * When catalog type is ranked, this is used to help order things
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries#rank CatalogEntries#rank}
    */
    readonly rank?: number;
}
export declare function catalogEntriesEntriesToTerraform(struct?: CatalogEntriesEntries | cdktf.IResolvable): any;
export declare function catalogEntriesEntriesToHclTerraform(struct?: CatalogEntriesEntries | cdktf.IResolvable): any;
export declare class CatalogEntriesEntriesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): CatalogEntriesEntries | cdktf.IResolvable | undefined;
    set internalValue(value: CatalogEntriesEntries | cdktf.IResolvable | undefined);
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    private _attributeValues;
    get attributeValues(): CatalogEntriesEntriesAttributeValuesMap;
    putAttributeValues(value: {
        [key: string]: CatalogEntriesEntriesAttributeValues;
    } | cdktf.IResolvable): void;
    get attributeValuesInput(): cdktf.IResolvable | {
        [key: string]: CatalogEntriesEntriesAttributeValues;
    } | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rank?;
    get rank(): number;
    set rank(value: number);
    resetRank(): void;
    get rankInput(): number | undefined;
}
export declare class CatalogEntriesEntriesMap extends cdktf.ComplexMap {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: CatalogEntriesEntries;
    } | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): CatalogEntriesEntriesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries incident_catalog_entries}
*/
export declare class CatalogEntries extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_catalog_entries";
    /**
    * Generates CDKTF code for importing a CatalogEntries resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CatalogEntries to import
    * @param importFromId The id of the existing CatalogEntries that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CatalogEntries to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entries incident_catalog_entries} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CatalogEntriesConfig
    */
    constructor(scope: Construct, id: string, config: CatalogEntriesConfig);
    private _entries;
    get entries(): CatalogEntriesEntriesMap;
    putEntries(value: {
        [key: string]: CatalogEntriesEntries;
    } | cdktf.IResolvable): void;
    get entriesInput(): cdktf.IResolvable | {
        [key: string]: CatalogEntriesEntries;
    } | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _managedAttributes?;
    get managedAttributes(): string[];
    set managedAttributes(value: string[]);
    resetManagedAttributes(): void;
    get managedAttributesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
