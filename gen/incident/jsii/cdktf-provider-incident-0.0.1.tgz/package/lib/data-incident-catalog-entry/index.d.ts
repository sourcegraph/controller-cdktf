import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIncidentCatalogEntryConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of this catalog type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_entry#catalog_type_id DataIncidentCatalogEntry#catalog_type_id}
    */
    readonly catalogTypeId: string;
    /**
    * The identifier to use for finding the catalog entry. This can be a name, external ID, or alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_entry#identifier DataIncidentCatalogEntry#identifier}
    */
    readonly identifier: string;
}
export interface DataIncidentCatalogEntryAttributeValues {
}
export declare function dataIncidentCatalogEntryAttributeValuesToTerraform(struct?: DataIncidentCatalogEntryAttributeValues): any;
export declare function dataIncidentCatalogEntryAttributeValuesToHclTerraform(struct?: DataIncidentCatalogEntryAttributeValues): any;
export declare class DataIncidentCatalogEntryAttributeValuesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentCatalogEntryAttributeValues | undefined;
    set internalValue(value: DataIncidentCatalogEntryAttributeValues | undefined);
    get arrayValue(): string[];
    get attribute(): string;
    get value(): string;
}
export declare class DataIncidentCatalogEntryAttributeValuesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentCatalogEntryAttributeValuesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_entry incident_catalog_entry}
*/
export declare class DataIncidentCatalogEntry extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "incident_catalog_entry";
    /**
    * Generates CDKTF code for importing a DataIncidentCatalogEntry resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIncidentCatalogEntry to import
    * @param importFromId The id of the existing DataIncidentCatalogEntry that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_entry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIncidentCatalogEntry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_entry incident_catalog_entry} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIncidentCatalogEntryConfig
    */
    constructor(scope: Construct, id: string, config: DataIncidentCatalogEntryConfig);
    get aliases(): string[];
    private _attributeValues;
    get attributeValues(): DataIncidentCatalogEntryAttributeValuesList;
    private _catalogTypeId?;
    get catalogTypeId(): string;
    set catalogTypeId(value: string);
    get catalogTypeIdInput(): string | undefined;
    get externalId(): string;
    get id(): string;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    get name(): string;
    get rank(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
