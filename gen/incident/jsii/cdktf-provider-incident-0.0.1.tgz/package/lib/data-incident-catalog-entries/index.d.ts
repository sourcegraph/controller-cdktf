import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIncidentCatalogEntriesConfig extends cdktf.TerraformMetaArguments {
    /**
    * The catalog type ID to list entries for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_entries#catalog_type_id DataIncidentCatalogEntries#catalog_type_id}
    */
    readonly catalogTypeId: string;
}
export interface DataIncidentCatalogEntriesCatalogEntriesAttributeValues {
}
export declare function dataIncidentCatalogEntriesCatalogEntriesAttributeValuesToTerraform(struct?: DataIncidentCatalogEntriesCatalogEntriesAttributeValues): any;
export declare function dataIncidentCatalogEntriesCatalogEntriesAttributeValuesToHclTerraform(struct?: DataIncidentCatalogEntriesCatalogEntriesAttributeValues): any;
export declare class DataIncidentCatalogEntriesCatalogEntriesAttributeValuesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentCatalogEntriesCatalogEntriesAttributeValues | undefined;
    set internalValue(value: DataIncidentCatalogEntriesCatalogEntriesAttributeValues | undefined);
    get arrayValue(): string[];
    get attribute(): string;
    get value(): string;
}
export declare class DataIncidentCatalogEntriesCatalogEntriesAttributeValuesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentCatalogEntriesCatalogEntriesAttributeValuesOutputReference;
}
export interface DataIncidentCatalogEntriesCatalogEntries {
}
export declare function dataIncidentCatalogEntriesCatalogEntriesToTerraform(struct?: DataIncidentCatalogEntriesCatalogEntries): any;
export declare function dataIncidentCatalogEntriesCatalogEntriesToHclTerraform(struct?: DataIncidentCatalogEntriesCatalogEntries): any;
export declare class DataIncidentCatalogEntriesCatalogEntriesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIncidentCatalogEntriesCatalogEntries | undefined;
    set internalValue(value: DataIncidentCatalogEntriesCatalogEntries | undefined);
    get aliases(): string[];
    private _attributeValues;
    get attributeValues(): DataIncidentCatalogEntriesCatalogEntriesAttributeValuesList;
    get catalogTypeId(): string;
    get externalId(): string;
    get id(): string;
    get name(): string;
    get rank(): number;
}
export declare class DataIncidentCatalogEntriesCatalogEntriesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIncidentCatalogEntriesCatalogEntriesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_entries incident_catalog_entries}
*/
export declare class DataIncidentCatalogEntries extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "incident_catalog_entries";
    /**
    * Generates CDKTF code for importing a DataIncidentCatalogEntries resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIncidentCatalogEntries to import
    * @param importFromId The id of the existing DataIncidentCatalogEntries that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_entries#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIncidentCatalogEntries to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/data-sources/catalog_entries incident_catalog_entries} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIncidentCatalogEntriesConfig
    */
    constructor(scope: Construct, id: string, config: DataIncidentCatalogEntriesConfig);
    private _catalogEntries;
    get catalogEntries(): DataIncidentCatalogEntriesCatalogEntriesList;
    private _catalogTypeId?;
    get catalogTypeId(): string;
    set catalogTypeId(value: string);
    get catalogTypeIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
