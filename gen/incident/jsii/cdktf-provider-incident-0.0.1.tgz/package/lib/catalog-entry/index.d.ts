import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CatalogEntryConfig extends cdktf.TerraformMetaArguments {
    /**
    * Optional aliases that can be used to reference this entry
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#aliases CatalogEntry#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#attribute_values CatalogEntry#attribute_values}
    */
    readonly attributeValues: CatalogEntryAttributeValues[] | cdktf.IResolvable;
    /**
    * ID of this catalog type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#catalog_type_id CatalogEntry#catalog_type_id}
    */
    readonly catalogTypeId: string;
    /**
    * An optional alternative ID for this entry, which is ensured to be unique for the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#external_id CatalogEntry#external_id}
    */
    readonly externalId?: string;
    /**
    * The set of attributes that are managed by this resource. By default, all attributes are managed by this resource.
    *
    * This can be used to allow other attributes of a catalog entry to be managed elsewhere, for example in another Terraform repository or the incident.io web UI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#managed_attributes CatalogEntry#managed_attributes}
    */
    readonly managedAttributes?: string[];
    /**
    * Name is the human readable name of this entry
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#name CatalogEntry#name}
    */
    readonly name: string;
    /**
    * When catalog type is ranked, this is used to help order things
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#rank CatalogEntry#rank}
    */
    readonly rank?: number;
}
export interface CatalogEntryAttributeValues {
    /**
    * The value of this element of the array, in a format suitable for this attribute type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#array_value CatalogEntry#array_value}
    */
    readonly arrayValue?: string[];
    /**
    * The ID of this attribute, usually loaded from the incident_catalog_type_attribute resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#attribute CatalogEntry#attribute}
    */
    readonly attribute: string;
    /**
    * The value of this attribute, in a format suitable for this attribute type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#value CatalogEntry#value}
    */
    readonly value?: string;
}
export declare function catalogEntryAttributeValuesToTerraform(struct?: CatalogEntryAttributeValues | cdktf.IResolvable): any;
export declare function catalogEntryAttributeValuesToHclTerraform(struct?: CatalogEntryAttributeValues | cdktf.IResolvable): any;
export declare class CatalogEntryAttributeValuesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogEntryAttributeValues | cdktf.IResolvable | undefined;
    set internalValue(value: CatalogEntryAttributeValues | cdktf.IResolvable | undefined);
    private _arrayValue?;
    get arrayValue(): string[];
    set arrayValue(value: string[]);
    resetArrayValue(): void;
    get arrayValueInput(): string[] | undefined;
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    get attributeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CatalogEntryAttributeValuesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CatalogEntryAttributeValues[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogEntryAttributeValuesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry incident_catalog_entry}
*/
export declare class CatalogEntry extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_catalog_entry";
    /**
    * Generates CDKTF code for importing a CatalogEntry resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CatalogEntry to import
    * @param importFromId The id of the existing CatalogEntry that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CatalogEntry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/catalog_entry incident_catalog_entry} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CatalogEntryConfig
    */
    constructor(scope: Construct, id: string, config: CatalogEntryConfig);
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    private _attributeValues;
    get attributeValues(): CatalogEntryAttributeValuesList;
    putAttributeValues(value: CatalogEntryAttributeValues[] | cdktf.IResolvable): void;
    get attributeValuesInput(): cdktf.IResolvable | CatalogEntryAttributeValues[] | undefined;
    private _catalogTypeId?;
    get catalogTypeId(): string;
    set catalogTypeId(value: string);
    get catalogTypeIdInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    get id(): string;
    private _managedAttributes?;
    get managedAttributes(): string[];
    set managedAttributes(value: string[]);
    resetManagedAttributes(): void;
    get managedAttributesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rank?;
    get rank(): number;
    set rank(value: number);
    resetRank(): void;
    get rankInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
