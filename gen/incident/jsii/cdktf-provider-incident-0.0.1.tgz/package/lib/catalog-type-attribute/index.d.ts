import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CatalogTypeAttributeConfig extends cdktf.TerraformMetaArguments {
    /**
    * Whether this attribute is an array or scalar.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type_attribute#array CatalogTypeAttribute#array}
    */
    readonly array?: boolean | cdktf.IResolvable;
    /**
    * If this is a backlink, the id of the attribute that it's linked from
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type_attribute#backlink_attribute CatalogTypeAttribute#backlink_attribute}
    */
    readonly backlinkAttribute?: string;
    /**
    * ID of this catalog type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type_attribute#catalog_type_id CatalogTypeAttribute#catalog_type_id}
    */
    readonly catalogTypeId: string;
    /**
    * The name of this attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type_attribute#name CatalogTypeAttribute#name}
    */
    readonly name: string;
    /**
    * If this is a path attribute, the path that we should use to pull the data
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type_attribute#path CatalogTypeAttribute#path}
    */
    readonly path?: string[];
    /**
    * If true, Terraform will only manage the schema of the attribute. Values for this attribute can be managed from the incident.io web dashboard.
    *
    * NOTE: When enabled, you should use the `managed_attributes` argument on either `incident_catalog_entry` or `incident_catalog_entries` to manage the values of other attributes on this type, without Terraform overwriting values set in the dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type_attribute#schema_only CatalogTypeAttribute#schema_only}
    */
    readonly schemaOnly?: boolean | cdktf.IResolvable;
    /**
    * The type of this attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type_attribute#type CatalogTypeAttribute#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type_attribute incident_catalog_type_attribute}
*/
export declare class CatalogTypeAttribute extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_catalog_type_attribute";
    /**
    * Generates CDKTF code for importing a CatalogTypeAttribute resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CatalogTypeAttribute to import
    * @param importFromId The id of the existing CatalogTypeAttribute that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type_attribute#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CatalogTypeAttribute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type_attribute incident_catalog_type_attribute} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CatalogTypeAttributeConfig
    */
    constructor(scope: Construct, id: string, config: CatalogTypeAttributeConfig);
    private _array?;
    get array(): boolean | cdktf.IResolvable;
    set array(value: boolean | cdktf.IResolvable);
    resetArray(): void;
    get arrayInput(): boolean | cdktf.IResolvable | undefined;
    private _backlinkAttribute?;
    get backlinkAttribute(): string;
    set backlinkAttribute(value: string);
    resetBacklinkAttribute(): void;
    get backlinkAttributeInput(): string | undefined;
    private _catalogTypeId?;
    get catalogTypeId(): string;
    set catalogTypeId(value: string);
    get catalogTypeIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string[];
    set path(value: string[]);
    resetPath(): void;
    get pathInput(): string[] | undefined;
    private _schemaOnly?;
    get schemaOnly(): boolean | cdktf.IResolvable;
    set schemaOnly(value: boolean | cdktf.IResolvable);
    resetSchemaOnly(): void;
    get schemaOnlyInput(): boolean | cdktf.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
