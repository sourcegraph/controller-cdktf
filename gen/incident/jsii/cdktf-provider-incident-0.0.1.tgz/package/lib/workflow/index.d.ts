import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WorkflowConfig extends cdktf.TerraformMetaArguments {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#condition_groups Workflow#condition_groups}
    */
    readonly conditionGroups: WorkflowConditionGroups[] | cdktf.IResolvable;
    /**
    * Whether to continue executing the workflow if a step fails
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#continue_on_step_error Workflow#continue_on_step_error}
    */
    readonly continueOnStepError: boolean | cdktf.IResolvable;
    /**
    * Configuration controlling workflow delay behaviour
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#delay Workflow#delay}
    */
    readonly delay?: WorkflowDelay;
    /**
    * The expressions to be prepared for use by steps and conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#expressions Workflow#expressions}
    */
    readonly expressions: WorkflowExpressions[] | cdktf.IResolvable;
    /**
    * Folder to display the workflow in
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#folder Workflow#folder}
    */
    readonly folder?: string;
    /**
    * Whether to include private incidents
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#include_private_incidents Workflow#include_private_incidents}
    */
    readonly includePrivateIncidents: boolean | cdktf.IResolvable;
    /**
    * Name provided by the user when creating the workflow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#name Workflow#name}
    */
    readonly name: string;
    /**
    * This workflow will run 'once for' a list of references
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#once_for Workflow#once_for}
    */
    readonly onceFor: string[];
    /**
    * Which incident modes should this workflow run on? By default, workflows only run on standard incidents, but can also be configured to run on test and retrospective incidents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#runs_on_incident_modes Workflow#runs_on_incident_modes}
    */
    readonly runsOnIncidentModes: string[];
    /**
    * Which incidents should the workflow be applied to?. Possible values are: `newly_created`, `newly_created_and_active`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#runs_on_incidents Workflow#runs_on_incidents}
    */
    readonly runsOnIncidents: string;
    /**
    * The shortform used to trigger this workflow (only applicable for manual triggers)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#shortform Workflow#shortform}
    */
    readonly shortform?: string;
    /**
    * What state this workflow is in. Possible values are: `active`, `disabled`, `draft`, `error`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#state Workflow#state}
    */
    readonly state: string;
    /**
    * Steps that are executed as part of the workflow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#steps Workflow#steps}
    */
    readonly steps: WorkflowSteps[] | cdktf.IResolvable;
    /**
    * Unique name of the trigger
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#trigger Workflow#trigger}
    */
    readonly trigger: string;
}
export interface WorkflowConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: WorkflowConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function workflowConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: WorkflowConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class WorkflowConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface WorkflowConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowConditionGroupsConditionsParamBindingsValueToTerraform(struct?: WorkflowConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function workflowConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: WorkflowConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class WorkflowConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowConditionGroupsConditionsParamBindingsValue;
}
export declare function workflowConditionGroupsConditionsParamBindingsToTerraform(struct?: WorkflowConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function workflowConditionGroupsConditionsParamBindingsToHclTerraform(struct?: WorkflowConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class WorkflowConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: WorkflowConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | WorkflowConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): WorkflowConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: WorkflowConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | WorkflowConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class WorkflowConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowConditionGroupsConditionsParamBindingsOutputReference;
}
export interface WorkflowConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#operation Workflow#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#param_bindings Workflow#param_bindings}
    */
    readonly paramBindings: WorkflowConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#subject Workflow#subject}
    */
    readonly subject: string;
}
export declare function workflowConditionGroupsConditionsToTerraform(struct?: WorkflowConditionGroupsConditions | cdktf.IResolvable): any;
export declare function workflowConditionGroupsConditionsToHclTerraform(struct?: WorkflowConditionGroupsConditions | cdktf.IResolvable): any;
export declare class WorkflowConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): WorkflowConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: WorkflowConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | WorkflowConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class WorkflowConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowConditionGroupsConditionsOutputReference;
}
export interface WorkflowConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#conditions Workflow#conditions}
    */
    readonly conditions: WorkflowConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function workflowConditionGroupsToTerraform(struct?: WorkflowConditionGroups | cdktf.IResolvable): any;
export declare function workflowConditionGroupsToHclTerraform(struct?: WorkflowConditionGroups | cdktf.IResolvable): any;
export declare class WorkflowConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): WorkflowConditionGroupsConditionsList;
    putConditions(value: WorkflowConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | WorkflowConditionGroupsConditions[] | undefined;
}
export declare class WorkflowConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowConditionGroupsOutputReference;
}
export interface WorkflowDelay {
    /**
    * If this workflow is delayed, whether the conditions should be rechecked between trigger firing and execution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#conditions_apply_over_delay Workflow#conditions_apply_over_delay}
    */
    readonly conditionsApplyOverDelay: boolean | cdktf.IResolvable;
    /**
    * Delay in seconds between trigger firing and running the workflow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#for_seconds Workflow#for_seconds}
    */
    readonly forSeconds: number;
}
export declare function workflowDelayToTerraform(struct?: WorkflowDelay | cdktf.IResolvable): any;
export declare function workflowDelayToHclTerraform(struct?: WorkflowDelay | cdktf.IResolvable): any;
export declare class WorkflowDelayOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowDelay | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowDelay | cdktf.IResolvable | undefined);
    private _conditionsApplyOverDelay?;
    get conditionsApplyOverDelay(): boolean | cdktf.IResolvable;
    set conditionsApplyOverDelay(value: boolean | cdktf.IResolvable);
    get conditionsApplyOverDelayInput(): boolean | cdktf.IResolvable | undefined;
    private _forSeconds?;
    get forSeconds(): number;
    set forSeconds(value: number);
    get forSecondsInput(): number | undefined;
}
export interface WorkflowExpressionsElseBranchResultArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsElseBranchResultArrayValueToTerraform(struct?: WorkflowExpressionsElseBranchResultArrayValue | cdktf.IResolvable): any;
export declare function workflowExpressionsElseBranchResultArrayValueToHclTerraform(struct?: WorkflowExpressionsElseBranchResultArrayValue | cdktf.IResolvable): any;
export declare class WorkflowExpressionsElseBranchResultArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsElseBranchResultArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsElseBranchResultArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowExpressionsElseBranchResultArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsElseBranchResultArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsElseBranchResultArrayValueOutputReference;
}
export interface WorkflowExpressionsElseBranchResultValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsElseBranchResultValueToTerraform(struct?: WorkflowExpressionsElseBranchResultValue | cdktf.IResolvable): any;
export declare function workflowExpressionsElseBranchResultValueToHclTerraform(struct?: WorkflowExpressionsElseBranchResultValue | cdktf.IResolvable): any;
export declare class WorkflowExpressionsElseBranchResultValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsElseBranchResultValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsElseBranchResultValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowExpressionsElseBranchResult {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowExpressionsElseBranchResultArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowExpressionsElseBranchResultValue;
}
export declare function workflowExpressionsElseBranchResultToTerraform(struct?: WorkflowExpressionsElseBranchResult | cdktf.IResolvable): any;
export declare function workflowExpressionsElseBranchResultToHclTerraform(struct?: WorkflowExpressionsElseBranchResult | cdktf.IResolvable): any;
export declare class WorkflowExpressionsElseBranchResultOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsElseBranchResult | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsElseBranchResult | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowExpressionsElseBranchResultArrayValueList;
    putArrayValue(value: WorkflowExpressionsElseBranchResultArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | WorkflowExpressionsElseBranchResultArrayValue[] | undefined;
    private _value;
    get value(): WorkflowExpressionsElseBranchResultValueOutputReference;
    putValue(value: WorkflowExpressionsElseBranchResultValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | WorkflowExpressionsElseBranchResultValue | undefined;
}
export interface WorkflowExpressionsElseBranch {
    /**
    * The result assumed if the else branch is reached
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#result Workflow#result}
    */
    readonly result: WorkflowExpressionsElseBranchResult;
}
export declare function workflowExpressionsElseBranchToTerraform(struct?: WorkflowExpressionsElseBranch | cdktf.IResolvable): any;
export declare function workflowExpressionsElseBranchToHclTerraform(struct?: WorkflowExpressionsElseBranch | cdktf.IResolvable): any;
export declare class WorkflowExpressionsElseBranchOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsElseBranch | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsElseBranch | cdktf.IResolvable | undefined);
    private _result;
    get result(): WorkflowExpressionsElseBranchResultOutputReference;
    putResult(value: WorkflowExpressionsElseBranchResult): void;
    get resultInput(): cdktf.IResolvable | WorkflowExpressionsElseBranchResult | undefined;
}
export interface WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue;
}
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#operation Workflow#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#param_bindings Workflow#param_bindings}
    */
    readonly paramBindings: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#subject Workflow#subject}
    */
    readonly subject: string;
}
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesBranchesConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#conditions Workflow#conditions}
    */
    readonly conditions: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesConditionGroupsToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditionsList;
    putConditions(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperationsBranchesBranchesConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesBranchesResultArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsBranchesBranchesResultArrayValueToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesResultArrayValueToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesResultArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesResultArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesResultArrayValueOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesBranchesResultValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsBranchesBranchesResultValueToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesResultValueToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesResultValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsBranchesBranchesResult {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowExpressionsOperationsBranchesBranchesResultValue;
}
export declare function workflowExpressionsOperationsBranchesBranchesResultToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesResultToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesResultOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowExpressionsOperationsBranchesBranchesResultArrayValueList;
    putArrayValue(value: WorkflowExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranchesBranchesResultArrayValue[] | undefined;
    private _value;
    get value(): WorkflowExpressionsOperationsBranchesBranchesResultValueOutputReference;
    putValue(value: WorkflowExpressionsOperationsBranchesBranchesResultValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranchesBranchesResultValue | undefined;
}
export interface WorkflowExpressionsOperationsBranchesBranches {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#condition_groups Workflow#condition_groups}
    */
    readonly conditionGroups: WorkflowExpressionsOperationsBranchesBranchesConditionGroups[] | cdktf.IResolvable;
    /**
    * The result assumed if the condition groups are satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#result Workflow#result}
    */
    readonly result: WorkflowExpressionsOperationsBranchesBranchesResult;
}
export declare function workflowExpressionsOperationsBranchesBranchesToTerraform(struct?: WorkflowExpressionsOperationsBranchesBranches | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesBranchesToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesBranches | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesBranchesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsBranchesBranches | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesBranches | cdktf.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): WorkflowExpressionsOperationsBranchesBranchesConditionGroupsList;
    putConditionGroups(value: WorkflowExpressionsOperationsBranchesBranchesConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranchesBranchesConditionGroups[] | undefined;
    private _result;
    get result(): WorkflowExpressionsOperationsBranchesBranchesResultOutputReference;
    putResult(value: WorkflowExpressionsOperationsBranchesBranchesResult): void;
    get resultInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranchesBranchesResult | undefined;
}
export declare class WorkflowExpressionsOperationsBranchesBranchesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperationsBranchesBranches[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsBranchesBranchesOutputReference;
}
export interface WorkflowExpressionsOperationsBranchesReturns {
    /**
    * Whether the return value should be single or multi-value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array Workflow#array}
    */
    readonly array: boolean | cdktf.IResolvable;
    /**
    * Expected return type of this expression (what to try casting the result to)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#type Workflow#type}
    */
    readonly type: string;
}
export declare function workflowExpressionsOperationsBranchesReturnsToTerraform(struct?: WorkflowExpressionsOperationsBranchesReturns | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesReturnsToHclTerraform(struct?: WorkflowExpressionsOperationsBranchesReturns | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesReturnsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsBranchesReturns | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranchesReturns | cdktf.IResolvable | undefined);
    private _array?;
    get array(): boolean | cdktf.IResolvable;
    set array(value: boolean | cdktf.IResolvable);
    get arrayInput(): boolean | cdktf.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsBranches {
    /**
    * The branches to apply for this operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#branches Workflow#branches}
    */
    readonly branches: WorkflowExpressionsOperationsBranchesBranches[] | cdktf.IResolvable;
    /**
    * The return type of an operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#returns Workflow#returns}
    */
    readonly returns: WorkflowExpressionsOperationsBranchesReturns;
}
export declare function workflowExpressionsOperationsBranchesToTerraform(struct?: WorkflowExpressionsOperationsBranches | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsBranchesToHclTerraform(struct?: WorkflowExpressionsOperationsBranches | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsBranchesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsBranches | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsBranches | cdktf.IResolvable | undefined);
    private _branches;
    get branches(): WorkflowExpressionsOperationsBranchesBranchesList;
    putBranches(value: WorkflowExpressionsOperationsBranchesBranches[] | cdktf.IResolvable): void;
    get branchesInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranchesBranches[] | undefined;
    private _returns;
    get returns(): WorkflowExpressionsOperationsBranchesReturnsOutputReference;
    putReturns(value: WorkflowExpressionsOperationsBranchesReturns): void;
    get returnsInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranchesReturns | undefined;
}
export interface WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue;
}
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToHclTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference;
}
export interface WorkflowExpressionsOperationsFilterConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#operation Workflow#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#param_bindings Workflow#param_bindings}
    */
    readonly paramBindings: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#subject Workflow#subject}
    */
    readonly subject: string;
}
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsToTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsFilterConditionGroupsConditionsToHclTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | WorkflowExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class WorkflowExpressionsOperationsFilterConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperationsFilterConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsFilterConditionGroupsConditionsOutputReference;
}
export interface WorkflowExpressionsOperationsFilterConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#conditions Workflow#conditions}
    */
    readonly conditions: WorkflowExpressionsOperationsFilterConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function workflowExpressionsOperationsFilterConditionGroupsToTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroups | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsFilterConditionGroupsToHclTerraform(struct?: WorkflowExpressionsOperationsFilterConditionGroups | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperationsFilterConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilterConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): WorkflowExpressionsOperationsFilterConditionGroupsConditionsList;
    putConditions(value: WorkflowExpressionsOperationsFilterConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | WorkflowExpressionsOperationsFilterConditionGroupsConditions[] | undefined;
}
export declare class WorkflowExpressionsOperationsFilterConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperationsFilterConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsFilterConditionGroupsOutputReference;
}
export interface WorkflowExpressionsOperationsFilter {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#condition_groups Workflow#condition_groups}
    */
    readonly conditionGroups: WorkflowExpressionsOperationsFilterConditionGroups[] | cdktf.IResolvable;
}
export declare function workflowExpressionsOperationsFilterToTerraform(struct?: WorkflowExpressionsOperationsFilter | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsFilterToHclTerraform(struct?: WorkflowExpressionsOperationsFilter | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsFilter | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsFilter | cdktf.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): WorkflowExpressionsOperationsFilterConditionGroupsList;
    putConditionGroups(value: WorkflowExpressionsOperationsFilterConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | WorkflowExpressionsOperationsFilterConditionGroups[] | undefined;
}
export interface WorkflowExpressionsOperationsNavigate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference: string;
}
export declare function workflowExpressionsOperationsNavigateToTerraform(struct?: WorkflowExpressionsOperationsNavigate | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsNavigateToHclTerraform(struct?: WorkflowExpressionsOperationsNavigate | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsNavigateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsNavigate | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsNavigate | cdktf.IResolvable | undefined);
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsParseReturns {
    /**
    * Whether the return value should be single or multi-value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array Workflow#array}
    */
    readonly array: boolean | cdktf.IResolvable;
    /**
    * Expected return type of this expression (what to try casting the result to)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#type Workflow#type}
    */
    readonly type: string;
}
export declare function workflowExpressionsOperationsParseReturnsToTerraform(struct?: WorkflowExpressionsOperationsParseReturns | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsParseReturnsToHclTerraform(struct?: WorkflowExpressionsOperationsParseReturns | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsParseReturnsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsParseReturns | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsParseReturns | cdktf.IResolvable | undefined);
    private _array?;
    get array(): boolean | cdktf.IResolvable;
    set array(value: boolean | cdktf.IResolvable);
    get arrayInput(): boolean | cdktf.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface WorkflowExpressionsOperationsParse {
    /**
    * The return type of an operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#returns Workflow#returns}
    */
    readonly returns: WorkflowExpressionsOperationsParseReturns;
    /**
    * The ES5 Javascript expression to execute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#source Workflow#source}
    */
    readonly source: string;
}
export declare function workflowExpressionsOperationsParseToTerraform(struct?: WorkflowExpressionsOperationsParse | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsParseToHclTerraform(struct?: WorkflowExpressionsOperationsParse | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsParseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowExpressionsOperationsParse | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperationsParse | cdktf.IResolvable | undefined);
    private _returns;
    get returns(): WorkflowExpressionsOperationsParseReturnsOutputReference;
    putReturns(value: WorkflowExpressionsOperationsParseReturns): void;
    get returnsInput(): cdktf.IResolvable | WorkflowExpressionsOperationsParseReturns | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export interface WorkflowExpressionsOperations {
    /**
    * An operation type that allows for a value to be set conditionally by a series of logical branches
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#branches Workflow#branches}
    */
    readonly branches?: WorkflowExpressionsOperationsBranches;
    /**
    * An operation type that allows values to be filtered out by conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#filter Workflow#filter}
    */
    readonly filter?: WorkflowExpressionsOperationsFilter;
    /**
    * An operation type that allows attributes of a type to be accessed by reference
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#navigate Workflow#navigate}
    */
    readonly navigate?: WorkflowExpressionsOperationsNavigate;
    /**
    * Indicates which operation type to execute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#operation_type Workflow#operation_type}
    */
    readonly operationType: string;
    /**
    * An operation type that allows a value to parsed from within a JSON object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#parse Workflow#parse}
    */
    readonly parse?: WorkflowExpressionsOperationsParse;
}
export declare function workflowExpressionsOperationsToTerraform(struct?: WorkflowExpressionsOperations | cdktf.IResolvable): any;
export declare function workflowExpressionsOperationsToHclTerraform(struct?: WorkflowExpressionsOperations | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOperationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressionsOperations | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressionsOperations | cdktf.IResolvable | undefined);
    private _branches;
    get branches(): WorkflowExpressionsOperationsBranchesOutputReference;
    putBranches(value: WorkflowExpressionsOperationsBranches): void;
    resetBranches(): void;
    get branchesInput(): cdktf.IResolvable | WorkflowExpressionsOperationsBranches | undefined;
    private _filter;
    get filter(): WorkflowExpressionsOperationsFilterOutputReference;
    putFilter(value: WorkflowExpressionsOperationsFilter): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | WorkflowExpressionsOperationsFilter | undefined;
    private _navigate;
    get navigate(): WorkflowExpressionsOperationsNavigateOutputReference;
    putNavigate(value: WorkflowExpressionsOperationsNavigate): void;
    resetNavigate(): void;
    get navigateInput(): cdktf.IResolvable | WorkflowExpressionsOperationsNavigate | undefined;
    private _operationType?;
    get operationType(): string;
    set operationType(value: string);
    get operationTypeInput(): string | undefined;
    private _parse;
    get parse(): WorkflowExpressionsOperationsParseOutputReference;
    putParse(value: WorkflowExpressionsOperationsParse): void;
    resetParse(): void;
    get parseInput(): cdktf.IResolvable | WorkflowExpressionsOperationsParse | undefined;
}
export declare class WorkflowExpressionsOperationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressionsOperations[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOperationsOutputReference;
}
export interface WorkflowExpressions {
    /**
    * The else branch to resort to if all operations fail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#else_branch Workflow#else_branch}
    */
    readonly elseBranch?: WorkflowExpressionsElseBranch;
    /**
    * The human readable label of the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#label Workflow#label}
    */
    readonly label: string;
    /**
    * The operations to execute in sequence for this expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#operations Workflow#operations}
    */
    readonly operations: WorkflowExpressionsOperations[] | cdktf.IResolvable;
    /**
    * A short ID that can be used to reference the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference: string;
    /**
    * The root reference for this expression (i.e. where the expression starts)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#root_reference Workflow#root_reference}
    */
    readonly rootReference: string;
}
export declare function workflowExpressionsToTerraform(struct?: WorkflowExpressions | cdktf.IResolvable): any;
export declare function workflowExpressionsToHclTerraform(struct?: WorkflowExpressions | cdktf.IResolvable): any;
export declare class WorkflowExpressionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowExpressions | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowExpressions | cdktf.IResolvable | undefined);
    private _elseBranch;
    get elseBranch(): WorkflowExpressionsElseBranchOutputReference;
    putElseBranch(value: WorkflowExpressionsElseBranch): void;
    resetElseBranch(): void;
    get elseBranchInput(): cdktf.IResolvable | WorkflowExpressionsElseBranch | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _operations;
    get operations(): WorkflowExpressionsOperationsList;
    putOperations(value: WorkflowExpressionsOperations[] | cdktf.IResolvable): void;
    get operationsInput(): cdktf.IResolvable | WorkflowExpressionsOperations[] | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
    private _rootReference?;
    get rootReference(): string;
    set rootReference(value: string);
    get rootReferenceInput(): string | undefined;
}
export declare class WorkflowExpressionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowExpressions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowExpressionsOutputReference;
}
export interface WorkflowStepsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowStepsParamBindingsArrayValueToTerraform(struct?: WorkflowStepsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function workflowStepsParamBindingsArrayValueToHclTerraform(struct?: WorkflowStepsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class WorkflowStepsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowStepsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowStepsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class WorkflowStepsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowStepsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowStepsParamBindingsArrayValueOutputReference;
}
export interface WorkflowStepsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#literal Workflow#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#reference Workflow#reference}
    */
    readonly reference?: string;
}
export declare function workflowStepsParamBindingsValueToTerraform(struct?: WorkflowStepsParamBindingsValue | cdktf.IResolvable): any;
export declare function workflowStepsParamBindingsValueToHclTerraform(struct?: WorkflowStepsParamBindingsValue | cdktf.IResolvable): any;
export declare class WorkflowStepsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowStepsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowStepsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface WorkflowStepsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#array_value Workflow#array_value}
    */
    readonly arrayValue?: WorkflowStepsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#value Workflow#value}
    */
    readonly value?: WorkflowStepsParamBindingsValue;
}
export declare function workflowStepsParamBindingsToTerraform(struct?: WorkflowStepsParamBindings | cdktf.IResolvable): any;
export declare function workflowStepsParamBindingsToHclTerraform(struct?: WorkflowStepsParamBindings | cdktf.IResolvable): any;
export declare class WorkflowStepsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowStepsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowStepsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): WorkflowStepsParamBindingsArrayValueList;
    putArrayValue(value: WorkflowStepsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | WorkflowStepsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): WorkflowStepsParamBindingsValueOutputReference;
    putValue(value: WorkflowStepsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | WorkflowStepsParamBindingsValue | undefined;
}
export declare class WorkflowStepsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowStepsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowStepsParamBindingsOutputReference;
}
export interface WorkflowSteps {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#for_each Workflow#for_each}
    */
    readonly forEach?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#id Workflow#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#name Workflow#name}
    */
    readonly name: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#param_bindings Workflow#param_bindings}
    */
    readonly paramBindings: WorkflowStepsParamBindings[] | cdktf.IResolvable;
}
export declare function workflowStepsToTerraform(struct?: WorkflowSteps | cdktf.IResolvable): any;
export declare function workflowStepsToHclTerraform(struct?: WorkflowSteps | cdktf.IResolvable): any;
export declare class WorkflowStepsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowSteps | cdktf.IResolvable | undefined;
    set internalValue(value: WorkflowSteps | cdktf.IResolvable | undefined);
    private _forEach?;
    get forEach(): string;
    set forEach(value: string);
    resetForEach(): void;
    get forEachInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): WorkflowStepsParamBindingsList;
    putParamBindings(value: WorkflowStepsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | WorkflowStepsParamBindings[] | undefined;
}
export declare class WorkflowStepsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkflowSteps[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowStepsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow incident_workflow}
*/
export declare class Workflow extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_workflow";
    /**
    * Generates CDKTF code for importing a Workflow resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Workflow to import
    * @param importFromId The id of the existing Workflow that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Workflow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/workflow incident_workflow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkflowConfig
    */
    constructor(scope: Construct, id: string, config: WorkflowConfig);
    private _conditionGroups;
    get conditionGroups(): WorkflowConditionGroupsList;
    putConditionGroups(value: WorkflowConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | WorkflowConditionGroups[] | undefined;
    private _continueOnStepError?;
    get continueOnStepError(): boolean | cdktf.IResolvable;
    set continueOnStepError(value: boolean | cdktf.IResolvable);
    get continueOnStepErrorInput(): boolean | cdktf.IResolvable | undefined;
    private _delay;
    get delay(): WorkflowDelayOutputReference;
    putDelay(value: WorkflowDelay): void;
    resetDelay(): void;
    get delayInput(): cdktf.IResolvable | WorkflowDelay | undefined;
    private _expressions;
    get expressions(): WorkflowExpressionsList;
    putExpressions(value: WorkflowExpressions[] | cdktf.IResolvable): void;
    get expressionsInput(): cdktf.IResolvable | WorkflowExpressions[] | undefined;
    private _folder?;
    get folder(): string;
    set folder(value: string);
    resetFolder(): void;
    get folderInput(): string | undefined;
    get id(): string;
    private _includePrivateIncidents?;
    get includePrivateIncidents(): boolean | cdktf.IResolvable;
    set includePrivateIncidents(value: boolean | cdktf.IResolvable);
    get includePrivateIncidentsInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _onceFor?;
    get onceFor(): string[];
    set onceFor(value: string[]);
    get onceForInput(): string[] | undefined;
    private _runsOnIncidentModes?;
    get runsOnIncidentModes(): string[];
    set runsOnIncidentModes(value: string[]);
    get runsOnIncidentModesInput(): string[] | undefined;
    private _runsOnIncidents?;
    get runsOnIncidents(): string;
    set runsOnIncidents(value: string);
    get runsOnIncidentsInput(): string | undefined;
    private _shortform?;
    get shortform(): string;
    set shortform(value: string);
    resetShortform(): void;
    get shortformInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    get stateInput(): string | undefined;
    private _steps;
    get steps(): WorkflowStepsList;
    putSteps(value: WorkflowSteps[] | cdktf.IResolvable): void;
    get stepsInput(): cdktf.IResolvable | WorkflowSteps[] | undefined;
    private _trigger?;
    get trigger(): string;
    set trigger(value: string);
    get triggerInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
