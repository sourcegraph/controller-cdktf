import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AlertRouteConfig extends cdktf.TerraformMetaArguments {
    /**
    * Which alert sources should this alert route match?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#alert_sources AlertRoute#alert_sources}
    */
    readonly alertSources: AlertRouteAlertSources[] | cdktf.IResolvable;
    /**
    * The channel configuration for this alert route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#channel_config AlertRoute#channel_config}
    */
    readonly channelConfig?: AlertRouteChannelConfig[] | cdktf.IResolvable;
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteConditionGroups[] | cdktf.IResolvable;
    /**
    * Whether this alert route is enabled or not
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#enabled AlertRoute#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#escalation_config AlertRoute#escalation_config}
    */
    readonly escalationConfig: AlertRouteEscalationConfig;
    /**
    * The expressions to be prepared for use by steps and conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#expressions AlertRoute#expressions}
    */
    readonly expressions: AlertRouteExpressions[] | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#incident_config AlertRoute#incident_config}
    */
    readonly incidentConfig: AlertRouteIncidentConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#incident_template AlertRoute#incident_template}
    */
    readonly incidentTemplate: AlertRouteIncidentTemplate;
    /**
    * Whether this alert route is private. Private alert routes will only create private incidents from alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#is_private AlertRoute#is_private}
    */
    readonly isPrivate: boolean | cdktf.IResolvable;
    /**
    * The name of this alert route config, for the user's reference
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#name AlertRoute#name}
    */
    readonly name: string;
}
export interface AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteAlertSourcesConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function alertRouteAlertSourcesConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteAlertSourcesConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteAlertSourcesConditionGroupsConditionsToTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditions | cdktf.IResolvable): any;
export declare function alertRouteAlertSourcesConditionGroupsConditionsToHclTerraform(struct?: AlertRouteAlertSourcesConditionGroupsConditions | cdktf.IResolvable): any;
export declare class AlertRouteAlertSourcesConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteAlertSourcesConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSourcesConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteAlertSourcesConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteAlertSourcesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | AlertRouteAlertSourcesConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteAlertSourcesConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteAlertSourcesConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteAlertSourcesConditionGroupsConditionsOutputReference;
}
export interface AlertRouteAlertSourcesConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteAlertSourcesConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function alertRouteAlertSourcesConditionGroupsToTerraform(struct?: AlertRouteAlertSourcesConditionGroups | cdktf.IResolvable): any;
export declare function alertRouteAlertSourcesConditionGroupsToHclTerraform(struct?: AlertRouteAlertSourcesConditionGroups | cdktf.IResolvable): any;
export declare class AlertRouteAlertSourcesConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteAlertSourcesConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSourcesConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteAlertSourcesConditionGroupsConditionsList;
    putConditions(value: AlertRouteAlertSourcesConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | AlertRouteAlertSourcesConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteAlertSourcesConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteAlertSourcesConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteAlertSourcesConditionGroupsOutputReference;
}
export interface AlertRouteAlertSources {
    /**
    * The alert source ID that will match for the route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#alert_source_id AlertRoute#alert_source_id}
    */
    readonly alertSourceId: string;
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteAlertSourcesConditionGroups[] | cdktf.IResolvable;
}
export declare function alertRouteAlertSourcesToTerraform(struct?: AlertRouteAlertSources | cdktf.IResolvable): any;
export declare function alertRouteAlertSourcesToHclTerraform(struct?: AlertRouteAlertSources | cdktf.IResolvable): any;
export declare class AlertRouteAlertSourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteAlertSources | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteAlertSources | cdktf.IResolvable | undefined);
    private _alertSourceId?;
    get alertSourceId(): string;
    set alertSourceId(value: string);
    get alertSourceIdInput(): string | undefined;
    private _conditionGroups;
    get conditionGroups(): AlertRouteAlertSourcesConditionGroupsList;
    putConditionGroups(value: AlertRouteAlertSourcesConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | AlertRouteAlertSourcesConditionGroups[] | undefined;
}
export declare class AlertRouteAlertSourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteAlertSources[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteAlertSourcesOutputReference;
}
export interface AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteChannelConfigConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteChannelConfigConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteChannelConfigConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteChannelConfigConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteChannelConfigConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteChannelConfigConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteChannelConfigConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteChannelConfigConditionGroupsConditionsToTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditions | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigConditionGroupsConditionsToHclTerraform(struct?: AlertRouteChannelConfigConditionGroupsConditions | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteChannelConfigConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteChannelConfigConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | AlertRouteChannelConfigConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteChannelConfigConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteChannelConfigConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigConditionGroupsConditionsOutputReference;
}
export interface AlertRouteChannelConfigConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteChannelConfigConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function alertRouteChannelConfigConditionGroupsToTerraform(struct?: AlertRouteChannelConfigConditionGroups | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigConditionGroupsToHclTerraform(struct?: AlertRouteChannelConfigConditionGroups | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteChannelConfigConditionGroupsConditionsList;
    putConditions(value: AlertRouteChannelConfigConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | AlertRouteChannelConfigConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteChannelConfigConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteChannelConfigConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigConditionGroupsOutputReference;
}
export interface AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigMsTeamsTargetsBindingArrayValueToTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigMsTeamsTargetsBindingArrayValueToHclTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigMsTeamsTargetsBindingArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteChannelConfigMsTeamsTargetsBindingArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigMsTeamsTargetsBindingArrayValueOutputReference;
}
export interface AlertRouteChannelConfigMsTeamsTargetsBindingValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigMsTeamsTargetsBindingValueToTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBindingValue | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigMsTeamsTargetsBindingValueToHclTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBindingValue | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigMsTeamsTargetsBindingValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigMsTeamsTargetsBindingValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigMsTeamsTargetsBindingValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteChannelConfigMsTeamsTargetsBinding {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteChannelConfigMsTeamsTargetsBindingValue;
}
export declare function alertRouteChannelConfigMsTeamsTargetsBindingToTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBinding | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigMsTeamsTargetsBindingToHclTerraform(struct?: AlertRouteChannelConfigMsTeamsTargetsBinding | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigMsTeamsTargetsBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigMsTeamsTargetsBinding | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigMsTeamsTargetsBinding | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteChannelConfigMsTeamsTargetsBindingArrayValueList;
    putArrayValue(value: AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteChannelConfigMsTeamsTargetsBindingArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteChannelConfigMsTeamsTargetsBindingValueOutputReference;
    putValue(value: AlertRouteChannelConfigMsTeamsTargetsBindingValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteChannelConfigMsTeamsTargetsBindingValue | undefined;
}
export interface AlertRouteChannelConfigMsTeamsTargets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#binding AlertRoute#binding}
    */
    readonly binding: AlertRouteChannelConfigMsTeamsTargetsBinding;
    /**
    * The visibility of the channel
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#channel_visibility AlertRoute#channel_visibility}
    */
    readonly channelVisibility: string;
}
export declare function alertRouteChannelConfigMsTeamsTargetsToTerraform(struct?: AlertRouteChannelConfigMsTeamsTargets | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigMsTeamsTargetsToHclTerraform(struct?: AlertRouteChannelConfigMsTeamsTargets | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigMsTeamsTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigMsTeamsTargets | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigMsTeamsTargets | cdktf.IResolvable | undefined);
    private _binding;
    get binding(): AlertRouteChannelConfigMsTeamsTargetsBindingOutputReference;
    putBinding(value: AlertRouteChannelConfigMsTeamsTargetsBinding): void;
    get bindingInput(): cdktf.IResolvable | AlertRouteChannelConfigMsTeamsTargetsBinding | undefined;
    private _channelVisibility?;
    get channelVisibility(): string;
    set channelVisibility(value: string);
    get channelVisibilityInput(): string | undefined;
}
export interface AlertRouteChannelConfigSlackTargetsBindingArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigSlackTargetsBindingArrayValueToTerraform(struct?: AlertRouteChannelConfigSlackTargetsBindingArrayValue | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigSlackTargetsBindingArrayValueToHclTerraform(struct?: AlertRouteChannelConfigSlackTargetsBindingArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigSlackTargetsBindingArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfigSlackTargetsBindingArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigSlackTargetsBindingArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteChannelConfigSlackTargetsBindingArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteChannelConfigSlackTargetsBindingArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigSlackTargetsBindingArrayValueOutputReference;
}
export interface AlertRouteChannelConfigSlackTargetsBindingValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteChannelConfigSlackTargetsBindingValueToTerraform(struct?: AlertRouteChannelConfigSlackTargetsBindingValue | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigSlackTargetsBindingValueToHclTerraform(struct?: AlertRouteChannelConfigSlackTargetsBindingValue | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigSlackTargetsBindingValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigSlackTargetsBindingValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigSlackTargetsBindingValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteChannelConfigSlackTargetsBinding {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteChannelConfigSlackTargetsBindingArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteChannelConfigSlackTargetsBindingValue;
}
export declare function alertRouteChannelConfigSlackTargetsBindingToTerraform(struct?: AlertRouteChannelConfigSlackTargetsBinding | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigSlackTargetsBindingToHclTerraform(struct?: AlertRouteChannelConfigSlackTargetsBinding | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigSlackTargetsBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigSlackTargetsBinding | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigSlackTargetsBinding | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteChannelConfigSlackTargetsBindingArrayValueList;
    putArrayValue(value: AlertRouteChannelConfigSlackTargetsBindingArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteChannelConfigSlackTargetsBindingArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteChannelConfigSlackTargetsBindingValueOutputReference;
    putValue(value: AlertRouteChannelConfigSlackTargetsBindingValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteChannelConfigSlackTargetsBindingValue | undefined;
}
export interface AlertRouteChannelConfigSlackTargets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#binding AlertRoute#binding}
    */
    readonly binding: AlertRouteChannelConfigSlackTargetsBinding;
    /**
    * The visibility of the channel
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#channel_visibility AlertRoute#channel_visibility}
    */
    readonly channelVisibility: string;
}
export declare function alertRouteChannelConfigSlackTargetsToTerraform(struct?: AlertRouteChannelConfigSlackTargets | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigSlackTargetsToHclTerraform(struct?: AlertRouteChannelConfigSlackTargets | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigSlackTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteChannelConfigSlackTargets | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfigSlackTargets | cdktf.IResolvable | undefined);
    private _binding;
    get binding(): AlertRouteChannelConfigSlackTargetsBindingOutputReference;
    putBinding(value: AlertRouteChannelConfigSlackTargetsBinding): void;
    get bindingInput(): cdktf.IResolvable | AlertRouteChannelConfigSlackTargetsBinding | undefined;
    private _channelVisibility?;
    get channelVisibility(): string;
    set channelVisibility(value: string);
    get channelVisibilityInput(): string | undefined;
}
export interface AlertRouteChannelConfig {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteChannelConfigConditionGroups[] | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#ms_teams_targets AlertRoute#ms_teams_targets}
    */
    readonly msTeamsTargets?: AlertRouteChannelConfigMsTeamsTargets;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#slack_targets AlertRoute#slack_targets}
    */
    readonly slackTargets?: AlertRouteChannelConfigSlackTargets;
}
export declare function alertRouteChannelConfigToTerraform(struct?: AlertRouteChannelConfig | cdktf.IResolvable): any;
export declare function alertRouteChannelConfigToHclTerraform(struct?: AlertRouteChannelConfig | cdktf.IResolvable): any;
export declare class AlertRouteChannelConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteChannelConfig | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteChannelConfig | cdktf.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): AlertRouteChannelConfigConditionGroupsList;
    putConditionGroups(value: AlertRouteChannelConfigConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | AlertRouteChannelConfigConditionGroups[] | undefined;
    private _msTeamsTargets;
    get msTeamsTargets(): AlertRouteChannelConfigMsTeamsTargetsOutputReference;
    putMsTeamsTargets(value: AlertRouteChannelConfigMsTeamsTargets): void;
    resetMsTeamsTargets(): void;
    get msTeamsTargetsInput(): cdktf.IResolvable | AlertRouteChannelConfigMsTeamsTargets | undefined;
    private _slackTargets;
    get slackTargets(): AlertRouteChannelConfigSlackTargetsOutputReference;
    putSlackTargets(value: AlertRouteChannelConfigSlackTargets): void;
    resetSlackTargets(): void;
    get slackTargetsInput(): cdktf.IResolvable | AlertRouteChannelConfigSlackTargets | undefined;
}
export declare class AlertRouteChannelConfigList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteChannelConfig[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteChannelConfigOutputReference;
}
export interface AlertRouteConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function alertRouteConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function alertRouteConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class AlertRouteConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function alertRouteConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class AlertRouteConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteConditionGroupsConditionsToTerraform(struct?: AlertRouteConditionGroupsConditions | cdktf.IResolvable): any;
export declare function alertRouteConditionGroupsConditionsToHclTerraform(struct?: AlertRouteConditionGroupsConditions | cdktf.IResolvable): any;
export declare class AlertRouteConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | AlertRouteConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteConditionGroupsConditionsOutputReference;
}
export interface AlertRouteConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function alertRouteConditionGroupsToTerraform(struct?: AlertRouteConditionGroups | cdktf.IResolvable): any;
export declare function alertRouteConditionGroupsToHclTerraform(struct?: AlertRouteConditionGroups | cdktf.IResolvable): any;
export declare class AlertRouteConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteConditionGroupsConditionsList;
    putConditions(value: AlertRouteConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | AlertRouteConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteConditionGroupsOutputReference;
}
export interface AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue | cdktf.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueOutputReference;
}
export interface AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsValueToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue | cdktf.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsValueToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue | cdktf.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsEscalationPathsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteEscalationConfigEscalationTargetsEscalationPaths {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue;
}
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPaths | cdktf.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsEscalationPathsToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsEscalationPaths | cdktf.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsEscalationPathsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsEscalationPaths | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsEscalationPaths | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValueList;
    putArrayValue(value: AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteEscalationConfigEscalationTargetsEscalationPathsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteEscalationConfigEscalationTargetsEscalationPathsValueOutputReference;
    putValue(value: AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteEscalationConfigEscalationTargetsEscalationPathsValue | undefined;
}
export interface AlertRouteEscalationConfigEscalationTargetsUsersArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteEscalationConfigEscalationTargetsUsersArrayValueToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue | cdktf.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsUsersArrayValueToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsUsersArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsUsersArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteEscalationConfigEscalationTargetsUsersArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteEscalationConfigEscalationTargetsUsersArrayValueOutputReference;
}
export interface AlertRouteEscalationConfigEscalationTargetsUsersValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteEscalationConfigEscalationTargetsUsersValueToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsersValue | cdktf.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsUsersValueToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsersValue | cdktf.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsUsersValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsUsersValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsUsersValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteEscalationConfigEscalationTargetsUsers {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteEscalationConfigEscalationTargetsUsersValue;
}
export declare function alertRouteEscalationConfigEscalationTargetsUsersToTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsers | cdktf.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsUsersToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargetsUsers | cdktf.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsUsersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteEscalationConfigEscalationTargetsUsers | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargetsUsers | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteEscalationConfigEscalationTargetsUsersArrayValueList;
    putArrayValue(value: AlertRouteEscalationConfigEscalationTargetsUsersArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteEscalationConfigEscalationTargetsUsersArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteEscalationConfigEscalationTargetsUsersValueOutputReference;
    putValue(value: AlertRouteEscalationConfigEscalationTargetsUsersValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteEscalationConfigEscalationTargetsUsersValue | undefined;
}
export interface AlertRouteEscalationConfigEscalationTargets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#escalation_paths AlertRoute#escalation_paths}
    */
    readonly escalationPaths?: AlertRouteEscalationConfigEscalationTargetsEscalationPaths;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#users AlertRoute#users}
    */
    readonly users?: AlertRouteEscalationConfigEscalationTargetsUsers;
}
export declare function alertRouteEscalationConfigEscalationTargetsToTerraform(struct?: AlertRouteEscalationConfigEscalationTargets | cdktf.IResolvable): any;
export declare function alertRouteEscalationConfigEscalationTargetsToHclTerraform(struct?: AlertRouteEscalationConfigEscalationTargets | cdktf.IResolvable): any;
export declare class AlertRouteEscalationConfigEscalationTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteEscalationConfigEscalationTargets | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfigEscalationTargets | cdktf.IResolvable | undefined);
    private _escalationPaths;
    get escalationPaths(): AlertRouteEscalationConfigEscalationTargetsEscalationPathsOutputReference;
    putEscalationPaths(value: AlertRouteEscalationConfigEscalationTargetsEscalationPaths): void;
    resetEscalationPaths(): void;
    get escalationPathsInput(): cdktf.IResolvable | AlertRouteEscalationConfigEscalationTargetsEscalationPaths | undefined;
    private _users;
    get users(): AlertRouteEscalationConfigEscalationTargetsUsersOutputReference;
    putUsers(value: AlertRouteEscalationConfigEscalationTargetsUsers): void;
    resetUsers(): void;
    get usersInput(): cdktf.IResolvable | AlertRouteEscalationConfigEscalationTargetsUsers | undefined;
}
export declare class AlertRouteEscalationConfigEscalationTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteEscalationConfigEscalationTargets[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteEscalationConfigEscalationTargetsOutputReference;
}
export interface AlertRouteEscalationConfig {
    /**
    * Should we auto cancel escalations when all alerts are resolved?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#auto_cancel_escalations AlertRoute#auto_cancel_escalations}
    */
    readonly autoCancelEscalations: boolean | cdktf.IResolvable;
    /**
    * Targets for escalation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#escalation_targets AlertRoute#escalation_targets}
    */
    readonly escalationTargets: AlertRouteEscalationConfigEscalationTargets[] | cdktf.IResolvable;
}
export declare function alertRouteEscalationConfigToTerraform(struct?: AlertRouteEscalationConfig | cdktf.IResolvable): any;
export declare function alertRouteEscalationConfigToHclTerraform(struct?: AlertRouteEscalationConfig | cdktf.IResolvable): any;
export declare class AlertRouteEscalationConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteEscalationConfig | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteEscalationConfig | cdktf.IResolvable | undefined);
    private _autoCancelEscalations?;
    get autoCancelEscalations(): boolean | cdktf.IResolvable;
    set autoCancelEscalations(value: boolean | cdktf.IResolvable);
    get autoCancelEscalationsInput(): boolean | cdktf.IResolvable | undefined;
    private _escalationTargets;
    get escalationTargets(): AlertRouteEscalationConfigEscalationTargetsList;
    putEscalationTargets(value: AlertRouteEscalationConfigEscalationTargets[] | cdktf.IResolvable): void;
    get escalationTargetsInput(): cdktf.IResolvable | AlertRouteEscalationConfigEscalationTargets[] | undefined;
}
export interface AlertRouteExpressionsElseBranchResultArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsElseBranchResultArrayValueToTerraform(struct?: AlertRouteExpressionsElseBranchResultArrayValue | cdktf.IResolvable): any;
export declare function alertRouteExpressionsElseBranchResultArrayValueToHclTerraform(struct?: AlertRouteExpressionsElseBranchResultArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsElseBranchResultArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsElseBranchResultArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsElseBranchResultArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteExpressionsElseBranchResultArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsElseBranchResultArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsElseBranchResultArrayValueOutputReference;
}
export interface AlertRouteExpressionsElseBranchResultValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsElseBranchResultValueToTerraform(struct?: AlertRouteExpressionsElseBranchResultValue | cdktf.IResolvable): any;
export declare function alertRouteExpressionsElseBranchResultValueToHclTerraform(struct?: AlertRouteExpressionsElseBranchResultValue | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsElseBranchResultValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsElseBranchResultValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsElseBranchResultValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteExpressionsElseBranchResult {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteExpressionsElseBranchResultArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteExpressionsElseBranchResultValue;
}
export declare function alertRouteExpressionsElseBranchResultToTerraform(struct?: AlertRouteExpressionsElseBranchResult | cdktf.IResolvable): any;
export declare function alertRouteExpressionsElseBranchResultToHclTerraform(struct?: AlertRouteExpressionsElseBranchResult | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsElseBranchResultOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsElseBranchResult | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsElseBranchResult | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteExpressionsElseBranchResultArrayValueList;
    putArrayValue(value: AlertRouteExpressionsElseBranchResultArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteExpressionsElseBranchResultArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteExpressionsElseBranchResultValueOutputReference;
    putValue(value: AlertRouteExpressionsElseBranchResultValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteExpressionsElseBranchResultValue | undefined;
}
export interface AlertRouteExpressionsElseBranch {
    /**
    * The result assumed if the else branch is reached
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#result AlertRoute#result}
    */
    readonly result: AlertRouteExpressionsElseBranchResult;
}
export declare function alertRouteExpressionsElseBranchToTerraform(struct?: AlertRouteExpressionsElseBranch | cdktf.IResolvable): any;
export declare function alertRouteExpressionsElseBranchToHclTerraform(struct?: AlertRouteExpressionsElseBranch | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsElseBranchOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsElseBranch | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsElseBranch | cdktf.IResolvable | undefined);
    private _result;
    get result(): AlertRouteExpressionsElseBranchResultOutputReference;
    putResult(value: AlertRouteExpressionsElseBranchResult): void;
    get resultInput(): cdktf.IResolvable | AlertRouteExpressionsElseBranchResult | undefined;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesConditionGroupsToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditionsList;
    putConditions(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesResultArrayValueToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesResultArrayValueToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesResultArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesResultArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesResultArrayValueOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesResultValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesResultValueToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesResultValueToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesResultValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsBranchesBranchesResult {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteExpressionsOperationsBranchesBranchesResultValue;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesResultToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesResultToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesResultOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteExpressionsOperationsBranchesBranchesResultArrayValueList;
    putArrayValue(value: AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesResultArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteExpressionsOperationsBranchesBranchesResultValueOutputReference;
    putValue(value: AlertRouteExpressionsOperationsBranchesBranchesResultValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesResultValue | undefined;
}
export interface AlertRouteExpressionsOperationsBranchesBranches {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups[] | cdktf.IResolvable;
    /**
    * The result assumed if the condition groups are satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#result AlertRoute#result}
    */
    readonly result: AlertRouteExpressionsOperationsBranchesBranchesResult;
}
export declare function alertRouteExpressionsOperationsBranchesBranchesToTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranches | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesBranchesToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesBranches | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesBranchesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsBranchesBranches | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesBranches | cdktf.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): AlertRouteExpressionsOperationsBranchesBranchesConditionGroupsList;
    putConditionGroups(value: AlertRouteExpressionsOperationsBranchesBranchesConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesConditionGroups[] | undefined;
    private _result;
    get result(): AlertRouteExpressionsOperationsBranchesBranchesResultOutputReference;
    putResult(value: AlertRouteExpressionsOperationsBranchesBranchesResult): void;
    get resultInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranchesBranchesResult | undefined;
}
export declare class AlertRouteExpressionsOperationsBranchesBranchesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperationsBranchesBranches[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsBranchesBranchesOutputReference;
}
export interface AlertRouteExpressionsOperationsBranchesReturns {
    /**
    * Whether the return value should be single or multi-value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array AlertRoute#array}
    */
    readonly array: boolean | cdktf.IResolvable;
    /**
    * Expected return type of this expression (what to try casting the result to)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#type AlertRoute#type}
    */
    readonly type: string;
}
export declare function alertRouteExpressionsOperationsBranchesReturnsToTerraform(struct?: AlertRouteExpressionsOperationsBranchesReturns | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesReturnsToHclTerraform(struct?: AlertRouteExpressionsOperationsBranchesReturns | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesReturnsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsBranchesReturns | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranchesReturns | cdktf.IResolvable | undefined);
    private _array?;
    get array(): boolean | cdktf.IResolvable;
    set array(value: boolean | cdktf.IResolvable);
    get arrayInput(): boolean | cdktf.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsBranches {
    /**
    * The branches to apply for this operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#branches AlertRoute#branches}
    */
    readonly branches: AlertRouteExpressionsOperationsBranchesBranches[] | cdktf.IResolvable;
    /**
    * The return type of an operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#returns AlertRoute#returns}
    */
    readonly returns: AlertRouteExpressionsOperationsBranchesReturns;
}
export declare function alertRouteExpressionsOperationsBranchesToTerraform(struct?: AlertRouteExpressionsOperationsBranches | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsBranchesToHclTerraform(struct?: AlertRouteExpressionsOperationsBranches | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsBranchesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsBranches | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsBranches | cdktf.IResolvable | undefined);
    private _branches;
    get branches(): AlertRouteExpressionsOperationsBranchesBranchesList;
    putBranches(value: AlertRouteExpressionsOperationsBranchesBranches[] | cdktf.IResolvable): void;
    get branchesInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranchesBranches[] | undefined;
    private _returns;
    get returns(): AlertRouteExpressionsOperationsBranchesReturnsOutputReference;
    putReturns(value: AlertRouteExpressionsOperationsBranchesReturns): void;
    get returnsInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranchesReturns | undefined;
}
export interface AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteExpressionsOperationsFilterConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsToTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterConditionGroupsConditionsToHclTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperationsFilterConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsOutputReference;
}
export interface AlertRouteExpressionsOperationsFilterConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteExpressionsOperationsFilterConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function alertRouteExpressionsOperationsFilterConditionGroupsToTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroups | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterConditionGroupsToHclTerraform(struct?: AlertRouteExpressionsOperationsFilterConditionGroups | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperationsFilterConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilterConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteExpressionsOperationsFilterConditionGroupsConditionsList;
    putConditions(value: AlertRouteExpressionsOperationsFilterConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsFilterConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteExpressionsOperationsFilterConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperationsFilterConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsFilterConditionGroupsOutputReference;
}
export interface AlertRouteExpressionsOperationsFilter {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteExpressionsOperationsFilterConditionGroups[] | cdktf.IResolvable;
}
export declare function alertRouteExpressionsOperationsFilterToTerraform(struct?: AlertRouteExpressionsOperationsFilter | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsFilterToHclTerraform(struct?: AlertRouteExpressionsOperationsFilter | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsFilter | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsFilter | cdktf.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): AlertRouteExpressionsOperationsFilterConditionGroupsList;
    putConditionGroups(value: AlertRouteExpressionsOperationsFilterConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsFilterConditionGroups[] | undefined;
}
export interface AlertRouteExpressionsOperationsNavigate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference: string;
}
export declare function alertRouteExpressionsOperationsNavigateToTerraform(struct?: AlertRouteExpressionsOperationsNavigate | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsNavigateToHclTerraform(struct?: AlertRouteExpressionsOperationsNavigate | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsNavigateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsNavigate | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsNavigate | cdktf.IResolvable | undefined);
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsParseReturns {
    /**
    * Whether the return value should be single or multi-value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array AlertRoute#array}
    */
    readonly array: boolean | cdktf.IResolvable;
    /**
    * Expected return type of this expression (what to try casting the result to)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#type AlertRoute#type}
    */
    readonly type: string;
}
export declare function alertRouteExpressionsOperationsParseReturnsToTerraform(struct?: AlertRouteExpressionsOperationsParseReturns | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsParseReturnsToHclTerraform(struct?: AlertRouteExpressionsOperationsParseReturns | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsParseReturnsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsParseReturns | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsParseReturns | cdktf.IResolvable | undefined);
    private _array?;
    get array(): boolean | cdktf.IResolvable;
    set array(value: boolean | cdktf.IResolvable);
    get arrayInput(): boolean | cdktf.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface AlertRouteExpressionsOperationsParse {
    /**
    * The return type of an operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#returns AlertRoute#returns}
    */
    readonly returns: AlertRouteExpressionsOperationsParseReturns;
    /**
    * The ES5 Javascript expression to execute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#source AlertRoute#source}
    */
    readonly source: string;
}
export declare function alertRouteExpressionsOperationsParseToTerraform(struct?: AlertRouteExpressionsOperationsParse | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsParseToHclTerraform(struct?: AlertRouteExpressionsOperationsParse | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsParseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteExpressionsOperationsParse | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperationsParse | cdktf.IResolvable | undefined);
    private _returns;
    get returns(): AlertRouteExpressionsOperationsParseReturnsOutputReference;
    putReturns(value: AlertRouteExpressionsOperationsParseReturns): void;
    get returnsInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsParseReturns | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export interface AlertRouteExpressionsOperations {
    /**
    * An operation type that allows for a value to be set conditionally by a series of logical branches
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#branches AlertRoute#branches}
    */
    readonly branches?: AlertRouteExpressionsOperationsBranches;
    /**
    * An operation type that allows values to be filtered out by conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#filter AlertRoute#filter}
    */
    readonly filter?: AlertRouteExpressionsOperationsFilter;
    /**
    * An operation type that allows attributes of a type to be accessed by reference
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#navigate AlertRoute#navigate}
    */
    readonly navigate?: AlertRouteExpressionsOperationsNavigate;
    /**
    * Indicates which operation type to execute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation_type AlertRoute#operation_type}
    */
    readonly operationType: string;
    /**
    * An operation type that allows a value to parsed from within a JSON object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#parse AlertRoute#parse}
    */
    readonly parse?: AlertRouteExpressionsOperationsParse;
}
export declare function alertRouteExpressionsOperationsToTerraform(struct?: AlertRouteExpressionsOperations | cdktf.IResolvable): any;
export declare function alertRouteExpressionsOperationsToHclTerraform(struct?: AlertRouteExpressionsOperations | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOperationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressionsOperations | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressionsOperations | cdktf.IResolvable | undefined);
    private _branches;
    get branches(): AlertRouteExpressionsOperationsBranchesOutputReference;
    putBranches(value: AlertRouteExpressionsOperationsBranches): void;
    resetBranches(): void;
    get branchesInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsBranches | undefined;
    private _filter;
    get filter(): AlertRouteExpressionsOperationsFilterOutputReference;
    putFilter(value: AlertRouteExpressionsOperationsFilter): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsFilter | undefined;
    private _navigate;
    get navigate(): AlertRouteExpressionsOperationsNavigateOutputReference;
    putNavigate(value: AlertRouteExpressionsOperationsNavigate): void;
    resetNavigate(): void;
    get navigateInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsNavigate | undefined;
    private _operationType?;
    get operationType(): string;
    set operationType(value: string);
    get operationTypeInput(): string | undefined;
    private _parse;
    get parse(): AlertRouteExpressionsOperationsParseOutputReference;
    putParse(value: AlertRouteExpressionsOperationsParse): void;
    resetParse(): void;
    get parseInput(): cdktf.IResolvable | AlertRouteExpressionsOperationsParse | undefined;
}
export declare class AlertRouteExpressionsOperationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressionsOperations[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOperationsOutputReference;
}
export interface AlertRouteExpressions {
    /**
    * The else branch to resort to if all operations fail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#else_branch AlertRoute#else_branch}
    */
    readonly elseBranch?: AlertRouteExpressionsElseBranch;
    /**
    * The human readable label of the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#label AlertRoute#label}
    */
    readonly label: string;
    /**
    * The operations to execute in sequence for this expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operations AlertRoute#operations}
    */
    readonly operations: AlertRouteExpressionsOperations[] | cdktf.IResolvable;
    /**
    * A short ID that can be used to reference the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference: string;
    /**
    * The root reference for this expression (i.e. where the expression starts)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#root_reference AlertRoute#root_reference}
    */
    readonly rootReference: string;
}
export declare function alertRouteExpressionsToTerraform(struct?: AlertRouteExpressions | cdktf.IResolvable): any;
export declare function alertRouteExpressionsToHclTerraform(struct?: AlertRouteExpressions | cdktf.IResolvable): any;
export declare class AlertRouteExpressionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteExpressions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteExpressions | cdktf.IResolvable | undefined);
    private _elseBranch;
    get elseBranch(): AlertRouteExpressionsElseBranchOutputReference;
    putElseBranch(value: AlertRouteExpressionsElseBranch): void;
    resetElseBranch(): void;
    get elseBranchInput(): cdktf.IResolvable | AlertRouteExpressionsElseBranch | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _operations;
    get operations(): AlertRouteExpressionsOperationsList;
    putOperations(value: AlertRouteExpressionsOperations[] | cdktf.IResolvable): void;
    get operationsInput(): cdktf.IResolvable | AlertRouteExpressionsOperations[] | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
    private _rootReference?;
    get rootReference(): string;
    set rootReference(value: string);
    get rootReferenceInput(): string | undefined;
}
export declare class AlertRouteExpressionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteExpressions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteExpressionsOutputReference;
}
export interface AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentConfigConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue;
}
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function alertRouteIncidentConfigConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertRouteIncidentConfigConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#operation AlertRoute#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#param_bindings AlertRoute#param_bindings}
    */
    readonly paramBindings: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#subject AlertRoute#subject}
    */
    readonly subject: string;
}
export declare function alertRouteIncidentConfigConditionGroupsConditionsToTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditions | cdktf.IResolvable): any;
export declare function alertRouteIncidentConfigConditionGroupsConditionsToHclTerraform(struct?: AlertRouteIncidentConfigConditionGroupsConditions | cdktf.IResolvable): any;
export declare class AlertRouteIncidentConfigConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentConfigConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertRouteIncidentConfigConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertRouteIncidentConfigConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | AlertRouteIncidentConfigConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertRouteIncidentConfigConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentConfigConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentConfigConditionGroupsConditionsOutputReference;
}
export interface AlertRouteIncidentConfigConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#conditions AlertRoute#conditions}
    */
    readonly conditions: AlertRouteIncidentConfigConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function alertRouteIncidentConfigConditionGroupsToTerraform(struct?: AlertRouteIncidentConfigConditionGroups | cdktf.IResolvable): any;
export declare function alertRouteIncidentConfigConditionGroupsToHclTerraform(struct?: AlertRouteIncidentConfigConditionGroups | cdktf.IResolvable): any;
export declare class AlertRouteIncidentConfigConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentConfigConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertRouteIncidentConfigConditionGroupsConditionsList;
    putConditions(value: AlertRouteIncidentConfigConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | AlertRouteIncidentConfigConditionGroupsConditions[] | undefined;
}
export declare class AlertRouteIncidentConfigConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentConfigConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentConfigConditionGroupsOutputReference;
}
export interface AlertRouteIncidentConfigGroupingKeys {
    /**
    * The alert attribute ID to use as a grouping key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference: string;
}
export declare function alertRouteIncidentConfigGroupingKeysToTerraform(struct?: AlertRouteIncidentConfigGroupingKeys | cdktf.IResolvable): any;
export declare function alertRouteIncidentConfigGroupingKeysToHclTerraform(struct?: AlertRouteIncidentConfigGroupingKeys | cdktf.IResolvable): any;
export declare class AlertRouteIncidentConfigGroupingKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentConfigGroupingKeys | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfigGroupingKeys | cdktf.IResolvable | undefined);
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentConfigGroupingKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentConfigGroupingKeys[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentConfigGroupingKeysOutputReference;
}
export interface AlertRouteIncidentConfig {
    /**
    * Should triage incidents be declined when alerts are resolved?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#auto_decline_enabled AlertRoute#auto_decline_enabled}
    */
    readonly autoDeclineEnabled: boolean | cdktf.IResolvable;
    /**
    * Should grouped alerts automatically be related to active incidents without confirmation?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#auto_relate_grouped_alerts AlertRoute#auto_relate_grouped_alerts}
    */
    readonly autoRelateGroupedAlerts?: boolean | cdktf.IResolvable;
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#condition_groups AlertRoute#condition_groups}
    */
    readonly conditionGroups: AlertRouteIncidentConfigConditionGroups[] | cdktf.IResolvable;
    /**
    * How long should the escalation defer time be?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#defer_time_seconds AlertRoute#defer_time_seconds}
    */
    readonly deferTimeSeconds: number;
    /**
    * Whether incident creation is enabled for this alert route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#enabled AlertRoute#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * Which attributes should this alert route use to group alerts?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#grouping_keys AlertRoute#grouping_keys}
    */
    readonly groupingKeys: AlertRouteIncidentConfigGroupingKeys[] | cdktf.IResolvable;
    /**
    * How large should the grouping window be?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#grouping_window_seconds AlertRoute#grouping_window_seconds}
    */
    readonly groupingWindowSeconds: number;
}
export declare function alertRouteIncidentConfigToTerraform(struct?: AlertRouteIncidentConfig | cdktf.IResolvable): any;
export declare function alertRouteIncidentConfigToHclTerraform(struct?: AlertRouteIncidentConfig | cdktf.IResolvable): any;
export declare class AlertRouteIncidentConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentConfig | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentConfig | cdktf.IResolvable | undefined);
    private _autoDeclineEnabled?;
    get autoDeclineEnabled(): boolean | cdktf.IResolvable;
    set autoDeclineEnabled(value: boolean | cdktf.IResolvable);
    get autoDeclineEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _autoRelateGroupedAlerts?;
    get autoRelateGroupedAlerts(): boolean | cdktf.IResolvable;
    set autoRelateGroupedAlerts(value: boolean | cdktf.IResolvable);
    resetAutoRelateGroupedAlerts(): void;
    get autoRelateGroupedAlertsInput(): boolean | cdktf.IResolvable | undefined;
    private _conditionGroups;
    get conditionGroups(): AlertRouteIncidentConfigConditionGroupsList;
    putConditionGroups(value: AlertRouteIncidentConfigConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | AlertRouteIncidentConfigConditionGroups[] | undefined;
    private _deferTimeSeconds?;
    get deferTimeSeconds(): number;
    set deferTimeSeconds(value: number);
    get deferTimeSecondsInput(): number | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _groupingKeys;
    get groupingKeys(): AlertRouteIncidentConfigGroupingKeysList;
    putGroupingKeys(value: AlertRouteIncidentConfigGroupingKeys[] | cdktf.IResolvable): void;
    get groupingKeysInput(): cdktf.IResolvable | AlertRouteIncidentConfigGroupingKeys[] | undefined;
    private _groupingWindowSeconds?;
    get groupingWindowSeconds(): number;
    set groupingWindowSeconds(value: number);
    get groupingWindowSecondsInput(): number | undefined;
}
export interface AlertRouteIncidentTemplateCustomFieldsBindingArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateCustomFieldsBindingArrayValueToTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateCustomFieldsBindingArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateCustomFieldsBindingArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateCustomFieldsBindingArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateCustomFieldsBindingArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateCustomFieldsBindingArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateCustomFieldsBindingValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateCustomFieldsBindingValueToTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBindingValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateCustomFieldsBindingValueToHclTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBindingValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateCustomFieldsBindingValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateCustomFieldsBindingValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateCustomFieldsBindingValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateCustomFieldsBinding {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateCustomFieldsBindingValue;
}
export declare function alertRouteIncidentTemplateCustomFieldsBindingToTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBinding | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateCustomFieldsBindingToHclTerraform(struct?: AlertRouteIncidentTemplateCustomFieldsBinding | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateCustomFieldsBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateCustomFieldsBinding | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateCustomFieldsBinding | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateCustomFieldsBindingArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateCustomFieldsBindingArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateCustomFieldsBindingArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateCustomFieldsBindingValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateCustomFieldsBindingValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateCustomFieldsBindingValue | undefined;
}
export interface AlertRouteIncidentTemplateCustomFields {
    /**
    * Binding for the custom field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#binding AlertRoute#binding}
    */
    readonly binding: AlertRouteIncidentTemplateCustomFieldsBinding;
    /**
    * ID of the custom field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#custom_field_id AlertRoute#custom_field_id}
    */
    readonly customFieldId: string;
    /**
    * The strategy to use when multiple alerts match this route. Possible values are: `first-wins`, `last-wins`, `append`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#merge_strategy AlertRoute#merge_strategy}
    */
    readonly mergeStrategy: string;
}
export declare function alertRouteIncidentTemplateCustomFieldsToTerraform(struct?: AlertRouteIncidentTemplateCustomFields | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateCustomFieldsToHclTerraform(struct?: AlertRouteIncidentTemplateCustomFields | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateCustomFieldsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateCustomFields | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateCustomFields | cdktf.IResolvable | undefined);
    private _binding;
    get binding(): AlertRouteIncidentTemplateCustomFieldsBindingOutputReference;
    putBinding(value: AlertRouteIncidentTemplateCustomFieldsBinding): void;
    get bindingInput(): cdktf.IResolvable | AlertRouteIncidentTemplateCustomFieldsBinding | undefined;
    private _customFieldId?;
    get customFieldId(): string;
    set customFieldId(value: string);
    get customFieldIdInput(): string | undefined;
    private _mergeStrategy?;
    get mergeStrategy(): string;
    set mergeStrategy(value: string);
    get mergeStrategyInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateCustomFieldsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentTemplateCustomFields[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateCustomFieldsOutputReference;
}
export interface AlertRouteIncidentTemplateIncidentModeArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateIncidentModeArrayValueToTerraform(struct?: AlertRouteIncidentTemplateIncidentModeArrayValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentModeArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentModeArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentModeArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateIncidentModeArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentModeArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateIncidentModeArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentTemplateIncidentModeArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateIncidentModeArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateIncidentModeValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateIncidentModeValueToTerraform(struct?: AlertRouteIncidentTemplateIncidentModeValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentModeValueToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentModeValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentModeValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateIncidentModeValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentModeValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateIncidentMode {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateIncidentModeArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateIncidentModeValue;
}
export declare function alertRouteIncidentTemplateIncidentModeToTerraform(struct?: AlertRouteIncidentTemplateIncidentMode | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentModeToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentMode | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentModeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateIncidentMode | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentMode | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateIncidentModeArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateIncidentModeArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateIncidentModeArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateIncidentModeValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateIncidentModeValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateIncidentModeValue | undefined;
}
export interface AlertRouteIncidentTemplateIncidentTypeArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateIncidentTypeArrayValueToTerraform(struct?: AlertRouteIncidentTemplateIncidentTypeArrayValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentTypeArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentTypeArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentTypeArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateIncidentTypeArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentTypeArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateIncidentTypeArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentTemplateIncidentTypeArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateIncidentTypeArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateIncidentTypeValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateIncidentTypeValueToTerraform(struct?: AlertRouteIncidentTemplateIncidentTypeValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentTypeValueToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentTypeValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentTypeValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateIncidentTypeValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentTypeValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateIncidentType {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateIncidentTypeArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateIncidentTypeValue;
}
export declare function alertRouteIncidentTemplateIncidentTypeToTerraform(struct?: AlertRouteIncidentTemplateIncidentType | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateIncidentTypeToHclTerraform(struct?: AlertRouteIncidentTemplateIncidentType | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateIncidentTypeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateIncidentType | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateIncidentType | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateIncidentTypeArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateIncidentTypeArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateIncidentTypeArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateIncidentTypeValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateIncidentTypeValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateIncidentTypeValue | undefined;
}
export interface AlertRouteIncidentTemplateNameArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateNameArrayValueToTerraform(struct?: AlertRouteIncidentTemplateNameArrayValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateNameArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateNameArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateNameArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateNameArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateNameArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateNameArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentTemplateNameArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateNameArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateNameValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateNameValueToTerraform(struct?: AlertRouteIncidentTemplateNameValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateNameValueToHclTerraform(struct?: AlertRouteIncidentTemplateNameValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateNameValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateNameValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateNameValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateName {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateNameArrayValue[] | cdktf.IResolvable;
    /**
    * Whether this attribute should be autogenerated using AI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#autogenerated AlertRoute#autogenerated}
    */
    readonly autogenerated?: boolean | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateNameValue;
}
export declare function alertRouteIncidentTemplateNameToTerraform(struct?: AlertRouteIncidentTemplateName | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateNameToHclTerraform(struct?: AlertRouteIncidentTemplateName | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateNameOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateName | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateName | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateNameArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateNameArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateNameArrayValue[] | undefined;
    private _autogenerated?;
    get autogenerated(): boolean | cdktf.IResolvable;
    set autogenerated(value: boolean | cdktf.IResolvable);
    resetAutogenerated(): void;
    get autogeneratedInput(): boolean | cdktf.IResolvable | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateNameValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateNameValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateNameValue | undefined;
}
export interface AlertRouteIncidentTemplateSeverityBindingArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateSeverityBindingArrayValueToTerraform(struct?: AlertRouteIncidentTemplateSeverityBindingArrayValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateSeverityBindingArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateSeverityBindingArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateSeverityBindingArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateSeverityBindingArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSeverityBindingArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateSeverityBindingArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentTemplateSeverityBindingArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateSeverityBindingArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateSeverityBindingValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateSeverityBindingValueToTerraform(struct?: AlertRouteIncidentTemplateSeverityBindingValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateSeverityBindingValueToHclTerraform(struct?: AlertRouteIncidentTemplateSeverityBindingValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateSeverityBindingValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateSeverityBindingValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSeverityBindingValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateSeverityBinding {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateSeverityBindingArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateSeverityBindingValue;
}
export declare function alertRouteIncidentTemplateSeverityBindingToTerraform(struct?: AlertRouteIncidentTemplateSeverityBinding | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateSeverityBindingToHclTerraform(struct?: AlertRouteIncidentTemplateSeverityBinding | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateSeverityBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateSeverityBinding | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSeverityBinding | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateSeverityBindingArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateSeverityBindingArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateSeverityBindingArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateSeverityBindingValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateSeverityBindingValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateSeverityBindingValue | undefined;
}
export interface AlertRouteIncidentTemplateSeverity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#binding AlertRoute#binding}
    */
    readonly binding?: AlertRouteIncidentTemplateSeverityBinding;
    /**
    * Strategy for merging severity when multiple alerts create/update the same incident. Possible values are: `first-wins`, `max`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#merge_strategy AlertRoute#merge_strategy}
    */
    readonly mergeStrategy: string;
}
export declare function alertRouteIncidentTemplateSeverityToTerraform(struct?: AlertRouteIncidentTemplateSeverity | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateSeverityToHclTerraform(struct?: AlertRouteIncidentTemplateSeverity | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateSeverityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateSeverity | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSeverity | cdktf.IResolvable | undefined);
    private _binding;
    get binding(): AlertRouteIncidentTemplateSeverityBindingOutputReference;
    putBinding(value: AlertRouteIncidentTemplateSeverityBinding): void;
    resetBinding(): void;
    get bindingInput(): cdktf.IResolvable | AlertRouteIncidentTemplateSeverityBinding | undefined;
    private _mergeStrategy?;
    get mergeStrategy(): string;
    set mergeStrategy(value: string);
    get mergeStrategyInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateStartInTriageArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateStartInTriageArrayValueToTerraform(struct?: AlertRouteIncidentTemplateStartInTriageArrayValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateStartInTriageArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateStartInTriageArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateStartInTriageArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateStartInTriageArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateStartInTriageArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateStartInTriageArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentTemplateStartInTriageArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateStartInTriageArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateStartInTriageValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateStartInTriageValueToTerraform(struct?: AlertRouteIncidentTemplateStartInTriageValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateStartInTriageValueToHclTerraform(struct?: AlertRouteIncidentTemplateStartInTriageValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateStartInTriageValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateStartInTriageValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateStartInTriageValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateStartInTriage {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateStartInTriageArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateStartInTriageValue;
}
export declare function alertRouteIncidentTemplateStartInTriageToTerraform(struct?: AlertRouteIncidentTemplateStartInTriage | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateStartInTriageToHclTerraform(struct?: AlertRouteIncidentTemplateStartInTriage | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateStartInTriageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateStartInTriage | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateStartInTriage | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateStartInTriageArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateStartInTriageArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateStartInTriageArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateStartInTriageValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateStartInTriageValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateStartInTriageValue | undefined;
}
export interface AlertRouteIncidentTemplateSummaryArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateSummaryArrayValueToTerraform(struct?: AlertRouteIncidentTemplateSummaryArrayValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateSummaryArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateSummaryArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateSummaryArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateSummaryArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSummaryArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateSummaryArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentTemplateSummaryArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateSummaryArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateSummaryValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateSummaryValueToTerraform(struct?: AlertRouteIncidentTemplateSummaryValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateSummaryValueToHclTerraform(struct?: AlertRouteIncidentTemplateSummaryValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateSummaryValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateSummaryValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSummaryValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateSummary {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateSummaryArrayValue[] | cdktf.IResolvable;
    /**
    * Whether this attribute should be autogenerated using AI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#autogenerated AlertRoute#autogenerated}
    */
    readonly autogenerated?: boolean | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateSummaryValue;
}
export declare function alertRouteIncidentTemplateSummaryToTerraform(struct?: AlertRouteIncidentTemplateSummary | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateSummaryToHclTerraform(struct?: AlertRouteIncidentTemplateSummary | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateSummaryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateSummary | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateSummary | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateSummaryArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateSummaryArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateSummaryArrayValue[] | undefined;
    private _autogenerated?;
    get autogenerated(): boolean | cdktf.IResolvable;
    set autogenerated(value: boolean | cdktf.IResolvable);
    resetAutogenerated(): void;
    get autogeneratedInput(): boolean | cdktf.IResolvable | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateSummaryValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateSummaryValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateSummaryValue | undefined;
}
export interface AlertRouteIncidentTemplateWorkspaceArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateWorkspaceArrayValueToTerraform(struct?: AlertRouteIncidentTemplateWorkspaceArrayValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateWorkspaceArrayValueToHclTerraform(struct?: AlertRouteIncidentTemplateWorkspaceArrayValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateWorkspaceArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertRouteIncidentTemplateWorkspaceArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateWorkspaceArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertRouteIncidentTemplateWorkspaceArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertRouteIncidentTemplateWorkspaceArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertRouteIncidentTemplateWorkspaceArrayValueOutputReference;
}
export interface AlertRouteIncidentTemplateWorkspaceValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#literal AlertRoute#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#reference AlertRoute#reference}
    */
    readonly reference?: string;
}
export declare function alertRouteIncidentTemplateWorkspaceValueToTerraform(struct?: AlertRouteIncidentTemplateWorkspaceValue | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateWorkspaceValueToHclTerraform(struct?: AlertRouteIncidentTemplateWorkspaceValue | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateWorkspaceValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateWorkspaceValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateWorkspaceValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertRouteIncidentTemplateWorkspace {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#array_value AlertRoute#array_value}
    */
    readonly arrayValue?: AlertRouteIncidentTemplateWorkspaceArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#value AlertRoute#value}
    */
    readonly value?: AlertRouteIncidentTemplateWorkspaceValue;
}
export declare function alertRouteIncidentTemplateWorkspaceToTerraform(struct?: AlertRouteIncidentTemplateWorkspace | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateWorkspaceToHclTerraform(struct?: AlertRouteIncidentTemplateWorkspace | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateWorkspaceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplateWorkspace | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplateWorkspace | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertRouteIncidentTemplateWorkspaceArrayValueList;
    putArrayValue(value: AlertRouteIncidentTemplateWorkspaceArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateWorkspaceArrayValue[] | undefined;
    private _value;
    get value(): AlertRouteIncidentTemplateWorkspaceValueOutputReference;
    putValue(value: AlertRouteIncidentTemplateWorkspaceValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertRouteIncidentTemplateWorkspaceValue | undefined;
}
export interface AlertRouteIncidentTemplate {
    /**
    * Custom fields configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#custom_fields AlertRoute#custom_fields}
    */
    readonly customFields?: AlertRouteIncidentTemplateCustomFields[] | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#incident_mode AlertRoute#incident_mode}
    */
    readonly incidentMode?: AlertRouteIncidentTemplateIncidentMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#incident_type AlertRoute#incident_type}
    */
    readonly incidentType?: AlertRouteIncidentTemplateIncidentType;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#name AlertRoute#name}
    */
    readonly name: AlertRouteIncidentTemplateName;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#severity AlertRoute#severity}
    */
    readonly severity?: AlertRouteIncidentTemplateSeverity;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#start_in_triage AlertRoute#start_in_triage}
    */
    readonly startInTriage?: AlertRouteIncidentTemplateStartInTriage;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#summary AlertRoute#summary}
    */
    readonly summary: AlertRouteIncidentTemplateSummary;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#workspace AlertRoute#workspace}
    */
    readonly workspace?: AlertRouteIncidentTemplateWorkspace;
}
export declare function alertRouteIncidentTemplateToTerraform(struct?: AlertRouteIncidentTemplate | cdktf.IResolvable): any;
export declare function alertRouteIncidentTemplateToHclTerraform(struct?: AlertRouteIncidentTemplate | cdktf.IResolvable): any;
export declare class AlertRouteIncidentTemplateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertRouteIncidentTemplate | cdktf.IResolvable | undefined;
    set internalValue(value: AlertRouteIncidentTemplate | cdktf.IResolvable | undefined);
    private _customFields;
    get customFields(): AlertRouteIncidentTemplateCustomFieldsList;
    putCustomFields(value: AlertRouteIncidentTemplateCustomFields[] | cdktf.IResolvable): void;
    resetCustomFields(): void;
    get customFieldsInput(): cdktf.IResolvable | AlertRouteIncidentTemplateCustomFields[] | undefined;
    private _incidentMode;
    get incidentMode(): AlertRouteIncidentTemplateIncidentModeOutputReference;
    putIncidentMode(value: AlertRouteIncidentTemplateIncidentMode): void;
    resetIncidentMode(): void;
    get incidentModeInput(): cdktf.IResolvable | AlertRouteIncidentTemplateIncidentMode | undefined;
    private _incidentType;
    get incidentType(): AlertRouteIncidentTemplateIncidentTypeOutputReference;
    putIncidentType(value: AlertRouteIncidentTemplateIncidentType): void;
    resetIncidentType(): void;
    get incidentTypeInput(): cdktf.IResolvable | AlertRouteIncidentTemplateIncidentType | undefined;
    private _name;
    get name(): AlertRouteIncidentTemplateNameOutputReference;
    putName(value: AlertRouteIncidentTemplateName): void;
    get nameInput(): cdktf.IResolvable | AlertRouteIncidentTemplateName | undefined;
    private _severity;
    get severity(): AlertRouteIncidentTemplateSeverityOutputReference;
    putSeverity(value: AlertRouteIncidentTemplateSeverity): void;
    resetSeverity(): void;
    get severityInput(): cdktf.IResolvable | AlertRouteIncidentTemplateSeverity | undefined;
    private _startInTriage;
    get startInTriage(): AlertRouteIncidentTemplateStartInTriageOutputReference;
    putStartInTriage(value: AlertRouteIncidentTemplateStartInTriage): void;
    resetStartInTriage(): void;
    get startInTriageInput(): cdktf.IResolvable | AlertRouteIncidentTemplateStartInTriage | undefined;
    private _summary;
    get summary(): AlertRouteIncidentTemplateSummaryOutputReference;
    putSummary(value: AlertRouteIncidentTemplateSummary): void;
    get summaryInput(): cdktf.IResolvable | AlertRouteIncidentTemplateSummary | undefined;
    private _workspace;
    get workspace(): AlertRouteIncidentTemplateWorkspaceOutputReference;
    putWorkspace(value: AlertRouteIncidentTemplateWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): cdktf.IResolvable | AlertRouteIncidentTemplateWorkspace | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route incident_alert_route}
*/
export declare class AlertRoute extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_alert_route";
    /**
    * Generates CDKTF code for importing a AlertRoute resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertRoute to import
    * @param importFromId The id of the existing AlertRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/alert_route incident_alert_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertRouteConfig
    */
    constructor(scope: Construct, id: string, config: AlertRouteConfig);
    private _alertSources;
    get alertSources(): AlertRouteAlertSourcesList;
    putAlertSources(value: AlertRouteAlertSources[] | cdktf.IResolvable): void;
    get alertSourcesInput(): cdktf.IResolvable | AlertRouteAlertSources[] | undefined;
    private _channelConfig;
    get channelConfig(): AlertRouteChannelConfigList;
    putChannelConfig(value: AlertRouteChannelConfig[] | cdktf.IResolvable): void;
    resetChannelConfig(): void;
    get channelConfigInput(): cdktf.IResolvable | AlertRouteChannelConfig[] | undefined;
    private _conditionGroups;
    get conditionGroups(): AlertRouteConditionGroupsList;
    putConditionGroups(value: AlertRouteConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | AlertRouteConditionGroups[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _escalationConfig;
    get escalationConfig(): AlertRouteEscalationConfigOutputReference;
    putEscalationConfig(value: AlertRouteEscalationConfig): void;
    get escalationConfigInput(): cdktf.IResolvable | AlertRouteEscalationConfig | undefined;
    private _expressions;
    get expressions(): AlertRouteExpressionsList;
    putExpressions(value: AlertRouteExpressions[] | cdktf.IResolvable): void;
    get expressionsInput(): cdktf.IResolvable | AlertRouteExpressions[] | undefined;
    get id(): string;
    private _incidentConfig;
    get incidentConfig(): AlertRouteIncidentConfigOutputReference;
    putIncidentConfig(value: AlertRouteIncidentConfig): void;
    get incidentConfigInput(): cdktf.IResolvable | AlertRouteIncidentConfig | undefined;
    private _incidentTemplate;
    get incidentTemplate(): AlertRouteIncidentTemplateOutputReference;
    putIncidentTemplate(value: AlertRouteIncidentTemplate): void;
    get incidentTemplateInput(): cdktf.IResolvable | AlertRouteIncidentTemplate | undefined;
    private _isPrivate?;
    get isPrivate(): boolean | cdktf.IResolvable;
    set isPrivate(value: boolean | cdktf.IResolvable);
    get isPrivateInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
