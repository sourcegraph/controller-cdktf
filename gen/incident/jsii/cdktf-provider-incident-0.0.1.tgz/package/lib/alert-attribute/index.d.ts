import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AlertAttributeConfig extends cdktf.TerraformMetaArguments {
    /**
    * Whether this attribute is an array
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_attribute#array AlertAttribute#array}
    */
    readonly array: boolean | cdktf.IResolvable;
    /**
    * Unique name of this attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_attribute#name AlertAttribute#name}
    */
    readonly name: string;
    /**
    * Whether this attribute is required. If this field is not set, the existing setting will be preserved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_attribute#required AlertAttribute#required}
    */
    readonly required?: boolean | cdktf.IResolvable;
    /**
    * Engine resource name for this attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_attribute#type AlertAttribute#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_attribute incident_alert_attribute}
*/
export declare class AlertAttribute extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_alert_attribute";
    /**
    * Generates CDKTF code for importing a AlertAttribute resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertAttribute to import
    * @param importFromId The id of the existing AlertAttribute that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_attribute#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertAttribute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_attribute incident_alert_attribute} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertAttributeConfig
    */
    constructor(scope: Construct, id: string, config: AlertAttributeConfig);
    private _array?;
    get array(): boolean | cdktf.IResolvable;
    set array(value: boolean | cdktf.IResolvable);
    get arrayInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktf.IResolvable;
    set required(value: boolean | cdktf.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktf.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
