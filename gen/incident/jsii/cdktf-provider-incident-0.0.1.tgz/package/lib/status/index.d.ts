import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface StatusConfig extends cdktf.TerraformMetaArguments {
    /**
    * What category of status it is. All statuses apart from live (renamed in the app to Active) and learning (renamed in the app to Post-incident) are managed by incident.io and cannot be configured. Possible values are: `triage`, `declined`, `merged`, `canceled`, `live`, `learning`, `closed`, `paused`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/status#category Status#category}
    */
    readonly category: string;
    /**
    * Rich text description of the incident status
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/status#description Status#description}
    */
    readonly description: string;
    /**
    * Unique name of this status
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/status#name Status#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/status incident_status}
*/
export declare class Status extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_status";
    /**
    * Generates CDKTF code for importing a Status resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Status to import
    * @param importFromId The id of the existing Status that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/status#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Status to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/status incident_status} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StatusConfig
    */
    constructor(scope: Construct, id: string, config: StatusConfig);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
