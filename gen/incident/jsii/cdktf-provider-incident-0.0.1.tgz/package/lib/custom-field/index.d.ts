import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CustomFieldConfig extends cdktf.TerraformMetaArguments {
    /**
    * For catalog fields, the ID of the associated catalog type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field#catalog_type_id CustomField#catalog_type_id}
    */
    readonly catalogTypeId?: string;
    /**
    * Description of the custom field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field#description CustomField#description}
    */
    readonly description: string;
    /**
    * Type of custom field. Possible values are: `single_select`, `multi_select`, `text`, `link`, `numeric`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field#field_type CustomField#field_type}
    */
    readonly fieldType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field#filter_by CustomField#filter_by}
    */
    readonly filterBy?: CustomFieldFilterBy;
    /**
    * For catalog fields, the ID of the attribute used to group catalog entries (if applicable)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field#group_by_catalog_attribute_id CustomField#group_by_catalog_attribute_id}
    */
    readonly groupByCatalogAttributeId?: string;
    /**
    * Which catalog attribute provides helptext for the options
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field#helptext_catalog_attribute_id CustomField#helptext_catalog_attribute_id}
    */
    readonly helptextCatalogAttributeId?: string;
    /**
    * Human readable name for the custom field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field#name CustomField#name}
    */
    readonly name: string;
}
export interface CustomFieldFilterBy {
    /**
    * This must be an attribute of the catalog type of this custom field. It must be an attribute that points to another catalog type (so not a plain string, number, or boolean attribute).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field#catalog_attribute_id CustomField#catalog_attribute_id}
    */
    readonly catalogAttributeId: string;
    /**
    * This must be the ID of a custom field, which must have values of the same type as the attribute you are filtering by.
    *
    * When this filtering field is set on an incident, the options for this custom field will be filtered to only those with the attribute value that matches the value of the filtering field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field#custom_field_id CustomField#custom_field_id}
    */
    readonly customFieldId: string;
}
export declare function customFieldFilterByToTerraform(struct?: CustomFieldFilterBy | cdktf.IResolvable): any;
export declare function customFieldFilterByToHclTerraform(struct?: CustomFieldFilterBy | cdktf.IResolvable): any;
export declare class CustomFieldFilterByOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomFieldFilterBy | cdktf.IResolvable | undefined;
    set internalValue(value: CustomFieldFilterBy | cdktf.IResolvable | undefined);
    private _catalogAttributeId?;
    get catalogAttributeId(): string;
    set catalogAttributeId(value: string);
    get catalogAttributeIdInput(): string | undefined;
    private _customFieldId?;
    get customFieldId(): string;
    set customFieldId(value: string);
    get customFieldIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field incident_custom_field}
*/
export declare class CustomField extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_custom_field";
    /**
    * Generates CDKTF code for importing a CustomField resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomField to import
    * @param importFromId The id of the existing CustomField that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomField to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/custom_field incident_custom_field} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomFieldConfig
    */
    constructor(scope: Construct, id: string, config: CustomFieldConfig);
    private _catalogTypeId?;
    get catalogTypeId(): string;
    set catalogTypeId(value: string);
    resetCatalogTypeId(): void;
    get catalogTypeIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _fieldType?;
    get fieldType(): string;
    set fieldType(value: string);
    get fieldTypeInput(): string | undefined;
    private _filterBy;
    get filterBy(): CustomFieldFilterByOutputReference;
    putFilterBy(value: CustomFieldFilterBy): void;
    resetFilterBy(): void;
    get filterByInput(): cdktf.IResolvable | CustomFieldFilterBy | undefined;
    private _groupByCatalogAttributeId?;
    get groupByCatalogAttributeId(): string;
    set groupByCatalogAttributeId(value: string);
    resetGroupByCatalogAttributeId(): void;
    get groupByCatalogAttributeIdInput(): string | undefined;
    private _helptextCatalogAttributeId?;
    get helptextCatalogAttributeId(): string;
    set helptextCatalogAttributeId(value: string);
    resetHelptextCatalogAttributeId(): void;
    get helptextCatalogAttributeIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
