import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CatalogTypeConfig extends cdktf.TerraformMetaArguments {
    /**
    * The categories that this type belongs to, to be shown in the web dashboard. Possible values are: `customer`, `issue-tracker`, `product-feature`, `service`, `on-call`, `team`, `user`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type#categories CatalogType#categories}
    */
    readonly categories?: string[];
    /**
    * Human readble description of this type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type#description CatalogType#description}
    */
    readonly description: string;
    /**
    * Name is the human readable name of this type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type#name CatalogType#name}
    */
    readonly name: string;
    /**
    * The url of the external repository where this type is managed. Users will not be able to edit the catalog type (or its entries) via the UI, and will instead be provided a link to this URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type#source_repo_url CatalogType#source_repo_url}
    */
    readonly sourceRepoUrl: string;
    /**
    * The type name of this catalog type, to be used when defining attributes. This is immutable once a CatalogType has been created. For non-externally sync types, it must follow the pattern Custom["SomeName"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type#type_name CatalogType#type_name}
    */
    readonly typeName?: string;
    /**
    * If enabled, you can refer to entries of this type by their name, as well as their external ID and any aliases.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type#use_name_as_identifier CatalogType#use_name_as_identifier}
    */
    readonly useNameAsIdentifier?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type incident_catalog_type}
*/
export declare class CatalogType extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_catalog_type";
    /**
    * Generates CDKTF code for importing a CatalogType resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CatalogType to import
    * @param importFromId The id of the existing CatalogType that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CatalogType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/catalog_type incident_catalog_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CatalogTypeConfig
    */
    constructor(scope: Construct, id: string, config: CatalogTypeConfig);
    private _categories?;
    get categories(): string[];
    set categories(value: string[]);
    resetCategories(): void;
    get categoriesInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sourceRepoUrl?;
    get sourceRepoUrl(): string;
    set sourceRepoUrl(value: string);
    get sourceRepoUrlInput(): string | undefined;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    resetTypeName(): void;
    get typeNameInput(): string | undefined;
    private _useNameAsIdentifier?;
    get useNameAsIdentifier(): boolean | cdktf.IResolvable;
    set useNameAsIdentifier(value: boolean | cdktf.IResolvable);
    resetUseNameAsIdentifier(): void;
    get useNameAsIdentifierInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
