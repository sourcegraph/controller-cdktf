import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EscalationPathConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of this escalation path, for the user's reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#name EscalationPath#name}
    */
    readonly name: string;
    /**
    * The nodes that form the levels and branches of this escalation path.
    *
    * -->**Note** Although the `if_else` block is recursive, currently a maximum of 3 levels are supported. Attempting to configure more than 3 levels of nesting will result in a schema error.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#path EscalationPath#path}
    */
    readonly path: EscalationPathPath[] | cdktf.IResolvable;
    /**
    * IDs of the teams that own this escalation path. This will automatically sync escalation paths with the right teams in Catalog. If you have an escalation paths attribute on your Teams, this attribute is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#team_ids EscalationPath#team_ids}
    */
    readonly teamIds?: string[];
    /**
    * The working hours for this escalation path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#working_hours EscalationPath#working_hours}
    */
    readonly workingHours?: EscalationPathWorkingHours[] | cdktf.IResolvable;
}
export interface EscalationPathPathIfElseConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#literal EscalationPath#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#reference EscalationPath#reference}
    */
    readonly reference?: string;
}
export declare function escalationPathPathIfElseConditionsParamBindingsArrayValueToTerraform(struct?: EscalationPathPathIfElseConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseConditionsParamBindingsArrayValueToHclTerraform(struct?: EscalationPathPathIfElseConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathIfElseConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class EscalationPathPathIfElseConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathIfElseConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathIfElseConditionsParamBindingsArrayValueOutputReference;
}
export interface EscalationPathPathIfElseConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#literal EscalationPath#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#reference EscalationPath#reference}
    */
    readonly reference?: string;
}
export declare function escalationPathPathIfElseConditionsParamBindingsValueToTerraform(struct?: EscalationPathPathIfElseConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseConditionsParamBindingsValueToHclTerraform(struct?: EscalationPathPathIfElseConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathIfElseConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface EscalationPathPathIfElseConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#array_value EscalationPath#array_value}
    */
    readonly arrayValue?: EscalationPathPathIfElseConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#value EscalationPath#value}
    */
    readonly value?: EscalationPathPathIfElseConditionsParamBindingsValue;
}
export declare function escalationPathPathIfElseConditionsParamBindingsToTerraform(struct?: EscalationPathPathIfElseConditionsParamBindings | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseConditionsParamBindingsToHclTerraform(struct?: EscalationPathPathIfElseConditionsParamBindings | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathIfElseConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): EscalationPathPathIfElseConditionsParamBindingsArrayValueList;
    putArrayValue(value: EscalationPathPathIfElseConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | EscalationPathPathIfElseConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): EscalationPathPathIfElseConditionsParamBindingsValueOutputReference;
    putValue(value: EscalationPathPathIfElseConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | EscalationPathPathIfElseConditionsParamBindingsValue | undefined;
}
export declare class EscalationPathPathIfElseConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathIfElseConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathIfElseConditionsParamBindingsOutputReference;
}
export interface EscalationPathPathIfElseConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#operation EscalationPath#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#param_bindings EscalationPath#param_bindings}
    */
    readonly paramBindings: EscalationPathPathIfElseConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#subject EscalationPath#subject}
    */
    readonly subject: string;
}
export declare function escalationPathPathIfElseConditionsToTerraform(struct?: EscalationPathPathIfElseConditions | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseConditionsToHclTerraform(struct?: EscalationPathPathIfElseConditions | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathIfElseConditions | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): EscalationPathPathIfElseConditionsParamBindingsList;
    putParamBindings(value: EscalationPathPathIfElseConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | EscalationPathPathIfElseConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class EscalationPathPathIfElseConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathIfElseConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathIfElseConditionsOutputReference;
}
export interface EscalationPathPathIfElseElsePathLevelRoundRobinConfig {
    /**
    * Whether round robin is enabled for this level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#enabled EscalationPath#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * How long should we wait before rotating to the next target in a round robin, if not set will stick with a single target per level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#rotate_after_seconds EscalationPath#rotate_after_seconds}
    */
    readonly rotateAfterSeconds?: number;
}
export declare function escalationPathPathIfElseElsePathLevelRoundRobinConfigToTerraform(struct?: EscalationPathPathIfElseElsePathLevelRoundRobinConfig | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseElsePathLevelRoundRobinConfigToHclTerraform(struct?: EscalationPathPathIfElseElsePathLevelRoundRobinConfig | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseElsePathLevelRoundRobinConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathIfElseElsePathLevelRoundRobinConfig | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseElsePathLevelRoundRobinConfig | cdktf.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _rotateAfterSeconds?;
    get rotateAfterSeconds(): number;
    set rotateAfterSeconds(value: number);
    resetRotateAfterSeconds(): void;
    get rotateAfterSecondsInput(): number | undefined;
}
export interface EscalationPathPathIfElseElsePathLevelTargets {
    /**
    * Uniquely identifies an entity of this type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#id EscalationPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Only set for schedule targets, and either currently_on_call, all_users or all_users_for_rota and specifies which users to fetch from the schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#schedule_mode EscalationPath#schedule_mode}
    */
    readonly scheduleMode?: string;
    /**
    * Controls what type of entity this target identifies, such as EscalationPolicy or User. Possible values are: `schedule`, `user`, `slack_channel`, `msteams_channel`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#type EscalationPath#type}
    */
    readonly type: string;
    /**
    * The urgency of this escalation path target. Possible values are: `high`, `low`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#urgency EscalationPath#urgency}
    */
    readonly urgency: string;
}
export declare function escalationPathPathIfElseElsePathLevelTargetsToTerraform(struct?: EscalationPathPathIfElseElsePathLevelTargets | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseElsePathLevelTargetsToHclTerraform(struct?: EscalationPathPathIfElseElsePathLevelTargets | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseElsePathLevelTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathIfElseElsePathLevelTargets | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseElsePathLevelTargets | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _scheduleMode?;
    get scheduleMode(): string;
    set scheduleMode(value: string);
    resetScheduleMode(): void;
    get scheduleModeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    get urgencyInput(): string | undefined;
}
export declare class EscalationPathPathIfElseElsePathLevelTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathIfElseElsePathLevelTargets[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathIfElseElsePathLevelTargetsOutputReference;
}
export interface EscalationPathPathIfElseElsePathLevel {
    /**
    * Controls the behaviour of acknowledgements for this level, with 'first' cancelling all other escalations on the same level when someone acks
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#ack_mode EscalationPath#ack_mode}
    */
    readonly ackMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#round_robin_config EscalationPath#round_robin_config}
    */
    readonly roundRobinConfig?: EscalationPathPathIfElseElsePathLevelRoundRobinConfig;
    /**
    * The targets (users or schedules) for this level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#targets EscalationPath#targets}
    */
    readonly targets: EscalationPathPathIfElseElsePathLevelTargets[] | cdktf.IResolvable;
    /**
    * If the time to ack is relative to a time window, this defines whether we move when the window is active or inactive
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_interval_condition EscalationPath#time_to_ack_interval_condition}
    */
    readonly timeToAckIntervalCondition?: string;
    /**
    * How long should we wait for this level to acknowledge before proceeding to the next node in the path?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_seconds EscalationPath#time_to_ack_seconds}
    */
    readonly timeToAckSeconds?: number;
    /**
    * If the time to ack is relative to a time window, this identifies which window it is relative to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_weekday_interval_config_id EscalationPath#time_to_ack_weekday_interval_config_id}
    */
    readonly timeToAckWeekdayIntervalConfigId?: string;
}
export declare function escalationPathPathIfElseElsePathLevelToTerraform(struct?: EscalationPathPathIfElseElsePathLevel | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseElsePathLevelToHclTerraform(struct?: EscalationPathPathIfElseElsePathLevel | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseElsePathLevelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathIfElseElsePathLevel | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseElsePathLevel | cdktf.IResolvable | undefined);
    private _ackMode?;
    get ackMode(): string;
    set ackMode(value: string);
    resetAckMode(): void;
    get ackModeInput(): string | undefined;
    private _roundRobinConfig;
    get roundRobinConfig(): EscalationPathPathIfElseElsePathLevelRoundRobinConfigOutputReference;
    putRoundRobinConfig(value: EscalationPathPathIfElseElsePathLevelRoundRobinConfig): void;
    resetRoundRobinConfig(): void;
    get roundRobinConfigInput(): cdktf.IResolvable | EscalationPathPathIfElseElsePathLevelRoundRobinConfig | undefined;
    private _targets;
    get targets(): EscalationPathPathIfElseElsePathLevelTargetsList;
    putTargets(value: EscalationPathPathIfElseElsePathLevelTargets[] | cdktf.IResolvable): void;
    get targetsInput(): cdktf.IResolvable | EscalationPathPathIfElseElsePathLevelTargets[] | undefined;
    private _timeToAckIntervalCondition?;
    get timeToAckIntervalCondition(): string;
    set timeToAckIntervalCondition(value: string);
    resetTimeToAckIntervalCondition(): void;
    get timeToAckIntervalConditionInput(): string | undefined;
    private _timeToAckSeconds?;
    get timeToAckSeconds(): number;
    set timeToAckSeconds(value: number);
    resetTimeToAckSeconds(): void;
    get timeToAckSecondsInput(): number | undefined;
    private _timeToAckWeekdayIntervalConfigId?;
    get timeToAckWeekdayIntervalConfigId(): string;
    set timeToAckWeekdayIntervalConfigId(value: string);
    resetTimeToAckWeekdayIntervalConfigId(): void;
    get timeToAckWeekdayIntervalConfigIdInput(): string | undefined;
}
export interface EscalationPathPathIfElseElsePathNotifyChannelTargets {
    /**
    * Uniquely identifies an entity of this type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#id EscalationPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Only set for schedule targets, and either currently_on_call, all_users or all_users_for_rota and specifies which users to fetch from the schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#schedule_mode EscalationPath#schedule_mode}
    */
    readonly scheduleMode?: string;
    /**
    * Controls what type of entity this target identifies, such as EscalationPolicy or User. Possible values are: `schedule`, `user`, `slack_channel`, `msteams_channel`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#type EscalationPath#type}
    */
    readonly type: string;
    /**
    * The urgency of this escalation path target. Possible values are: `high`, `low`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#urgency EscalationPath#urgency}
    */
    readonly urgency: string;
}
export declare function escalationPathPathIfElseElsePathNotifyChannelTargetsToTerraform(struct?: EscalationPathPathIfElseElsePathNotifyChannelTargets | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseElsePathNotifyChannelTargetsToHclTerraform(struct?: EscalationPathPathIfElseElsePathNotifyChannelTargets | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseElsePathNotifyChannelTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathIfElseElsePathNotifyChannelTargets | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseElsePathNotifyChannelTargets | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _scheduleMode?;
    get scheduleMode(): string;
    set scheduleMode(value: string);
    resetScheduleMode(): void;
    get scheduleModeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    get urgencyInput(): string | undefined;
}
export declare class EscalationPathPathIfElseElsePathNotifyChannelTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathIfElseElsePathNotifyChannelTargets[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathIfElseElsePathNotifyChannelTargetsOutputReference;
}
export interface EscalationPathPathIfElseElsePathNotifyChannel {
    /**
    * The targets (Slack channels) for this level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#targets EscalationPath#targets}
    */
    readonly targets: EscalationPathPathIfElseElsePathNotifyChannelTargets[] | cdktf.IResolvable;
    /**
    * If the time to ack is relative to a time window, this defines whether we move when the window is active or inactive
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_interval_condition EscalationPath#time_to_ack_interval_condition}
    */
    readonly timeToAckIntervalCondition?: string;
    /**
    * How long should we wait for this level to acknowledge before moving on to the next node in the path?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_seconds EscalationPath#time_to_ack_seconds}
    */
    readonly timeToAckSeconds?: number;
    /**
    * If the time to ack is relative to a time window, this identifies which window it is relative to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_weekday_interval_config_id EscalationPath#time_to_ack_weekday_interval_config_id}
    */
    readonly timeToAckWeekdayIntervalConfigId?: string;
}
export declare function escalationPathPathIfElseElsePathNotifyChannelToTerraform(struct?: EscalationPathPathIfElseElsePathNotifyChannel | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseElsePathNotifyChannelToHclTerraform(struct?: EscalationPathPathIfElseElsePathNotifyChannel | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseElsePathNotifyChannelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathIfElseElsePathNotifyChannel | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseElsePathNotifyChannel | cdktf.IResolvable | undefined);
    private _targets;
    get targets(): EscalationPathPathIfElseElsePathNotifyChannelTargetsList;
    putTargets(value: EscalationPathPathIfElseElsePathNotifyChannelTargets[] | cdktf.IResolvable): void;
    get targetsInput(): cdktf.IResolvable | EscalationPathPathIfElseElsePathNotifyChannelTargets[] | undefined;
    private _timeToAckIntervalCondition?;
    get timeToAckIntervalCondition(): string;
    set timeToAckIntervalCondition(value: string);
    resetTimeToAckIntervalCondition(): void;
    get timeToAckIntervalConditionInput(): string | undefined;
    private _timeToAckSeconds?;
    get timeToAckSeconds(): number;
    set timeToAckSeconds(value: number);
    resetTimeToAckSeconds(): void;
    get timeToAckSecondsInput(): number | undefined;
    private _timeToAckWeekdayIntervalConfigId?;
    get timeToAckWeekdayIntervalConfigId(): string;
    set timeToAckWeekdayIntervalConfigId(value: string);
    resetTimeToAckWeekdayIntervalConfigId(): void;
    get timeToAckWeekdayIntervalConfigIdInput(): string | undefined;
}
export interface EscalationPathPathIfElseElsePathRepeat {
    /**
    * How many times to repeat these nodes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#repeat_times EscalationPath#repeat_times}
    */
    readonly repeatTimes: number;
    /**
    * Which node ID we begin repeating from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#to_node EscalationPath#to_node}
    */
    readonly toNode: string;
}
export declare function escalationPathPathIfElseElsePathRepeatToTerraform(struct?: EscalationPathPathIfElseElsePathRepeat | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseElsePathRepeatToHclTerraform(struct?: EscalationPathPathIfElseElsePathRepeat | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseElsePathRepeatOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathIfElseElsePathRepeat | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseElsePathRepeat | cdktf.IResolvable | undefined);
    private _repeatTimes?;
    get repeatTimes(): number;
    set repeatTimes(value: number);
    get repeatTimesInput(): number | undefined;
    private _toNode?;
    get toNode(): string;
    set toNode(value: string);
    get toNodeInput(): string | undefined;
}
export interface EscalationPathPathIfElseElsePath {
    /**
    * An ID for this node, unique within the escalation path.
    *
    * This allows you to reference the node in other nodes, such as when configuring a 'repeat' node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#id EscalationPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#if_else EscalationPath#if_else}
    */
    readonly ifElse?: EscalationPathPathIfElse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#level EscalationPath#level}
    */
    readonly level?: EscalationPathPathIfElseElsePathLevel;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#notify_channel EscalationPath#notify_channel}
    */
    readonly notifyChannel?: EscalationPathPathIfElseElsePathNotifyChannel;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#repeat EscalationPath#repeat}
    */
    readonly repeat?: EscalationPathPathIfElseElsePathRepeat;
    /**
    * The type of this node. Available types are:
    * * level: A set of targets (users or schedules) that should be paged, either all at once, or with a round-robin configuration.
    * * notify_channel: Send the escalation to a Slack channel, where it can be acked by anyone in the channel.
    * * if_else: Branch the escalation based on a set of conditions.
    * * repeat: Go back to a previous node and repeat the logic from there.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#type EscalationPath#type}
    */
    readonly type: string;
}
export declare function escalationPathPathIfElseElsePathToTerraform(struct?: EscalationPathPathIfElseElsePath | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseElsePathToHclTerraform(struct?: EscalationPathPathIfElseElsePath | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseElsePathOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathIfElseElsePath | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseElsePath | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifElse;
    get ifElse(): EscalationPathPathIfElseOutputReference;
    putIfElse(value: EscalationPathPathIfElse): void;
    resetIfElse(): void;
    get ifElseInput(): cdktf.IResolvable | EscalationPathPathIfElse | undefined;
    private _level;
    get level(): EscalationPathPathIfElseElsePathLevelOutputReference;
    putLevel(value: EscalationPathPathIfElseElsePathLevel): void;
    resetLevel(): void;
    get levelInput(): cdktf.IResolvable | EscalationPathPathIfElseElsePathLevel | undefined;
    private _notifyChannel;
    get notifyChannel(): EscalationPathPathIfElseElsePathNotifyChannelOutputReference;
    putNotifyChannel(value: EscalationPathPathIfElseElsePathNotifyChannel): void;
    resetNotifyChannel(): void;
    get notifyChannelInput(): cdktf.IResolvable | EscalationPathPathIfElseElsePathNotifyChannel | undefined;
    private _repeat;
    get repeat(): EscalationPathPathIfElseElsePathRepeatOutputReference;
    putRepeat(value: EscalationPathPathIfElseElsePathRepeat): void;
    resetRepeat(): void;
    get repeatInput(): cdktf.IResolvable | EscalationPathPathIfElseElsePathRepeat | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class EscalationPathPathIfElseElsePathList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathIfElseElsePath[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathIfElseElsePathOutputReference;
}
export interface EscalationPathPathIfElseThenPathLevelRoundRobinConfig {
    /**
    * Whether round robin is enabled for this level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#enabled EscalationPath#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * How long should we wait before rotating to the next target in a round robin, if not set will stick with a single target per level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#rotate_after_seconds EscalationPath#rotate_after_seconds}
    */
    readonly rotateAfterSeconds?: number;
}
export declare function escalationPathPathIfElseThenPathLevelRoundRobinConfigToTerraform(struct?: EscalationPathPathIfElseThenPathLevelRoundRobinConfig | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseThenPathLevelRoundRobinConfigToHclTerraform(struct?: EscalationPathPathIfElseThenPathLevelRoundRobinConfig | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseThenPathLevelRoundRobinConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathIfElseThenPathLevelRoundRobinConfig | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseThenPathLevelRoundRobinConfig | cdktf.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _rotateAfterSeconds?;
    get rotateAfterSeconds(): number;
    set rotateAfterSeconds(value: number);
    resetRotateAfterSeconds(): void;
    get rotateAfterSecondsInput(): number | undefined;
}
export interface EscalationPathPathIfElseThenPathLevelTargets {
    /**
    * Uniquely identifies an entity of this type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#id EscalationPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Only set for schedule targets, and either currently_on_call, all_users or all_users_for_rota and specifies which users to fetch from the schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#schedule_mode EscalationPath#schedule_mode}
    */
    readonly scheduleMode?: string;
    /**
    * Controls what type of entity this target identifies, such as EscalationPolicy or User. Possible values are: `schedule`, `user`, `slack_channel`, `msteams_channel`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#type EscalationPath#type}
    */
    readonly type: string;
    /**
    * The urgency of this escalation path target. Possible values are: `high`, `low`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#urgency EscalationPath#urgency}
    */
    readonly urgency: string;
}
export declare function escalationPathPathIfElseThenPathLevelTargetsToTerraform(struct?: EscalationPathPathIfElseThenPathLevelTargets | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseThenPathLevelTargetsToHclTerraform(struct?: EscalationPathPathIfElseThenPathLevelTargets | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseThenPathLevelTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathIfElseThenPathLevelTargets | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseThenPathLevelTargets | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _scheduleMode?;
    get scheduleMode(): string;
    set scheduleMode(value: string);
    resetScheduleMode(): void;
    get scheduleModeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    get urgencyInput(): string | undefined;
}
export declare class EscalationPathPathIfElseThenPathLevelTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathIfElseThenPathLevelTargets[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathIfElseThenPathLevelTargetsOutputReference;
}
export interface EscalationPathPathIfElseThenPathLevel {
    /**
    * Controls the behaviour of acknowledgements for this level, with 'first' cancelling all other escalations on the same level when someone acks
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#ack_mode EscalationPath#ack_mode}
    */
    readonly ackMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#round_robin_config EscalationPath#round_robin_config}
    */
    readonly roundRobinConfig?: EscalationPathPathIfElseThenPathLevelRoundRobinConfig;
    /**
    * The targets (users or schedules) for this level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#targets EscalationPath#targets}
    */
    readonly targets: EscalationPathPathIfElseThenPathLevelTargets[] | cdktf.IResolvable;
    /**
    * If the time to ack is relative to a time window, this defines whether we move when the window is active or inactive
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_interval_condition EscalationPath#time_to_ack_interval_condition}
    */
    readonly timeToAckIntervalCondition?: string;
    /**
    * How long should we wait for this level to acknowledge before proceeding to the next node in the path?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_seconds EscalationPath#time_to_ack_seconds}
    */
    readonly timeToAckSeconds?: number;
    /**
    * If the time to ack is relative to a time window, this identifies which window it is relative to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_weekday_interval_config_id EscalationPath#time_to_ack_weekday_interval_config_id}
    */
    readonly timeToAckWeekdayIntervalConfigId?: string;
}
export declare function escalationPathPathIfElseThenPathLevelToTerraform(struct?: EscalationPathPathIfElseThenPathLevel | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseThenPathLevelToHclTerraform(struct?: EscalationPathPathIfElseThenPathLevel | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseThenPathLevelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathIfElseThenPathLevel | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseThenPathLevel | cdktf.IResolvable | undefined);
    private _ackMode?;
    get ackMode(): string;
    set ackMode(value: string);
    resetAckMode(): void;
    get ackModeInput(): string | undefined;
    private _roundRobinConfig;
    get roundRobinConfig(): EscalationPathPathIfElseThenPathLevelRoundRobinConfigOutputReference;
    putRoundRobinConfig(value: EscalationPathPathIfElseThenPathLevelRoundRobinConfig): void;
    resetRoundRobinConfig(): void;
    get roundRobinConfigInput(): cdktf.IResolvable | EscalationPathPathIfElseThenPathLevelRoundRobinConfig | undefined;
    private _targets;
    get targets(): EscalationPathPathIfElseThenPathLevelTargetsList;
    putTargets(value: EscalationPathPathIfElseThenPathLevelTargets[] | cdktf.IResolvable): void;
    get targetsInput(): cdktf.IResolvable | EscalationPathPathIfElseThenPathLevelTargets[] | undefined;
    private _timeToAckIntervalCondition?;
    get timeToAckIntervalCondition(): string;
    set timeToAckIntervalCondition(value: string);
    resetTimeToAckIntervalCondition(): void;
    get timeToAckIntervalConditionInput(): string | undefined;
    private _timeToAckSeconds?;
    get timeToAckSeconds(): number;
    set timeToAckSeconds(value: number);
    resetTimeToAckSeconds(): void;
    get timeToAckSecondsInput(): number | undefined;
    private _timeToAckWeekdayIntervalConfigId?;
    get timeToAckWeekdayIntervalConfigId(): string;
    set timeToAckWeekdayIntervalConfigId(value: string);
    resetTimeToAckWeekdayIntervalConfigId(): void;
    get timeToAckWeekdayIntervalConfigIdInput(): string | undefined;
}
export interface EscalationPathPathIfElseThenPathNotifyChannelTargets {
    /**
    * Uniquely identifies an entity of this type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#id EscalationPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Only set for schedule targets, and either currently_on_call, all_users or all_users_for_rota and specifies which users to fetch from the schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#schedule_mode EscalationPath#schedule_mode}
    */
    readonly scheduleMode?: string;
    /**
    * Controls what type of entity this target identifies, such as EscalationPolicy or User. Possible values are: `schedule`, `user`, `slack_channel`, `msteams_channel`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#type EscalationPath#type}
    */
    readonly type: string;
    /**
    * The urgency of this escalation path target. Possible values are: `high`, `low`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#urgency EscalationPath#urgency}
    */
    readonly urgency: string;
}
export declare function escalationPathPathIfElseThenPathNotifyChannelTargetsToTerraform(struct?: EscalationPathPathIfElseThenPathNotifyChannelTargets | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseThenPathNotifyChannelTargetsToHclTerraform(struct?: EscalationPathPathIfElseThenPathNotifyChannelTargets | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseThenPathNotifyChannelTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathIfElseThenPathNotifyChannelTargets | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseThenPathNotifyChannelTargets | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _scheduleMode?;
    get scheduleMode(): string;
    set scheduleMode(value: string);
    resetScheduleMode(): void;
    get scheduleModeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    get urgencyInput(): string | undefined;
}
export declare class EscalationPathPathIfElseThenPathNotifyChannelTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathIfElseThenPathNotifyChannelTargets[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathIfElseThenPathNotifyChannelTargetsOutputReference;
}
export interface EscalationPathPathIfElseThenPathNotifyChannel {
    /**
    * The targets (Slack channels) for this level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#targets EscalationPath#targets}
    */
    readonly targets: EscalationPathPathIfElseThenPathNotifyChannelTargets[] | cdktf.IResolvable;
    /**
    * If the time to ack is relative to a time window, this defines whether we move when the window is active or inactive
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_interval_condition EscalationPath#time_to_ack_interval_condition}
    */
    readonly timeToAckIntervalCondition?: string;
    /**
    * How long should we wait for this level to acknowledge before moving on to the next node in the path?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_seconds EscalationPath#time_to_ack_seconds}
    */
    readonly timeToAckSeconds?: number;
    /**
    * If the time to ack is relative to a time window, this identifies which window it is relative to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_weekday_interval_config_id EscalationPath#time_to_ack_weekday_interval_config_id}
    */
    readonly timeToAckWeekdayIntervalConfigId?: string;
}
export declare function escalationPathPathIfElseThenPathNotifyChannelToTerraform(struct?: EscalationPathPathIfElseThenPathNotifyChannel | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseThenPathNotifyChannelToHclTerraform(struct?: EscalationPathPathIfElseThenPathNotifyChannel | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseThenPathNotifyChannelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathIfElseThenPathNotifyChannel | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseThenPathNotifyChannel | cdktf.IResolvable | undefined);
    private _targets;
    get targets(): EscalationPathPathIfElseThenPathNotifyChannelTargetsList;
    putTargets(value: EscalationPathPathIfElseThenPathNotifyChannelTargets[] | cdktf.IResolvable): void;
    get targetsInput(): cdktf.IResolvable | EscalationPathPathIfElseThenPathNotifyChannelTargets[] | undefined;
    private _timeToAckIntervalCondition?;
    get timeToAckIntervalCondition(): string;
    set timeToAckIntervalCondition(value: string);
    resetTimeToAckIntervalCondition(): void;
    get timeToAckIntervalConditionInput(): string | undefined;
    private _timeToAckSeconds?;
    get timeToAckSeconds(): number;
    set timeToAckSeconds(value: number);
    resetTimeToAckSeconds(): void;
    get timeToAckSecondsInput(): number | undefined;
    private _timeToAckWeekdayIntervalConfigId?;
    get timeToAckWeekdayIntervalConfigId(): string;
    set timeToAckWeekdayIntervalConfigId(value: string);
    resetTimeToAckWeekdayIntervalConfigId(): void;
    get timeToAckWeekdayIntervalConfigIdInput(): string | undefined;
}
export interface EscalationPathPathIfElseThenPathRepeat {
    /**
    * How many times to repeat these nodes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#repeat_times EscalationPath#repeat_times}
    */
    readonly repeatTimes: number;
    /**
    * Which node ID we begin repeating from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#to_node EscalationPath#to_node}
    */
    readonly toNode: string;
}
export declare function escalationPathPathIfElseThenPathRepeatToTerraform(struct?: EscalationPathPathIfElseThenPathRepeat | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseThenPathRepeatToHclTerraform(struct?: EscalationPathPathIfElseThenPathRepeat | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseThenPathRepeatOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathIfElseThenPathRepeat | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseThenPathRepeat | cdktf.IResolvable | undefined);
    private _repeatTimes?;
    get repeatTimes(): number;
    set repeatTimes(value: number);
    get repeatTimesInput(): number | undefined;
    private _toNode?;
    get toNode(): string;
    set toNode(value: string);
    get toNodeInput(): string | undefined;
}
export interface EscalationPathPathIfElseThenPath {
    /**
    * An ID for this node, unique within the escalation path.
    *
    * This allows you to reference the node in other nodes, such as when configuring a 'repeat' node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#id EscalationPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#if_else EscalationPath#if_else}
    */
    readonly ifElse?: EscalationPathPathIfElse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#level EscalationPath#level}
    */
    readonly level?: EscalationPathPathIfElseThenPathLevel;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#notify_channel EscalationPath#notify_channel}
    */
    readonly notifyChannel?: EscalationPathPathIfElseThenPathNotifyChannel;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#repeat EscalationPath#repeat}
    */
    readonly repeat?: EscalationPathPathIfElseThenPathRepeat;
    /**
    * The type of this node. Available types are:
    * * level: A set of targets (users or schedules) that should be paged, either all at once, or with a round-robin configuration.
    * * notify_channel: Send the escalation to a Slack channel, where it can be acked by anyone in the channel.
    * * if_else: Branch the escalation based on a set of conditions.
    * * repeat: Go back to a previous node and repeat the logic from there.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#type EscalationPath#type}
    */
    readonly type: string;
}
export declare function escalationPathPathIfElseThenPathToTerraform(struct?: EscalationPathPathIfElseThenPath | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseThenPathToHclTerraform(struct?: EscalationPathPathIfElseThenPath | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseThenPathOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathIfElseThenPath | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElseThenPath | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifElse;
    get ifElse(): EscalationPathPathIfElseOutputReference;
    putIfElse(value: EscalationPathPathIfElse): void;
    resetIfElse(): void;
    get ifElseInput(): cdktf.IResolvable | EscalationPathPathIfElse | undefined;
    private _level;
    get level(): EscalationPathPathIfElseThenPathLevelOutputReference;
    putLevel(value: EscalationPathPathIfElseThenPathLevel): void;
    resetLevel(): void;
    get levelInput(): cdktf.IResolvable | EscalationPathPathIfElseThenPathLevel | undefined;
    private _notifyChannel;
    get notifyChannel(): EscalationPathPathIfElseThenPathNotifyChannelOutputReference;
    putNotifyChannel(value: EscalationPathPathIfElseThenPathNotifyChannel): void;
    resetNotifyChannel(): void;
    get notifyChannelInput(): cdktf.IResolvable | EscalationPathPathIfElseThenPathNotifyChannel | undefined;
    private _repeat;
    get repeat(): EscalationPathPathIfElseThenPathRepeatOutputReference;
    putRepeat(value: EscalationPathPathIfElseThenPathRepeat): void;
    resetRepeat(): void;
    get repeatInput(): cdktf.IResolvable | EscalationPathPathIfElseThenPathRepeat | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class EscalationPathPathIfElseThenPathList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathIfElseThenPath[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathIfElseThenPathOutputReference;
}
export interface EscalationPathPathIfElse {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#conditions EscalationPath#conditions}
    */
    readonly conditions: EscalationPathPathIfElseConditions[] | cdktf.IResolvable;
    /**
    * The nodes that form the levels if our condition is not met
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#else_path EscalationPath#else_path}
    */
    readonly elsePath?: EscalationPathPathIfElseElsePath[] | cdktf.IResolvable;
    /**
    * Then path nodes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#then_path EscalationPath#then_path}
    */
    readonly thenPath: EscalationPathPathIfElseThenPath[] | cdktf.IResolvable;
}
export declare function escalationPathPathIfElseToTerraform(struct?: EscalationPathPathIfElse | cdktf.IResolvable): any;
export declare function escalationPathPathIfElseToHclTerraform(struct?: EscalationPathPathIfElse | cdktf.IResolvable): any;
export declare class EscalationPathPathIfElseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathIfElse | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathIfElse | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): EscalationPathPathIfElseConditionsList;
    putConditions(value: EscalationPathPathIfElseConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | EscalationPathPathIfElseConditions[] | undefined;
    private _elsePath;
    get elsePath(): EscalationPathPathIfElseElsePathList;
    putElsePath(value: EscalationPathPathIfElseElsePath[] | cdktf.IResolvable): void;
    resetElsePath(): void;
    get elsePathInput(): cdktf.IResolvable | EscalationPathPathIfElseElsePath[] | undefined;
    private _thenPath;
    get thenPath(): EscalationPathPathIfElseThenPathList;
    putThenPath(value: EscalationPathPathIfElseThenPath[] | cdktf.IResolvable): void;
    get thenPathInput(): cdktf.IResolvable | EscalationPathPathIfElseThenPath[] | undefined;
}
export interface EscalationPathPathLevelRoundRobinConfig {
    /**
    * Whether round robin is enabled for this level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#enabled EscalationPath#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * How long should we wait before rotating to the next target in a round robin, if not set will stick with a single target per level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#rotate_after_seconds EscalationPath#rotate_after_seconds}
    */
    readonly rotateAfterSeconds?: number;
}
export declare function escalationPathPathLevelRoundRobinConfigToTerraform(struct?: EscalationPathPathLevelRoundRobinConfig | cdktf.IResolvable): any;
export declare function escalationPathPathLevelRoundRobinConfigToHclTerraform(struct?: EscalationPathPathLevelRoundRobinConfig | cdktf.IResolvable): any;
export declare class EscalationPathPathLevelRoundRobinConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathLevelRoundRobinConfig | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathLevelRoundRobinConfig | cdktf.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _rotateAfterSeconds?;
    get rotateAfterSeconds(): number;
    set rotateAfterSeconds(value: number);
    resetRotateAfterSeconds(): void;
    get rotateAfterSecondsInput(): number | undefined;
}
export interface EscalationPathPathLevelTargets {
    /**
    * Uniquely identifies an entity of this type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#id EscalationPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Only set for schedule targets, and either currently_on_call, all_users or all_users_for_rota and specifies which users to fetch from the schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#schedule_mode EscalationPath#schedule_mode}
    */
    readonly scheduleMode?: string;
    /**
    * Controls what type of entity this target identifies, such as EscalationPolicy or User. Possible values are: `schedule`, `user`, `slack_channel`, `msteams_channel`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#type EscalationPath#type}
    */
    readonly type: string;
    /**
    * The urgency of this escalation path target. Possible values are: `high`, `low`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#urgency EscalationPath#urgency}
    */
    readonly urgency: string;
}
export declare function escalationPathPathLevelTargetsToTerraform(struct?: EscalationPathPathLevelTargets | cdktf.IResolvable): any;
export declare function escalationPathPathLevelTargetsToHclTerraform(struct?: EscalationPathPathLevelTargets | cdktf.IResolvable): any;
export declare class EscalationPathPathLevelTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathLevelTargets | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathLevelTargets | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _scheduleMode?;
    get scheduleMode(): string;
    set scheduleMode(value: string);
    resetScheduleMode(): void;
    get scheduleModeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    get urgencyInput(): string | undefined;
}
export declare class EscalationPathPathLevelTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathLevelTargets[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathLevelTargetsOutputReference;
}
export interface EscalationPathPathLevel {
    /**
    * Controls the behaviour of acknowledgements for this level, with 'first' cancelling all other escalations on the same level when someone acks
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#ack_mode EscalationPath#ack_mode}
    */
    readonly ackMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#round_robin_config EscalationPath#round_robin_config}
    */
    readonly roundRobinConfig?: EscalationPathPathLevelRoundRobinConfig;
    /**
    * The targets (users or schedules) for this level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#targets EscalationPath#targets}
    */
    readonly targets: EscalationPathPathLevelTargets[] | cdktf.IResolvable;
    /**
    * If the time to ack is relative to a time window, this defines whether we move when the window is active or inactive
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_interval_condition EscalationPath#time_to_ack_interval_condition}
    */
    readonly timeToAckIntervalCondition?: string;
    /**
    * How long should we wait for this level to acknowledge before proceeding to the next node in the path?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_seconds EscalationPath#time_to_ack_seconds}
    */
    readonly timeToAckSeconds?: number;
    /**
    * If the time to ack is relative to a time window, this identifies which window it is relative to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_weekday_interval_config_id EscalationPath#time_to_ack_weekday_interval_config_id}
    */
    readonly timeToAckWeekdayIntervalConfigId?: string;
}
export declare function escalationPathPathLevelToTerraform(struct?: EscalationPathPathLevel | cdktf.IResolvable): any;
export declare function escalationPathPathLevelToHclTerraform(struct?: EscalationPathPathLevel | cdktf.IResolvable): any;
export declare class EscalationPathPathLevelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathLevel | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathLevel | cdktf.IResolvable | undefined);
    private _ackMode?;
    get ackMode(): string;
    set ackMode(value: string);
    resetAckMode(): void;
    get ackModeInput(): string | undefined;
    private _roundRobinConfig;
    get roundRobinConfig(): EscalationPathPathLevelRoundRobinConfigOutputReference;
    putRoundRobinConfig(value: EscalationPathPathLevelRoundRobinConfig): void;
    resetRoundRobinConfig(): void;
    get roundRobinConfigInput(): cdktf.IResolvable | EscalationPathPathLevelRoundRobinConfig | undefined;
    private _targets;
    get targets(): EscalationPathPathLevelTargetsList;
    putTargets(value: EscalationPathPathLevelTargets[] | cdktf.IResolvable): void;
    get targetsInput(): cdktf.IResolvable | EscalationPathPathLevelTargets[] | undefined;
    private _timeToAckIntervalCondition?;
    get timeToAckIntervalCondition(): string;
    set timeToAckIntervalCondition(value: string);
    resetTimeToAckIntervalCondition(): void;
    get timeToAckIntervalConditionInput(): string | undefined;
    private _timeToAckSeconds?;
    get timeToAckSeconds(): number;
    set timeToAckSeconds(value: number);
    resetTimeToAckSeconds(): void;
    get timeToAckSecondsInput(): number | undefined;
    private _timeToAckWeekdayIntervalConfigId?;
    get timeToAckWeekdayIntervalConfigId(): string;
    set timeToAckWeekdayIntervalConfigId(value: string);
    resetTimeToAckWeekdayIntervalConfigId(): void;
    get timeToAckWeekdayIntervalConfigIdInput(): string | undefined;
}
export interface EscalationPathPathNotifyChannelTargets {
    /**
    * Uniquely identifies an entity of this type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#id EscalationPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Only set for schedule targets, and either currently_on_call, all_users or all_users_for_rota and specifies which users to fetch from the schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#schedule_mode EscalationPath#schedule_mode}
    */
    readonly scheduleMode?: string;
    /**
    * Controls what type of entity this target identifies, such as EscalationPolicy or User. Possible values are: `schedule`, `user`, `slack_channel`, `msteams_channel`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#type EscalationPath#type}
    */
    readonly type: string;
    /**
    * The urgency of this escalation path target. Possible values are: `high`, `low`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#urgency EscalationPath#urgency}
    */
    readonly urgency: string;
}
export declare function escalationPathPathNotifyChannelTargetsToTerraform(struct?: EscalationPathPathNotifyChannelTargets | cdktf.IResolvable): any;
export declare function escalationPathPathNotifyChannelTargetsToHclTerraform(struct?: EscalationPathPathNotifyChannelTargets | cdktf.IResolvable): any;
export declare class EscalationPathPathNotifyChannelTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPathNotifyChannelTargets | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathNotifyChannelTargets | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _scheduleMode?;
    get scheduleMode(): string;
    set scheduleMode(value: string);
    resetScheduleMode(): void;
    get scheduleModeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    get urgencyInput(): string | undefined;
}
export declare class EscalationPathPathNotifyChannelTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPathNotifyChannelTargets[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathNotifyChannelTargetsOutputReference;
}
export interface EscalationPathPathNotifyChannel {
    /**
    * The targets (Slack channels) for this level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#targets EscalationPath#targets}
    */
    readonly targets: EscalationPathPathNotifyChannelTargets[] | cdktf.IResolvable;
    /**
    * If the time to ack is relative to a time window, this defines whether we move when the window is active or inactive
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_interval_condition EscalationPath#time_to_ack_interval_condition}
    */
    readonly timeToAckIntervalCondition?: string;
    /**
    * How long should we wait for this level to acknowledge before moving on to the next node in the path?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_seconds EscalationPath#time_to_ack_seconds}
    */
    readonly timeToAckSeconds?: number;
    /**
    * If the time to ack is relative to a time window, this identifies which window it is relative to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#time_to_ack_weekday_interval_config_id EscalationPath#time_to_ack_weekday_interval_config_id}
    */
    readonly timeToAckWeekdayIntervalConfigId?: string;
}
export declare function escalationPathPathNotifyChannelToTerraform(struct?: EscalationPathPathNotifyChannel | cdktf.IResolvable): any;
export declare function escalationPathPathNotifyChannelToHclTerraform(struct?: EscalationPathPathNotifyChannel | cdktf.IResolvable): any;
export declare class EscalationPathPathNotifyChannelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathNotifyChannel | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathNotifyChannel | cdktf.IResolvable | undefined);
    private _targets;
    get targets(): EscalationPathPathNotifyChannelTargetsList;
    putTargets(value: EscalationPathPathNotifyChannelTargets[] | cdktf.IResolvable): void;
    get targetsInput(): cdktf.IResolvable | EscalationPathPathNotifyChannelTargets[] | undefined;
    private _timeToAckIntervalCondition?;
    get timeToAckIntervalCondition(): string;
    set timeToAckIntervalCondition(value: string);
    resetTimeToAckIntervalCondition(): void;
    get timeToAckIntervalConditionInput(): string | undefined;
    private _timeToAckSeconds?;
    get timeToAckSeconds(): number;
    set timeToAckSeconds(value: number);
    resetTimeToAckSeconds(): void;
    get timeToAckSecondsInput(): number | undefined;
    private _timeToAckWeekdayIntervalConfigId?;
    get timeToAckWeekdayIntervalConfigId(): string;
    set timeToAckWeekdayIntervalConfigId(value: string);
    resetTimeToAckWeekdayIntervalConfigId(): void;
    get timeToAckWeekdayIntervalConfigIdInput(): string | undefined;
}
export interface EscalationPathPathRepeat {
    /**
    * How many times to repeat these nodes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#repeat_times EscalationPath#repeat_times}
    */
    readonly repeatTimes: number;
    /**
    * Which node ID we begin repeating from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#to_node EscalationPath#to_node}
    */
    readonly toNode: string;
}
export declare function escalationPathPathRepeatToTerraform(struct?: EscalationPathPathRepeat | cdktf.IResolvable): any;
export declare function escalationPathPathRepeatToHclTerraform(struct?: EscalationPathPathRepeat | cdktf.IResolvable): any;
export declare class EscalationPathPathRepeatOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPathPathRepeat | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPathRepeat | cdktf.IResolvable | undefined);
    private _repeatTimes?;
    get repeatTimes(): number;
    set repeatTimes(value: number);
    get repeatTimesInput(): number | undefined;
    private _toNode?;
    get toNode(): string;
    set toNode(value: string);
    get toNodeInput(): string | undefined;
}
export interface EscalationPathPath {
    /**
    * An ID for this node, unique within the escalation path.
    *
    * This allows you to reference the node in other nodes, such as when configuring a 'repeat' node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#id EscalationPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#if_else EscalationPath#if_else}
    */
    readonly ifElse?: EscalationPathPathIfElse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#level EscalationPath#level}
    */
    readonly level?: EscalationPathPathLevel;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#notify_channel EscalationPath#notify_channel}
    */
    readonly notifyChannel?: EscalationPathPathNotifyChannel;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#repeat EscalationPath#repeat}
    */
    readonly repeat?: EscalationPathPathRepeat;
    /**
    * The type of this node. Available types are:
    * * level: A set of targets (users or schedules) that should be paged, either all at once, or with a round-robin configuration.
    * * notify_channel: Send the escalation to a Slack channel, where it can be acked by anyone in the channel.
    * * if_else: Branch the escalation based on a set of conditions.
    * * repeat: Go back to a previous node and repeat the logic from there.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#type EscalationPath#type}
    */
    readonly type: string;
}
export declare function escalationPathPathToTerraform(struct?: EscalationPathPath | cdktf.IResolvable): any;
export declare function escalationPathPathToHclTerraform(struct?: EscalationPathPath | cdktf.IResolvable): any;
export declare class EscalationPathPathOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathPath | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathPath | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifElse;
    get ifElse(): EscalationPathPathIfElseOutputReference;
    putIfElse(value: EscalationPathPathIfElse): void;
    resetIfElse(): void;
    get ifElseInput(): cdktf.IResolvable | EscalationPathPathIfElse | undefined;
    private _level;
    get level(): EscalationPathPathLevelOutputReference;
    putLevel(value: EscalationPathPathLevel): void;
    resetLevel(): void;
    get levelInput(): cdktf.IResolvable | EscalationPathPathLevel | undefined;
    private _notifyChannel;
    get notifyChannel(): EscalationPathPathNotifyChannelOutputReference;
    putNotifyChannel(value: EscalationPathPathNotifyChannel): void;
    resetNotifyChannel(): void;
    get notifyChannelInput(): cdktf.IResolvable | EscalationPathPathNotifyChannel | undefined;
    private _repeat;
    get repeat(): EscalationPathPathRepeatOutputReference;
    putRepeat(value: EscalationPathPathRepeat): void;
    resetRepeat(): void;
    get repeatInput(): cdktf.IResolvable | EscalationPathPathRepeat | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class EscalationPathPathList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathPath[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathPathOutputReference;
}
export interface EscalationPathWorkingHoursWeekdayIntervals {
    /**
    * End time of the interval, in 24hr format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#end_time EscalationPath#end_time}
    */
    readonly endTime: string;
    /**
    * Start time of the interval, in 24hr format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#start_time EscalationPath#start_time}
    */
    readonly startTime: string;
    /**
    * Weekdays for use within a schedule or escalation path
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#weekday EscalationPath#weekday}
    */
    readonly weekday: string;
}
export declare function escalationPathWorkingHoursWeekdayIntervalsToTerraform(struct?: EscalationPathWorkingHoursWeekdayIntervals | cdktf.IResolvable): any;
export declare function escalationPathWorkingHoursWeekdayIntervalsToHclTerraform(struct?: EscalationPathWorkingHoursWeekdayIntervals | cdktf.IResolvable): any;
export declare class EscalationPathWorkingHoursWeekdayIntervalsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathWorkingHoursWeekdayIntervals | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathWorkingHoursWeekdayIntervals | cdktf.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    private _weekday?;
    get weekday(): string;
    set weekday(value: string);
    get weekdayInput(): string | undefined;
}
export declare class EscalationPathWorkingHoursWeekdayIntervalsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathWorkingHoursWeekdayIntervals[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathWorkingHoursWeekdayIntervalsOutputReference;
}
export interface EscalationPathWorkingHours {
    /**
    * The unique identifier for this set of working intervals
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#id EscalationPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * A human readable label for this set of working intervals
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#name EscalationPath#name}
    */
    readonly name: string;
    /**
    * How to interpret all the intervals
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#timezone EscalationPath#timezone}
    */
    readonly timezone: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#weekday_intervals EscalationPath#weekday_intervals}
    */
    readonly weekdayIntervals: EscalationPathWorkingHoursWeekdayIntervals[] | cdktf.IResolvable;
}
export declare function escalationPathWorkingHoursToTerraform(struct?: EscalationPathWorkingHours | cdktf.IResolvable): any;
export declare function escalationPathWorkingHoursToHclTerraform(struct?: EscalationPathWorkingHours | cdktf.IResolvable): any;
export declare class EscalationPathWorkingHoursOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPathWorkingHours | cdktf.IResolvable | undefined;
    set internalValue(value: EscalationPathWorkingHours | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    get timezoneInput(): string | undefined;
    private _weekdayIntervals;
    get weekdayIntervals(): EscalationPathWorkingHoursWeekdayIntervalsList;
    putWeekdayIntervals(value: EscalationPathWorkingHoursWeekdayIntervals[] | cdktf.IResolvable): void;
    get weekdayIntervalsInput(): cdktf.IResolvable | EscalationPathWorkingHoursWeekdayIntervals[] | undefined;
}
export declare class EscalationPathWorkingHoursList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPathWorkingHours[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPathWorkingHoursOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path incident_escalation_path}
*/
export declare class EscalationPath extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_escalation_path";
    /**
    * Generates CDKTF code for importing a EscalationPath resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EscalationPath to import
    * @param importFromId The id of the existing EscalationPath that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EscalationPath to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.21.1/docs/resources/escalation_path incident_escalation_path} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EscalationPathConfig
    */
    constructor(scope: Construct, id: string, config: EscalationPathConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path;
    get path(): EscalationPathPathList;
    putPath(value: EscalationPathPath[] | cdktf.IResolvable): void;
    get pathInput(): cdktf.IResolvable | EscalationPathPath[] | undefined;
    private _teamIds?;
    get teamIds(): string[];
    set teamIds(value: string[]);
    resetTeamIds(): void;
    get teamIdsInput(): string[] | undefined;
    private _workingHours;
    get workingHours(): EscalationPathWorkingHoursList;
    putWorkingHours(value: EscalationPathWorkingHours[] | cdktf.IResolvable): void;
    resetWorkingHours(): void;
    get workingHoursInput(): cdktf.IResolvable | EscalationPathWorkingHours[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
