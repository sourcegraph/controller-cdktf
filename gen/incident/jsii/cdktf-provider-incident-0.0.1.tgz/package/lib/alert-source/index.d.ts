import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AlertSourceConfig extends cdktf.TerraformMetaArguments {
    /**
    * Email address this alert source receives alerts to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#email_address AlertSource#email_address}
    */
    readonly emailAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#http_custom_options AlertSource#http_custom_options}
    */
    readonly httpCustomOptions?: AlertSourceHttpCustomOptions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#jira_options AlertSource#jira_options}
    */
    readonly jiraOptions?: AlertSourceJiraOptions;
    /**
    * Unique name of the alert source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#name AlertSource#name}
    */
    readonly name: string;
    /**
    * Type of alert source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#source_type AlertSource#source_type}
    */
    readonly sourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#template AlertSource#template}
    */
    readonly template: AlertSourceTemplate;
}
export interface AlertSourceHttpCustomOptions {
    /**
    * JSON path to extract the deduplication key from the payload
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#deduplication_key_path AlertSource#deduplication_key_path}
    */
    readonly deduplicationKeyPath: string;
    /**
    * JavaScript expression that returns an object with all alert fields
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#transform_expression AlertSource#transform_expression}
    */
    readonly transformExpression: string;
}
export declare function alertSourceHttpCustomOptionsToTerraform(struct?: AlertSourceHttpCustomOptions | cdktf.IResolvable): any;
export declare function alertSourceHttpCustomOptionsToHclTerraform(struct?: AlertSourceHttpCustomOptions | cdktf.IResolvable): any;
export declare class AlertSourceHttpCustomOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceHttpCustomOptions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceHttpCustomOptions | cdktf.IResolvable | undefined);
    private _deduplicationKeyPath?;
    get deduplicationKeyPath(): string;
    set deduplicationKeyPath(value: string);
    get deduplicationKeyPathInput(): string | undefined;
    private _transformExpression?;
    get transformExpression(): string;
    set transformExpression(value: string);
    get transformExpressionInput(): string | undefined;
}
export interface AlertSourceJiraOptions {
    /**
    * Which projects in Jira should this alert source watch for new issues? IDs can either be IDs of the projects in Jira, or ID of catalog entries in the 'Jira Project' catalog type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#project_ids AlertSource#project_ids}
    */
    readonly projectIds?: string[];
}
export declare function alertSourceJiraOptionsToTerraform(struct?: AlertSourceJiraOptions | cdktf.IResolvable): any;
export declare function alertSourceJiraOptionsToHclTerraform(struct?: AlertSourceJiraOptions | cdktf.IResolvable): any;
export declare class AlertSourceJiraOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceJiraOptions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceJiraOptions | cdktf.IResolvable | undefined);
    private _projectIds?;
    get projectIds(): string[];
    set projectIds(value: string[]);
    resetProjectIds(): void;
    get projectIdsInput(): string[] | undefined;
}
export interface AlertSourceTemplateAttributesBindingArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateAttributesBindingArrayValueToTerraform(struct?: AlertSourceTemplateAttributesBindingArrayValue | cdktf.IResolvable): any;
export declare function alertSourceTemplateAttributesBindingArrayValueToHclTerraform(struct?: AlertSourceTemplateAttributesBindingArrayValue | cdktf.IResolvable): any;
export declare class AlertSourceTemplateAttributesBindingArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateAttributesBindingArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateAttributesBindingArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertSourceTemplateAttributesBindingArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateAttributesBindingArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateAttributesBindingArrayValueOutputReference;
}
export interface AlertSourceTemplateAttributesBindingValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateAttributesBindingValueToTerraform(struct?: AlertSourceTemplateAttributesBindingValue | cdktf.IResolvable): any;
export declare function alertSourceTemplateAttributesBindingValueToHclTerraform(struct?: AlertSourceTemplateAttributesBindingValue | cdktf.IResolvable): any;
export declare class AlertSourceTemplateAttributesBindingValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateAttributesBindingValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateAttributesBindingValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertSourceTemplateAttributesBinding {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#array_value AlertSource#array_value}
    */
    readonly arrayValue?: AlertSourceTemplateAttributesBindingArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#value AlertSource#value}
    */
    readonly value?: AlertSourceTemplateAttributesBindingValue;
}
export declare function alertSourceTemplateAttributesBindingToTerraform(struct?: AlertSourceTemplateAttributesBinding | cdktf.IResolvable): any;
export declare function alertSourceTemplateAttributesBindingToHclTerraform(struct?: AlertSourceTemplateAttributesBinding | cdktf.IResolvable): any;
export declare class AlertSourceTemplateAttributesBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateAttributesBinding | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateAttributesBinding | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertSourceTemplateAttributesBindingArrayValueList;
    putArrayValue(value: AlertSourceTemplateAttributesBindingArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertSourceTemplateAttributesBindingArrayValue[] | undefined;
    private _value;
    get value(): AlertSourceTemplateAttributesBindingValueOutputReference;
    putValue(value: AlertSourceTemplateAttributesBindingValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertSourceTemplateAttributesBindingValue | undefined;
}
export interface AlertSourceTemplateAttributes {
    /**
    * ID of the alert attribute to set with this binding
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#alert_attribute_id AlertSource#alert_attribute_id}
    */
    readonly alertAttributeId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#binding AlertSource#binding}
    */
    readonly binding: AlertSourceTemplateAttributesBinding;
}
export declare function alertSourceTemplateAttributesToTerraform(struct?: AlertSourceTemplateAttributes | cdktf.IResolvable): any;
export declare function alertSourceTemplateAttributesToHclTerraform(struct?: AlertSourceTemplateAttributes | cdktf.IResolvable): any;
export declare class AlertSourceTemplateAttributesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateAttributes | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateAttributes | cdktf.IResolvable | undefined);
    private _alertAttributeId?;
    get alertAttributeId(): string;
    set alertAttributeId(value: string);
    get alertAttributeIdInput(): string | undefined;
    private _binding;
    get binding(): AlertSourceTemplateAttributesBindingOutputReference;
    putBinding(value: AlertSourceTemplateAttributesBinding): void;
    get bindingInput(): cdktf.IResolvable | AlertSourceTemplateAttributesBinding | undefined;
}
export declare class AlertSourceTemplateAttributesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateAttributes[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateAttributesOutputReference;
}
export interface AlertSourceTemplateDescription {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateDescriptionToTerraform(struct?: AlertSourceTemplateDescription | cdktf.IResolvable): any;
export declare function alertSourceTemplateDescriptionToHclTerraform(struct?: AlertSourceTemplateDescription | cdktf.IResolvable): any;
export declare class AlertSourceTemplateDescriptionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateDescription | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateDescription | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertSourceTemplateExpressionsElseBranchResultArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateExpressionsElseBranchResultArrayValueToTerraform(struct?: AlertSourceTemplateExpressionsElseBranchResultArrayValue | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsElseBranchResultArrayValueToHclTerraform(struct?: AlertSourceTemplateExpressionsElseBranchResultArrayValue | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsElseBranchResultArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsElseBranchResultArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsElseBranchResultArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertSourceTemplateExpressionsElseBranchResultArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsElseBranchResultArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsElseBranchResultArrayValueOutputReference;
}
export interface AlertSourceTemplateExpressionsElseBranchResultValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateExpressionsElseBranchResultValueToTerraform(struct?: AlertSourceTemplateExpressionsElseBranchResultValue | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsElseBranchResultValueToHclTerraform(struct?: AlertSourceTemplateExpressionsElseBranchResultValue | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsElseBranchResultValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsElseBranchResultValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsElseBranchResultValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertSourceTemplateExpressionsElseBranchResult {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#array_value AlertSource#array_value}
    */
    readonly arrayValue?: AlertSourceTemplateExpressionsElseBranchResultArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#value AlertSource#value}
    */
    readonly value?: AlertSourceTemplateExpressionsElseBranchResultValue;
}
export declare function alertSourceTemplateExpressionsElseBranchResultToTerraform(struct?: AlertSourceTemplateExpressionsElseBranchResult | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsElseBranchResultToHclTerraform(struct?: AlertSourceTemplateExpressionsElseBranchResult | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsElseBranchResultOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsElseBranchResult | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsElseBranchResult | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertSourceTemplateExpressionsElseBranchResultArrayValueList;
    putArrayValue(value: AlertSourceTemplateExpressionsElseBranchResultArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsElseBranchResultArrayValue[] | undefined;
    private _value;
    get value(): AlertSourceTemplateExpressionsElseBranchResultValueOutputReference;
    putValue(value: AlertSourceTemplateExpressionsElseBranchResultValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsElseBranchResultValue | undefined;
}
export interface AlertSourceTemplateExpressionsElseBranch {
    /**
    * The result assumed if the else branch is reached
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#result AlertSource#result}
    */
    readonly result: AlertSourceTemplateExpressionsElseBranchResult;
}
export declare function alertSourceTemplateExpressionsElseBranchToTerraform(struct?: AlertSourceTemplateExpressionsElseBranch | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsElseBranchToHclTerraform(struct?: AlertSourceTemplateExpressionsElseBranch | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsElseBranchOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsElseBranch | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsElseBranch | cdktf.IResolvable | undefined);
    private _result;
    get result(): AlertSourceTemplateExpressionsElseBranchResultOutputReference;
    putResult(value: AlertSourceTemplateExpressionsElseBranchResult): void;
    get resultInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsElseBranchResult | undefined;
}
export interface AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#array_value AlertSource#array_value}
    */
    readonly arrayValue?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#value AlertSource#value}
    */
    readonly value?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#operation AlertSource#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#param_bindings AlertSource#param_bindings}
    */
    readonly paramBindings: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#subject AlertSource#subject}
    */
    readonly subject: string;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsOutputReference;
}
export interface AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#conditions AlertSource#conditions}
    */
    readonly conditions: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditionsList;
    putConditions(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsConditions[] | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsOutputReference;
}
export interface AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValueToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValueToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValueOutputReference;
}
export interface AlertSourceTemplateExpressionsOperationsBranchesBranchesResultValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesResultValueToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesResultValueToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesResultValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertSourceTemplateExpressionsOperationsBranchesBranchesResult {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#array_value AlertSource#array_value}
    */
    readonly arrayValue?: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#value AlertSource#value}
    */
    readonly value?: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultValue;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesResultToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesResultToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesResultOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesResult | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValueList;
    putArrayValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranchesBranchesResultArrayValue[] | undefined;
    private _value;
    get value(): AlertSourceTemplateExpressionsOperationsBranchesBranchesResultValueOutputReference;
    putValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesResultValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranchesBranchesResultValue | undefined;
}
export interface AlertSourceTemplateExpressionsOperationsBranchesBranches {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#condition_groups AlertSource#condition_groups}
    */
    readonly conditionGroups: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroups[] | cdktf.IResolvable;
    /**
    * The result assumed if the condition groups are satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#result AlertSource#result}
    */
    readonly result: AlertSourceTemplateExpressionsOperationsBranchesBranchesResult;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranches | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesBranchesToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesBranches | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranchesBranches | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranchesBranches | cdktf.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroupsList;
    putConditionGroups(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranchesBranchesConditionGroups[] | undefined;
    private _result;
    get result(): AlertSourceTemplateExpressionsOperationsBranchesBranchesResultOutputReference;
    putResult(value: AlertSourceTemplateExpressionsOperationsBranchesBranchesResult): void;
    get resultInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranchesBranchesResult | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsBranchesBranchesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperationsBranchesBranches[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsBranchesBranchesOutputReference;
}
export interface AlertSourceTemplateExpressionsOperationsBranchesReturns {
    /**
    * Whether the return value should be single or multi-value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#array AlertSource#array}
    */
    readonly array: boolean | cdktf.IResolvable;
    /**
    * Expected return type of this expression (what to try casting the result to)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#type AlertSource#type}
    */
    readonly type: string;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesReturnsToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesReturns | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesReturnsToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranchesReturns | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesReturnsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranchesReturns | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranchesReturns | cdktf.IResolvable | undefined);
    private _array?;
    get array(): boolean | cdktf.IResolvable;
    set array(value: boolean | cdktf.IResolvable);
    get arrayInput(): boolean | cdktf.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface AlertSourceTemplateExpressionsOperationsBranches {
    /**
    * The branches to apply for this operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#branches AlertSource#branches}
    */
    readonly branches: AlertSourceTemplateExpressionsOperationsBranchesBranches[] | cdktf.IResolvable;
    /**
    * The return type of an operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#returns AlertSource#returns}
    */
    readonly returns: AlertSourceTemplateExpressionsOperationsBranchesReturns;
}
export declare function alertSourceTemplateExpressionsOperationsBranchesToTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranches | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsBranchesToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsBranches | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsBranchesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsOperationsBranches | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsBranches | cdktf.IResolvable | undefined);
    private _branches;
    get branches(): AlertSourceTemplateExpressionsOperationsBranchesBranchesList;
    putBranches(value: AlertSourceTemplateExpressionsOperationsBranchesBranches[] | cdktf.IResolvable): void;
    get branchesInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranchesBranches[] | undefined;
    private _returns;
    get returns(): AlertSourceTemplateExpressionsOperationsBranchesReturnsOutputReference;
    putReturns(value: AlertSourceTemplateExpressionsOperationsBranchesReturns): void;
    get returnsInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranchesReturns | undefined;
}
export interface AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueOutputReference;
}
export interface AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings {
    /**
    * The array of literal or reference parameter values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#array_value AlertSource#array_value}
    */
    readonly arrayValue?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable;
    /**
    * The literal or reference parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#value AlertSource#value}
    */
    readonly value?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue;
}
export declare function alertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings | cdktf.IResolvable | undefined);
    private _arrayValue;
    get arrayValue(): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValueList;
    putArrayValue(value: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | cdktf.IResolvable): void;
    resetArrayValue(): void;
    get arrayValueInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsArrayValue[] | undefined;
    private _value;
    get value(): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValueOutputReference;
    putValue(value: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue): void;
    resetValue(): void;
    get valueInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsValue | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsOutputReference;
}
export interface AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditions {
    /**
    * The logical operation to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#operation AlertSource#operation}
    */
    readonly operation: string;
    /**
    * Bindings for the operation parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#param_bindings AlertSource#param_bindings}
    */
    readonly paramBindings: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktf.IResolvable;
    /**
    * The subject of the condition, on which the operation is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#subject AlertSource#subject}
    */
    readonly subject: string;
}
export declare function alertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsToTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditions | cdktf.IResolvable | undefined);
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _paramBindings;
    get paramBindings(): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindingsList;
    putParamBindings(value: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | cdktf.IResolvable): void;
    get paramBindingsInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsParamBindings[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsOutputReference;
}
export interface AlertSourceTemplateExpressionsOperationsFilterConditionGroups {
    /**
    * The prerequisite conditions that must all be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#conditions AlertSource#conditions}
    */
    readonly conditions: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditions[] | cdktf.IResolvable;
}
export declare function alertSourceTemplateExpressionsOperationsFilterConditionGroupsToTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilterConditionGroups | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsFilterConditionGroupsToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilterConditionGroups | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsFilterConditionGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperationsFilterConditionGroups | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsFilterConditionGroups | cdktf.IResolvable | undefined);
    private _conditions;
    get conditions(): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditionsList;
    putConditions(value: AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsFilterConditionGroupsConditions[] | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsFilterConditionGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperationsFilterConditionGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsOutputReference;
}
export interface AlertSourceTemplateExpressionsOperationsFilter {
    /**
    * Groups of prerequisite conditions. All conditions in at least one group must be satisfied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#condition_groups AlertSource#condition_groups}
    */
    readonly conditionGroups: AlertSourceTemplateExpressionsOperationsFilterConditionGroups[] | cdktf.IResolvable;
}
export declare function alertSourceTemplateExpressionsOperationsFilterToTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilter | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsFilterToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsFilter | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsOperationsFilter | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsFilter | cdktf.IResolvable | undefined);
    private _conditionGroups;
    get conditionGroups(): AlertSourceTemplateExpressionsOperationsFilterConditionGroupsList;
    putConditionGroups(value: AlertSourceTemplateExpressionsOperationsFilterConditionGroups[] | cdktf.IResolvable): void;
    get conditionGroupsInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsFilterConditionGroups[] | undefined;
}
export interface AlertSourceTemplateExpressionsOperationsNavigate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference: string;
}
export declare function alertSourceTemplateExpressionsOperationsNavigateToTerraform(struct?: AlertSourceTemplateExpressionsOperationsNavigate | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsNavigateToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsNavigate | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsNavigateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsOperationsNavigate | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsNavigate | cdktf.IResolvable | undefined);
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
}
export interface AlertSourceTemplateExpressionsOperationsParseReturns {
    /**
    * Whether the return value should be single or multi-value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#array AlertSource#array}
    */
    readonly array: boolean | cdktf.IResolvable;
    /**
    * Expected return type of this expression (what to try casting the result to)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#type AlertSource#type}
    */
    readonly type: string;
}
export declare function alertSourceTemplateExpressionsOperationsParseReturnsToTerraform(struct?: AlertSourceTemplateExpressionsOperationsParseReturns | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsParseReturnsToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsParseReturns | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsParseReturnsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsOperationsParseReturns | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsParseReturns | cdktf.IResolvable | undefined);
    private _array?;
    get array(): boolean | cdktf.IResolvable;
    set array(value: boolean | cdktf.IResolvable);
    get arrayInput(): boolean | cdktf.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface AlertSourceTemplateExpressionsOperationsParse {
    /**
    * The return type of an operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#returns AlertSource#returns}
    */
    readonly returns: AlertSourceTemplateExpressionsOperationsParseReturns;
    /**
    * The ES5 Javascript expression to execute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#source AlertSource#source}
    */
    readonly source: string;
}
export declare function alertSourceTemplateExpressionsOperationsParseToTerraform(struct?: AlertSourceTemplateExpressionsOperationsParse | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsParseToHclTerraform(struct?: AlertSourceTemplateExpressionsOperationsParse | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsParseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateExpressionsOperationsParse | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperationsParse | cdktf.IResolvable | undefined);
    private _returns;
    get returns(): AlertSourceTemplateExpressionsOperationsParseReturnsOutputReference;
    putReturns(value: AlertSourceTemplateExpressionsOperationsParseReturns): void;
    get returnsInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsParseReturns | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export interface AlertSourceTemplateExpressionsOperations {
    /**
    * An operation type that allows for a value to be set conditionally by a series of logical branches
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#branches AlertSource#branches}
    */
    readonly branches?: AlertSourceTemplateExpressionsOperationsBranches;
    /**
    * An operation type that allows values to be filtered out by conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#filter AlertSource#filter}
    */
    readonly filter?: AlertSourceTemplateExpressionsOperationsFilter;
    /**
    * An operation type that allows attributes of a type to be accessed by reference
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#navigate AlertSource#navigate}
    */
    readonly navigate?: AlertSourceTemplateExpressionsOperationsNavigate;
    /**
    * Indicates which operation type to execute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#operation_type AlertSource#operation_type}
    */
    readonly operationType: string;
    /**
    * An operation type that allows a value to parsed from within a JSON object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#parse AlertSource#parse}
    */
    readonly parse?: AlertSourceTemplateExpressionsOperationsParse;
}
export declare function alertSourceTemplateExpressionsOperationsToTerraform(struct?: AlertSourceTemplateExpressionsOperations | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsOperationsToHclTerraform(struct?: AlertSourceTemplateExpressionsOperations | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOperationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressionsOperations | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressionsOperations | cdktf.IResolvable | undefined);
    private _branches;
    get branches(): AlertSourceTemplateExpressionsOperationsBranchesOutputReference;
    putBranches(value: AlertSourceTemplateExpressionsOperationsBranches): void;
    resetBranches(): void;
    get branchesInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsBranches | undefined;
    private _filter;
    get filter(): AlertSourceTemplateExpressionsOperationsFilterOutputReference;
    putFilter(value: AlertSourceTemplateExpressionsOperationsFilter): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsFilter | undefined;
    private _navigate;
    get navigate(): AlertSourceTemplateExpressionsOperationsNavigateOutputReference;
    putNavigate(value: AlertSourceTemplateExpressionsOperationsNavigate): void;
    resetNavigate(): void;
    get navigateInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsNavigate | undefined;
    private _operationType?;
    get operationType(): string;
    set operationType(value: string);
    get operationTypeInput(): string | undefined;
    private _parse;
    get parse(): AlertSourceTemplateExpressionsOperationsParseOutputReference;
    putParse(value: AlertSourceTemplateExpressionsOperationsParse): void;
    resetParse(): void;
    get parseInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperationsParse | undefined;
}
export declare class AlertSourceTemplateExpressionsOperationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressionsOperations[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOperationsOutputReference;
}
export interface AlertSourceTemplateExpressions {
    /**
    * The else branch to resort to if all operations fail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#else_branch AlertSource#else_branch}
    */
    readonly elseBranch?: AlertSourceTemplateExpressionsElseBranch;
    /**
    * The human readable label of the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#label AlertSource#label}
    */
    readonly label: string;
    /**
    * The operations to execute in sequence for this expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#operations AlertSource#operations}
    */
    readonly operations: AlertSourceTemplateExpressionsOperations[] | cdktf.IResolvable;
    /**
    * A short ID that can be used to reference the expression
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference: string;
    /**
    * The root reference for this expression (i.e. where the expression starts)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#root_reference AlertSource#root_reference}
    */
    readonly rootReference: string;
}
export declare function alertSourceTemplateExpressionsToTerraform(struct?: AlertSourceTemplateExpressions | cdktf.IResolvable): any;
export declare function alertSourceTemplateExpressionsToHclTerraform(struct?: AlertSourceTemplateExpressions | cdktf.IResolvable): any;
export declare class AlertSourceTemplateExpressionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertSourceTemplateExpressions | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateExpressions | cdktf.IResolvable | undefined);
    private _elseBranch;
    get elseBranch(): AlertSourceTemplateExpressionsElseBranchOutputReference;
    putElseBranch(value: AlertSourceTemplateExpressionsElseBranch): void;
    resetElseBranch(): void;
    get elseBranchInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsElseBranch | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _operations;
    get operations(): AlertSourceTemplateExpressionsOperationsList;
    putOperations(value: AlertSourceTemplateExpressionsOperations[] | cdktf.IResolvable): void;
    get operationsInput(): cdktf.IResolvable | AlertSourceTemplateExpressionsOperations[] | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    get referenceInput(): string | undefined;
    private _rootReference?;
    get rootReference(): string;
    set rootReference(value: string);
    get rootReferenceInput(): string | undefined;
}
export declare class AlertSourceTemplateExpressionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlertSourceTemplateExpressions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertSourceTemplateExpressionsOutputReference;
}
export interface AlertSourceTemplateTitle {
    /**
    * If set, this is the literal value of the step parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#literal AlertSource#literal}
    */
    readonly literal?: string;
    /**
    * If set, this is the reference into the trigger scope that is the value of this parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#reference AlertSource#reference}
    */
    readonly reference?: string;
}
export declare function alertSourceTemplateTitleToTerraform(struct?: AlertSourceTemplateTitle | cdktf.IResolvable): any;
export declare function alertSourceTemplateTitleToHclTerraform(struct?: AlertSourceTemplateTitle | cdktf.IResolvable): any;
export declare class AlertSourceTemplateTitleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplateTitle | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplateTitle | cdktf.IResolvable | undefined);
    private _literal?;
    get literal(): string;
    set literal(value: string);
    resetLiteral(): void;
    get literalInput(): string | undefined;
    private _reference?;
    get reference(): string;
    set reference(value: string);
    resetReference(): void;
    get referenceInput(): string | undefined;
}
export interface AlertSourceTemplate {
    /**
    * Attributes to set on alerts coming from this source, with a binding describing how to set them.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#attributes AlertSource#attributes}
    */
    readonly attributes: AlertSourceTemplateAttributes[] | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#description AlertSource#description}
    */
    readonly description: AlertSourceTemplateDescription;
    /**
    * The expressions to be prepared for use by steps and conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#expressions AlertSource#expressions}
    */
    readonly expressions: AlertSourceTemplateExpressions[] | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#title AlertSource#title}
    */
    readonly title: AlertSourceTemplateTitle;
}
export declare function alertSourceTemplateToTerraform(struct?: AlertSourceTemplate | cdktf.IResolvable): any;
export declare function alertSourceTemplateToHclTerraform(struct?: AlertSourceTemplate | cdktf.IResolvable): any;
export declare class AlertSourceTemplateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertSourceTemplate | cdktf.IResolvable | undefined;
    set internalValue(value: AlertSourceTemplate | cdktf.IResolvable | undefined);
    private _attributes;
    get attributes(): AlertSourceTemplateAttributesList;
    putAttributes(value: AlertSourceTemplateAttributes[] | cdktf.IResolvable): void;
    get attributesInput(): cdktf.IResolvable | AlertSourceTemplateAttributes[] | undefined;
    private _description;
    get description(): AlertSourceTemplateDescriptionOutputReference;
    putDescription(value: AlertSourceTemplateDescription): void;
    get descriptionInput(): cdktf.IResolvable | AlertSourceTemplateDescription | undefined;
    private _expressions;
    get expressions(): AlertSourceTemplateExpressionsList;
    putExpressions(value: AlertSourceTemplateExpressions[] | cdktf.IResolvable): void;
    get expressionsInput(): cdktf.IResolvable | AlertSourceTemplateExpressions[] | undefined;
    private _title;
    get title(): AlertSourceTemplateTitleOutputReference;
    putTitle(value: AlertSourceTemplateTitle): void;
    get titleInput(): cdktf.IResolvable | AlertSourceTemplateTitle | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source incident_alert_source}
*/
export declare class AlertSource extends cdktf.TerraformResource {
    static readonly tfResourceType = "incident_alert_source";
    /**
    * Generates CDKTF code for importing a AlertSource resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertSource to import
    * @param importFromId The id of the existing AlertSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/incident-io/incident/5.17.1/docs/resources/alert_source incident_alert_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertSourceConfig
    */
    constructor(scope: Construct, id: string, config: AlertSourceConfig);
    private _emailAddress?;
    get emailAddress(): string;
    set emailAddress(value: string);
    resetEmailAddress(): void;
    get emailAddressInput(): string | undefined;
    private _httpCustomOptions;
    get httpCustomOptions(): AlertSourceHttpCustomOptionsOutputReference;
    putHttpCustomOptions(value: AlertSourceHttpCustomOptions): void;
    resetHttpCustomOptions(): void;
    get httpCustomOptionsInput(): cdktf.IResolvable | AlertSourceHttpCustomOptions | undefined;
    get id(): string;
    private _jiraOptions;
    get jiraOptions(): AlertSourceJiraOptionsOutputReference;
    putJiraOptions(value: AlertSourceJiraOptions): void;
    resetJiraOptions(): void;
    get jiraOptionsInput(): cdktf.IResolvable | AlertSourceJiraOptions | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get secretToken(): string;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    get sourceTypeInput(): string | undefined;
    private _template;
    get template(): AlertSourceTemplateOutputReference;
    putTemplate(value: AlertSourceTemplate): void;
    get templateInput(): cdktf.IResolvable | AlertSourceTemplate | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
