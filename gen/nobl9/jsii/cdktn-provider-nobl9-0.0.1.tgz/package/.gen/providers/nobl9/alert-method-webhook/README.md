# `nobl9_alert_method_webhook`

Refer to the Terraform Registry for docs: [`nobl9_alert_method_webhook`](https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook).
