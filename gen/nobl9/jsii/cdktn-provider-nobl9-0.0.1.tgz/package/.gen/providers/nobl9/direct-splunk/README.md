# `nobl9_direct_splunk`

Refer to the Terraform Registry for docs: [`nobl9_direct_splunk`](https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_splunk).
