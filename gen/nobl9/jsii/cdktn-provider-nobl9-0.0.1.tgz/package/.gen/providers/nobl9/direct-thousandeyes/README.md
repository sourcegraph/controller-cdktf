# `nobl9_direct_thousandeyes`

Refer to the Terraform Registry for docs: [`nobl9_direct_thousandeyes`](https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes).
