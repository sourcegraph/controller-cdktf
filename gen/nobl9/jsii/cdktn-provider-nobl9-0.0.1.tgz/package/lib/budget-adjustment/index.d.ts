import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BudgetAdjustmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#description BudgetAdjustment#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#display_name BudgetAdjustment#display_name}
    */
    readonly displayName?: string;
    /**
    * The duration of the budget adjustment event. The expected value for this field is a string formatted as a time duration. The duration must be defined with a precision of 1 minute. Example: `1h10m`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#duration BudgetAdjustment#duration}
    */
    readonly duration: string;
    /**
    * The time at which the first event is scheduled to start. The expected value must be a string representing the date and time in RFC3339 format. Example: `2022-12-31T00:00:00Z`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#first_event_start BudgetAdjustment#first_event_start}
    */
    readonly firstEventStart: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#id BudgetAdjustment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#name BudgetAdjustment#name}
    */
    readonly name: string;
    /**
    * The recurrence rule for the budget adjustment event. The expected value is a string in RRULE format. Example: `FREQ=MONTHLY;BYMONTHDAY=1`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#rrule BudgetAdjustment#rrule}
    */
    readonly rrule?: string;
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#filters BudgetAdjustment#filters}
    */
    readonly filters?: BudgetAdjustmentFilters[] | cdktn.IResolvable;
}
export interface BudgetAdjustmentFiltersSlosSlo {
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#name BudgetAdjustment#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#project BudgetAdjustment#project}
    */
    readonly project: string;
}
export declare function budgetAdjustmentFiltersSlosSloToTerraform(struct?: BudgetAdjustmentFiltersSlosSlo | cdktn.IResolvable): any;
export declare function budgetAdjustmentFiltersSlosSloToHclTerraform(struct?: BudgetAdjustmentFiltersSlosSlo | cdktn.IResolvable): any;
export declare class BudgetAdjustmentFiltersSlosSloOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetAdjustmentFiltersSlosSlo | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetAdjustmentFiltersSlosSlo | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
}
export declare class BudgetAdjustmentFiltersSlosSloList extends cdktn.ComplexList {
    internalValue?: BudgetAdjustmentFiltersSlosSlo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetAdjustmentFiltersSlosSloOutputReference;
}
export interface BudgetAdjustmentFiltersSlos {
    /**
    * slo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#slo BudgetAdjustment#slo}
    */
    readonly slo: BudgetAdjustmentFiltersSlosSlo[] | cdktn.IResolvable;
}
export declare function budgetAdjustmentFiltersSlosToTerraform(struct?: BudgetAdjustmentFiltersSlos | cdktn.IResolvable): any;
export declare function budgetAdjustmentFiltersSlosToHclTerraform(struct?: BudgetAdjustmentFiltersSlos | cdktn.IResolvable): any;
export declare class BudgetAdjustmentFiltersSlosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetAdjustmentFiltersSlos | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetAdjustmentFiltersSlos | cdktn.IResolvable | undefined);
    private _slo;
    get slo(): BudgetAdjustmentFiltersSlosSloList;
    putSlo(value: BudgetAdjustmentFiltersSlosSlo[] | cdktn.IResolvable): void;
    get sloInput(): cdktn.IResolvable | BudgetAdjustmentFiltersSlosSlo[] | undefined;
}
export declare class BudgetAdjustmentFiltersSlosList extends cdktn.ComplexList {
    internalValue?: BudgetAdjustmentFiltersSlos[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetAdjustmentFiltersSlosOutputReference;
}
export interface BudgetAdjustmentFilters {
    /**
    * slos block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#slos BudgetAdjustment#slos}
    */
    readonly slos: BudgetAdjustmentFiltersSlos[] | cdktn.IResolvable;
}
export declare function budgetAdjustmentFiltersToTerraform(struct?: BudgetAdjustmentFilters | cdktn.IResolvable): any;
export declare function budgetAdjustmentFiltersToHclTerraform(struct?: BudgetAdjustmentFilters | cdktn.IResolvable): any;
export declare class BudgetAdjustmentFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetAdjustmentFilters | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetAdjustmentFilters | cdktn.IResolvable | undefined);
    private _slos;
    get slos(): BudgetAdjustmentFiltersSlosList;
    putSlos(value: BudgetAdjustmentFiltersSlos[] | cdktn.IResolvable): void;
    get slosInput(): cdktn.IResolvable | BudgetAdjustmentFiltersSlos[] | undefined;
}
export declare class BudgetAdjustmentFiltersList extends cdktn.ComplexList {
    internalValue?: BudgetAdjustmentFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetAdjustmentFiltersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment nobl9_budget_adjustment}
*/
export declare class BudgetAdjustment extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_budget_adjustment";
    /**
    * Generates CDKTN code for importing a BudgetAdjustment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BudgetAdjustment to import
    * @param importFromId The id of the existing BudgetAdjustment that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BudgetAdjustment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/budget_adjustment nobl9_budget_adjustment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BudgetAdjustmentConfig
    */
    constructor(scope: Construct, id: string, config: BudgetAdjustmentConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _duration?;
    get duration(): string;
    set duration(value: string);
    get durationInput(): string | undefined;
    private _firstEventStart?;
    get firstEventStart(): string;
    set firstEventStart(value: string);
    get firstEventStartInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rrule?;
    get rrule(): string;
    set rrule(value: string);
    resetRrule(): void;
    get rruleInput(): string | undefined;
    private _filters;
    get filters(): BudgetAdjustmentFiltersList;
    putFilters(value: BudgetAdjustmentFilters[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | BudgetAdjustmentFilters[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
