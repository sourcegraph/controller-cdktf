import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectPingdomConfig extends cdktn.TerraformMetaArguments {
    /**
    * [required] | Pingdom API token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#api_token DirectPingdom#api_token}
    */
    readonly apiToken?: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#description DirectPingdom#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#display_name DirectPingdom#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#id DirectPingdom#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#log_collection_enabled DirectPingdom#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#name DirectPingdom#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#project DirectPingdom#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#release_channel DirectPingdom#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#source_of DirectPingdom#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#query_delay DirectPingdom#query_delay}
    */
    readonly queryDelay?: DirectPingdomQueryDelay;
}
export interface DirectPingdomQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#unit DirectPingdom#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#value DirectPingdom#value}
    */
    readonly value: number;
}
export declare function directPingdomQueryDelayToTerraform(struct?: DirectPingdomQueryDelayOutputReference | DirectPingdomQueryDelay): any;
export declare function directPingdomQueryDelayToHclTerraform(struct?: DirectPingdomQueryDelayOutputReference | DirectPingdomQueryDelay): any;
export declare class DirectPingdomQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectPingdomQueryDelay | undefined;
    set internalValue(value: DirectPingdomQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom nobl9_direct_pingdom}
*/
export declare class DirectPingdom extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_pingdom";
    /**
    * Generates CDKTN code for importing a DirectPingdom resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectPingdom to import
    * @param importFromId The id of the existing DirectPingdom that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectPingdom to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_pingdom nobl9_direct_pingdom} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectPingdomConfig
    */
    constructor(scope: Construct, id: string, config: DirectPingdomConfig);
    private _apiToken?;
    get apiToken(): string;
    set apiToken(value: string);
    resetApiToken(): void;
    get apiTokenInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _queryDelay;
    get queryDelay(): DirectPingdomQueryDelayOutputReference;
    putQueryDelay(value: DirectPingdomQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectPingdomQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
