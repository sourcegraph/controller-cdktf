import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectThousandeyesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#description DirectThousandeyes#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#display_name DirectThousandeyes#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#id DirectThousandeyes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#log_collection_enabled DirectThousandeyes#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#name DirectThousandeyes#name}
    */
    readonly name: string;
    /**
    * [required] | ThousandEyes OAuth Bearer Token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#oauth_bearer_token DirectThousandeyes#oauth_bearer_token}
    */
    readonly oauthBearerToken?: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#project DirectThousandeyes#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#release_channel DirectThousandeyes#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#source_of DirectThousandeyes#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#query_delay DirectThousandeyes#query_delay}
    */
    readonly queryDelay?: DirectThousandeyesQueryDelay;
}
export interface DirectThousandeyesQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#unit DirectThousandeyes#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#value DirectThousandeyes#value}
    */
    readonly value: number;
}
export declare function directThousandeyesQueryDelayToTerraform(struct?: DirectThousandeyesQueryDelayOutputReference | DirectThousandeyesQueryDelay): any;
export declare function directThousandeyesQueryDelayToHclTerraform(struct?: DirectThousandeyesQueryDelayOutputReference | DirectThousandeyesQueryDelay): any;
export declare class DirectThousandeyesQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectThousandeyesQueryDelay | undefined;
    set internalValue(value: DirectThousandeyesQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes nobl9_direct_thousandeyes}
*/
export declare class DirectThousandeyes extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_thousandeyes";
    /**
    * Generates CDKTN code for importing a DirectThousandeyes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectThousandeyes to import
    * @param importFromId The id of the existing DirectThousandeyes that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectThousandeyes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_thousandeyes nobl9_direct_thousandeyes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectThousandeyesConfig
    */
    constructor(scope: Construct, id: string, config: DirectThousandeyesConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _oauthBearerToken?;
    get oauthBearerToken(): string;
    set oauthBearerToken(value: string);
    resetOauthBearerToken(): void;
    get oauthBearerTokenInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _queryDelay;
    get queryDelay(): DirectThousandeyesQueryDelayOutputReference;
    putQueryDelay(value: DirectThousandeyesQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectThousandeyesQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
