import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertMethodPagerdutyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty#description AlertMethodPagerduty#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty#display_name AlertMethodPagerduty#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty#id AlertMethodPagerduty#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * PagerDuty Integration Key. For more details, check [Services and integrations](https://support.pagerduty.com/docs/services-and-integrations).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty#integration_key AlertMethodPagerduty#integration_key}
    */
    readonly integrationKey?: string;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty#name AlertMethodPagerduty#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty#project AlertMethodPagerduty#project}
    */
    readonly project: string;
    /**
    * send_resolution block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty#send_resolution AlertMethodPagerduty#send_resolution}
    */
    readonly sendResolution?: AlertMethodPagerdutySendResolution;
}
export interface AlertMethodPagerdutySendResolution {
    /**
    * A message that will be attached to your 'all clear' notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty#message AlertMethodPagerduty#message}
    */
    readonly message?: string;
}
export declare function alertMethodPagerdutySendResolutionToTerraform(struct?: AlertMethodPagerdutySendResolutionOutputReference | AlertMethodPagerdutySendResolution): any;
export declare function alertMethodPagerdutySendResolutionToHclTerraform(struct?: AlertMethodPagerdutySendResolutionOutputReference | AlertMethodPagerdutySendResolution): any;
export declare class AlertMethodPagerdutySendResolutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertMethodPagerdutySendResolution | undefined;
    set internalValue(value: AlertMethodPagerdutySendResolution | undefined);
    private _message?;
    get message(): string;
    set message(value: string);
    resetMessage(): void;
    get messageInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty nobl9_alert_method_pagerduty}
*/
export declare class AlertMethodPagerduty extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_alert_method_pagerduty";
    /**
    * Generates CDKTN code for importing a AlertMethodPagerduty resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertMethodPagerduty to import
    * @param importFromId The id of the existing AlertMethodPagerduty that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertMethodPagerduty to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_pagerduty nobl9_alert_method_pagerduty} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertMethodPagerdutyConfig
    */
    constructor(scope: Construct, id: string, config: AlertMethodPagerdutyConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _integrationKey?;
    get integrationKey(): string;
    set integrationKey(value: string);
    resetIntegrationKey(): void;
    get integrationKeyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _sendResolution;
    get sendResolution(): AlertMethodPagerdutySendResolutionOutputReference;
    putSendResolution(value: AlertMethodPagerdutySendResolution): void;
    resetSendResolution(): void;
    get sendResolutionInput(): AlertMethodPagerdutySendResolution | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
