import * as cdktn from 'cdktn';
import { SloObjectiveCountMetricsGoodTotalAmazonPrometheus, SloObjectiveCountMetricsGoodTotalAmazonPrometheusList, SloObjectiveCountMetricsGoodTotalAppdynamics, SloObjectiveCountMetricsGoodTotalAppdynamicsList, SloObjectiveCountMetricsGoodTotalAzureMonitor, SloObjectiveCountMetricsGoodTotalAzureMonitorList, SloObjectiveCountMetricsGoodTotalBigquery, SloObjectiveCountMetricsGoodTotalBigqueryList, SloObjectiveCountMetricsGoodTotalCloudwatch, SloObjectiveCountMetricsGoodTotalCloudwatchList, SloObjectiveCountMetricsGoodTotalDatadog, SloObjectiveCountMetricsGoodTotalDatadogList, SloObjectiveCountMetricsGoodTotalDynatrace, SloObjectiveCountMetricsGoodTotalDynatraceList, SloObjectiveCountMetricsGoodTotalElasticsearch, SloObjectiveCountMetricsGoodTotalElasticsearchList, SloObjectiveCountMetricsGoodTotalGcm, SloObjectiveCountMetricsGoodTotalGcmList, SloObjectiveCountMetricsGoodTotalGrafanaLoki, SloObjectiveCountMetricsGoodTotalGrafanaLokiList, SloObjectiveCountMetricsGoodTotalGraphite, SloObjectiveCountMetricsGoodTotalGraphiteList, SloObjectiveCountMetricsGoodTotalHoneycomb, SloObjectiveCountMetricsGoodTotalHoneycombList, SloObjectiveCountMetricsGoodTotalInfluxdb, SloObjectiveCountMetricsGoodTotalInfluxdbList, SloObjectiveCountMetricsGoodTotalInstana, SloObjectiveCountMetricsGoodTotalInstanaList, SloObjectiveCountMetricsGoodTotalLightstep, SloObjectiveCountMetricsGoodTotalLightstepList, SloObjectiveCountMetricsGoodTotalLogicMonitor, SloObjectiveCountMetricsGoodTotalLogicMonitorList, SloObjectiveCountMetricsGoodTotalNewrelic, SloObjectiveCountMetricsGoodTotalNewrelicList, SloObjectiveCountMetricsGoodTotalOpentsdb, SloObjectiveCountMetricsGoodTotalOpentsdbList, SloObjectiveCountMetricsBad, SloObjectiveCountMetricsBadList, SloObjectiveCountMetricsGood, SloObjectiveCountMetricsGoodList, SloObjectiveComposite, SloObjectiveCompositeOutputReference } from './structs0';
export interface SloObjectiveCountMetricsGoodTotalPingdom {
    /**
    * Pingdom uptime or transaction check's ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#check_id Slo#check_id}
    */
    readonly checkId: string;
    /**
    * Pingdom check type - uptime or transaction
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#check_type Slo#check_type}
    */
    readonly checkType?: string;
    /**
    * Optional for the Uptime checks. Use it to filter the Pingdom check results by status
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#status Slo#status}
    */
    readonly status?: string;
}
export declare function sloObjectiveCountMetricsGoodTotalPingdomToTerraform(struct?: SloObjectiveCountMetricsGoodTotalPingdom | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalPingdomToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalPingdom | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalPingdomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalPingdom | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalPingdom | cdktn.IResolvable | undefined);
    private _checkId?;
    get checkId(): string;
    set checkId(value: string);
    get checkIdInput(): string | undefined;
    private _checkType?;
    get checkType(): string;
    set checkType(value: string);
    resetCheckType(): void;
    get checkTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalPingdomList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalPingdom[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalPingdomOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalPrometheus {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql: string;
}
export declare function sloObjectiveCountMetricsGoodTotalPrometheusToTerraform(struct?: SloObjectiveCountMetricsGoodTotalPrometheus | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalPrometheusToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalPrometheus | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalPrometheusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalPrometheus | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalPrometheus | cdktn.IResolvable | undefined);
    private _promql?;
    get promql(): string;
    set promql(value: string);
    get promqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalPrometheusList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalPrometheus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalPrometheusOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalRedshift {
    /**
    * Redshift custer ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#cluster_id Slo#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Database name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#database_name Slo#database_name}
    */
    readonly databaseName: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
    /**
    * Region of the Redshift instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#region Slo#region}
    */
    readonly region: string;
}
export declare function sloObjectiveCountMetricsGoodTotalRedshiftToTerraform(struct?: SloObjectiveCountMetricsGoodTotalRedshift | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalRedshiftToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalRedshift | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalRedshiftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalRedshift | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalRedshift | cdktn.IResolvable | undefined);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalRedshiftList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalRedshift[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalRedshiftOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalSplunk {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodTotalSplunkToTerraform(struct?: SloObjectiveCountMetricsGoodTotalSplunk | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalSplunkToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalSplunk | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalSplunkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalSplunk | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalSplunk | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalSplunkList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalSplunk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalSplunkOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalSplunkObservability {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#program Slo#program}
    */
    readonly program: string;
}
export declare function sloObjectiveCountMetricsGoodTotalSplunkObservabilityToTerraform(struct?: SloObjectiveCountMetricsGoodTotalSplunkObservability | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalSplunkObservabilityToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalSplunkObservability | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalSplunkObservabilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalSplunkObservability | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalSplunkObservability | cdktn.IResolvable | undefined);
    private _program?;
    get program(): string;
    set program(value: string);
    get programInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalSplunkObservabilityList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalSplunkObservability[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalSplunkObservabilityOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalSumologic {
    /**
    * Period of data aggregation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#quantization Slo#quantization}
    */
    readonly quantization?: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
    /**
    * Aggregation function - avg, sum, min, max, count, none
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#rollup Slo#rollup}
    */
    readonly rollup?: string;
    /**
    * Sumologic source - metrics or logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#type Slo#type}
    */
    readonly type: string;
}
export declare function sloObjectiveCountMetricsGoodTotalSumologicToTerraform(struct?: SloObjectiveCountMetricsGoodTotalSumologic | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalSumologicToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalSumologic | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalSumologicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalSumologic | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalSumologic | cdktn.IResolvable | undefined);
    private _quantization?;
    get quantization(): string;
    set quantization(value: string);
    resetQuantization(): void;
    get quantizationInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _rollup?;
    get rollup(): string;
    set rollup(value: string);
    resetRollup(): void;
    get rollupInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalSumologicList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalSumologic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalSumologicOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalThousandeyes {
    /**
    * ID of the test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#test_id Slo#test_id}
    */
    readonly testId: number;
    /**
    * Type of the test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#test_type Slo#test_type}
    */
    readonly testType?: string;
}
export declare function sloObjectiveCountMetricsGoodTotalThousandeyesToTerraform(struct?: SloObjectiveCountMetricsGoodTotalThousandeyes | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalThousandeyesToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalThousandeyes | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalThousandeyesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalThousandeyes | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalThousandeyes | cdktn.IResolvable | undefined);
    private _testId?;
    get testId(): number;
    set testId(value: number);
    get testIdInput(): number | undefined;
    private _testType?;
    get testType(): string;
    set testType(value: string);
    resetTestType(): void;
    get testTypeInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalThousandeyesList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalThousandeyes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalThousandeyesOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotal {
    /**
    * amazon_prometheus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#amazon_prometheus Slo#amazon_prometheus}
    */
    readonly amazonPrometheus?: SloObjectiveCountMetricsGoodTotalAmazonPrometheus[] | cdktn.IResolvable;
    /**
    * appdynamics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#appdynamics Slo#appdynamics}
    */
    readonly appdynamics?: SloObjectiveCountMetricsGoodTotalAppdynamics[] | cdktn.IResolvable;
    /**
    * azure_monitor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#azure_monitor Slo#azure_monitor}
    */
    readonly azureMonitor?: SloObjectiveCountMetricsGoodTotalAzureMonitor[] | cdktn.IResolvable;
    /**
    * bigquery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#bigquery Slo#bigquery}
    */
    readonly bigquery?: SloObjectiveCountMetricsGoodTotalBigquery[] | cdktn.IResolvable;
    /**
    * cloudwatch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#cloudwatch Slo#cloudwatch}
    */
    readonly cloudwatch?: SloObjectiveCountMetricsGoodTotalCloudwatch[] | cdktn.IResolvable;
    /**
    * datadog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#datadog Slo#datadog}
    */
    readonly datadog?: SloObjectiveCountMetricsGoodTotalDatadog[] | cdktn.IResolvable;
    /**
    * dynatrace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dynatrace Slo#dynatrace}
    */
    readonly dynatrace?: SloObjectiveCountMetricsGoodTotalDynatrace[] | cdktn.IResolvable;
    /**
    * elasticsearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#elasticsearch Slo#elasticsearch}
    */
    readonly elasticsearch?: SloObjectiveCountMetricsGoodTotalElasticsearch[] | cdktn.IResolvable;
    /**
    * gcm block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#gcm Slo#gcm}
    */
    readonly gcm?: SloObjectiveCountMetricsGoodTotalGcm[] | cdktn.IResolvable;
    /**
    * grafana_loki block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#grafana_loki Slo#grafana_loki}
    */
    readonly grafanaLoki?: SloObjectiveCountMetricsGoodTotalGrafanaLoki[] | cdktn.IResolvable;
    /**
    * graphite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graphite Slo#graphite}
    */
    readonly graphite?: SloObjectiveCountMetricsGoodTotalGraphite[] | cdktn.IResolvable;
    /**
    * honeycomb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#honeycomb Slo#honeycomb}
    */
    readonly honeycomb?: SloObjectiveCountMetricsGoodTotalHoneycomb[] | cdktn.IResolvable;
    /**
    * influxdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#influxdb Slo#influxdb}
    */
    readonly influxdb?: SloObjectiveCountMetricsGoodTotalInfluxdb[] | cdktn.IResolvable;
    /**
    * instana block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#instana Slo#instana}
    */
    readonly instana?: SloObjectiveCountMetricsGoodTotalInstana[] | cdktn.IResolvable;
    /**
    * lightstep block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#lightstep Slo#lightstep}
    */
    readonly lightstep?: SloObjectiveCountMetricsGoodTotalLightstep[] | cdktn.IResolvable;
    /**
    * logic_monitor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#logic_monitor Slo#logic_monitor}
    */
    readonly logicMonitor?: SloObjectiveCountMetricsGoodTotalLogicMonitor[] | cdktn.IResolvable;
    /**
    * newrelic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#newrelic Slo#newrelic}
    */
    readonly newrelic?: SloObjectiveCountMetricsGoodTotalNewrelic[] | cdktn.IResolvable;
    /**
    * opentsdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#opentsdb Slo#opentsdb}
    */
    readonly opentsdb?: SloObjectiveCountMetricsGoodTotalOpentsdb[] | cdktn.IResolvable;
    /**
    * pingdom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#pingdom Slo#pingdom}
    */
    readonly pingdom?: SloObjectiveCountMetricsGoodTotalPingdom[] | cdktn.IResolvable;
    /**
    * prometheus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#prometheus Slo#prometheus}
    */
    readonly prometheus?: SloObjectiveCountMetricsGoodTotalPrometheus[] | cdktn.IResolvable;
    /**
    * redshift block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#redshift Slo#redshift}
    */
    readonly redshift?: SloObjectiveCountMetricsGoodTotalRedshift[] | cdktn.IResolvable;
    /**
    * splunk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#splunk Slo#splunk}
    */
    readonly splunk?: SloObjectiveCountMetricsGoodTotalSplunk[] | cdktn.IResolvable;
    /**
    * splunk_observability block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#splunk_observability Slo#splunk_observability}
    */
    readonly splunkObservability?: SloObjectiveCountMetricsGoodTotalSplunkObservability[] | cdktn.IResolvable;
    /**
    * sumologic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#sumologic Slo#sumologic}
    */
    readonly sumologic?: SloObjectiveCountMetricsGoodTotalSumologic[] | cdktn.IResolvable;
    /**
    * thousandeyes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#thousandeyes Slo#thousandeyes}
    */
    readonly thousandeyes?: SloObjectiveCountMetricsGoodTotalThousandeyes[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsGoodTotalToTerraform(struct?: SloObjectiveCountMetricsGoodTotal | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotal | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotal | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotal | cdktn.IResolvable | undefined);
    private _amazonPrometheus;
    get amazonPrometheus(): SloObjectiveCountMetricsGoodTotalAmazonPrometheusList;
    putAmazonPrometheus(value: SloObjectiveCountMetricsGoodTotalAmazonPrometheus[] | cdktn.IResolvable): void;
    resetAmazonPrometheus(): void;
    get amazonPrometheusInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalAmazonPrometheus[] | undefined;
    private _appdynamics;
    get appdynamics(): SloObjectiveCountMetricsGoodTotalAppdynamicsList;
    putAppdynamics(value: SloObjectiveCountMetricsGoodTotalAppdynamics[] | cdktn.IResolvable): void;
    resetAppdynamics(): void;
    get appdynamicsInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalAppdynamics[] | undefined;
    private _azureMonitor;
    get azureMonitor(): SloObjectiveCountMetricsGoodTotalAzureMonitorList;
    putAzureMonitor(value: SloObjectiveCountMetricsGoodTotalAzureMonitor[] | cdktn.IResolvable): void;
    resetAzureMonitor(): void;
    get azureMonitorInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalAzureMonitor[] | undefined;
    private _bigquery;
    get bigquery(): SloObjectiveCountMetricsGoodTotalBigqueryList;
    putBigquery(value: SloObjectiveCountMetricsGoodTotalBigquery[] | cdktn.IResolvable): void;
    resetBigquery(): void;
    get bigqueryInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalBigquery[] | undefined;
    private _cloudwatch;
    get cloudwatch(): SloObjectiveCountMetricsGoodTotalCloudwatchList;
    putCloudwatch(value: SloObjectiveCountMetricsGoodTotalCloudwatch[] | cdktn.IResolvable): void;
    resetCloudwatch(): void;
    get cloudwatchInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalCloudwatch[] | undefined;
    private _datadog;
    get datadog(): SloObjectiveCountMetricsGoodTotalDatadogList;
    putDatadog(value: SloObjectiveCountMetricsGoodTotalDatadog[] | cdktn.IResolvable): void;
    resetDatadog(): void;
    get datadogInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalDatadog[] | undefined;
    private _dynatrace;
    get dynatrace(): SloObjectiveCountMetricsGoodTotalDynatraceList;
    putDynatrace(value: SloObjectiveCountMetricsGoodTotalDynatrace[] | cdktn.IResolvable): void;
    resetDynatrace(): void;
    get dynatraceInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalDynatrace[] | undefined;
    private _elasticsearch;
    get elasticsearch(): SloObjectiveCountMetricsGoodTotalElasticsearchList;
    putElasticsearch(value: SloObjectiveCountMetricsGoodTotalElasticsearch[] | cdktn.IResolvable): void;
    resetElasticsearch(): void;
    get elasticsearchInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalElasticsearch[] | undefined;
    private _gcm;
    get gcm(): SloObjectiveCountMetricsGoodTotalGcmList;
    putGcm(value: SloObjectiveCountMetricsGoodTotalGcm[] | cdktn.IResolvable): void;
    resetGcm(): void;
    get gcmInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalGcm[] | undefined;
    private _grafanaLoki;
    get grafanaLoki(): SloObjectiveCountMetricsGoodTotalGrafanaLokiList;
    putGrafanaLoki(value: SloObjectiveCountMetricsGoodTotalGrafanaLoki[] | cdktn.IResolvable): void;
    resetGrafanaLoki(): void;
    get grafanaLokiInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalGrafanaLoki[] | undefined;
    private _graphite;
    get graphite(): SloObjectiveCountMetricsGoodTotalGraphiteList;
    putGraphite(value: SloObjectiveCountMetricsGoodTotalGraphite[] | cdktn.IResolvable): void;
    resetGraphite(): void;
    get graphiteInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalGraphite[] | undefined;
    private _honeycomb;
    get honeycomb(): SloObjectiveCountMetricsGoodTotalHoneycombList;
    putHoneycomb(value: SloObjectiveCountMetricsGoodTotalHoneycomb[] | cdktn.IResolvable): void;
    resetHoneycomb(): void;
    get honeycombInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalHoneycomb[] | undefined;
    private _influxdb;
    get influxdb(): SloObjectiveCountMetricsGoodTotalInfluxdbList;
    putInfluxdb(value: SloObjectiveCountMetricsGoodTotalInfluxdb[] | cdktn.IResolvable): void;
    resetInfluxdb(): void;
    get influxdbInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalInfluxdb[] | undefined;
    private _instana;
    get instana(): SloObjectiveCountMetricsGoodTotalInstanaList;
    putInstana(value: SloObjectiveCountMetricsGoodTotalInstana[] | cdktn.IResolvable): void;
    resetInstana(): void;
    get instanaInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalInstana[] | undefined;
    private _lightstep;
    get lightstep(): SloObjectiveCountMetricsGoodTotalLightstepList;
    putLightstep(value: SloObjectiveCountMetricsGoodTotalLightstep[] | cdktn.IResolvable): void;
    resetLightstep(): void;
    get lightstepInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalLightstep[] | undefined;
    private _logicMonitor;
    get logicMonitor(): SloObjectiveCountMetricsGoodTotalLogicMonitorList;
    putLogicMonitor(value: SloObjectiveCountMetricsGoodTotalLogicMonitor[] | cdktn.IResolvable): void;
    resetLogicMonitor(): void;
    get logicMonitorInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalLogicMonitor[] | undefined;
    private _newrelic;
    get newrelic(): SloObjectiveCountMetricsGoodTotalNewrelicList;
    putNewrelic(value: SloObjectiveCountMetricsGoodTotalNewrelic[] | cdktn.IResolvable): void;
    resetNewrelic(): void;
    get newrelicInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalNewrelic[] | undefined;
    private _opentsdb;
    get opentsdb(): SloObjectiveCountMetricsGoodTotalOpentsdbList;
    putOpentsdb(value: SloObjectiveCountMetricsGoodTotalOpentsdb[] | cdktn.IResolvable): void;
    resetOpentsdb(): void;
    get opentsdbInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalOpentsdb[] | undefined;
    private _pingdom;
    get pingdom(): SloObjectiveCountMetricsGoodTotalPingdomList;
    putPingdom(value: SloObjectiveCountMetricsGoodTotalPingdom[] | cdktn.IResolvable): void;
    resetPingdom(): void;
    get pingdomInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalPingdom[] | undefined;
    private _prometheus;
    get prometheus(): SloObjectiveCountMetricsGoodTotalPrometheusList;
    putPrometheus(value: SloObjectiveCountMetricsGoodTotalPrometheus[] | cdktn.IResolvable): void;
    resetPrometheus(): void;
    get prometheusInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalPrometheus[] | undefined;
    private _redshift;
    get redshift(): SloObjectiveCountMetricsGoodTotalRedshiftList;
    putRedshift(value: SloObjectiveCountMetricsGoodTotalRedshift[] | cdktn.IResolvable): void;
    resetRedshift(): void;
    get redshiftInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalRedshift[] | undefined;
    private _splunk;
    get splunk(): SloObjectiveCountMetricsGoodTotalSplunkList;
    putSplunk(value: SloObjectiveCountMetricsGoodTotalSplunk[] | cdktn.IResolvable): void;
    resetSplunk(): void;
    get splunkInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalSplunk[] | undefined;
    private _splunkObservability;
    get splunkObservability(): SloObjectiveCountMetricsGoodTotalSplunkObservabilityList;
    putSplunkObservability(value: SloObjectiveCountMetricsGoodTotalSplunkObservability[] | cdktn.IResolvable): void;
    resetSplunkObservability(): void;
    get splunkObservabilityInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalSplunkObservability[] | undefined;
    private _sumologic;
    get sumologic(): SloObjectiveCountMetricsGoodTotalSumologicList;
    putSumologic(value: SloObjectiveCountMetricsGoodTotalSumologic[] | cdktn.IResolvable): void;
    resetSumologic(): void;
    get sumologicInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalSumologic[] | undefined;
    private _thousandeyes;
    get thousandeyes(): SloObjectiveCountMetricsGoodTotalThousandeyesList;
    putThousandeyes(value: SloObjectiveCountMetricsGoodTotalThousandeyes[] | cdktn.IResolvable): void;
    resetThousandeyes(): void;
    get thousandeyesInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalThousandeyes[] | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotal[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalOutputReference;
}
export interface SloObjectiveCountMetricsTotalAmazonPrometheus {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql: string;
}
export declare function sloObjectiveCountMetricsTotalAmazonPrometheusToTerraform(struct?: SloObjectiveCountMetricsTotalAmazonPrometheus | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalAmazonPrometheusToHclTerraform(struct?: SloObjectiveCountMetricsTotalAmazonPrometheus | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalAmazonPrometheusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalAmazonPrometheus | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalAmazonPrometheus | cdktn.IResolvable | undefined);
    private _promql?;
    get promql(): string;
    set promql(value: string);
    get promqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalAmazonPrometheusList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalAmazonPrometheus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalAmazonPrometheusOutputReference;
}
export interface SloObjectiveCountMetricsTotalAppdynamics {
    /**
    * Name of the added application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#application_name Slo#application_name}
    */
    readonly applicationName: string;
    /**
    * Path to the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_path Slo#metric_path}
    */
    readonly metricPath: string;
}
export declare function sloObjectiveCountMetricsTotalAppdynamicsToTerraform(struct?: SloObjectiveCountMetricsTotalAppdynamics | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalAppdynamicsToHclTerraform(struct?: SloObjectiveCountMetricsTotalAppdynamics | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalAppdynamicsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalAppdynamics | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalAppdynamics | cdktn.IResolvable | undefined);
    private _applicationName?;
    get applicationName(): string;
    set applicationName(value: string);
    get applicationNameInput(): string | undefined;
    private _metricPath?;
    get metricPath(): string;
    set metricPath(value: string);
    get metricPathInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalAppdynamicsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalAppdynamics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalAppdynamicsOutputReference;
}
export interface SloObjectiveCountMetricsTotalAzureMonitorDimensions {
    /**
    * Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: string;
}
export declare function sloObjectiveCountMetricsTotalAzureMonitorDimensionsToTerraform(struct?: SloObjectiveCountMetricsTotalAzureMonitorDimensions | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalAzureMonitorDimensionsToHclTerraform(struct?: SloObjectiveCountMetricsTotalAzureMonitorDimensions | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalAzureMonitorDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalAzureMonitorDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalAzureMonitorDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalAzureMonitorDimensionsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalAzureMonitorDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalAzureMonitorDimensionsOutputReference;
}
export interface SloObjectiveCountMetricsTotalAzureMonitorWorkspace {
    /**
    * Resource group of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#resource_group Slo#resource_group}
    */
    readonly resourceGroup: string;
    /**
    * Subscription ID of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#subscription_id Slo#subscription_id}
    */
    readonly subscriptionId: string;
    /**
    * ID of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#workspace_id Slo#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function sloObjectiveCountMetricsTotalAzureMonitorWorkspaceToTerraform(struct?: SloObjectiveCountMetricsTotalAzureMonitorWorkspace | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalAzureMonitorWorkspaceToHclTerraform(struct?: SloObjectiveCountMetricsTotalAzureMonitorWorkspace | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalAzureMonitorWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalAzureMonitorWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalAzureMonitorWorkspace | cdktn.IResolvable | undefined);
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    get subscriptionIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalAzureMonitorWorkspaceList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalAzureMonitorWorkspace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalAzureMonitorWorkspaceOutputReference;
}
export interface SloObjectiveCountMetricsTotalAzureMonitor {
    /**
    * Aggregation type [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#aggregation Slo#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Specifies source: 'metrics' or 'logs'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#data_type Slo#data_type}
    */
    readonly dataType: string;
    /**
    * Logs query in Kusto Query Language [Required for logs]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#kql_query Slo#kql_query}
    */
    readonly kqlQuery?: string;
    /**
    * Name of the metric [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_name Slo#metric_name}
    */
    readonly metricName?: string;
    /**
    * Namespace of the metric [Optional for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_namespace Slo#metric_namespace}
    */
    readonly metricNamespace?: string;
    /**
    * Identifier of the Azure Cloud resource [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#resource_id Slo#resource_id}
    */
    readonly resourceId?: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dimensions Slo#dimensions}
    */
    readonly dimensions?: SloObjectiveCountMetricsTotalAzureMonitorDimensions[] | cdktn.IResolvable;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#workspace Slo#workspace}
    */
    readonly workspace?: SloObjectiveCountMetricsTotalAzureMonitorWorkspace[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsTotalAzureMonitorToTerraform(struct?: SloObjectiveCountMetricsTotalAzureMonitor | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalAzureMonitorToHclTerraform(struct?: SloObjectiveCountMetricsTotalAzureMonitor | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalAzureMonitorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalAzureMonitor | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalAzureMonitor | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _kqlQuery?;
    get kqlQuery(): string;
    set kqlQuery(value: string);
    resetKqlQuery(): void;
    get kqlQueryInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _metricNamespace?;
    get metricNamespace(): string;
    set metricNamespace(value: string);
    resetMetricNamespace(): void;
    get metricNamespaceInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _dimensions;
    get dimensions(): SloObjectiveCountMetricsTotalAzureMonitorDimensionsList;
    putDimensions(value: SloObjectiveCountMetricsTotalAzureMonitorDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalAzureMonitorDimensions[] | undefined;
    private _workspace;
    get workspace(): SloObjectiveCountMetricsTotalAzureMonitorWorkspaceList;
    putWorkspace(value: SloObjectiveCountMetricsTotalAzureMonitorWorkspace[] | cdktn.IResolvable): void;
    resetWorkspace(): void;
    get workspaceInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalAzureMonitorWorkspace[] | undefined;
}
export declare class SloObjectiveCountMetricsTotalAzureMonitorList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalAzureMonitor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalAzureMonitorOutputReference;
}
export interface SloObjectiveCountMetricsTotalBigquery {
    /**
    * Location of you BigQuery
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#location Slo#location}
    */
    readonly location: string;
    /**
    * Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project_id Slo#project_id}
    */
    readonly projectId: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsTotalBigqueryToTerraform(struct?: SloObjectiveCountMetricsTotalBigquery | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalBigqueryToHclTerraform(struct?: SloObjectiveCountMetricsTotalBigquery | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalBigqueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalBigquery | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalBigquery | cdktn.IResolvable | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalBigqueryList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalBigquery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalBigqueryOutputReference;
}
export interface SloObjectiveCountMetricsTotalCloudwatchDimensions {
    /**
    * Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: string;
}
export declare function sloObjectiveCountMetricsTotalCloudwatchDimensionsToTerraform(struct?: SloObjectiveCountMetricsTotalCloudwatchDimensions | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalCloudwatchDimensionsToHclTerraform(struct?: SloObjectiveCountMetricsTotalCloudwatchDimensions | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalCloudwatchDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalCloudwatchDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalCloudwatchDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalCloudwatchDimensionsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalCloudwatchDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalCloudwatchDimensionsOutputReference;
}
export interface SloObjectiveCountMetricsTotalCloudwatch {
    /**
    * AccountID used with cross-account observability feature
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#account_id Slo#account_id}
    */
    readonly accountId?: string;
    /**
    * JSON query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#json Slo#json}
    */
    readonly json?: string;
    /**
    * Metric name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_name Slo#metric_name}
    */
    readonly metricName?: string;
    /**
    * Namespace of the metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#namespace Slo#namespace}
    */
    readonly namespace?: string;
    /**
    * Region of the CloudWatch instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#region Slo#region}
    */
    readonly region: string;
    /**
    * SQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#sql Slo#sql}
    */
    readonly sql?: string;
    /**
    * Metric data aggregations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#stat Slo#stat}
    */
    readonly stat?: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dimensions Slo#dimensions}
    */
    readonly dimensions?: SloObjectiveCountMetricsTotalCloudwatchDimensions[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsTotalCloudwatchToTerraform(struct?: SloObjectiveCountMetricsTotalCloudwatch | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalCloudwatchToHclTerraform(struct?: SloObjectiveCountMetricsTotalCloudwatch | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalCloudwatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalCloudwatch | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalCloudwatch | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _json?;
    get json(): string;
    set json(value: string);
    resetJson(): void;
    get jsonInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    resetSql(): void;
    get sqlInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _dimensions;
    get dimensions(): SloObjectiveCountMetricsTotalCloudwatchDimensionsList;
    putDimensions(value: SloObjectiveCountMetricsTotalCloudwatchDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalCloudwatchDimensions[] | undefined;
}
export declare class SloObjectiveCountMetricsTotalCloudwatchList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalCloudwatch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalCloudwatchOutputReference;
}
export interface SloObjectiveCountMetricsTotalDatadog {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsTotalDatadogToTerraform(struct?: SloObjectiveCountMetricsTotalDatadog | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalDatadogToHclTerraform(struct?: SloObjectiveCountMetricsTotalDatadog | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalDatadog | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalDatadog | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalDatadogList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalDatadog[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalDatadogOutputReference;
}
export interface SloObjectiveCountMetricsTotalDynatrace {
    /**
    * Selector for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_selector Slo#metric_selector}
    */
    readonly metricSelector: string;
}
export declare function sloObjectiveCountMetricsTotalDynatraceToTerraform(struct?: SloObjectiveCountMetricsTotalDynatrace | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalDynatraceToHclTerraform(struct?: SloObjectiveCountMetricsTotalDynatrace | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalDynatraceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalDynatrace | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalDynatrace | cdktn.IResolvable | undefined);
    private _metricSelector?;
    get metricSelector(): string;
    set metricSelector(value: string);
    get metricSelectorInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalDynatraceList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalDynatrace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalDynatraceOutputReference;
}
export interface SloObjectiveCountMetricsTotalElasticsearch {
    /**
    * Index of metrics we want to query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#index Slo#index}
    */
    readonly index: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsTotalElasticsearchToTerraform(struct?: SloObjectiveCountMetricsTotalElasticsearch | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalElasticsearchToHclTerraform(struct?: SloObjectiveCountMetricsTotalElasticsearch | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalElasticsearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalElasticsearch | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalElasticsearch | cdktn.IResolvable | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalElasticsearchList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalElasticsearch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalElasticsearchOutputReference;
}
export interface SloObjectiveCountMetricsTotalGcm {
    /**
    * Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project_id Slo#project_id}
    */
    readonly projectId: string;
    /**
    * Query for the metrics in PromQL format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql?: string;
    /**
    * Query for the metrics in MQL format ([deprecated](https://cloud.google.com/stackdriver/docs/deprecations/mql))
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query?: string;
}
export declare function sloObjectiveCountMetricsTotalGcmToTerraform(struct?: SloObjectiveCountMetricsTotalGcm | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalGcmToHclTerraform(struct?: SloObjectiveCountMetricsTotalGcm | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalGcmOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalGcm | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalGcm | cdktn.IResolvable | undefined);
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _promql?;
    get promql(): string;
    set promql(value: string);
    resetPromql(): void;
    get promqlInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalGcmList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalGcm[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalGcmOutputReference;
}
export interface SloObjectiveCountMetricsTotalGrafanaLoki {
    /**
    * Query for the logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#logql Slo#logql}
    */
    readonly logql: string;
}
export declare function sloObjectiveCountMetricsTotalGrafanaLokiToTerraform(struct?: SloObjectiveCountMetricsTotalGrafanaLoki | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalGrafanaLokiToHclTerraform(struct?: SloObjectiveCountMetricsTotalGrafanaLoki | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalGrafanaLokiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalGrafanaLoki | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalGrafanaLoki | cdktn.IResolvable | undefined);
    private _logql?;
    get logql(): string;
    set logql(value: string);
    get logqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalGrafanaLokiList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalGrafanaLoki[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalGrafanaLokiOutputReference;
}
export interface SloObjectiveCountMetricsTotalGraphite {
    /**
    * Path to the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_path Slo#metric_path}
    */
    readonly metricPath: string;
}
export declare function sloObjectiveCountMetricsTotalGraphiteToTerraform(struct?: SloObjectiveCountMetricsTotalGraphite | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalGraphiteToHclTerraform(struct?: SloObjectiveCountMetricsTotalGraphite | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalGraphiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalGraphite | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalGraphite | cdktn.IResolvable | undefined);
    private _metricPath?;
    get metricPath(): string;
    set metricPath(value: string);
    get metricPathInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalGraphiteList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalGraphite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalGraphiteOutputReference;
}
export interface SloObjectiveCountMetricsTotalHoneycomb {
    /**
    * Column name - required for all calculation types besides 'CONCURRENCY' and 'COUNT'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#attribute Slo#attribute}
    */
    readonly attribute?: string;
    /**
    * Calculation type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#calculation Slo#calculation}
    */
    readonly calculation: string;
}
export declare function sloObjectiveCountMetricsTotalHoneycombToTerraform(struct?: SloObjectiveCountMetricsTotalHoneycomb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalHoneycombToHclTerraform(struct?: SloObjectiveCountMetricsTotalHoneycomb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalHoneycombOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalHoneycomb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalHoneycomb | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _calculation?;
    get calculation(): string;
    set calculation(value: string);
    get calculationInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalHoneycombList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalHoneycomb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalHoneycombOutputReference;
}
export interface SloObjectiveCountMetricsTotalInfluxdb {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsTotalInfluxdbToTerraform(struct?: SloObjectiveCountMetricsTotalInfluxdb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalInfluxdbToHclTerraform(struct?: SloObjectiveCountMetricsTotalInfluxdb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalInfluxdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalInfluxdb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalInfluxdb | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalInfluxdbList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalInfluxdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalInfluxdbOutputReference;
}
export interface SloObjectiveCountMetricsTotalInstanaApplicationGroupBy {
    /**
    * Group by tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag Slo#tag}
    */
    readonly tag: string;
    /**
    * Tag entity - one of 'DESTINATION', 'SOURCE', 'NOT_APPLICABLE'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag_entity Slo#tag_entity}
    */
    readonly tagEntity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag_second_level_key Slo#tag_second_level_key}
    */
    readonly tagSecondLevelKey?: string;
}
export declare function sloObjectiveCountMetricsTotalInstanaApplicationGroupByToTerraform(struct?: SloObjectiveCountMetricsTotalInstanaApplicationGroupBy | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalInstanaApplicationGroupByToHclTerraform(struct?: SloObjectiveCountMetricsTotalInstanaApplicationGroupBy | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalInstanaApplicationGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalInstanaApplicationGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalInstanaApplicationGroupBy | cdktn.IResolvable | undefined);
    private _tag?;
    get tag(): string;
    set tag(value: string);
    get tagInput(): string | undefined;
    private _tagEntity?;
    get tagEntity(): string;
    set tagEntity(value: string);
    get tagEntityInput(): string | undefined;
    private _tagSecondLevelKey?;
    get tagSecondLevelKey(): string;
    set tagSecondLevelKey(value: string);
    resetTagSecondLevelKey(): void;
    get tagSecondLevelKeyInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalInstanaApplicationGroupByList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalInstanaApplicationGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalInstanaApplicationGroupByOutputReference;
}
export interface SloObjectiveCountMetricsTotalInstanaApplication {
    /**
    * Depends on the value specified for 'metric_id'- more info in N9 docs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#aggregation Slo#aggregation}
    */
    readonly aggregation: string;
    /**
    * API query user passes in a JSON format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#api_query Slo#api_query}
    */
    readonly apiQuery: string;
    /**
    * Include internal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#include_internal Slo#include_internal}
    */
    readonly includeInternal?: boolean | cdktn.IResolvable;
    /**
    * Include synthetic
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#include_synthetic Slo#include_synthetic}
    */
    readonly includeSynthetic?: boolean | cdktn.IResolvable;
    /**
    * Metric ID one of 'calls', 'erroneousCalls', 'errors', 'latency'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_id Slo#metric_id}
    */
    readonly metricId: string;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#group_by Slo#group_by}
    */
    readonly groupBy: SloObjectiveCountMetricsTotalInstanaApplicationGroupBy[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsTotalInstanaApplicationToTerraform(struct?: SloObjectiveCountMetricsTotalInstanaApplication | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalInstanaApplicationToHclTerraform(struct?: SloObjectiveCountMetricsTotalInstanaApplication | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalInstanaApplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalInstanaApplication | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalInstanaApplication | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _apiQuery?;
    get apiQuery(): string;
    set apiQuery(value: string);
    get apiQueryInput(): string | undefined;
    private _includeInternal?;
    get includeInternal(): boolean | cdktn.IResolvable;
    set includeInternal(value: boolean | cdktn.IResolvable);
    resetIncludeInternal(): void;
    get includeInternalInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSynthetic?;
    get includeSynthetic(): boolean | cdktn.IResolvable;
    set includeSynthetic(value: boolean | cdktn.IResolvable);
    resetIncludeSynthetic(): void;
    get includeSyntheticInput(): boolean | cdktn.IResolvable | undefined;
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    get metricIdInput(): string | undefined;
    private _groupBy;
    get groupBy(): SloObjectiveCountMetricsTotalInstanaApplicationGroupByList;
    putGroupBy(value: SloObjectiveCountMetricsTotalInstanaApplicationGroupBy[] | cdktn.IResolvable): void;
    get groupByInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalInstanaApplicationGroupBy[] | undefined;
}
export declare class SloObjectiveCountMetricsTotalInstanaApplicationList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalInstanaApplication[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalInstanaApplicationOutputReference;
}
export interface SloObjectiveCountMetricsTotalInstanaInfrastructure {
    /**
    * Metric ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_id Slo#metric_id}
    */
    readonly metricId: string;
    /**
    * Metric retrieval method 'query' or 'snapshot'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_retrieval_method Slo#metric_retrieval_method}
    */
    readonly metricRetrievalMethod: string;
    /**
    * Plugin ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#plugin_id Slo#plugin_id}
    */
    readonly pluginId: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query?: string;
    /**
    * Snapshot ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#snapshot_id Slo#snapshot_id}
    */
    readonly snapshotId?: string;
}
export declare function sloObjectiveCountMetricsTotalInstanaInfrastructureToTerraform(struct?: SloObjectiveCountMetricsTotalInstanaInfrastructure | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalInstanaInfrastructureToHclTerraform(struct?: SloObjectiveCountMetricsTotalInstanaInfrastructure | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalInstanaInfrastructureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalInstanaInfrastructure | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalInstanaInfrastructure | cdktn.IResolvable | undefined);
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    get metricIdInput(): string | undefined;
    private _metricRetrievalMethod?;
    get metricRetrievalMethod(): string;
    set metricRetrievalMethod(value: string);
    get metricRetrievalMethodInput(): string | undefined;
    private _pluginId?;
    get pluginId(): string;
    set pluginId(value: string);
    get pluginIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _snapshotId?;
    get snapshotId(): string;
    set snapshotId(value: string);
    resetSnapshotId(): void;
    get snapshotIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalInstanaInfrastructureList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalInstanaInfrastructure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalInstanaInfrastructureOutputReference;
}
export interface SloObjectiveCountMetricsTotalInstana {
    /**
    * Instana metric type 'application' or 'infrastructure'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_type Slo#metric_type}
    */
    readonly metricType: string;
    /**
    * application block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#application Slo#application}
    */
    readonly application?: SloObjectiveCountMetricsTotalInstanaApplication[] | cdktn.IResolvable;
    /**
    * infrastructure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#infrastructure Slo#infrastructure}
    */
    readonly infrastructure?: SloObjectiveCountMetricsTotalInstanaInfrastructure[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsTotalInstanaToTerraform(struct?: SloObjectiveCountMetricsTotalInstana | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalInstanaToHclTerraform(struct?: SloObjectiveCountMetricsTotalInstana | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalInstanaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalInstana | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalInstana | cdktn.IResolvable | undefined);
    private _metricType?;
    get metricType(): string;
    set metricType(value: string);
    get metricTypeInput(): string | undefined;
    private _application;
    get application(): SloObjectiveCountMetricsTotalInstanaApplicationList;
    putApplication(value: SloObjectiveCountMetricsTotalInstanaApplication[] | cdktn.IResolvable): void;
    resetApplication(): void;
    get applicationInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalInstanaApplication[] | undefined;
    private _infrastructure;
    get infrastructure(): SloObjectiveCountMetricsTotalInstanaInfrastructureList;
    putInfrastructure(value: SloObjectiveCountMetricsTotalInstanaInfrastructure[] | cdktn.IResolvable): void;
    resetInfrastructure(): void;
    get infrastructureInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalInstanaInfrastructure[] | undefined;
}
export declare class SloObjectiveCountMetricsTotalInstanaList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalInstana[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalInstanaOutputReference;
}
export interface SloObjectiveCountMetricsTotalLightstep {
    /**
    * Optional value to filter by percentiles
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#percentile Slo#percentile}
    */
    readonly percentile?: number;
    /**
    * ID of the metrics stream
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#stream_id Slo#stream_id}
    */
    readonly streamId?: string;
    /**
    * Type of data to filter by
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#type_of_data Slo#type_of_data}
    */
    readonly typeOfData: string;
    /**
    * UQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#uql Slo#uql}
    */
    readonly uql?: string;
}
export declare function sloObjectiveCountMetricsTotalLightstepToTerraform(struct?: SloObjectiveCountMetricsTotalLightstep | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalLightstepToHclTerraform(struct?: SloObjectiveCountMetricsTotalLightstep | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalLightstepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalLightstep | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalLightstep | cdktn.IResolvable | undefined);
    private _percentile?;
    get percentile(): number;
    set percentile(value: number);
    resetPercentile(): void;
    get percentileInput(): number | undefined;
    private _streamId?;
    get streamId(): string;
    set streamId(value: string);
    resetStreamId(): void;
    get streamIdInput(): string | undefined;
    private _typeOfData?;
    get typeOfData(): string;
    set typeOfData(value: string);
    get typeOfDataInput(): string | undefined;
    private _uql?;
    get uql(): string;
    set uql(value: string);
    resetUql(): void;
    get uqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalLightstepList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalLightstep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalLightstepOutputReference;
}
export interface SloObjectiveCountMetricsTotalLogicMonitor {
    /**
    * Checkpoint ID. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#checkpoint_id Slo#checkpoint_id}
    */
    readonly checkpointId?: string;
    /**
    * Device Datasource Instance ID. Used by Query type = device_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#device_data_source_instance_id Slo#device_data_source_instance_id}
    */
    readonly deviceDataSourceInstanceId?: number;
    /**
    * Graph ID. Used by Query type = device_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graph_id Slo#graph_id}
    */
    readonly graphId?: number;
    /**
    * Graph Name. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graph_name Slo#graph_name}
    */
    readonly graphName?: string;
    /**
    * Line
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#line Slo#line}
    */
    readonly line: string;
    /**
    * Query type: device_metrics or website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query_type Slo#query_type}
    */
    readonly queryType: string;
    /**
    * Website ID. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#website_id Slo#website_id}
    */
    readonly websiteId?: string;
}
export declare function sloObjectiveCountMetricsTotalLogicMonitorToTerraform(struct?: SloObjectiveCountMetricsTotalLogicMonitor | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalLogicMonitorToHclTerraform(struct?: SloObjectiveCountMetricsTotalLogicMonitor | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalLogicMonitorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalLogicMonitor | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalLogicMonitor | cdktn.IResolvable | undefined);
    private _checkpointId?;
    get checkpointId(): string;
    set checkpointId(value: string);
    resetCheckpointId(): void;
    get checkpointIdInput(): string | undefined;
    private _deviceDataSourceInstanceId?;
    get deviceDataSourceInstanceId(): number;
    set deviceDataSourceInstanceId(value: number);
    resetDeviceDataSourceInstanceId(): void;
    get deviceDataSourceInstanceIdInput(): number | undefined;
    private _graphId?;
    get graphId(): number;
    set graphId(value: number);
    resetGraphId(): void;
    get graphIdInput(): number | undefined;
    private _graphName?;
    get graphName(): string;
    set graphName(value: string);
    resetGraphName(): void;
    get graphNameInput(): string | undefined;
    private _line?;
    get line(): string;
    set line(value: string);
    get lineInput(): string | undefined;
    private _queryType?;
    get queryType(): string;
    set queryType(value: string);
    get queryTypeInput(): string | undefined;
    private _websiteId?;
    get websiteId(): string;
    set websiteId(value: string);
    resetWebsiteId(): void;
    get websiteIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalLogicMonitorList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalLogicMonitor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalLogicMonitorOutputReference;
}
export interface SloObjectiveCountMetricsTotalNewrelic {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#nrql Slo#nrql}
    */
    readonly nrql: string;
}
export declare function sloObjectiveCountMetricsTotalNewrelicToTerraform(struct?: SloObjectiveCountMetricsTotalNewrelic | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalNewrelicToHclTerraform(struct?: SloObjectiveCountMetricsTotalNewrelic | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalNewrelicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalNewrelic | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalNewrelic | cdktn.IResolvable | undefined);
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalNewrelicList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalNewrelic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalNewrelicOutputReference;
}
export interface SloObjectiveCountMetricsTotalOpentsdb {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsTotalOpentsdbToTerraform(struct?: SloObjectiveCountMetricsTotalOpentsdb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalOpentsdbToHclTerraform(struct?: SloObjectiveCountMetricsTotalOpentsdb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalOpentsdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalOpentsdb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalOpentsdb | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalOpentsdbList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalOpentsdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalOpentsdbOutputReference;
}
export interface SloObjectiveCountMetricsTotalPingdom {
    /**
    * Pingdom uptime or transaction check's ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#check_id Slo#check_id}
    */
    readonly checkId: string;
    /**
    * Pingdom check type - uptime or transaction
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#check_type Slo#check_type}
    */
    readonly checkType?: string;
    /**
    * Optional for the Uptime checks. Use it to filter the Pingdom check results by status
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#status Slo#status}
    */
    readonly status?: string;
}
export declare function sloObjectiveCountMetricsTotalPingdomToTerraform(struct?: SloObjectiveCountMetricsTotalPingdom | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalPingdomToHclTerraform(struct?: SloObjectiveCountMetricsTotalPingdom | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalPingdomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalPingdom | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalPingdom | cdktn.IResolvable | undefined);
    private _checkId?;
    get checkId(): string;
    set checkId(value: string);
    get checkIdInput(): string | undefined;
    private _checkType?;
    get checkType(): string;
    set checkType(value: string);
    resetCheckType(): void;
    get checkTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalPingdomList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalPingdom[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalPingdomOutputReference;
}
export interface SloObjectiveCountMetricsTotalPrometheus {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql: string;
}
export declare function sloObjectiveCountMetricsTotalPrometheusToTerraform(struct?: SloObjectiveCountMetricsTotalPrometheus | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalPrometheusToHclTerraform(struct?: SloObjectiveCountMetricsTotalPrometheus | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalPrometheusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalPrometheus | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalPrometheus | cdktn.IResolvable | undefined);
    private _promql?;
    get promql(): string;
    set promql(value: string);
    get promqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalPrometheusList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalPrometheus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalPrometheusOutputReference;
}
export interface SloObjectiveCountMetricsTotalRedshift {
    /**
    * Redshift custer ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#cluster_id Slo#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Database name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#database_name Slo#database_name}
    */
    readonly databaseName: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
    /**
    * Region of the Redshift instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#region Slo#region}
    */
    readonly region: string;
}
export declare function sloObjectiveCountMetricsTotalRedshiftToTerraform(struct?: SloObjectiveCountMetricsTotalRedshift | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalRedshiftToHclTerraform(struct?: SloObjectiveCountMetricsTotalRedshift | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalRedshiftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalRedshift | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalRedshift | cdktn.IResolvable | undefined);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalRedshiftList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalRedshift[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalRedshiftOutputReference;
}
export interface SloObjectiveCountMetricsTotalSplunk {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsTotalSplunkToTerraform(struct?: SloObjectiveCountMetricsTotalSplunk | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalSplunkToHclTerraform(struct?: SloObjectiveCountMetricsTotalSplunk | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalSplunkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalSplunk | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalSplunk | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalSplunkList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalSplunk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalSplunkOutputReference;
}
export interface SloObjectiveCountMetricsTotalSplunkObservability {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#program Slo#program}
    */
    readonly program: string;
}
export declare function sloObjectiveCountMetricsTotalSplunkObservabilityToTerraform(struct?: SloObjectiveCountMetricsTotalSplunkObservability | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalSplunkObservabilityToHclTerraform(struct?: SloObjectiveCountMetricsTotalSplunkObservability | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalSplunkObservabilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalSplunkObservability | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalSplunkObservability | cdktn.IResolvable | undefined);
    private _program?;
    get program(): string;
    set program(value: string);
    get programInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalSplunkObservabilityList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalSplunkObservability[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalSplunkObservabilityOutputReference;
}
export interface SloObjectiveCountMetricsTotalSumologic {
    /**
    * Period of data aggregation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#quantization Slo#quantization}
    */
    readonly quantization?: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
    /**
    * Aggregation function - avg, sum, min, max, count, none
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#rollup Slo#rollup}
    */
    readonly rollup?: string;
    /**
    * Sumologic source - metrics or logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#type Slo#type}
    */
    readonly type: string;
}
export declare function sloObjectiveCountMetricsTotalSumologicToTerraform(struct?: SloObjectiveCountMetricsTotalSumologic | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalSumologicToHclTerraform(struct?: SloObjectiveCountMetricsTotalSumologic | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalSumologicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalSumologic | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalSumologic | cdktn.IResolvable | undefined);
    private _quantization?;
    get quantization(): string;
    set quantization(value: string);
    resetQuantization(): void;
    get quantizationInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _rollup?;
    get rollup(): string;
    set rollup(value: string);
    resetRollup(): void;
    get rollupInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalSumologicList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalSumologic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalSumologicOutputReference;
}
export interface SloObjectiveCountMetricsTotalThousandeyes {
    /**
    * ID of the test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#test_id Slo#test_id}
    */
    readonly testId: number;
    /**
    * Type of the test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#test_type Slo#test_type}
    */
    readonly testType?: string;
}
export declare function sloObjectiveCountMetricsTotalThousandeyesToTerraform(struct?: SloObjectiveCountMetricsTotalThousandeyes | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalThousandeyesToHclTerraform(struct?: SloObjectiveCountMetricsTotalThousandeyes | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalThousandeyesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotalThousandeyes | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotalThousandeyes | cdktn.IResolvable | undefined);
    private _testId?;
    get testId(): number;
    set testId(value: number);
    get testIdInput(): number | undefined;
    private _testType?;
    get testType(): string;
    set testType(value: string);
    resetTestType(): void;
    get testTypeInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsTotalThousandeyesList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotalThousandeyes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalThousandeyesOutputReference;
}
export interface SloObjectiveCountMetricsTotal {
    /**
    * amazon_prometheus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#amazon_prometheus Slo#amazon_prometheus}
    */
    readonly amazonPrometheus?: SloObjectiveCountMetricsTotalAmazonPrometheus[] | cdktn.IResolvable;
    /**
    * appdynamics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#appdynamics Slo#appdynamics}
    */
    readonly appdynamics?: SloObjectiveCountMetricsTotalAppdynamics[] | cdktn.IResolvable;
    /**
    * azure_monitor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#azure_monitor Slo#azure_monitor}
    */
    readonly azureMonitor?: SloObjectiveCountMetricsTotalAzureMonitor[] | cdktn.IResolvable;
    /**
    * bigquery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#bigquery Slo#bigquery}
    */
    readonly bigquery?: SloObjectiveCountMetricsTotalBigquery[] | cdktn.IResolvable;
    /**
    * cloudwatch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#cloudwatch Slo#cloudwatch}
    */
    readonly cloudwatch?: SloObjectiveCountMetricsTotalCloudwatch[] | cdktn.IResolvable;
    /**
    * datadog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#datadog Slo#datadog}
    */
    readonly datadog?: SloObjectiveCountMetricsTotalDatadog[] | cdktn.IResolvable;
    /**
    * dynatrace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dynatrace Slo#dynatrace}
    */
    readonly dynatrace?: SloObjectiveCountMetricsTotalDynatrace[] | cdktn.IResolvable;
    /**
    * elasticsearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#elasticsearch Slo#elasticsearch}
    */
    readonly elasticsearch?: SloObjectiveCountMetricsTotalElasticsearch[] | cdktn.IResolvable;
    /**
    * gcm block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#gcm Slo#gcm}
    */
    readonly gcm?: SloObjectiveCountMetricsTotalGcm[] | cdktn.IResolvable;
    /**
    * grafana_loki block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#grafana_loki Slo#grafana_loki}
    */
    readonly grafanaLoki?: SloObjectiveCountMetricsTotalGrafanaLoki[] | cdktn.IResolvable;
    /**
    * graphite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graphite Slo#graphite}
    */
    readonly graphite?: SloObjectiveCountMetricsTotalGraphite[] | cdktn.IResolvable;
    /**
    * honeycomb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#honeycomb Slo#honeycomb}
    */
    readonly honeycomb?: SloObjectiveCountMetricsTotalHoneycomb[] | cdktn.IResolvable;
    /**
    * influxdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#influxdb Slo#influxdb}
    */
    readonly influxdb?: SloObjectiveCountMetricsTotalInfluxdb[] | cdktn.IResolvable;
    /**
    * instana block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#instana Slo#instana}
    */
    readonly instana?: SloObjectiveCountMetricsTotalInstana[] | cdktn.IResolvable;
    /**
    * lightstep block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#lightstep Slo#lightstep}
    */
    readonly lightstep?: SloObjectiveCountMetricsTotalLightstep[] | cdktn.IResolvable;
    /**
    * logic_monitor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#logic_monitor Slo#logic_monitor}
    */
    readonly logicMonitor?: SloObjectiveCountMetricsTotalLogicMonitor[] | cdktn.IResolvable;
    /**
    * newrelic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#newrelic Slo#newrelic}
    */
    readonly newrelic?: SloObjectiveCountMetricsTotalNewrelic[] | cdktn.IResolvable;
    /**
    * opentsdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#opentsdb Slo#opentsdb}
    */
    readonly opentsdb?: SloObjectiveCountMetricsTotalOpentsdb[] | cdktn.IResolvable;
    /**
    * pingdom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#pingdom Slo#pingdom}
    */
    readonly pingdom?: SloObjectiveCountMetricsTotalPingdom[] | cdktn.IResolvable;
    /**
    * prometheus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#prometheus Slo#prometheus}
    */
    readonly prometheus?: SloObjectiveCountMetricsTotalPrometheus[] | cdktn.IResolvable;
    /**
    * redshift block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#redshift Slo#redshift}
    */
    readonly redshift?: SloObjectiveCountMetricsTotalRedshift[] | cdktn.IResolvable;
    /**
    * splunk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#splunk Slo#splunk}
    */
    readonly splunk?: SloObjectiveCountMetricsTotalSplunk[] | cdktn.IResolvable;
    /**
    * splunk_observability block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#splunk_observability Slo#splunk_observability}
    */
    readonly splunkObservability?: SloObjectiveCountMetricsTotalSplunkObservability[] | cdktn.IResolvable;
    /**
    * sumologic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#sumologic Slo#sumologic}
    */
    readonly sumologic?: SloObjectiveCountMetricsTotalSumologic[] | cdktn.IResolvable;
    /**
    * thousandeyes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#thousandeyes Slo#thousandeyes}
    */
    readonly thousandeyes?: SloObjectiveCountMetricsTotalThousandeyes[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsTotalToTerraform(struct?: SloObjectiveCountMetricsTotal | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsTotalToHclTerraform(struct?: SloObjectiveCountMetricsTotal | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsTotalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsTotal | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsTotal | cdktn.IResolvable | undefined);
    private _amazonPrometheus;
    get amazonPrometheus(): SloObjectiveCountMetricsTotalAmazonPrometheusList;
    putAmazonPrometheus(value: SloObjectiveCountMetricsTotalAmazonPrometheus[] | cdktn.IResolvable): void;
    resetAmazonPrometheus(): void;
    get amazonPrometheusInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalAmazonPrometheus[] | undefined;
    private _appdynamics;
    get appdynamics(): SloObjectiveCountMetricsTotalAppdynamicsList;
    putAppdynamics(value: SloObjectiveCountMetricsTotalAppdynamics[] | cdktn.IResolvable): void;
    resetAppdynamics(): void;
    get appdynamicsInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalAppdynamics[] | undefined;
    private _azureMonitor;
    get azureMonitor(): SloObjectiveCountMetricsTotalAzureMonitorList;
    putAzureMonitor(value: SloObjectiveCountMetricsTotalAzureMonitor[] | cdktn.IResolvable): void;
    resetAzureMonitor(): void;
    get azureMonitorInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalAzureMonitor[] | undefined;
    private _bigquery;
    get bigquery(): SloObjectiveCountMetricsTotalBigqueryList;
    putBigquery(value: SloObjectiveCountMetricsTotalBigquery[] | cdktn.IResolvable): void;
    resetBigquery(): void;
    get bigqueryInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalBigquery[] | undefined;
    private _cloudwatch;
    get cloudwatch(): SloObjectiveCountMetricsTotalCloudwatchList;
    putCloudwatch(value: SloObjectiveCountMetricsTotalCloudwatch[] | cdktn.IResolvable): void;
    resetCloudwatch(): void;
    get cloudwatchInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalCloudwatch[] | undefined;
    private _datadog;
    get datadog(): SloObjectiveCountMetricsTotalDatadogList;
    putDatadog(value: SloObjectiveCountMetricsTotalDatadog[] | cdktn.IResolvable): void;
    resetDatadog(): void;
    get datadogInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalDatadog[] | undefined;
    private _dynatrace;
    get dynatrace(): SloObjectiveCountMetricsTotalDynatraceList;
    putDynatrace(value: SloObjectiveCountMetricsTotalDynatrace[] | cdktn.IResolvable): void;
    resetDynatrace(): void;
    get dynatraceInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalDynatrace[] | undefined;
    private _elasticsearch;
    get elasticsearch(): SloObjectiveCountMetricsTotalElasticsearchList;
    putElasticsearch(value: SloObjectiveCountMetricsTotalElasticsearch[] | cdktn.IResolvable): void;
    resetElasticsearch(): void;
    get elasticsearchInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalElasticsearch[] | undefined;
    private _gcm;
    get gcm(): SloObjectiveCountMetricsTotalGcmList;
    putGcm(value: SloObjectiveCountMetricsTotalGcm[] | cdktn.IResolvable): void;
    resetGcm(): void;
    get gcmInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalGcm[] | undefined;
    private _grafanaLoki;
    get grafanaLoki(): SloObjectiveCountMetricsTotalGrafanaLokiList;
    putGrafanaLoki(value: SloObjectiveCountMetricsTotalGrafanaLoki[] | cdktn.IResolvable): void;
    resetGrafanaLoki(): void;
    get grafanaLokiInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalGrafanaLoki[] | undefined;
    private _graphite;
    get graphite(): SloObjectiveCountMetricsTotalGraphiteList;
    putGraphite(value: SloObjectiveCountMetricsTotalGraphite[] | cdktn.IResolvable): void;
    resetGraphite(): void;
    get graphiteInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalGraphite[] | undefined;
    private _honeycomb;
    get honeycomb(): SloObjectiveCountMetricsTotalHoneycombList;
    putHoneycomb(value: SloObjectiveCountMetricsTotalHoneycomb[] | cdktn.IResolvable): void;
    resetHoneycomb(): void;
    get honeycombInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalHoneycomb[] | undefined;
    private _influxdb;
    get influxdb(): SloObjectiveCountMetricsTotalInfluxdbList;
    putInfluxdb(value: SloObjectiveCountMetricsTotalInfluxdb[] | cdktn.IResolvable): void;
    resetInfluxdb(): void;
    get influxdbInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalInfluxdb[] | undefined;
    private _instana;
    get instana(): SloObjectiveCountMetricsTotalInstanaList;
    putInstana(value: SloObjectiveCountMetricsTotalInstana[] | cdktn.IResolvable): void;
    resetInstana(): void;
    get instanaInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalInstana[] | undefined;
    private _lightstep;
    get lightstep(): SloObjectiveCountMetricsTotalLightstepList;
    putLightstep(value: SloObjectiveCountMetricsTotalLightstep[] | cdktn.IResolvable): void;
    resetLightstep(): void;
    get lightstepInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalLightstep[] | undefined;
    private _logicMonitor;
    get logicMonitor(): SloObjectiveCountMetricsTotalLogicMonitorList;
    putLogicMonitor(value: SloObjectiveCountMetricsTotalLogicMonitor[] | cdktn.IResolvable): void;
    resetLogicMonitor(): void;
    get logicMonitorInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalLogicMonitor[] | undefined;
    private _newrelic;
    get newrelic(): SloObjectiveCountMetricsTotalNewrelicList;
    putNewrelic(value: SloObjectiveCountMetricsTotalNewrelic[] | cdktn.IResolvable): void;
    resetNewrelic(): void;
    get newrelicInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalNewrelic[] | undefined;
    private _opentsdb;
    get opentsdb(): SloObjectiveCountMetricsTotalOpentsdbList;
    putOpentsdb(value: SloObjectiveCountMetricsTotalOpentsdb[] | cdktn.IResolvable): void;
    resetOpentsdb(): void;
    get opentsdbInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalOpentsdb[] | undefined;
    private _pingdom;
    get pingdom(): SloObjectiveCountMetricsTotalPingdomList;
    putPingdom(value: SloObjectiveCountMetricsTotalPingdom[] | cdktn.IResolvable): void;
    resetPingdom(): void;
    get pingdomInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalPingdom[] | undefined;
    private _prometheus;
    get prometheus(): SloObjectiveCountMetricsTotalPrometheusList;
    putPrometheus(value: SloObjectiveCountMetricsTotalPrometheus[] | cdktn.IResolvable): void;
    resetPrometheus(): void;
    get prometheusInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalPrometheus[] | undefined;
    private _redshift;
    get redshift(): SloObjectiveCountMetricsTotalRedshiftList;
    putRedshift(value: SloObjectiveCountMetricsTotalRedshift[] | cdktn.IResolvable): void;
    resetRedshift(): void;
    get redshiftInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalRedshift[] | undefined;
    private _splunk;
    get splunk(): SloObjectiveCountMetricsTotalSplunkList;
    putSplunk(value: SloObjectiveCountMetricsTotalSplunk[] | cdktn.IResolvable): void;
    resetSplunk(): void;
    get splunkInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalSplunk[] | undefined;
    private _splunkObservability;
    get splunkObservability(): SloObjectiveCountMetricsTotalSplunkObservabilityList;
    putSplunkObservability(value: SloObjectiveCountMetricsTotalSplunkObservability[] | cdktn.IResolvable): void;
    resetSplunkObservability(): void;
    get splunkObservabilityInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalSplunkObservability[] | undefined;
    private _sumologic;
    get sumologic(): SloObjectiveCountMetricsTotalSumologicList;
    putSumologic(value: SloObjectiveCountMetricsTotalSumologic[] | cdktn.IResolvable): void;
    resetSumologic(): void;
    get sumologicInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalSumologic[] | undefined;
    private _thousandeyes;
    get thousandeyes(): SloObjectiveCountMetricsTotalThousandeyesList;
    putThousandeyes(value: SloObjectiveCountMetricsTotalThousandeyes[] | cdktn.IResolvable): void;
    resetThousandeyes(): void;
    get thousandeyesInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotalThousandeyes[] | undefined;
}
export declare class SloObjectiveCountMetricsTotalList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsTotal[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsTotalOutputReference;
}
export interface SloObjectiveCountMetrics {
    /**
    * Should the metrics be incrementing or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#incremental Slo#incremental}
    */
    readonly incremental: boolean | cdktn.IResolvable;
    /**
    * bad block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#bad Slo#bad}
    */
    readonly bad?: SloObjectiveCountMetricsBad[] | cdktn.IResolvable;
    /**
    * good block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#good Slo#good}
    */
    readonly good?: SloObjectiveCountMetricsGood[] | cdktn.IResolvable;
    /**
    * good_total block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#good_total Slo#good_total}
    */
    readonly goodTotal?: SloObjectiveCountMetricsGoodTotal[] | cdktn.IResolvable;
    /**
    * total block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#total Slo#total}
    */
    readonly total?: SloObjectiveCountMetricsTotal[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsToTerraform(struct?: SloObjectiveCountMetrics | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsToHclTerraform(struct?: SloObjectiveCountMetrics | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetrics | cdktn.IResolvable | undefined);
    private _incremental?;
    get incremental(): boolean | cdktn.IResolvable;
    set incremental(value: boolean | cdktn.IResolvable);
    get incrementalInput(): boolean | cdktn.IResolvable | undefined;
    private _bad;
    get bad(): SloObjectiveCountMetricsBadList;
    putBad(value: SloObjectiveCountMetricsBad[] | cdktn.IResolvable): void;
    resetBad(): void;
    get badInput(): cdktn.IResolvable | SloObjectiveCountMetricsBad[] | undefined;
    private _good;
    get good(): SloObjectiveCountMetricsGoodList;
    putGood(value: SloObjectiveCountMetricsGood[] | cdktn.IResolvable): void;
    resetGood(): void;
    get goodInput(): cdktn.IResolvable | SloObjectiveCountMetricsGood[] | undefined;
    private _goodTotal;
    get goodTotal(): SloObjectiveCountMetricsGoodTotalList;
    putGoodTotal(value: SloObjectiveCountMetricsGoodTotal[] | cdktn.IResolvable): void;
    resetGoodTotal(): void;
    get goodTotalInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotal[] | undefined;
    private _total;
    get total(): SloObjectiveCountMetricsTotalList;
    putTotal(value: SloObjectiveCountMetricsTotal[] | cdktn.IResolvable): void;
    resetTotal(): void;
    get totalInput(): cdktn.IResolvable | SloObjectiveCountMetricsTotal[] | undefined;
}
export declare class SloObjectiveCountMetricsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsOutputReference;
}
export interface SloObjectiveRawMetricQueryAmazonPrometheus {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql: string;
}
export declare function sloObjectiveRawMetricQueryAmazonPrometheusToTerraform(struct?: SloObjectiveRawMetricQueryAmazonPrometheus | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryAmazonPrometheusToHclTerraform(struct?: SloObjectiveRawMetricQueryAmazonPrometheus | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryAmazonPrometheusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryAmazonPrometheus | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryAmazonPrometheus | cdktn.IResolvable | undefined);
    private _promql?;
    get promql(): string;
    set promql(value: string);
    get promqlInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryAmazonPrometheusList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryAmazonPrometheus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryAmazonPrometheusOutputReference;
}
export interface SloObjectiveRawMetricQueryAppdynamics {
    /**
    * Name of the added application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#application_name Slo#application_name}
    */
    readonly applicationName: string;
    /**
    * Path to the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_path Slo#metric_path}
    */
    readonly metricPath: string;
}
export declare function sloObjectiveRawMetricQueryAppdynamicsToTerraform(struct?: SloObjectiveRawMetricQueryAppdynamics | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryAppdynamicsToHclTerraform(struct?: SloObjectiveRawMetricQueryAppdynamics | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryAppdynamicsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryAppdynamics | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryAppdynamics | cdktn.IResolvable | undefined);
    private _applicationName?;
    get applicationName(): string;
    set applicationName(value: string);
    get applicationNameInput(): string | undefined;
    private _metricPath?;
    get metricPath(): string;
    set metricPath(value: string);
    get metricPathInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryAppdynamicsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryAppdynamics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryAppdynamicsOutputReference;
}
export interface SloObjectiveRawMetricQueryAzureMonitorDimensions {
    /**
    * Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: string;
}
export declare function sloObjectiveRawMetricQueryAzureMonitorDimensionsToTerraform(struct?: SloObjectiveRawMetricQueryAzureMonitorDimensions | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryAzureMonitorDimensionsToHclTerraform(struct?: SloObjectiveRawMetricQueryAzureMonitorDimensions | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryAzureMonitorDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryAzureMonitorDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryAzureMonitorDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryAzureMonitorDimensionsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryAzureMonitorDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryAzureMonitorDimensionsOutputReference;
}
export interface SloObjectiveRawMetricQueryAzureMonitorWorkspace {
    /**
    * Resource group of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#resource_group Slo#resource_group}
    */
    readonly resourceGroup: string;
    /**
    * Subscription ID of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#subscription_id Slo#subscription_id}
    */
    readonly subscriptionId: string;
    /**
    * ID of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#workspace_id Slo#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function sloObjectiveRawMetricQueryAzureMonitorWorkspaceToTerraform(struct?: SloObjectiveRawMetricQueryAzureMonitorWorkspace | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryAzureMonitorWorkspaceToHclTerraform(struct?: SloObjectiveRawMetricQueryAzureMonitorWorkspace | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryAzureMonitorWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryAzureMonitorWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryAzureMonitorWorkspace | cdktn.IResolvable | undefined);
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    get subscriptionIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryAzureMonitorWorkspaceList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryAzureMonitorWorkspace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryAzureMonitorWorkspaceOutputReference;
}
export interface SloObjectiveRawMetricQueryAzureMonitor {
    /**
    * Aggregation type [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#aggregation Slo#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Specifies source: 'metrics' or 'logs'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#data_type Slo#data_type}
    */
    readonly dataType: string;
    /**
    * Logs query in Kusto Query Language [Required for logs]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#kql_query Slo#kql_query}
    */
    readonly kqlQuery?: string;
    /**
    * Name of the metric [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_name Slo#metric_name}
    */
    readonly metricName?: string;
    /**
    * Namespace of the metric [Optional for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_namespace Slo#metric_namespace}
    */
    readonly metricNamespace?: string;
    /**
    * Identifier of the Azure Cloud resource [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#resource_id Slo#resource_id}
    */
    readonly resourceId?: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dimensions Slo#dimensions}
    */
    readonly dimensions?: SloObjectiveRawMetricQueryAzureMonitorDimensions[] | cdktn.IResolvable;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#workspace Slo#workspace}
    */
    readonly workspace?: SloObjectiveRawMetricQueryAzureMonitorWorkspace[] | cdktn.IResolvable;
}
export declare function sloObjectiveRawMetricQueryAzureMonitorToTerraform(struct?: SloObjectiveRawMetricQueryAzureMonitor | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryAzureMonitorToHclTerraform(struct?: SloObjectiveRawMetricQueryAzureMonitor | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryAzureMonitorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryAzureMonitor | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryAzureMonitor | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _kqlQuery?;
    get kqlQuery(): string;
    set kqlQuery(value: string);
    resetKqlQuery(): void;
    get kqlQueryInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _metricNamespace?;
    get metricNamespace(): string;
    set metricNamespace(value: string);
    resetMetricNamespace(): void;
    get metricNamespaceInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _dimensions;
    get dimensions(): SloObjectiveRawMetricQueryAzureMonitorDimensionsList;
    putDimensions(value: SloObjectiveRawMetricQueryAzureMonitorDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryAzureMonitorDimensions[] | undefined;
    private _workspace;
    get workspace(): SloObjectiveRawMetricQueryAzureMonitorWorkspaceList;
    putWorkspace(value: SloObjectiveRawMetricQueryAzureMonitorWorkspace[] | cdktn.IResolvable): void;
    resetWorkspace(): void;
    get workspaceInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryAzureMonitorWorkspace[] | undefined;
}
export declare class SloObjectiveRawMetricQueryAzureMonitorList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryAzureMonitor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryAzureMonitorOutputReference;
}
export interface SloObjectiveRawMetricQueryBigquery {
    /**
    * Location of you BigQuery
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#location Slo#location}
    */
    readonly location: string;
    /**
    * Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project_id Slo#project_id}
    */
    readonly projectId: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveRawMetricQueryBigqueryToTerraform(struct?: SloObjectiveRawMetricQueryBigquery | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryBigqueryToHclTerraform(struct?: SloObjectiveRawMetricQueryBigquery | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryBigqueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryBigquery | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryBigquery | cdktn.IResolvable | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryBigqueryList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryBigquery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryBigqueryOutputReference;
}
export interface SloObjectiveRawMetricQueryCloudwatchDimensions {
    /**
    * Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: string;
}
export declare function sloObjectiveRawMetricQueryCloudwatchDimensionsToTerraform(struct?: SloObjectiveRawMetricQueryCloudwatchDimensions | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryCloudwatchDimensionsToHclTerraform(struct?: SloObjectiveRawMetricQueryCloudwatchDimensions | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryCloudwatchDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryCloudwatchDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryCloudwatchDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryCloudwatchDimensionsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryCloudwatchDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryCloudwatchDimensionsOutputReference;
}
export interface SloObjectiveRawMetricQueryCloudwatch {
    /**
    * AccountID used with cross-account observability feature
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#account_id Slo#account_id}
    */
    readonly accountId?: string;
    /**
    * JSON query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#json Slo#json}
    */
    readonly json?: string;
    /**
    * Metric name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_name Slo#metric_name}
    */
    readonly metricName?: string;
    /**
    * Namespace of the metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#namespace Slo#namespace}
    */
    readonly namespace?: string;
    /**
    * Region of the CloudWatch instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#region Slo#region}
    */
    readonly region: string;
    /**
    * SQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#sql Slo#sql}
    */
    readonly sql?: string;
    /**
    * Metric data aggregations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#stat Slo#stat}
    */
    readonly stat?: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dimensions Slo#dimensions}
    */
    readonly dimensions?: SloObjectiveRawMetricQueryCloudwatchDimensions[] | cdktn.IResolvable;
}
export declare function sloObjectiveRawMetricQueryCloudwatchToTerraform(struct?: SloObjectiveRawMetricQueryCloudwatch | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryCloudwatchToHclTerraform(struct?: SloObjectiveRawMetricQueryCloudwatch | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryCloudwatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryCloudwatch | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryCloudwatch | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _json?;
    get json(): string;
    set json(value: string);
    resetJson(): void;
    get jsonInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    resetSql(): void;
    get sqlInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _dimensions;
    get dimensions(): SloObjectiveRawMetricQueryCloudwatchDimensionsList;
    putDimensions(value: SloObjectiveRawMetricQueryCloudwatchDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryCloudwatchDimensions[] | undefined;
}
export declare class SloObjectiveRawMetricQueryCloudwatchList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryCloudwatch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryCloudwatchOutputReference;
}
export interface SloObjectiveRawMetricQueryDatadog {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveRawMetricQueryDatadogToTerraform(struct?: SloObjectiveRawMetricQueryDatadog | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryDatadogToHclTerraform(struct?: SloObjectiveRawMetricQueryDatadog | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryDatadog | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryDatadog | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryDatadogList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryDatadog[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryDatadogOutputReference;
}
export interface SloObjectiveRawMetricQueryDynatrace {
    /**
    * Selector for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_selector Slo#metric_selector}
    */
    readonly metricSelector: string;
}
export declare function sloObjectiveRawMetricQueryDynatraceToTerraform(struct?: SloObjectiveRawMetricQueryDynatrace | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryDynatraceToHclTerraform(struct?: SloObjectiveRawMetricQueryDynatrace | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryDynatraceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryDynatrace | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryDynatrace | cdktn.IResolvable | undefined);
    private _metricSelector?;
    get metricSelector(): string;
    set metricSelector(value: string);
    get metricSelectorInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryDynatraceList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryDynatrace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryDynatraceOutputReference;
}
export interface SloObjectiveRawMetricQueryElasticsearch {
    /**
    * Index of metrics we want to query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#index Slo#index}
    */
    readonly index: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveRawMetricQueryElasticsearchToTerraform(struct?: SloObjectiveRawMetricQueryElasticsearch | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryElasticsearchToHclTerraform(struct?: SloObjectiveRawMetricQueryElasticsearch | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryElasticsearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryElasticsearch | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryElasticsearch | cdktn.IResolvable | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryElasticsearchList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryElasticsearch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryElasticsearchOutputReference;
}
export interface SloObjectiveRawMetricQueryGcm {
    /**
    * Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project_id Slo#project_id}
    */
    readonly projectId: string;
    /**
    * Query for the metrics in PromQL format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql?: string;
    /**
    * Query for the metrics in MQL format ([deprecated](https://cloud.google.com/stackdriver/docs/deprecations/mql))
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query?: string;
}
export declare function sloObjectiveRawMetricQueryGcmToTerraform(struct?: SloObjectiveRawMetricQueryGcm | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryGcmToHclTerraform(struct?: SloObjectiveRawMetricQueryGcm | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryGcmOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryGcm | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryGcm | cdktn.IResolvable | undefined);
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _promql?;
    get promql(): string;
    set promql(value: string);
    resetPromql(): void;
    get promqlInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryGcmList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryGcm[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryGcmOutputReference;
}
export interface SloObjectiveRawMetricQueryGrafanaLoki {
    /**
    * Query for the logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#logql Slo#logql}
    */
    readonly logql: string;
}
export declare function sloObjectiveRawMetricQueryGrafanaLokiToTerraform(struct?: SloObjectiveRawMetricQueryGrafanaLoki | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryGrafanaLokiToHclTerraform(struct?: SloObjectiveRawMetricQueryGrafanaLoki | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryGrafanaLokiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryGrafanaLoki | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryGrafanaLoki | cdktn.IResolvable | undefined);
    private _logql?;
    get logql(): string;
    set logql(value: string);
    get logqlInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryGrafanaLokiList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryGrafanaLoki[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryGrafanaLokiOutputReference;
}
export interface SloObjectiveRawMetricQueryGraphite {
    /**
    * Path to the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_path Slo#metric_path}
    */
    readonly metricPath: string;
}
export declare function sloObjectiveRawMetricQueryGraphiteToTerraform(struct?: SloObjectiveRawMetricQueryGraphite | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryGraphiteToHclTerraform(struct?: SloObjectiveRawMetricQueryGraphite | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryGraphiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryGraphite | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryGraphite | cdktn.IResolvable | undefined);
    private _metricPath?;
    get metricPath(): string;
    set metricPath(value: string);
    get metricPathInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryGraphiteList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryGraphite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryGraphiteOutputReference;
}
export interface SloObjectiveRawMetricQueryHoneycomb {
    /**
    * Column name - required for all calculation types besides 'CONCURRENCY' and 'COUNT'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#attribute Slo#attribute}
    */
    readonly attribute?: string;
    /**
    * Calculation type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#calculation Slo#calculation}
    */
    readonly calculation: string;
}
export declare function sloObjectiveRawMetricQueryHoneycombToTerraform(struct?: SloObjectiveRawMetricQueryHoneycomb | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryHoneycombToHclTerraform(struct?: SloObjectiveRawMetricQueryHoneycomb | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryHoneycombOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryHoneycomb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryHoneycomb | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _calculation?;
    get calculation(): string;
    set calculation(value: string);
    get calculationInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryHoneycombList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryHoneycomb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryHoneycombOutputReference;
}
export interface SloObjectiveRawMetricQueryInfluxdb {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveRawMetricQueryInfluxdbToTerraform(struct?: SloObjectiveRawMetricQueryInfluxdb | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryInfluxdbToHclTerraform(struct?: SloObjectiveRawMetricQueryInfluxdb | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryInfluxdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryInfluxdb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryInfluxdb | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryInfluxdbList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryInfluxdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryInfluxdbOutputReference;
}
export interface SloObjectiveRawMetricQueryInstanaApplicationGroupBy {
    /**
    * Group by tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag Slo#tag}
    */
    readonly tag: string;
    /**
    * Tag entity - one of 'DESTINATION', 'SOURCE', 'NOT_APPLICABLE'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag_entity Slo#tag_entity}
    */
    readonly tagEntity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag_second_level_key Slo#tag_second_level_key}
    */
    readonly tagSecondLevelKey?: string;
}
export declare function sloObjectiveRawMetricQueryInstanaApplicationGroupByToTerraform(struct?: SloObjectiveRawMetricQueryInstanaApplicationGroupBy | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryInstanaApplicationGroupByToHclTerraform(struct?: SloObjectiveRawMetricQueryInstanaApplicationGroupBy | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryInstanaApplicationGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryInstanaApplicationGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryInstanaApplicationGroupBy | cdktn.IResolvable | undefined);
    private _tag?;
    get tag(): string;
    set tag(value: string);
    get tagInput(): string | undefined;
    private _tagEntity?;
    get tagEntity(): string;
    set tagEntity(value: string);
    get tagEntityInput(): string | undefined;
    private _tagSecondLevelKey?;
    get tagSecondLevelKey(): string;
    set tagSecondLevelKey(value: string);
    resetTagSecondLevelKey(): void;
    get tagSecondLevelKeyInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryInstanaApplicationGroupByList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryInstanaApplicationGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryInstanaApplicationGroupByOutputReference;
}
export interface SloObjectiveRawMetricQueryInstanaApplication {
    /**
    * Depends on the value specified for 'metric_id'- more info in N9 docs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#aggregation Slo#aggregation}
    */
    readonly aggregation: string;
    /**
    * API query user passes in a JSON format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#api_query Slo#api_query}
    */
    readonly apiQuery: string;
    /**
    * Include internal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#include_internal Slo#include_internal}
    */
    readonly includeInternal?: boolean | cdktn.IResolvable;
    /**
    * Include synthetic
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#include_synthetic Slo#include_synthetic}
    */
    readonly includeSynthetic?: boolean | cdktn.IResolvable;
    /**
    * Metric ID one of 'calls', 'erroneousCalls', 'errors', 'latency'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_id Slo#metric_id}
    */
    readonly metricId: string;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#group_by Slo#group_by}
    */
    readonly groupBy: SloObjectiveRawMetricQueryInstanaApplicationGroupBy[] | cdktn.IResolvable;
}
export declare function sloObjectiveRawMetricQueryInstanaApplicationToTerraform(struct?: SloObjectiveRawMetricQueryInstanaApplication | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryInstanaApplicationToHclTerraform(struct?: SloObjectiveRawMetricQueryInstanaApplication | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryInstanaApplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryInstanaApplication | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryInstanaApplication | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _apiQuery?;
    get apiQuery(): string;
    set apiQuery(value: string);
    get apiQueryInput(): string | undefined;
    private _includeInternal?;
    get includeInternal(): boolean | cdktn.IResolvable;
    set includeInternal(value: boolean | cdktn.IResolvable);
    resetIncludeInternal(): void;
    get includeInternalInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSynthetic?;
    get includeSynthetic(): boolean | cdktn.IResolvable;
    set includeSynthetic(value: boolean | cdktn.IResolvable);
    resetIncludeSynthetic(): void;
    get includeSyntheticInput(): boolean | cdktn.IResolvable | undefined;
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    get metricIdInput(): string | undefined;
    private _groupBy;
    get groupBy(): SloObjectiveRawMetricQueryInstanaApplicationGroupByList;
    putGroupBy(value: SloObjectiveRawMetricQueryInstanaApplicationGroupBy[] | cdktn.IResolvable): void;
    get groupByInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryInstanaApplicationGroupBy[] | undefined;
}
export declare class SloObjectiveRawMetricQueryInstanaApplicationList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryInstanaApplication[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryInstanaApplicationOutputReference;
}
export interface SloObjectiveRawMetricQueryInstanaInfrastructure {
    /**
    * Metric ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_id Slo#metric_id}
    */
    readonly metricId: string;
    /**
    * Metric retrieval method 'query' or 'snapshot'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_retrieval_method Slo#metric_retrieval_method}
    */
    readonly metricRetrievalMethod: string;
    /**
    * Plugin ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#plugin_id Slo#plugin_id}
    */
    readonly pluginId: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query?: string;
    /**
    * Snapshot ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#snapshot_id Slo#snapshot_id}
    */
    readonly snapshotId?: string;
}
export declare function sloObjectiveRawMetricQueryInstanaInfrastructureToTerraform(struct?: SloObjectiveRawMetricQueryInstanaInfrastructure | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryInstanaInfrastructureToHclTerraform(struct?: SloObjectiveRawMetricQueryInstanaInfrastructure | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryInstanaInfrastructureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryInstanaInfrastructure | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryInstanaInfrastructure | cdktn.IResolvable | undefined);
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    get metricIdInput(): string | undefined;
    private _metricRetrievalMethod?;
    get metricRetrievalMethod(): string;
    set metricRetrievalMethod(value: string);
    get metricRetrievalMethodInput(): string | undefined;
    private _pluginId?;
    get pluginId(): string;
    set pluginId(value: string);
    get pluginIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _snapshotId?;
    get snapshotId(): string;
    set snapshotId(value: string);
    resetSnapshotId(): void;
    get snapshotIdInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryInstanaInfrastructureList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryInstanaInfrastructure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryInstanaInfrastructureOutputReference;
}
export interface SloObjectiveRawMetricQueryInstana {
    /**
    * Instana metric type 'application' or 'infrastructure'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_type Slo#metric_type}
    */
    readonly metricType: string;
    /**
    * application block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#application Slo#application}
    */
    readonly application?: SloObjectiveRawMetricQueryInstanaApplication[] | cdktn.IResolvable;
    /**
    * infrastructure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#infrastructure Slo#infrastructure}
    */
    readonly infrastructure?: SloObjectiveRawMetricQueryInstanaInfrastructure[] | cdktn.IResolvable;
}
export declare function sloObjectiveRawMetricQueryInstanaToTerraform(struct?: SloObjectiveRawMetricQueryInstana | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryInstanaToHclTerraform(struct?: SloObjectiveRawMetricQueryInstana | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryInstanaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryInstana | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryInstana | cdktn.IResolvable | undefined);
    private _metricType?;
    get metricType(): string;
    set metricType(value: string);
    get metricTypeInput(): string | undefined;
    private _application;
    get application(): SloObjectiveRawMetricQueryInstanaApplicationList;
    putApplication(value: SloObjectiveRawMetricQueryInstanaApplication[] | cdktn.IResolvable): void;
    resetApplication(): void;
    get applicationInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryInstanaApplication[] | undefined;
    private _infrastructure;
    get infrastructure(): SloObjectiveRawMetricQueryInstanaInfrastructureList;
    putInfrastructure(value: SloObjectiveRawMetricQueryInstanaInfrastructure[] | cdktn.IResolvable): void;
    resetInfrastructure(): void;
    get infrastructureInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryInstanaInfrastructure[] | undefined;
}
export declare class SloObjectiveRawMetricQueryInstanaList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryInstana[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryInstanaOutputReference;
}
export interface SloObjectiveRawMetricQueryLightstep {
    /**
    * Optional value to filter by percentiles
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#percentile Slo#percentile}
    */
    readonly percentile?: number;
    /**
    * ID of the metrics stream
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#stream_id Slo#stream_id}
    */
    readonly streamId?: string;
    /**
    * Type of data to filter by
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#type_of_data Slo#type_of_data}
    */
    readonly typeOfData: string;
    /**
    * UQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#uql Slo#uql}
    */
    readonly uql?: string;
}
export declare function sloObjectiveRawMetricQueryLightstepToTerraform(struct?: SloObjectiveRawMetricQueryLightstep | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryLightstepToHclTerraform(struct?: SloObjectiveRawMetricQueryLightstep | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryLightstepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryLightstep | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryLightstep | cdktn.IResolvable | undefined);
    private _percentile?;
    get percentile(): number;
    set percentile(value: number);
    resetPercentile(): void;
    get percentileInput(): number | undefined;
    private _streamId?;
    get streamId(): string;
    set streamId(value: string);
    resetStreamId(): void;
    get streamIdInput(): string | undefined;
    private _typeOfData?;
    get typeOfData(): string;
    set typeOfData(value: string);
    get typeOfDataInput(): string | undefined;
    private _uql?;
    get uql(): string;
    set uql(value: string);
    resetUql(): void;
    get uqlInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryLightstepList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryLightstep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryLightstepOutputReference;
}
export interface SloObjectiveRawMetricQueryLogicMonitor {
    /**
    * Checkpoint ID. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#checkpoint_id Slo#checkpoint_id}
    */
    readonly checkpointId?: string;
    /**
    * Device Datasource Instance ID. Used by Query type = device_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#device_data_source_instance_id Slo#device_data_source_instance_id}
    */
    readonly deviceDataSourceInstanceId?: number;
    /**
    * Graph ID. Used by Query type = device_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graph_id Slo#graph_id}
    */
    readonly graphId?: number;
    /**
    * Graph Name. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graph_name Slo#graph_name}
    */
    readonly graphName?: string;
    /**
    * Line
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#line Slo#line}
    */
    readonly line: string;
    /**
    * Query type: device_metrics or website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query_type Slo#query_type}
    */
    readonly queryType: string;
    /**
    * Website ID. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#website_id Slo#website_id}
    */
    readonly websiteId?: string;
}
export declare function sloObjectiveRawMetricQueryLogicMonitorToTerraform(struct?: SloObjectiveRawMetricQueryLogicMonitor | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryLogicMonitorToHclTerraform(struct?: SloObjectiveRawMetricQueryLogicMonitor | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryLogicMonitorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryLogicMonitor | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryLogicMonitor | cdktn.IResolvable | undefined);
    private _checkpointId?;
    get checkpointId(): string;
    set checkpointId(value: string);
    resetCheckpointId(): void;
    get checkpointIdInput(): string | undefined;
    private _deviceDataSourceInstanceId?;
    get deviceDataSourceInstanceId(): number;
    set deviceDataSourceInstanceId(value: number);
    resetDeviceDataSourceInstanceId(): void;
    get deviceDataSourceInstanceIdInput(): number | undefined;
    private _graphId?;
    get graphId(): number;
    set graphId(value: number);
    resetGraphId(): void;
    get graphIdInput(): number | undefined;
    private _graphName?;
    get graphName(): string;
    set graphName(value: string);
    resetGraphName(): void;
    get graphNameInput(): string | undefined;
    private _line?;
    get line(): string;
    set line(value: string);
    get lineInput(): string | undefined;
    private _queryType?;
    get queryType(): string;
    set queryType(value: string);
    get queryTypeInput(): string | undefined;
    private _websiteId?;
    get websiteId(): string;
    set websiteId(value: string);
    resetWebsiteId(): void;
    get websiteIdInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryLogicMonitorList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryLogicMonitor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryLogicMonitorOutputReference;
}
export interface SloObjectiveRawMetricQueryNewrelic {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#nrql Slo#nrql}
    */
    readonly nrql: string;
}
export declare function sloObjectiveRawMetricQueryNewrelicToTerraform(struct?: SloObjectiveRawMetricQueryNewrelic | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryNewrelicToHclTerraform(struct?: SloObjectiveRawMetricQueryNewrelic | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryNewrelicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryNewrelic | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryNewrelic | cdktn.IResolvable | undefined);
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryNewrelicList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryNewrelic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryNewrelicOutputReference;
}
export interface SloObjectiveRawMetricQueryOpentsdb {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveRawMetricQueryOpentsdbToTerraform(struct?: SloObjectiveRawMetricQueryOpentsdb | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryOpentsdbToHclTerraform(struct?: SloObjectiveRawMetricQueryOpentsdb | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryOpentsdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryOpentsdb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryOpentsdb | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryOpentsdbList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryOpentsdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryOpentsdbOutputReference;
}
export interface SloObjectiveRawMetricQueryPingdom {
    /**
    * Pingdom uptime or transaction check's ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#check_id Slo#check_id}
    */
    readonly checkId: string;
    /**
    * Pingdom check type - uptime or transaction
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#check_type Slo#check_type}
    */
    readonly checkType?: string;
    /**
    * Optional for the Uptime checks. Use it to filter the Pingdom check results by status
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#status Slo#status}
    */
    readonly status?: string;
}
export declare function sloObjectiveRawMetricQueryPingdomToTerraform(struct?: SloObjectiveRawMetricQueryPingdom | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryPingdomToHclTerraform(struct?: SloObjectiveRawMetricQueryPingdom | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryPingdomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryPingdom | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryPingdom | cdktn.IResolvable | undefined);
    private _checkId?;
    get checkId(): string;
    set checkId(value: string);
    get checkIdInput(): string | undefined;
    private _checkType?;
    get checkType(): string;
    set checkType(value: string);
    resetCheckType(): void;
    get checkTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryPingdomList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryPingdom[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryPingdomOutputReference;
}
export interface SloObjectiveRawMetricQueryPrometheus {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql: string;
}
export declare function sloObjectiveRawMetricQueryPrometheusToTerraform(struct?: SloObjectiveRawMetricQueryPrometheus | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryPrometheusToHclTerraform(struct?: SloObjectiveRawMetricQueryPrometheus | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryPrometheusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryPrometheus | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryPrometheus | cdktn.IResolvable | undefined);
    private _promql?;
    get promql(): string;
    set promql(value: string);
    get promqlInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryPrometheusList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryPrometheus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryPrometheusOutputReference;
}
export interface SloObjectiveRawMetricQueryRedshift {
    /**
    * Redshift custer ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#cluster_id Slo#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Database name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#database_name Slo#database_name}
    */
    readonly databaseName: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
    /**
    * Region of the Redshift instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#region Slo#region}
    */
    readonly region: string;
}
export declare function sloObjectiveRawMetricQueryRedshiftToTerraform(struct?: SloObjectiveRawMetricQueryRedshift | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryRedshiftToHclTerraform(struct?: SloObjectiveRawMetricQueryRedshift | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryRedshiftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryRedshift | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryRedshift | cdktn.IResolvable | undefined);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryRedshiftList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryRedshift[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryRedshiftOutputReference;
}
export interface SloObjectiveRawMetricQuerySplunk {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveRawMetricQuerySplunkToTerraform(struct?: SloObjectiveRawMetricQuerySplunk | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQuerySplunkToHclTerraform(struct?: SloObjectiveRawMetricQuerySplunk | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQuerySplunkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQuerySplunk | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQuerySplunk | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQuerySplunkList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQuerySplunk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQuerySplunkOutputReference;
}
export interface SloObjectiveRawMetricQuerySplunkObservability {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#program Slo#program}
    */
    readonly program: string;
}
export declare function sloObjectiveRawMetricQuerySplunkObservabilityToTerraform(struct?: SloObjectiveRawMetricQuerySplunkObservability | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQuerySplunkObservabilityToHclTerraform(struct?: SloObjectiveRawMetricQuerySplunkObservability | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQuerySplunkObservabilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQuerySplunkObservability | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQuerySplunkObservability | cdktn.IResolvable | undefined);
    private _program?;
    get program(): string;
    set program(value: string);
    get programInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQuerySplunkObservabilityList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQuerySplunkObservability[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQuerySplunkObservabilityOutputReference;
}
export interface SloObjectiveRawMetricQuerySumologic {
    /**
    * Period of data aggregation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#quantization Slo#quantization}
    */
    readonly quantization?: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
    /**
    * Aggregation function - avg, sum, min, max, count, none
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#rollup Slo#rollup}
    */
    readonly rollup?: string;
    /**
    * Sumologic source - metrics or logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#type Slo#type}
    */
    readonly type: string;
}
export declare function sloObjectiveRawMetricQuerySumologicToTerraform(struct?: SloObjectiveRawMetricQuerySumologic | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQuerySumologicToHclTerraform(struct?: SloObjectiveRawMetricQuerySumologic | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQuerySumologicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQuerySumologic | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQuerySumologic | cdktn.IResolvable | undefined);
    private _quantization?;
    get quantization(): string;
    set quantization(value: string);
    resetQuantization(): void;
    get quantizationInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _rollup?;
    get rollup(): string;
    set rollup(value: string);
    resetRollup(): void;
    get rollupInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQuerySumologicList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQuerySumologic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQuerySumologicOutputReference;
}
export interface SloObjectiveRawMetricQueryThousandeyes {
    /**
    * ID of the test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#test_id Slo#test_id}
    */
    readonly testId: number;
    /**
    * Type of the test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#test_type Slo#test_type}
    */
    readonly testType?: string;
}
export declare function sloObjectiveRawMetricQueryThousandeyesToTerraform(struct?: SloObjectiveRawMetricQueryThousandeyes | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryThousandeyesToHclTerraform(struct?: SloObjectiveRawMetricQueryThousandeyes | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryThousandeyesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQueryThousandeyes | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQueryThousandeyes | cdktn.IResolvable | undefined);
    private _testId?;
    get testId(): number;
    set testId(value: number);
    get testIdInput(): number | undefined;
    private _testType?;
    get testType(): string;
    set testType(value: string);
    resetTestType(): void;
    get testTypeInput(): string | undefined;
}
export declare class SloObjectiveRawMetricQueryThousandeyesList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQueryThousandeyes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryThousandeyesOutputReference;
}
export interface SloObjectiveRawMetricQuery {
    /**
    * amazon_prometheus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#amazon_prometheus Slo#amazon_prometheus}
    */
    readonly amazonPrometheus?: SloObjectiveRawMetricQueryAmazonPrometheus[] | cdktn.IResolvable;
    /**
    * appdynamics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#appdynamics Slo#appdynamics}
    */
    readonly appdynamics?: SloObjectiveRawMetricQueryAppdynamics[] | cdktn.IResolvable;
    /**
    * azure_monitor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#azure_monitor Slo#azure_monitor}
    */
    readonly azureMonitor?: SloObjectiveRawMetricQueryAzureMonitor[] | cdktn.IResolvable;
    /**
    * bigquery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#bigquery Slo#bigquery}
    */
    readonly bigquery?: SloObjectiveRawMetricQueryBigquery[] | cdktn.IResolvable;
    /**
    * cloudwatch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#cloudwatch Slo#cloudwatch}
    */
    readonly cloudwatch?: SloObjectiveRawMetricQueryCloudwatch[] | cdktn.IResolvable;
    /**
    * datadog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#datadog Slo#datadog}
    */
    readonly datadog?: SloObjectiveRawMetricQueryDatadog[] | cdktn.IResolvable;
    /**
    * dynatrace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dynatrace Slo#dynatrace}
    */
    readonly dynatrace?: SloObjectiveRawMetricQueryDynatrace[] | cdktn.IResolvable;
    /**
    * elasticsearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#elasticsearch Slo#elasticsearch}
    */
    readonly elasticsearch?: SloObjectiveRawMetricQueryElasticsearch[] | cdktn.IResolvable;
    /**
    * gcm block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#gcm Slo#gcm}
    */
    readonly gcm?: SloObjectiveRawMetricQueryGcm[] | cdktn.IResolvable;
    /**
    * grafana_loki block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#grafana_loki Slo#grafana_loki}
    */
    readonly grafanaLoki?: SloObjectiveRawMetricQueryGrafanaLoki[] | cdktn.IResolvable;
    /**
    * graphite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graphite Slo#graphite}
    */
    readonly graphite?: SloObjectiveRawMetricQueryGraphite[] | cdktn.IResolvable;
    /**
    * honeycomb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#honeycomb Slo#honeycomb}
    */
    readonly honeycomb?: SloObjectiveRawMetricQueryHoneycomb[] | cdktn.IResolvable;
    /**
    * influxdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#influxdb Slo#influxdb}
    */
    readonly influxdb?: SloObjectiveRawMetricQueryInfluxdb[] | cdktn.IResolvable;
    /**
    * instana block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#instana Slo#instana}
    */
    readonly instana?: SloObjectiveRawMetricQueryInstana[] | cdktn.IResolvable;
    /**
    * lightstep block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#lightstep Slo#lightstep}
    */
    readonly lightstep?: SloObjectiveRawMetricQueryLightstep[] | cdktn.IResolvable;
    /**
    * logic_monitor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#logic_monitor Slo#logic_monitor}
    */
    readonly logicMonitor?: SloObjectiveRawMetricQueryLogicMonitor[] | cdktn.IResolvable;
    /**
    * newrelic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#newrelic Slo#newrelic}
    */
    readonly newrelic?: SloObjectiveRawMetricQueryNewrelic[] | cdktn.IResolvable;
    /**
    * opentsdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#opentsdb Slo#opentsdb}
    */
    readonly opentsdb?: SloObjectiveRawMetricQueryOpentsdb[] | cdktn.IResolvable;
    /**
    * pingdom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#pingdom Slo#pingdom}
    */
    readonly pingdom?: SloObjectiveRawMetricQueryPingdom[] | cdktn.IResolvable;
    /**
    * prometheus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#prometheus Slo#prometheus}
    */
    readonly prometheus?: SloObjectiveRawMetricQueryPrometheus[] | cdktn.IResolvable;
    /**
    * redshift block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#redshift Slo#redshift}
    */
    readonly redshift?: SloObjectiveRawMetricQueryRedshift[] | cdktn.IResolvable;
    /**
    * splunk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#splunk Slo#splunk}
    */
    readonly splunk?: SloObjectiveRawMetricQuerySplunk[] | cdktn.IResolvable;
    /**
    * splunk_observability block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#splunk_observability Slo#splunk_observability}
    */
    readonly splunkObservability?: SloObjectiveRawMetricQuerySplunkObservability[] | cdktn.IResolvable;
    /**
    * sumologic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#sumologic Slo#sumologic}
    */
    readonly sumologic?: SloObjectiveRawMetricQuerySumologic[] | cdktn.IResolvable;
    /**
    * thousandeyes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#thousandeyes Slo#thousandeyes}
    */
    readonly thousandeyes?: SloObjectiveRawMetricQueryThousandeyes[] | cdktn.IResolvable;
}
export declare function sloObjectiveRawMetricQueryToTerraform(struct?: SloObjectiveRawMetricQuery | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricQueryToHclTerraform(struct?: SloObjectiveRawMetricQuery | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetricQuery | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetricQuery | cdktn.IResolvable | undefined);
    private _amazonPrometheus;
    get amazonPrometheus(): SloObjectiveRawMetricQueryAmazonPrometheusList;
    putAmazonPrometheus(value: SloObjectiveRawMetricQueryAmazonPrometheus[] | cdktn.IResolvable): void;
    resetAmazonPrometheus(): void;
    get amazonPrometheusInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryAmazonPrometheus[] | undefined;
    private _appdynamics;
    get appdynamics(): SloObjectiveRawMetricQueryAppdynamicsList;
    putAppdynamics(value: SloObjectiveRawMetricQueryAppdynamics[] | cdktn.IResolvable): void;
    resetAppdynamics(): void;
    get appdynamicsInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryAppdynamics[] | undefined;
    private _azureMonitor;
    get azureMonitor(): SloObjectiveRawMetricQueryAzureMonitorList;
    putAzureMonitor(value: SloObjectiveRawMetricQueryAzureMonitor[] | cdktn.IResolvable): void;
    resetAzureMonitor(): void;
    get azureMonitorInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryAzureMonitor[] | undefined;
    private _bigquery;
    get bigquery(): SloObjectiveRawMetricQueryBigqueryList;
    putBigquery(value: SloObjectiveRawMetricQueryBigquery[] | cdktn.IResolvable): void;
    resetBigquery(): void;
    get bigqueryInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryBigquery[] | undefined;
    private _cloudwatch;
    get cloudwatch(): SloObjectiveRawMetricQueryCloudwatchList;
    putCloudwatch(value: SloObjectiveRawMetricQueryCloudwatch[] | cdktn.IResolvable): void;
    resetCloudwatch(): void;
    get cloudwatchInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryCloudwatch[] | undefined;
    private _datadog;
    get datadog(): SloObjectiveRawMetricQueryDatadogList;
    putDatadog(value: SloObjectiveRawMetricQueryDatadog[] | cdktn.IResolvable): void;
    resetDatadog(): void;
    get datadogInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryDatadog[] | undefined;
    private _dynatrace;
    get dynatrace(): SloObjectiveRawMetricQueryDynatraceList;
    putDynatrace(value: SloObjectiveRawMetricQueryDynatrace[] | cdktn.IResolvable): void;
    resetDynatrace(): void;
    get dynatraceInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryDynatrace[] | undefined;
    private _elasticsearch;
    get elasticsearch(): SloObjectiveRawMetricQueryElasticsearchList;
    putElasticsearch(value: SloObjectiveRawMetricQueryElasticsearch[] | cdktn.IResolvable): void;
    resetElasticsearch(): void;
    get elasticsearchInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryElasticsearch[] | undefined;
    private _gcm;
    get gcm(): SloObjectiveRawMetricQueryGcmList;
    putGcm(value: SloObjectiveRawMetricQueryGcm[] | cdktn.IResolvable): void;
    resetGcm(): void;
    get gcmInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryGcm[] | undefined;
    private _grafanaLoki;
    get grafanaLoki(): SloObjectiveRawMetricQueryGrafanaLokiList;
    putGrafanaLoki(value: SloObjectiveRawMetricQueryGrafanaLoki[] | cdktn.IResolvable): void;
    resetGrafanaLoki(): void;
    get grafanaLokiInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryGrafanaLoki[] | undefined;
    private _graphite;
    get graphite(): SloObjectiveRawMetricQueryGraphiteList;
    putGraphite(value: SloObjectiveRawMetricQueryGraphite[] | cdktn.IResolvable): void;
    resetGraphite(): void;
    get graphiteInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryGraphite[] | undefined;
    private _honeycomb;
    get honeycomb(): SloObjectiveRawMetricQueryHoneycombList;
    putHoneycomb(value: SloObjectiveRawMetricQueryHoneycomb[] | cdktn.IResolvable): void;
    resetHoneycomb(): void;
    get honeycombInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryHoneycomb[] | undefined;
    private _influxdb;
    get influxdb(): SloObjectiveRawMetricQueryInfluxdbList;
    putInfluxdb(value: SloObjectiveRawMetricQueryInfluxdb[] | cdktn.IResolvable): void;
    resetInfluxdb(): void;
    get influxdbInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryInfluxdb[] | undefined;
    private _instana;
    get instana(): SloObjectiveRawMetricQueryInstanaList;
    putInstana(value: SloObjectiveRawMetricQueryInstana[] | cdktn.IResolvable): void;
    resetInstana(): void;
    get instanaInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryInstana[] | undefined;
    private _lightstep;
    get lightstep(): SloObjectiveRawMetricQueryLightstepList;
    putLightstep(value: SloObjectiveRawMetricQueryLightstep[] | cdktn.IResolvable): void;
    resetLightstep(): void;
    get lightstepInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryLightstep[] | undefined;
    private _logicMonitor;
    get logicMonitor(): SloObjectiveRawMetricQueryLogicMonitorList;
    putLogicMonitor(value: SloObjectiveRawMetricQueryLogicMonitor[] | cdktn.IResolvable): void;
    resetLogicMonitor(): void;
    get logicMonitorInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryLogicMonitor[] | undefined;
    private _newrelic;
    get newrelic(): SloObjectiveRawMetricQueryNewrelicList;
    putNewrelic(value: SloObjectiveRawMetricQueryNewrelic[] | cdktn.IResolvable): void;
    resetNewrelic(): void;
    get newrelicInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryNewrelic[] | undefined;
    private _opentsdb;
    get opentsdb(): SloObjectiveRawMetricQueryOpentsdbList;
    putOpentsdb(value: SloObjectiveRawMetricQueryOpentsdb[] | cdktn.IResolvable): void;
    resetOpentsdb(): void;
    get opentsdbInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryOpentsdb[] | undefined;
    private _pingdom;
    get pingdom(): SloObjectiveRawMetricQueryPingdomList;
    putPingdom(value: SloObjectiveRawMetricQueryPingdom[] | cdktn.IResolvable): void;
    resetPingdom(): void;
    get pingdomInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryPingdom[] | undefined;
    private _prometheus;
    get prometheus(): SloObjectiveRawMetricQueryPrometheusList;
    putPrometheus(value: SloObjectiveRawMetricQueryPrometheus[] | cdktn.IResolvable): void;
    resetPrometheus(): void;
    get prometheusInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryPrometheus[] | undefined;
    private _redshift;
    get redshift(): SloObjectiveRawMetricQueryRedshiftList;
    putRedshift(value: SloObjectiveRawMetricQueryRedshift[] | cdktn.IResolvable): void;
    resetRedshift(): void;
    get redshiftInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryRedshift[] | undefined;
    private _splunk;
    get splunk(): SloObjectiveRawMetricQuerySplunkList;
    putSplunk(value: SloObjectiveRawMetricQuerySplunk[] | cdktn.IResolvable): void;
    resetSplunk(): void;
    get splunkInput(): cdktn.IResolvable | SloObjectiveRawMetricQuerySplunk[] | undefined;
    private _splunkObservability;
    get splunkObservability(): SloObjectiveRawMetricQuerySplunkObservabilityList;
    putSplunkObservability(value: SloObjectiveRawMetricQuerySplunkObservability[] | cdktn.IResolvable): void;
    resetSplunkObservability(): void;
    get splunkObservabilityInput(): cdktn.IResolvable | SloObjectiveRawMetricQuerySplunkObservability[] | undefined;
    private _sumologic;
    get sumologic(): SloObjectiveRawMetricQuerySumologicList;
    putSumologic(value: SloObjectiveRawMetricQuerySumologic[] | cdktn.IResolvable): void;
    resetSumologic(): void;
    get sumologicInput(): cdktn.IResolvable | SloObjectiveRawMetricQuerySumologic[] | undefined;
    private _thousandeyes;
    get thousandeyes(): SloObjectiveRawMetricQueryThousandeyesList;
    putThousandeyes(value: SloObjectiveRawMetricQueryThousandeyes[] | cdktn.IResolvable): void;
    resetThousandeyes(): void;
    get thousandeyesInput(): cdktn.IResolvable | SloObjectiveRawMetricQueryThousandeyes[] | undefined;
}
export declare class SloObjectiveRawMetricQueryList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetricQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricQueryOutputReference;
}
export interface SloObjectiveRawMetric {
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: SloObjectiveRawMetricQuery[] | cdktn.IResolvable;
}
export declare function sloObjectiveRawMetricToTerraform(struct?: SloObjectiveRawMetric | cdktn.IResolvable): any;
export declare function sloObjectiveRawMetricToHclTerraform(struct?: SloObjectiveRawMetric | cdktn.IResolvable): any;
export declare class SloObjectiveRawMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveRawMetric | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveRawMetric | cdktn.IResolvable | undefined);
    private _query;
    get query(): SloObjectiveRawMetricQueryList;
    putQuery(value: SloObjectiveRawMetricQuery[] | cdktn.IResolvable): void;
    get queryInput(): cdktn.IResolvable | SloObjectiveRawMetricQuery[] | undefined;
}
export declare class SloObjectiveRawMetricList extends cdktn.ComplexList {
    internalValue?: SloObjectiveRawMetric[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveRawMetricOutputReference;
}
export interface SloObjective {
    /**
    * Name to be displayed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#display_name Slo#display_name}
    */
    readonly displayName?: string;
    /**
    * Objective's name. This field is computed if not provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name?: string;
    /**
    * For threshold metrics, the logical operator applied to the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#op Slo#op}
    */
    readonly op?: string;
    /**
    * Is objective marked as primary.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#primary Slo#primary}
    */
    readonly primary?: boolean | cdktn.IResolvable;
    /**
    * The numeric target for your objective.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#target Slo#target}
    */
    readonly target: number;
    /**
    * Designated value for slice.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#time_slice_target Slo#time_slice_target}
    */
    readonly timeSliceTarget?: number;
    /**
    * Required for threshold and ratio metrics. Optional for composite SLOs. For threshold metrics, the threshold value. For ratio metrics, this must be a unique value per objective (for legacy reasons). For composite SLOs, it should be omitted. If, for composite SLO, it was set previously to a non-zero value, then it must remain unchanged.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value?: number;
    /**
    * composite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#composite Slo#composite}
    */
    readonly composite?: SloObjectiveComposite;
    /**
    * count_metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#count_metrics Slo#count_metrics}
    */
    readonly countMetrics?: SloObjectiveCountMetrics[] | cdktn.IResolvable;
    /**
    * raw_metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#raw_metric Slo#raw_metric}
    */
    readonly rawMetric?: SloObjectiveRawMetric[] | cdktn.IResolvable;
}
export declare function sloObjectiveToTerraform(struct?: SloObjective | cdktn.IResolvable): any;
export declare function sloObjectiveToHclTerraform(struct?: SloObjective | cdktn.IResolvable): any;
export declare class SloObjectiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjective | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjective | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    resetOp(): void;
    get opInput(): string | undefined;
    private _primary?;
    get primary(): boolean | cdktn.IResolvable;
    set primary(value: boolean | cdktn.IResolvable);
    resetPrimary(): void;
    get primaryInput(): boolean | cdktn.IResolvable | undefined;
    private _target?;
    get target(): number;
    set target(value: number);
    get targetInput(): number | undefined;
    private _timeSliceTarget?;
    get timeSliceTarget(): number;
    set timeSliceTarget(value: number);
    resetTimeSliceTarget(): void;
    get timeSliceTargetInput(): number | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
    private _composite;
    get composite(): SloObjectiveCompositeOutputReference;
    putComposite(value: SloObjectiveComposite): void;
    resetComposite(): void;
    get compositeInput(): SloObjectiveComposite | undefined;
    private _countMetrics;
    get countMetrics(): SloObjectiveCountMetricsList;
    putCountMetrics(value: SloObjectiveCountMetrics[] | cdktn.IResolvable): void;
    resetCountMetrics(): void;
    get countMetricsInput(): cdktn.IResolvable | SloObjectiveCountMetrics[] | undefined;
    private _rawMetric;
    get rawMetric(): SloObjectiveRawMetricList;
    putRawMetric(value: SloObjectiveRawMetric[] | cdktn.IResolvable): void;
    resetRawMetric(): void;
    get rawMetricInput(): cdktn.IResolvable | SloObjectiveRawMetric[] | undefined;
}
export declare class SloObjectiveList extends cdktn.ComplexList {
    internalValue?: SloObjective[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveOutputReference;
}
export interface SloTimeWindowCalendar {
    /**
    * Date of the start.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#start_time Slo#start_time}
    */
    readonly startTime: string;
    /**
    * Timezone name in IANA Time Zone Database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#time_zone Slo#time_zone}
    */
    readonly timeZone: string;
}
export declare function sloTimeWindowCalendarToTerraform(struct?: SloTimeWindowCalendar | cdktn.IResolvable): any;
export declare function sloTimeWindowCalendarToHclTerraform(struct?: SloTimeWindowCalendar | cdktn.IResolvable): any;
export declare class SloTimeWindowCalendarOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloTimeWindowCalendar | cdktn.IResolvable | undefined;
    set internalValue(value: SloTimeWindowCalendar | cdktn.IResolvable | undefined);
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
}
export declare class SloTimeWindowCalendarList extends cdktn.ComplexList {
    internalValue?: SloTimeWindowCalendar[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloTimeWindowCalendarOutputReference;
}
export interface SloTimeWindow {
    /**
    * Count of the time unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#count Slo#count}
    */
    readonly count: number;
    /**
    * Is the window moving or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#is_rolling Slo#is_rolling}
    */
    readonly isRolling?: boolean | cdktn.IResolvable;
    /**
    * Unit of time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#unit Slo#unit}
    */
    readonly unit: string;
    /**
    * calendar block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#calendar Slo#calendar}
    */
    readonly calendar?: SloTimeWindowCalendar[] | cdktn.IResolvable;
}
export declare function sloTimeWindowToTerraform(struct?: SloTimeWindowOutputReference | SloTimeWindow): any;
export declare function sloTimeWindowToHclTerraform(struct?: SloTimeWindowOutputReference | SloTimeWindow): any;
export declare class SloTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SloTimeWindow | undefined;
    set internalValue(value: SloTimeWindow | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    get countInput(): number | undefined;
    private _isRolling?;
    get isRolling(): boolean | cdktn.IResolvable;
    set isRolling(value: boolean | cdktn.IResolvable);
    resetIsRolling(): void;
    get isRollingInput(): boolean | cdktn.IResolvable | undefined;
    private _period;
    get period(): cdktn.StringMap;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _calendar;
    get calendar(): SloTimeWindowCalendarList;
    putCalendar(value: SloTimeWindowCalendar[] | cdktn.IResolvable): void;
    resetCalendar(): void;
    get calendarInput(): cdktn.IResolvable | SloTimeWindowCalendar[] | undefined;
}
