import * as cdktn from 'cdktn';
export interface SloAnomalyConfigNoDataAlertMethod {
    /**
    * The name of the previously defined alert method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Project name the Alert Method is in,  must conform to the naming convention from [DNS RFC1123] (https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names). If not defined, Nobl9 returns a default value for this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project Slo#project}
    */
    readonly project: string;
}
export declare function sloAnomalyConfigNoDataAlertMethodToTerraform(struct?: SloAnomalyConfigNoDataAlertMethod | cdktn.IResolvable): any;
export declare function sloAnomalyConfigNoDataAlertMethodToHclTerraform(struct?: SloAnomalyConfigNoDataAlertMethod | cdktn.IResolvable): any;
export declare class SloAnomalyConfigNoDataAlertMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloAnomalyConfigNoDataAlertMethod | cdktn.IResolvable | undefined;
    set internalValue(value: SloAnomalyConfigNoDataAlertMethod | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
}
export declare class SloAnomalyConfigNoDataAlertMethodList extends cdktn.ComplexList {
    internalValue?: SloAnomalyConfigNoDataAlertMethod[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloAnomalyConfigNoDataAlertMethodOutputReference;
}
export interface SloAnomalyConfigNoData {
    /**
    * alert_method block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#alert_method Slo#alert_method}
    */
    readonly alertMethod: SloAnomalyConfigNoDataAlertMethod[] | cdktn.IResolvable;
}
export declare function sloAnomalyConfigNoDataToTerraform(struct?: SloAnomalyConfigNoDataOutputReference | SloAnomalyConfigNoData): any;
export declare function sloAnomalyConfigNoDataToHclTerraform(struct?: SloAnomalyConfigNoDataOutputReference | SloAnomalyConfigNoData): any;
export declare class SloAnomalyConfigNoDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SloAnomalyConfigNoData | undefined;
    set internalValue(value: SloAnomalyConfigNoData | undefined);
    private _alertMethod;
    get alertMethod(): SloAnomalyConfigNoDataAlertMethodList;
    putAlertMethod(value: SloAnomalyConfigNoDataAlertMethod[] | cdktn.IResolvable): void;
    get alertMethodInput(): cdktn.IResolvable | SloAnomalyConfigNoDataAlertMethod[] | undefined;
}
export interface SloAnomalyConfig {
    /**
    * no_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#no_data Slo#no_data}
    */
    readonly noData: SloAnomalyConfigNoData;
}
export declare function sloAnomalyConfigToTerraform(struct?: SloAnomalyConfigOutputReference | SloAnomalyConfig): any;
export declare function sloAnomalyConfigToHclTerraform(struct?: SloAnomalyConfigOutputReference | SloAnomalyConfig): any;
export declare class SloAnomalyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SloAnomalyConfig | undefined;
    set internalValue(value: SloAnomalyConfig | undefined);
    private _noData;
    get noData(): SloAnomalyConfigNoDataOutputReference;
    putNoData(value: SloAnomalyConfigNoData): void;
    get noDataInput(): SloAnomalyConfigNoData | undefined;
}
export interface SloAttachment {
    /**
    * Name displayed for the attachment. Max. length: 63 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#display_name Slo#display_name}
    */
    readonly displayName?: string;
    /**
    * URL to the attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#url Slo#url}
    */
    readonly url: string;
}
export declare function sloAttachmentToTerraform(struct?: SloAttachment | cdktn.IResolvable): any;
export declare function sloAttachmentToHclTerraform(struct?: SloAttachment | cdktn.IResolvable): any;
export declare class SloAttachmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloAttachment | cdktn.IResolvable | undefined;
    set internalValue(value: SloAttachment | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class SloAttachmentList extends cdktn.ComplexList {
    internalValue?: SloAttachment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloAttachmentOutputReference;
}
export interface SloAttachments {
    /**
    * Name displayed for the attachment. Max. length: 63 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#display_name Slo#display_name}
    */
    readonly displayName?: string;
    /**
    * URL to the attachment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#url Slo#url}
    */
    readonly url: string;
}
export declare function sloAttachmentsToTerraform(struct?: SloAttachments | cdktn.IResolvable): any;
export declare function sloAttachmentsToHclTerraform(struct?: SloAttachments | cdktn.IResolvable): any;
export declare class SloAttachmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloAttachments | cdktn.IResolvable | undefined;
    set internalValue(value: SloAttachments | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class SloAttachmentsList extends cdktn.ComplexList {
    internalValue?: SloAttachments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloAttachmentsOutputReference;
}
export interface SloCompositeBurnRateCondition {
    /**
    * Type of logical operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#op Slo#op}
    */
    readonly op: string;
    /**
    * Burn rate value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: number;
}
export declare function sloCompositeBurnRateConditionToTerraform(struct?: SloCompositeBurnRateCondition | cdktn.IResolvable): any;
export declare function sloCompositeBurnRateConditionToHclTerraform(struct?: SloCompositeBurnRateCondition | cdktn.IResolvable): any;
export declare class SloCompositeBurnRateConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloCompositeBurnRateCondition | cdktn.IResolvable | undefined;
    set internalValue(value: SloCompositeBurnRateCondition | cdktn.IResolvable | undefined);
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class SloCompositeBurnRateConditionList extends cdktn.ComplexList {
    internalValue?: SloCompositeBurnRateCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloCompositeBurnRateConditionOutputReference;
}
export interface SloComposite {
    /**
    * The numeric target for your objective.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#target Slo#target}
    */
    readonly target: number;
    /**
    * burn_rate_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#burn_rate_condition Slo#burn_rate_condition}
    */
    readonly burnRateCondition?: SloCompositeBurnRateCondition[] | cdktn.IResolvable;
}
export declare function sloCompositeToTerraform(struct?: SloCompositeOutputReference | SloComposite): any;
export declare function sloCompositeToHclTerraform(struct?: SloCompositeOutputReference | SloComposite): any;
export declare class SloCompositeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SloComposite | undefined;
    set internalValue(value: SloComposite | undefined);
    private _target?;
    get target(): number;
    set target(value: number);
    get targetInput(): number | undefined;
    private _burnRateCondition;
    get burnRateCondition(): SloCompositeBurnRateConditionList;
    putBurnRateCondition(value: SloCompositeBurnRateCondition[] | cdktn.IResolvable): void;
    resetBurnRateCondition(): void;
    get burnRateConditionInput(): cdktn.IResolvable | SloCompositeBurnRateCondition[] | undefined;
}
export interface SloIndicator {
    /**
    * Kind of the metric source. One of {Agent, Direct}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#kind Slo#kind}
    */
    readonly kind?: string;
    /**
    * Name of the metric source (agent).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Name of the metric source project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project Slo#project}
    */
    readonly project?: string;
}
export declare function sloIndicatorToTerraform(struct?: SloIndicatorOutputReference | SloIndicator): any;
export declare function sloIndicatorToHclTerraform(struct?: SloIndicatorOutputReference | SloIndicator): any;
export declare class SloIndicatorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SloIndicator | undefined;
    set internalValue(value: SloIndicator | undefined);
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
}
export interface SloLabel {
    /**
    * A key for the label, unique within the associated resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#key Slo#key}
    */
    readonly key: string;
    /**
    * A list of unique values for a single key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#values Slo#values}
    */
    readonly values: string[];
}
export declare function sloLabelToTerraform(struct?: SloLabel | cdktn.IResolvable): any;
export declare function sloLabelToHclTerraform(struct?: SloLabel | cdktn.IResolvable): any;
export declare class SloLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloLabel | cdktn.IResolvable | undefined;
    set internalValue(value: SloLabel | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class SloLabelList extends cdktn.ComplexList {
    internalValue?: SloLabel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloLabelOutputReference;
}
export interface SloObjectiveCompositeComponentsObjectivesCompositeObjective {
    /**
    * SLO objective name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#objective Slo#objective}
    */
    readonly objective: string;
    /**
    * Project name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project Slo#project}
    */
    readonly project: string;
    /**
    * SLO name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#slo Slo#slo}
    */
    readonly slo: string;
    /**
    * Weights determine each component’s contribution to the composite SLO.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#weight Slo#weight}
    */
    readonly weight: number;
    /**
    * Defines how to treat missing component data on `max_delay` expiry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#when_delayed Slo#when_delayed}
    */
    readonly whenDelayed: string;
}
export declare function sloObjectiveCompositeComponentsObjectivesCompositeObjectiveToTerraform(struct?: SloObjectiveCompositeComponentsObjectivesCompositeObjective | cdktn.IResolvable): any;
export declare function sloObjectiveCompositeComponentsObjectivesCompositeObjectiveToHclTerraform(struct?: SloObjectiveCompositeComponentsObjectivesCompositeObjective | cdktn.IResolvable): any;
export declare class SloObjectiveCompositeComponentsObjectivesCompositeObjectiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCompositeComponentsObjectivesCompositeObjective | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCompositeComponentsObjectivesCompositeObjective | cdktn.IResolvable | undefined);
    private _objective?;
    get objective(): string;
    set objective(value: string);
    get objectiveInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _slo?;
    get slo(): string;
    set slo(value: string);
    get sloInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
    private _whenDelayed?;
    get whenDelayed(): string;
    set whenDelayed(value: string);
    get whenDelayedInput(): string | undefined;
}
export declare class SloObjectiveCompositeComponentsObjectivesCompositeObjectiveList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCompositeComponentsObjectivesCompositeObjective[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCompositeComponentsObjectivesCompositeObjectiveOutputReference;
}
export interface SloObjectiveCompositeComponentsObjectives {
    /**
    * composite_objective block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#composite_objective Slo#composite_objective}
    */
    readonly compositeObjective?: SloObjectiveCompositeComponentsObjectivesCompositeObjective[] | cdktn.IResolvable;
}
export declare function sloObjectiveCompositeComponentsObjectivesToTerraform(struct?: SloObjectiveCompositeComponentsObjectivesOutputReference | SloObjectiveCompositeComponentsObjectives): any;
export declare function sloObjectiveCompositeComponentsObjectivesToHclTerraform(struct?: SloObjectiveCompositeComponentsObjectivesOutputReference | SloObjectiveCompositeComponentsObjectives): any;
export declare class SloObjectiveCompositeComponentsObjectivesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SloObjectiveCompositeComponentsObjectives | undefined;
    set internalValue(value: SloObjectiveCompositeComponentsObjectives | undefined);
    private _compositeObjective;
    get compositeObjective(): SloObjectiveCompositeComponentsObjectivesCompositeObjectiveList;
    putCompositeObjective(value: SloObjectiveCompositeComponentsObjectivesCompositeObjective[] | cdktn.IResolvable): void;
    resetCompositeObjective(): void;
    get compositeObjectiveInput(): cdktn.IResolvable | SloObjectiveCompositeComponentsObjectivesCompositeObjective[] | undefined;
}
export interface SloObjectiveCompositeComponents {
    /**
    * objectives block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#objectives Slo#objectives}
    */
    readonly objectives?: SloObjectiveCompositeComponentsObjectives;
}
export declare function sloObjectiveCompositeComponentsToTerraform(struct?: SloObjectiveCompositeComponentsOutputReference | SloObjectiveCompositeComponents): any;
export declare function sloObjectiveCompositeComponentsToHclTerraform(struct?: SloObjectiveCompositeComponentsOutputReference | SloObjectiveCompositeComponents): any;
export declare class SloObjectiveCompositeComponentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SloObjectiveCompositeComponents | undefined;
    set internalValue(value: SloObjectiveCompositeComponents | undefined);
    private _objectives;
    get objectives(): SloObjectiveCompositeComponentsObjectivesOutputReference;
    putObjectives(value: SloObjectiveCompositeComponentsObjectives): void;
    resetObjectives(): void;
    get objectivesInput(): SloObjectiveCompositeComponentsObjectives | undefined;
}
export interface SloObjectiveComposite {
    /**
    * Maximum time for your composite SLO to wait for data from objectives.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#max_delay Slo#max_delay}
    */
    readonly maxDelay: string;
    /**
    * components block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#components Slo#components}
    */
    readonly components?: SloObjectiveCompositeComponents;
}
export declare function sloObjectiveCompositeToTerraform(struct?: SloObjectiveCompositeOutputReference | SloObjectiveComposite): any;
export declare function sloObjectiveCompositeToHclTerraform(struct?: SloObjectiveCompositeOutputReference | SloObjectiveComposite): any;
export declare class SloObjectiveCompositeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SloObjectiveComposite | undefined;
    set internalValue(value: SloObjectiveComposite | undefined);
    private _maxDelay?;
    get maxDelay(): string;
    set maxDelay(value: string);
    get maxDelayInput(): string | undefined;
    private _components;
    get components(): SloObjectiveCompositeComponentsOutputReference;
    putComponents(value: SloObjectiveCompositeComponents): void;
    resetComponents(): void;
    get componentsInput(): SloObjectiveCompositeComponents | undefined;
}
export interface SloObjectiveCountMetricsBadAmazonPrometheus {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql: string;
}
export declare function sloObjectiveCountMetricsBadAmazonPrometheusToTerraform(struct?: SloObjectiveCountMetricsBadAmazonPrometheus | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadAmazonPrometheusToHclTerraform(struct?: SloObjectiveCountMetricsBadAmazonPrometheus | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadAmazonPrometheusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadAmazonPrometheus | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadAmazonPrometheus | cdktn.IResolvable | undefined);
    private _promql?;
    get promql(): string;
    set promql(value: string);
    get promqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadAmazonPrometheusList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadAmazonPrometheus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadAmazonPrometheusOutputReference;
}
export interface SloObjectiveCountMetricsBadAppdynamics {
    /**
    * Name of the added application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#application_name Slo#application_name}
    */
    readonly applicationName: string;
    /**
    * Path to the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_path Slo#metric_path}
    */
    readonly metricPath: string;
}
export declare function sloObjectiveCountMetricsBadAppdynamicsToTerraform(struct?: SloObjectiveCountMetricsBadAppdynamics | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadAppdynamicsToHclTerraform(struct?: SloObjectiveCountMetricsBadAppdynamics | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadAppdynamicsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadAppdynamics | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadAppdynamics | cdktn.IResolvable | undefined);
    private _applicationName?;
    get applicationName(): string;
    set applicationName(value: string);
    get applicationNameInput(): string | undefined;
    private _metricPath?;
    get metricPath(): string;
    set metricPath(value: string);
    get metricPathInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadAppdynamicsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadAppdynamics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadAppdynamicsOutputReference;
}
export interface SloObjectiveCountMetricsBadAzureMonitorDimensions {
    /**
    * Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: string;
}
export declare function sloObjectiveCountMetricsBadAzureMonitorDimensionsToTerraform(struct?: SloObjectiveCountMetricsBadAzureMonitorDimensions | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadAzureMonitorDimensionsToHclTerraform(struct?: SloObjectiveCountMetricsBadAzureMonitorDimensions | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadAzureMonitorDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadAzureMonitorDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadAzureMonitorDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadAzureMonitorDimensionsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadAzureMonitorDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadAzureMonitorDimensionsOutputReference;
}
export interface SloObjectiveCountMetricsBadAzureMonitorWorkspace {
    /**
    * Resource group of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#resource_group Slo#resource_group}
    */
    readonly resourceGroup: string;
    /**
    * Subscription ID of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#subscription_id Slo#subscription_id}
    */
    readonly subscriptionId: string;
    /**
    * ID of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#workspace_id Slo#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function sloObjectiveCountMetricsBadAzureMonitorWorkspaceToTerraform(struct?: SloObjectiveCountMetricsBadAzureMonitorWorkspace | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadAzureMonitorWorkspaceToHclTerraform(struct?: SloObjectiveCountMetricsBadAzureMonitorWorkspace | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadAzureMonitorWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadAzureMonitorWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadAzureMonitorWorkspace | cdktn.IResolvable | undefined);
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    get subscriptionIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadAzureMonitorWorkspaceList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadAzureMonitorWorkspace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadAzureMonitorWorkspaceOutputReference;
}
export interface SloObjectiveCountMetricsBadAzureMonitor {
    /**
    * Aggregation type [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#aggregation Slo#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Specifies source: 'metrics' or 'logs'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#data_type Slo#data_type}
    */
    readonly dataType: string;
    /**
    * Logs query in Kusto Query Language [Required for logs]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#kql_query Slo#kql_query}
    */
    readonly kqlQuery?: string;
    /**
    * Name of the metric [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_name Slo#metric_name}
    */
    readonly metricName?: string;
    /**
    * Namespace of the metric [Optional for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_namespace Slo#metric_namespace}
    */
    readonly metricNamespace?: string;
    /**
    * Identifier of the Azure Cloud resource [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#resource_id Slo#resource_id}
    */
    readonly resourceId?: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dimensions Slo#dimensions}
    */
    readonly dimensions?: SloObjectiveCountMetricsBadAzureMonitorDimensions[] | cdktn.IResolvable;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#workspace Slo#workspace}
    */
    readonly workspace?: SloObjectiveCountMetricsBadAzureMonitorWorkspace[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsBadAzureMonitorToTerraform(struct?: SloObjectiveCountMetricsBadAzureMonitor | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadAzureMonitorToHclTerraform(struct?: SloObjectiveCountMetricsBadAzureMonitor | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadAzureMonitorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadAzureMonitor | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadAzureMonitor | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _kqlQuery?;
    get kqlQuery(): string;
    set kqlQuery(value: string);
    resetKqlQuery(): void;
    get kqlQueryInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _metricNamespace?;
    get metricNamespace(): string;
    set metricNamespace(value: string);
    resetMetricNamespace(): void;
    get metricNamespaceInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _dimensions;
    get dimensions(): SloObjectiveCountMetricsBadAzureMonitorDimensionsList;
    putDimensions(value: SloObjectiveCountMetricsBadAzureMonitorDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadAzureMonitorDimensions[] | undefined;
    private _workspace;
    get workspace(): SloObjectiveCountMetricsBadAzureMonitorWorkspaceList;
    putWorkspace(value: SloObjectiveCountMetricsBadAzureMonitorWorkspace[] | cdktn.IResolvable): void;
    resetWorkspace(): void;
    get workspaceInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadAzureMonitorWorkspace[] | undefined;
}
export declare class SloObjectiveCountMetricsBadAzureMonitorList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadAzureMonitor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadAzureMonitorOutputReference;
}
export interface SloObjectiveCountMetricsBadBigquery {
    /**
    * Location of you BigQuery
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#location Slo#location}
    */
    readonly location: string;
    /**
    * Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project_id Slo#project_id}
    */
    readonly projectId: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsBadBigqueryToTerraform(struct?: SloObjectiveCountMetricsBadBigquery | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadBigqueryToHclTerraform(struct?: SloObjectiveCountMetricsBadBigquery | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadBigqueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadBigquery | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadBigquery | cdktn.IResolvable | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadBigqueryList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadBigquery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadBigqueryOutputReference;
}
export interface SloObjectiveCountMetricsBadCloudwatchDimensions {
    /**
    * Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: string;
}
export declare function sloObjectiveCountMetricsBadCloudwatchDimensionsToTerraform(struct?: SloObjectiveCountMetricsBadCloudwatchDimensions | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadCloudwatchDimensionsToHclTerraform(struct?: SloObjectiveCountMetricsBadCloudwatchDimensions | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadCloudwatchDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadCloudwatchDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadCloudwatchDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadCloudwatchDimensionsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadCloudwatchDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadCloudwatchDimensionsOutputReference;
}
export interface SloObjectiveCountMetricsBadCloudwatch {
    /**
    * AccountID used with cross-account observability feature
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#account_id Slo#account_id}
    */
    readonly accountId?: string;
    /**
    * JSON query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#json Slo#json}
    */
    readonly json?: string;
    /**
    * Metric name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_name Slo#metric_name}
    */
    readonly metricName?: string;
    /**
    * Namespace of the metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#namespace Slo#namespace}
    */
    readonly namespace?: string;
    /**
    * Region of the CloudWatch instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#region Slo#region}
    */
    readonly region: string;
    /**
    * SQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#sql Slo#sql}
    */
    readonly sql?: string;
    /**
    * Metric data aggregations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#stat Slo#stat}
    */
    readonly stat?: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dimensions Slo#dimensions}
    */
    readonly dimensions?: SloObjectiveCountMetricsBadCloudwatchDimensions[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsBadCloudwatchToTerraform(struct?: SloObjectiveCountMetricsBadCloudwatch | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadCloudwatchToHclTerraform(struct?: SloObjectiveCountMetricsBadCloudwatch | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadCloudwatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadCloudwatch | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadCloudwatch | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _json?;
    get json(): string;
    set json(value: string);
    resetJson(): void;
    get jsonInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    resetSql(): void;
    get sqlInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _dimensions;
    get dimensions(): SloObjectiveCountMetricsBadCloudwatchDimensionsList;
    putDimensions(value: SloObjectiveCountMetricsBadCloudwatchDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadCloudwatchDimensions[] | undefined;
}
export declare class SloObjectiveCountMetricsBadCloudwatchList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadCloudwatch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadCloudwatchOutputReference;
}
export interface SloObjectiveCountMetricsBadDatadog {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsBadDatadogToTerraform(struct?: SloObjectiveCountMetricsBadDatadog | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadDatadogToHclTerraform(struct?: SloObjectiveCountMetricsBadDatadog | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadDatadog | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadDatadog | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadDatadogList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadDatadog[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadDatadogOutputReference;
}
export interface SloObjectiveCountMetricsBadDynatrace {
    /**
    * Selector for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_selector Slo#metric_selector}
    */
    readonly metricSelector: string;
}
export declare function sloObjectiveCountMetricsBadDynatraceToTerraform(struct?: SloObjectiveCountMetricsBadDynatrace | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadDynatraceToHclTerraform(struct?: SloObjectiveCountMetricsBadDynatrace | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadDynatraceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadDynatrace | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadDynatrace | cdktn.IResolvable | undefined);
    private _metricSelector?;
    get metricSelector(): string;
    set metricSelector(value: string);
    get metricSelectorInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadDynatraceList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadDynatrace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadDynatraceOutputReference;
}
export interface SloObjectiveCountMetricsBadElasticsearch {
    /**
    * Index of metrics we want to query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#index Slo#index}
    */
    readonly index: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsBadElasticsearchToTerraform(struct?: SloObjectiveCountMetricsBadElasticsearch | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadElasticsearchToHclTerraform(struct?: SloObjectiveCountMetricsBadElasticsearch | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadElasticsearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadElasticsearch | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadElasticsearch | cdktn.IResolvable | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadElasticsearchList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadElasticsearch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadElasticsearchOutputReference;
}
export interface SloObjectiveCountMetricsBadGcm {
    /**
    * Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project_id Slo#project_id}
    */
    readonly projectId: string;
    /**
    * Query for the metrics in PromQL format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql?: string;
    /**
    * Query for the metrics in MQL format ([deprecated](https://cloud.google.com/stackdriver/docs/deprecations/mql))
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query?: string;
}
export declare function sloObjectiveCountMetricsBadGcmToTerraform(struct?: SloObjectiveCountMetricsBadGcm | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadGcmToHclTerraform(struct?: SloObjectiveCountMetricsBadGcm | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadGcmOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadGcm | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadGcm | cdktn.IResolvable | undefined);
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _promql?;
    get promql(): string;
    set promql(value: string);
    resetPromql(): void;
    get promqlInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadGcmList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadGcm[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadGcmOutputReference;
}
export interface SloObjectiveCountMetricsBadGrafanaLoki {
    /**
    * Query for the logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#logql Slo#logql}
    */
    readonly logql: string;
}
export declare function sloObjectiveCountMetricsBadGrafanaLokiToTerraform(struct?: SloObjectiveCountMetricsBadGrafanaLoki | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadGrafanaLokiToHclTerraform(struct?: SloObjectiveCountMetricsBadGrafanaLoki | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadGrafanaLokiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadGrafanaLoki | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadGrafanaLoki | cdktn.IResolvable | undefined);
    private _logql?;
    get logql(): string;
    set logql(value: string);
    get logqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadGrafanaLokiList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadGrafanaLoki[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadGrafanaLokiOutputReference;
}
export interface SloObjectiveCountMetricsBadGraphite {
    /**
    * Path to the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_path Slo#metric_path}
    */
    readonly metricPath: string;
}
export declare function sloObjectiveCountMetricsBadGraphiteToTerraform(struct?: SloObjectiveCountMetricsBadGraphite | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadGraphiteToHclTerraform(struct?: SloObjectiveCountMetricsBadGraphite | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadGraphiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadGraphite | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadGraphite | cdktn.IResolvable | undefined);
    private _metricPath?;
    get metricPath(): string;
    set metricPath(value: string);
    get metricPathInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadGraphiteList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadGraphite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadGraphiteOutputReference;
}
export interface SloObjectiveCountMetricsBadHoneycomb {
    /**
    * Column name - required for all calculation types besides 'CONCURRENCY' and 'COUNT'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#attribute Slo#attribute}
    */
    readonly attribute?: string;
    /**
    * Calculation type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#calculation Slo#calculation}
    */
    readonly calculation: string;
}
export declare function sloObjectiveCountMetricsBadHoneycombToTerraform(struct?: SloObjectiveCountMetricsBadHoneycomb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadHoneycombToHclTerraform(struct?: SloObjectiveCountMetricsBadHoneycomb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadHoneycombOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadHoneycomb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadHoneycomb | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _calculation?;
    get calculation(): string;
    set calculation(value: string);
    get calculationInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadHoneycombList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadHoneycomb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadHoneycombOutputReference;
}
export interface SloObjectiveCountMetricsBadInfluxdb {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsBadInfluxdbToTerraform(struct?: SloObjectiveCountMetricsBadInfluxdb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadInfluxdbToHclTerraform(struct?: SloObjectiveCountMetricsBadInfluxdb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadInfluxdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadInfluxdb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadInfluxdb | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadInfluxdbList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadInfluxdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadInfluxdbOutputReference;
}
export interface SloObjectiveCountMetricsBadInstanaApplicationGroupBy {
    /**
    * Group by tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag Slo#tag}
    */
    readonly tag: string;
    /**
    * Tag entity - one of 'DESTINATION', 'SOURCE', 'NOT_APPLICABLE'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag_entity Slo#tag_entity}
    */
    readonly tagEntity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag_second_level_key Slo#tag_second_level_key}
    */
    readonly tagSecondLevelKey?: string;
}
export declare function sloObjectiveCountMetricsBadInstanaApplicationGroupByToTerraform(struct?: SloObjectiveCountMetricsBadInstanaApplicationGroupBy | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadInstanaApplicationGroupByToHclTerraform(struct?: SloObjectiveCountMetricsBadInstanaApplicationGroupBy | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadInstanaApplicationGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadInstanaApplicationGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadInstanaApplicationGroupBy | cdktn.IResolvable | undefined);
    private _tag?;
    get tag(): string;
    set tag(value: string);
    get tagInput(): string | undefined;
    private _tagEntity?;
    get tagEntity(): string;
    set tagEntity(value: string);
    get tagEntityInput(): string | undefined;
    private _tagSecondLevelKey?;
    get tagSecondLevelKey(): string;
    set tagSecondLevelKey(value: string);
    resetTagSecondLevelKey(): void;
    get tagSecondLevelKeyInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadInstanaApplicationGroupByList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadInstanaApplicationGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadInstanaApplicationGroupByOutputReference;
}
export interface SloObjectiveCountMetricsBadInstanaApplication {
    /**
    * Depends on the value specified for 'metric_id'- more info in N9 docs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#aggregation Slo#aggregation}
    */
    readonly aggregation: string;
    /**
    * API query user passes in a JSON format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#api_query Slo#api_query}
    */
    readonly apiQuery: string;
    /**
    * Include internal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#include_internal Slo#include_internal}
    */
    readonly includeInternal?: boolean | cdktn.IResolvable;
    /**
    * Include synthetic
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#include_synthetic Slo#include_synthetic}
    */
    readonly includeSynthetic?: boolean | cdktn.IResolvable;
    /**
    * Metric ID one of 'calls', 'erroneousCalls', 'errors', 'latency'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_id Slo#metric_id}
    */
    readonly metricId: string;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#group_by Slo#group_by}
    */
    readonly groupBy: SloObjectiveCountMetricsBadInstanaApplicationGroupBy[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsBadInstanaApplicationToTerraform(struct?: SloObjectiveCountMetricsBadInstanaApplication | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadInstanaApplicationToHclTerraform(struct?: SloObjectiveCountMetricsBadInstanaApplication | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadInstanaApplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadInstanaApplication | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadInstanaApplication | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _apiQuery?;
    get apiQuery(): string;
    set apiQuery(value: string);
    get apiQueryInput(): string | undefined;
    private _includeInternal?;
    get includeInternal(): boolean | cdktn.IResolvable;
    set includeInternal(value: boolean | cdktn.IResolvable);
    resetIncludeInternal(): void;
    get includeInternalInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSynthetic?;
    get includeSynthetic(): boolean | cdktn.IResolvable;
    set includeSynthetic(value: boolean | cdktn.IResolvable);
    resetIncludeSynthetic(): void;
    get includeSyntheticInput(): boolean | cdktn.IResolvable | undefined;
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    get metricIdInput(): string | undefined;
    private _groupBy;
    get groupBy(): SloObjectiveCountMetricsBadInstanaApplicationGroupByList;
    putGroupBy(value: SloObjectiveCountMetricsBadInstanaApplicationGroupBy[] | cdktn.IResolvable): void;
    get groupByInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadInstanaApplicationGroupBy[] | undefined;
}
export declare class SloObjectiveCountMetricsBadInstanaApplicationList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadInstanaApplication[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadInstanaApplicationOutputReference;
}
export interface SloObjectiveCountMetricsBadInstanaInfrastructure {
    /**
    * Metric ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_id Slo#metric_id}
    */
    readonly metricId: string;
    /**
    * Metric retrieval method 'query' or 'snapshot'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_retrieval_method Slo#metric_retrieval_method}
    */
    readonly metricRetrievalMethod: string;
    /**
    * Plugin ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#plugin_id Slo#plugin_id}
    */
    readonly pluginId: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query?: string;
    /**
    * Snapshot ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#snapshot_id Slo#snapshot_id}
    */
    readonly snapshotId?: string;
}
export declare function sloObjectiveCountMetricsBadInstanaInfrastructureToTerraform(struct?: SloObjectiveCountMetricsBadInstanaInfrastructure | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadInstanaInfrastructureToHclTerraform(struct?: SloObjectiveCountMetricsBadInstanaInfrastructure | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadInstanaInfrastructureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadInstanaInfrastructure | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadInstanaInfrastructure | cdktn.IResolvable | undefined);
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    get metricIdInput(): string | undefined;
    private _metricRetrievalMethod?;
    get metricRetrievalMethod(): string;
    set metricRetrievalMethod(value: string);
    get metricRetrievalMethodInput(): string | undefined;
    private _pluginId?;
    get pluginId(): string;
    set pluginId(value: string);
    get pluginIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _snapshotId?;
    get snapshotId(): string;
    set snapshotId(value: string);
    resetSnapshotId(): void;
    get snapshotIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadInstanaInfrastructureList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadInstanaInfrastructure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadInstanaInfrastructureOutputReference;
}
export interface SloObjectiveCountMetricsBadInstana {
    /**
    * Instana metric type 'application' or 'infrastructure'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_type Slo#metric_type}
    */
    readonly metricType: string;
    /**
    * application block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#application Slo#application}
    */
    readonly application?: SloObjectiveCountMetricsBadInstanaApplication[] | cdktn.IResolvable;
    /**
    * infrastructure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#infrastructure Slo#infrastructure}
    */
    readonly infrastructure?: SloObjectiveCountMetricsBadInstanaInfrastructure[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsBadInstanaToTerraform(struct?: SloObjectiveCountMetricsBadInstana | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadInstanaToHclTerraform(struct?: SloObjectiveCountMetricsBadInstana | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadInstanaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadInstana | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadInstana | cdktn.IResolvable | undefined);
    private _metricType?;
    get metricType(): string;
    set metricType(value: string);
    get metricTypeInput(): string | undefined;
    private _application;
    get application(): SloObjectiveCountMetricsBadInstanaApplicationList;
    putApplication(value: SloObjectiveCountMetricsBadInstanaApplication[] | cdktn.IResolvable): void;
    resetApplication(): void;
    get applicationInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadInstanaApplication[] | undefined;
    private _infrastructure;
    get infrastructure(): SloObjectiveCountMetricsBadInstanaInfrastructureList;
    putInfrastructure(value: SloObjectiveCountMetricsBadInstanaInfrastructure[] | cdktn.IResolvable): void;
    resetInfrastructure(): void;
    get infrastructureInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadInstanaInfrastructure[] | undefined;
}
export declare class SloObjectiveCountMetricsBadInstanaList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadInstana[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadInstanaOutputReference;
}
export interface SloObjectiveCountMetricsBadLightstep {
    /**
    * Optional value to filter by percentiles
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#percentile Slo#percentile}
    */
    readonly percentile?: number;
    /**
    * ID of the metrics stream
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#stream_id Slo#stream_id}
    */
    readonly streamId?: string;
    /**
    * Type of data to filter by
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#type_of_data Slo#type_of_data}
    */
    readonly typeOfData: string;
    /**
    * UQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#uql Slo#uql}
    */
    readonly uql?: string;
}
export declare function sloObjectiveCountMetricsBadLightstepToTerraform(struct?: SloObjectiveCountMetricsBadLightstep | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadLightstepToHclTerraform(struct?: SloObjectiveCountMetricsBadLightstep | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadLightstepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadLightstep | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadLightstep | cdktn.IResolvable | undefined);
    private _percentile?;
    get percentile(): number;
    set percentile(value: number);
    resetPercentile(): void;
    get percentileInput(): number | undefined;
    private _streamId?;
    get streamId(): string;
    set streamId(value: string);
    resetStreamId(): void;
    get streamIdInput(): string | undefined;
    private _typeOfData?;
    get typeOfData(): string;
    set typeOfData(value: string);
    get typeOfDataInput(): string | undefined;
    private _uql?;
    get uql(): string;
    set uql(value: string);
    resetUql(): void;
    get uqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadLightstepList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadLightstep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadLightstepOutputReference;
}
export interface SloObjectiveCountMetricsBadLogicMonitor {
    /**
    * Checkpoint ID. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#checkpoint_id Slo#checkpoint_id}
    */
    readonly checkpointId?: string;
    /**
    * Device Datasource Instance ID. Used by Query type = device_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#device_data_source_instance_id Slo#device_data_source_instance_id}
    */
    readonly deviceDataSourceInstanceId?: number;
    /**
    * Graph ID. Used by Query type = device_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graph_id Slo#graph_id}
    */
    readonly graphId?: number;
    /**
    * Graph Name. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graph_name Slo#graph_name}
    */
    readonly graphName?: string;
    /**
    * Line
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#line Slo#line}
    */
    readonly line: string;
    /**
    * Query type: device_metrics or website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query_type Slo#query_type}
    */
    readonly queryType: string;
    /**
    * Website ID. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#website_id Slo#website_id}
    */
    readonly websiteId?: string;
}
export declare function sloObjectiveCountMetricsBadLogicMonitorToTerraform(struct?: SloObjectiveCountMetricsBadLogicMonitor | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadLogicMonitorToHclTerraform(struct?: SloObjectiveCountMetricsBadLogicMonitor | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadLogicMonitorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadLogicMonitor | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadLogicMonitor | cdktn.IResolvable | undefined);
    private _checkpointId?;
    get checkpointId(): string;
    set checkpointId(value: string);
    resetCheckpointId(): void;
    get checkpointIdInput(): string | undefined;
    private _deviceDataSourceInstanceId?;
    get deviceDataSourceInstanceId(): number;
    set deviceDataSourceInstanceId(value: number);
    resetDeviceDataSourceInstanceId(): void;
    get deviceDataSourceInstanceIdInput(): number | undefined;
    private _graphId?;
    get graphId(): number;
    set graphId(value: number);
    resetGraphId(): void;
    get graphIdInput(): number | undefined;
    private _graphName?;
    get graphName(): string;
    set graphName(value: string);
    resetGraphName(): void;
    get graphNameInput(): string | undefined;
    private _line?;
    get line(): string;
    set line(value: string);
    get lineInput(): string | undefined;
    private _queryType?;
    get queryType(): string;
    set queryType(value: string);
    get queryTypeInput(): string | undefined;
    private _websiteId?;
    get websiteId(): string;
    set websiteId(value: string);
    resetWebsiteId(): void;
    get websiteIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadLogicMonitorList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadLogicMonitor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadLogicMonitorOutputReference;
}
export interface SloObjectiveCountMetricsBadNewrelic {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#nrql Slo#nrql}
    */
    readonly nrql: string;
}
export declare function sloObjectiveCountMetricsBadNewrelicToTerraform(struct?: SloObjectiveCountMetricsBadNewrelic | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadNewrelicToHclTerraform(struct?: SloObjectiveCountMetricsBadNewrelic | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadNewrelicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadNewrelic | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadNewrelic | cdktn.IResolvable | undefined);
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadNewrelicList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadNewrelic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadNewrelicOutputReference;
}
export interface SloObjectiveCountMetricsBadOpentsdb {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsBadOpentsdbToTerraform(struct?: SloObjectiveCountMetricsBadOpentsdb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadOpentsdbToHclTerraform(struct?: SloObjectiveCountMetricsBadOpentsdb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadOpentsdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadOpentsdb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadOpentsdb | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadOpentsdbList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadOpentsdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadOpentsdbOutputReference;
}
export interface SloObjectiveCountMetricsBadPingdom {
    /**
    * Pingdom uptime or transaction check's ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#check_id Slo#check_id}
    */
    readonly checkId: string;
    /**
    * Pingdom check type - uptime or transaction
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#check_type Slo#check_type}
    */
    readonly checkType?: string;
    /**
    * Optional for the Uptime checks. Use it to filter the Pingdom check results by status
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#status Slo#status}
    */
    readonly status?: string;
}
export declare function sloObjectiveCountMetricsBadPingdomToTerraform(struct?: SloObjectiveCountMetricsBadPingdom | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadPingdomToHclTerraform(struct?: SloObjectiveCountMetricsBadPingdom | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadPingdomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadPingdom | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadPingdom | cdktn.IResolvable | undefined);
    private _checkId?;
    get checkId(): string;
    set checkId(value: string);
    get checkIdInput(): string | undefined;
    private _checkType?;
    get checkType(): string;
    set checkType(value: string);
    resetCheckType(): void;
    get checkTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadPingdomList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadPingdom[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadPingdomOutputReference;
}
export interface SloObjectiveCountMetricsBadPrometheus {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql: string;
}
export declare function sloObjectiveCountMetricsBadPrometheusToTerraform(struct?: SloObjectiveCountMetricsBadPrometheus | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadPrometheusToHclTerraform(struct?: SloObjectiveCountMetricsBadPrometheus | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadPrometheusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadPrometheus | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadPrometheus | cdktn.IResolvable | undefined);
    private _promql?;
    get promql(): string;
    set promql(value: string);
    get promqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadPrometheusList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadPrometheus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadPrometheusOutputReference;
}
export interface SloObjectiveCountMetricsBadRedshift {
    /**
    * Redshift custer ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#cluster_id Slo#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Database name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#database_name Slo#database_name}
    */
    readonly databaseName: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
    /**
    * Region of the Redshift instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#region Slo#region}
    */
    readonly region: string;
}
export declare function sloObjectiveCountMetricsBadRedshiftToTerraform(struct?: SloObjectiveCountMetricsBadRedshift | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadRedshiftToHclTerraform(struct?: SloObjectiveCountMetricsBadRedshift | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadRedshiftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadRedshift | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadRedshift | cdktn.IResolvable | undefined);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadRedshiftList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadRedshift[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadRedshiftOutputReference;
}
export interface SloObjectiveCountMetricsBadSplunk {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsBadSplunkToTerraform(struct?: SloObjectiveCountMetricsBadSplunk | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadSplunkToHclTerraform(struct?: SloObjectiveCountMetricsBadSplunk | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadSplunkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadSplunk | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadSplunk | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadSplunkList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadSplunk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadSplunkOutputReference;
}
export interface SloObjectiveCountMetricsBadSplunkObservability {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#program Slo#program}
    */
    readonly program: string;
}
export declare function sloObjectiveCountMetricsBadSplunkObservabilityToTerraform(struct?: SloObjectiveCountMetricsBadSplunkObservability | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadSplunkObservabilityToHclTerraform(struct?: SloObjectiveCountMetricsBadSplunkObservability | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadSplunkObservabilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadSplunkObservability | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadSplunkObservability | cdktn.IResolvable | undefined);
    private _program?;
    get program(): string;
    set program(value: string);
    get programInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadSplunkObservabilityList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadSplunkObservability[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadSplunkObservabilityOutputReference;
}
export interface SloObjectiveCountMetricsBadSumologic {
    /**
    * Period of data aggregation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#quantization Slo#quantization}
    */
    readonly quantization?: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
    /**
    * Aggregation function - avg, sum, min, max, count, none
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#rollup Slo#rollup}
    */
    readonly rollup?: string;
    /**
    * Sumologic source - metrics or logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#type Slo#type}
    */
    readonly type: string;
}
export declare function sloObjectiveCountMetricsBadSumologicToTerraform(struct?: SloObjectiveCountMetricsBadSumologic | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadSumologicToHclTerraform(struct?: SloObjectiveCountMetricsBadSumologic | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadSumologicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadSumologic | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadSumologic | cdktn.IResolvable | undefined);
    private _quantization?;
    get quantization(): string;
    set quantization(value: string);
    resetQuantization(): void;
    get quantizationInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _rollup?;
    get rollup(): string;
    set rollup(value: string);
    resetRollup(): void;
    get rollupInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadSumologicList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadSumologic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadSumologicOutputReference;
}
export interface SloObjectiveCountMetricsBadThousandeyes {
    /**
    * ID of the test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#test_id Slo#test_id}
    */
    readonly testId: number;
    /**
    * Type of the test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#test_type Slo#test_type}
    */
    readonly testType?: string;
}
export declare function sloObjectiveCountMetricsBadThousandeyesToTerraform(struct?: SloObjectiveCountMetricsBadThousandeyes | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadThousandeyesToHclTerraform(struct?: SloObjectiveCountMetricsBadThousandeyes | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadThousandeyesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBadThousandeyes | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBadThousandeyes | cdktn.IResolvable | undefined);
    private _testId?;
    get testId(): number;
    set testId(value: number);
    get testIdInput(): number | undefined;
    private _testType?;
    get testType(): string;
    set testType(value: string);
    resetTestType(): void;
    get testTypeInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsBadThousandeyesList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBadThousandeyes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadThousandeyesOutputReference;
}
export interface SloObjectiveCountMetricsBad {
    /**
    * amazon_prometheus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#amazon_prometheus Slo#amazon_prometheus}
    */
    readonly amazonPrometheus?: SloObjectiveCountMetricsBadAmazonPrometheus[] | cdktn.IResolvable;
    /**
    * appdynamics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#appdynamics Slo#appdynamics}
    */
    readonly appdynamics?: SloObjectiveCountMetricsBadAppdynamics[] | cdktn.IResolvable;
    /**
    * azure_monitor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#azure_monitor Slo#azure_monitor}
    */
    readonly azureMonitor?: SloObjectiveCountMetricsBadAzureMonitor[] | cdktn.IResolvable;
    /**
    * bigquery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#bigquery Slo#bigquery}
    */
    readonly bigquery?: SloObjectiveCountMetricsBadBigquery[] | cdktn.IResolvable;
    /**
    * cloudwatch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#cloudwatch Slo#cloudwatch}
    */
    readonly cloudwatch?: SloObjectiveCountMetricsBadCloudwatch[] | cdktn.IResolvable;
    /**
    * datadog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#datadog Slo#datadog}
    */
    readonly datadog?: SloObjectiveCountMetricsBadDatadog[] | cdktn.IResolvable;
    /**
    * dynatrace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dynatrace Slo#dynatrace}
    */
    readonly dynatrace?: SloObjectiveCountMetricsBadDynatrace[] | cdktn.IResolvable;
    /**
    * elasticsearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#elasticsearch Slo#elasticsearch}
    */
    readonly elasticsearch?: SloObjectiveCountMetricsBadElasticsearch[] | cdktn.IResolvable;
    /**
    * gcm block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#gcm Slo#gcm}
    */
    readonly gcm?: SloObjectiveCountMetricsBadGcm[] | cdktn.IResolvable;
    /**
    * grafana_loki block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#grafana_loki Slo#grafana_loki}
    */
    readonly grafanaLoki?: SloObjectiveCountMetricsBadGrafanaLoki[] | cdktn.IResolvable;
    /**
    * graphite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graphite Slo#graphite}
    */
    readonly graphite?: SloObjectiveCountMetricsBadGraphite[] | cdktn.IResolvable;
    /**
    * honeycomb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#honeycomb Slo#honeycomb}
    */
    readonly honeycomb?: SloObjectiveCountMetricsBadHoneycomb[] | cdktn.IResolvable;
    /**
    * influxdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#influxdb Slo#influxdb}
    */
    readonly influxdb?: SloObjectiveCountMetricsBadInfluxdb[] | cdktn.IResolvable;
    /**
    * instana block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#instana Slo#instana}
    */
    readonly instana?: SloObjectiveCountMetricsBadInstana[] | cdktn.IResolvable;
    /**
    * lightstep block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#lightstep Slo#lightstep}
    */
    readonly lightstep?: SloObjectiveCountMetricsBadLightstep[] | cdktn.IResolvable;
    /**
    * logic_monitor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#logic_monitor Slo#logic_monitor}
    */
    readonly logicMonitor?: SloObjectiveCountMetricsBadLogicMonitor[] | cdktn.IResolvable;
    /**
    * newrelic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#newrelic Slo#newrelic}
    */
    readonly newrelic?: SloObjectiveCountMetricsBadNewrelic[] | cdktn.IResolvable;
    /**
    * opentsdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#opentsdb Slo#opentsdb}
    */
    readonly opentsdb?: SloObjectiveCountMetricsBadOpentsdb[] | cdktn.IResolvable;
    /**
    * pingdom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#pingdom Slo#pingdom}
    */
    readonly pingdom?: SloObjectiveCountMetricsBadPingdom[] | cdktn.IResolvable;
    /**
    * prometheus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#prometheus Slo#prometheus}
    */
    readonly prometheus?: SloObjectiveCountMetricsBadPrometheus[] | cdktn.IResolvable;
    /**
    * redshift block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#redshift Slo#redshift}
    */
    readonly redshift?: SloObjectiveCountMetricsBadRedshift[] | cdktn.IResolvable;
    /**
    * splunk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#splunk Slo#splunk}
    */
    readonly splunk?: SloObjectiveCountMetricsBadSplunk[] | cdktn.IResolvable;
    /**
    * splunk_observability block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#splunk_observability Slo#splunk_observability}
    */
    readonly splunkObservability?: SloObjectiveCountMetricsBadSplunkObservability[] | cdktn.IResolvable;
    /**
    * sumologic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#sumologic Slo#sumologic}
    */
    readonly sumologic?: SloObjectiveCountMetricsBadSumologic[] | cdktn.IResolvable;
    /**
    * thousandeyes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#thousandeyes Slo#thousandeyes}
    */
    readonly thousandeyes?: SloObjectiveCountMetricsBadThousandeyes[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsBadToTerraform(struct?: SloObjectiveCountMetricsBad | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsBadToHclTerraform(struct?: SloObjectiveCountMetricsBad | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsBadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsBad | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsBad | cdktn.IResolvable | undefined);
    private _amazonPrometheus;
    get amazonPrometheus(): SloObjectiveCountMetricsBadAmazonPrometheusList;
    putAmazonPrometheus(value: SloObjectiveCountMetricsBadAmazonPrometheus[] | cdktn.IResolvable): void;
    resetAmazonPrometheus(): void;
    get amazonPrometheusInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadAmazonPrometheus[] | undefined;
    private _appdynamics;
    get appdynamics(): SloObjectiveCountMetricsBadAppdynamicsList;
    putAppdynamics(value: SloObjectiveCountMetricsBadAppdynamics[] | cdktn.IResolvable): void;
    resetAppdynamics(): void;
    get appdynamicsInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadAppdynamics[] | undefined;
    private _azureMonitor;
    get azureMonitor(): SloObjectiveCountMetricsBadAzureMonitorList;
    putAzureMonitor(value: SloObjectiveCountMetricsBadAzureMonitor[] | cdktn.IResolvable): void;
    resetAzureMonitor(): void;
    get azureMonitorInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadAzureMonitor[] | undefined;
    private _bigquery;
    get bigquery(): SloObjectiveCountMetricsBadBigqueryList;
    putBigquery(value: SloObjectiveCountMetricsBadBigquery[] | cdktn.IResolvable): void;
    resetBigquery(): void;
    get bigqueryInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadBigquery[] | undefined;
    private _cloudwatch;
    get cloudwatch(): SloObjectiveCountMetricsBadCloudwatchList;
    putCloudwatch(value: SloObjectiveCountMetricsBadCloudwatch[] | cdktn.IResolvable): void;
    resetCloudwatch(): void;
    get cloudwatchInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadCloudwatch[] | undefined;
    private _datadog;
    get datadog(): SloObjectiveCountMetricsBadDatadogList;
    putDatadog(value: SloObjectiveCountMetricsBadDatadog[] | cdktn.IResolvable): void;
    resetDatadog(): void;
    get datadogInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadDatadog[] | undefined;
    private _dynatrace;
    get dynatrace(): SloObjectiveCountMetricsBadDynatraceList;
    putDynatrace(value: SloObjectiveCountMetricsBadDynatrace[] | cdktn.IResolvable): void;
    resetDynatrace(): void;
    get dynatraceInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadDynatrace[] | undefined;
    private _elasticsearch;
    get elasticsearch(): SloObjectiveCountMetricsBadElasticsearchList;
    putElasticsearch(value: SloObjectiveCountMetricsBadElasticsearch[] | cdktn.IResolvable): void;
    resetElasticsearch(): void;
    get elasticsearchInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadElasticsearch[] | undefined;
    private _gcm;
    get gcm(): SloObjectiveCountMetricsBadGcmList;
    putGcm(value: SloObjectiveCountMetricsBadGcm[] | cdktn.IResolvable): void;
    resetGcm(): void;
    get gcmInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadGcm[] | undefined;
    private _grafanaLoki;
    get grafanaLoki(): SloObjectiveCountMetricsBadGrafanaLokiList;
    putGrafanaLoki(value: SloObjectiveCountMetricsBadGrafanaLoki[] | cdktn.IResolvable): void;
    resetGrafanaLoki(): void;
    get grafanaLokiInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadGrafanaLoki[] | undefined;
    private _graphite;
    get graphite(): SloObjectiveCountMetricsBadGraphiteList;
    putGraphite(value: SloObjectiveCountMetricsBadGraphite[] | cdktn.IResolvable): void;
    resetGraphite(): void;
    get graphiteInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadGraphite[] | undefined;
    private _honeycomb;
    get honeycomb(): SloObjectiveCountMetricsBadHoneycombList;
    putHoneycomb(value: SloObjectiveCountMetricsBadHoneycomb[] | cdktn.IResolvable): void;
    resetHoneycomb(): void;
    get honeycombInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadHoneycomb[] | undefined;
    private _influxdb;
    get influxdb(): SloObjectiveCountMetricsBadInfluxdbList;
    putInfluxdb(value: SloObjectiveCountMetricsBadInfluxdb[] | cdktn.IResolvable): void;
    resetInfluxdb(): void;
    get influxdbInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadInfluxdb[] | undefined;
    private _instana;
    get instana(): SloObjectiveCountMetricsBadInstanaList;
    putInstana(value: SloObjectiveCountMetricsBadInstana[] | cdktn.IResolvable): void;
    resetInstana(): void;
    get instanaInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadInstana[] | undefined;
    private _lightstep;
    get lightstep(): SloObjectiveCountMetricsBadLightstepList;
    putLightstep(value: SloObjectiveCountMetricsBadLightstep[] | cdktn.IResolvable): void;
    resetLightstep(): void;
    get lightstepInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadLightstep[] | undefined;
    private _logicMonitor;
    get logicMonitor(): SloObjectiveCountMetricsBadLogicMonitorList;
    putLogicMonitor(value: SloObjectiveCountMetricsBadLogicMonitor[] | cdktn.IResolvable): void;
    resetLogicMonitor(): void;
    get logicMonitorInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadLogicMonitor[] | undefined;
    private _newrelic;
    get newrelic(): SloObjectiveCountMetricsBadNewrelicList;
    putNewrelic(value: SloObjectiveCountMetricsBadNewrelic[] | cdktn.IResolvable): void;
    resetNewrelic(): void;
    get newrelicInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadNewrelic[] | undefined;
    private _opentsdb;
    get opentsdb(): SloObjectiveCountMetricsBadOpentsdbList;
    putOpentsdb(value: SloObjectiveCountMetricsBadOpentsdb[] | cdktn.IResolvable): void;
    resetOpentsdb(): void;
    get opentsdbInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadOpentsdb[] | undefined;
    private _pingdom;
    get pingdom(): SloObjectiveCountMetricsBadPingdomList;
    putPingdom(value: SloObjectiveCountMetricsBadPingdom[] | cdktn.IResolvable): void;
    resetPingdom(): void;
    get pingdomInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadPingdom[] | undefined;
    private _prometheus;
    get prometheus(): SloObjectiveCountMetricsBadPrometheusList;
    putPrometheus(value: SloObjectiveCountMetricsBadPrometheus[] | cdktn.IResolvable): void;
    resetPrometheus(): void;
    get prometheusInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadPrometheus[] | undefined;
    private _redshift;
    get redshift(): SloObjectiveCountMetricsBadRedshiftList;
    putRedshift(value: SloObjectiveCountMetricsBadRedshift[] | cdktn.IResolvable): void;
    resetRedshift(): void;
    get redshiftInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadRedshift[] | undefined;
    private _splunk;
    get splunk(): SloObjectiveCountMetricsBadSplunkList;
    putSplunk(value: SloObjectiveCountMetricsBadSplunk[] | cdktn.IResolvable): void;
    resetSplunk(): void;
    get splunkInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadSplunk[] | undefined;
    private _splunkObservability;
    get splunkObservability(): SloObjectiveCountMetricsBadSplunkObservabilityList;
    putSplunkObservability(value: SloObjectiveCountMetricsBadSplunkObservability[] | cdktn.IResolvable): void;
    resetSplunkObservability(): void;
    get splunkObservabilityInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadSplunkObservability[] | undefined;
    private _sumologic;
    get sumologic(): SloObjectiveCountMetricsBadSumologicList;
    putSumologic(value: SloObjectiveCountMetricsBadSumologic[] | cdktn.IResolvable): void;
    resetSumologic(): void;
    get sumologicInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadSumologic[] | undefined;
    private _thousandeyes;
    get thousandeyes(): SloObjectiveCountMetricsBadThousandeyesList;
    putThousandeyes(value: SloObjectiveCountMetricsBadThousandeyes[] | cdktn.IResolvable): void;
    resetThousandeyes(): void;
    get thousandeyesInput(): cdktn.IResolvable | SloObjectiveCountMetricsBadThousandeyes[] | undefined;
}
export declare class SloObjectiveCountMetricsBadList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsBad[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsBadOutputReference;
}
export interface SloObjectiveCountMetricsGoodAmazonPrometheus {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql: string;
}
export declare function sloObjectiveCountMetricsGoodAmazonPrometheusToTerraform(struct?: SloObjectiveCountMetricsGoodAmazonPrometheus | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodAmazonPrometheusToHclTerraform(struct?: SloObjectiveCountMetricsGoodAmazonPrometheus | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodAmazonPrometheusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodAmazonPrometheus | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodAmazonPrometheus | cdktn.IResolvable | undefined);
    private _promql?;
    get promql(): string;
    set promql(value: string);
    get promqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodAmazonPrometheusList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodAmazonPrometheus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodAmazonPrometheusOutputReference;
}
export interface SloObjectiveCountMetricsGoodAppdynamics {
    /**
    * Name of the added application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#application_name Slo#application_name}
    */
    readonly applicationName: string;
    /**
    * Path to the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_path Slo#metric_path}
    */
    readonly metricPath: string;
}
export declare function sloObjectiveCountMetricsGoodAppdynamicsToTerraform(struct?: SloObjectiveCountMetricsGoodAppdynamics | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodAppdynamicsToHclTerraform(struct?: SloObjectiveCountMetricsGoodAppdynamics | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodAppdynamicsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodAppdynamics | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodAppdynamics | cdktn.IResolvable | undefined);
    private _applicationName?;
    get applicationName(): string;
    set applicationName(value: string);
    get applicationNameInput(): string | undefined;
    private _metricPath?;
    get metricPath(): string;
    set metricPath(value: string);
    get metricPathInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodAppdynamicsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodAppdynamics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodAppdynamicsOutputReference;
}
export interface SloObjectiveCountMetricsGoodAzureMonitorDimensions {
    /**
    * Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: string;
}
export declare function sloObjectiveCountMetricsGoodAzureMonitorDimensionsToTerraform(struct?: SloObjectiveCountMetricsGoodAzureMonitorDimensions | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodAzureMonitorDimensionsToHclTerraform(struct?: SloObjectiveCountMetricsGoodAzureMonitorDimensions | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodAzureMonitorDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodAzureMonitorDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodAzureMonitorDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodAzureMonitorDimensionsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodAzureMonitorDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodAzureMonitorDimensionsOutputReference;
}
export interface SloObjectiveCountMetricsGoodAzureMonitorWorkspace {
    /**
    * Resource group of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#resource_group Slo#resource_group}
    */
    readonly resourceGroup: string;
    /**
    * Subscription ID of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#subscription_id Slo#subscription_id}
    */
    readonly subscriptionId: string;
    /**
    * ID of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#workspace_id Slo#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function sloObjectiveCountMetricsGoodAzureMonitorWorkspaceToTerraform(struct?: SloObjectiveCountMetricsGoodAzureMonitorWorkspace | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodAzureMonitorWorkspaceToHclTerraform(struct?: SloObjectiveCountMetricsGoodAzureMonitorWorkspace | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodAzureMonitorWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodAzureMonitorWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodAzureMonitorWorkspace | cdktn.IResolvable | undefined);
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    get subscriptionIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodAzureMonitorWorkspaceList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodAzureMonitorWorkspace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodAzureMonitorWorkspaceOutputReference;
}
export interface SloObjectiveCountMetricsGoodAzureMonitor {
    /**
    * Aggregation type [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#aggregation Slo#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Specifies source: 'metrics' or 'logs'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#data_type Slo#data_type}
    */
    readonly dataType: string;
    /**
    * Logs query in Kusto Query Language [Required for logs]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#kql_query Slo#kql_query}
    */
    readonly kqlQuery?: string;
    /**
    * Name of the metric [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_name Slo#metric_name}
    */
    readonly metricName?: string;
    /**
    * Namespace of the metric [Optional for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_namespace Slo#metric_namespace}
    */
    readonly metricNamespace?: string;
    /**
    * Identifier of the Azure Cloud resource [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#resource_id Slo#resource_id}
    */
    readonly resourceId?: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dimensions Slo#dimensions}
    */
    readonly dimensions?: SloObjectiveCountMetricsGoodAzureMonitorDimensions[] | cdktn.IResolvable;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#workspace Slo#workspace}
    */
    readonly workspace?: SloObjectiveCountMetricsGoodAzureMonitorWorkspace[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsGoodAzureMonitorToTerraform(struct?: SloObjectiveCountMetricsGoodAzureMonitor | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodAzureMonitorToHclTerraform(struct?: SloObjectiveCountMetricsGoodAzureMonitor | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodAzureMonitorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodAzureMonitor | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodAzureMonitor | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _kqlQuery?;
    get kqlQuery(): string;
    set kqlQuery(value: string);
    resetKqlQuery(): void;
    get kqlQueryInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _metricNamespace?;
    get metricNamespace(): string;
    set metricNamespace(value: string);
    resetMetricNamespace(): void;
    get metricNamespaceInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _dimensions;
    get dimensions(): SloObjectiveCountMetricsGoodAzureMonitorDimensionsList;
    putDimensions(value: SloObjectiveCountMetricsGoodAzureMonitorDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodAzureMonitorDimensions[] | undefined;
    private _workspace;
    get workspace(): SloObjectiveCountMetricsGoodAzureMonitorWorkspaceList;
    putWorkspace(value: SloObjectiveCountMetricsGoodAzureMonitorWorkspace[] | cdktn.IResolvable): void;
    resetWorkspace(): void;
    get workspaceInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodAzureMonitorWorkspace[] | undefined;
}
export declare class SloObjectiveCountMetricsGoodAzureMonitorList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodAzureMonitor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodAzureMonitorOutputReference;
}
export interface SloObjectiveCountMetricsGoodBigquery {
    /**
    * Location of you BigQuery
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#location Slo#location}
    */
    readonly location: string;
    /**
    * Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project_id Slo#project_id}
    */
    readonly projectId: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodBigqueryToTerraform(struct?: SloObjectiveCountMetricsGoodBigquery | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodBigqueryToHclTerraform(struct?: SloObjectiveCountMetricsGoodBigquery | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodBigqueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodBigquery | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodBigquery | cdktn.IResolvable | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodBigqueryList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodBigquery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodBigqueryOutputReference;
}
export interface SloObjectiveCountMetricsGoodCloudwatchDimensions {
    /**
    * Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: string;
}
export declare function sloObjectiveCountMetricsGoodCloudwatchDimensionsToTerraform(struct?: SloObjectiveCountMetricsGoodCloudwatchDimensions | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodCloudwatchDimensionsToHclTerraform(struct?: SloObjectiveCountMetricsGoodCloudwatchDimensions | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodCloudwatchDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodCloudwatchDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodCloudwatchDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodCloudwatchDimensionsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodCloudwatchDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodCloudwatchDimensionsOutputReference;
}
export interface SloObjectiveCountMetricsGoodCloudwatch {
    /**
    * AccountID used with cross-account observability feature
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#account_id Slo#account_id}
    */
    readonly accountId?: string;
    /**
    * JSON query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#json Slo#json}
    */
    readonly json?: string;
    /**
    * Metric name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_name Slo#metric_name}
    */
    readonly metricName?: string;
    /**
    * Namespace of the metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#namespace Slo#namespace}
    */
    readonly namespace?: string;
    /**
    * Region of the CloudWatch instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#region Slo#region}
    */
    readonly region: string;
    /**
    * SQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#sql Slo#sql}
    */
    readonly sql?: string;
    /**
    * Metric data aggregations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#stat Slo#stat}
    */
    readonly stat?: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dimensions Slo#dimensions}
    */
    readonly dimensions?: SloObjectiveCountMetricsGoodCloudwatchDimensions[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsGoodCloudwatchToTerraform(struct?: SloObjectiveCountMetricsGoodCloudwatch | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodCloudwatchToHclTerraform(struct?: SloObjectiveCountMetricsGoodCloudwatch | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodCloudwatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodCloudwatch | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodCloudwatch | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _json?;
    get json(): string;
    set json(value: string);
    resetJson(): void;
    get jsonInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    resetSql(): void;
    get sqlInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _dimensions;
    get dimensions(): SloObjectiveCountMetricsGoodCloudwatchDimensionsList;
    putDimensions(value: SloObjectiveCountMetricsGoodCloudwatchDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodCloudwatchDimensions[] | undefined;
}
export declare class SloObjectiveCountMetricsGoodCloudwatchList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodCloudwatch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodCloudwatchOutputReference;
}
export interface SloObjectiveCountMetricsGoodDatadog {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodDatadogToTerraform(struct?: SloObjectiveCountMetricsGoodDatadog | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodDatadogToHclTerraform(struct?: SloObjectiveCountMetricsGoodDatadog | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodDatadog | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodDatadog | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodDatadogList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodDatadog[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodDatadogOutputReference;
}
export interface SloObjectiveCountMetricsGoodDynatrace {
    /**
    * Selector for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_selector Slo#metric_selector}
    */
    readonly metricSelector: string;
}
export declare function sloObjectiveCountMetricsGoodDynatraceToTerraform(struct?: SloObjectiveCountMetricsGoodDynatrace | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodDynatraceToHclTerraform(struct?: SloObjectiveCountMetricsGoodDynatrace | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodDynatraceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodDynatrace | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodDynatrace | cdktn.IResolvable | undefined);
    private _metricSelector?;
    get metricSelector(): string;
    set metricSelector(value: string);
    get metricSelectorInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodDynatraceList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodDynatrace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodDynatraceOutputReference;
}
export interface SloObjectiveCountMetricsGoodElasticsearch {
    /**
    * Index of metrics we want to query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#index Slo#index}
    */
    readonly index: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodElasticsearchToTerraform(struct?: SloObjectiveCountMetricsGoodElasticsearch | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodElasticsearchToHclTerraform(struct?: SloObjectiveCountMetricsGoodElasticsearch | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodElasticsearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodElasticsearch | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodElasticsearch | cdktn.IResolvable | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodElasticsearchList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodElasticsearch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodElasticsearchOutputReference;
}
export interface SloObjectiveCountMetricsGoodGcm {
    /**
    * Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project_id Slo#project_id}
    */
    readonly projectId: string;
    /**
    * Query for the metrics in PromQL format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql?: string;
    /**
    * Query for the metrics in MQL format ([deprecated](https://cloud.google.com/stackdriver/docs/deprecations/mql))
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query?: string;
}
export declare function sloObjectiveCountMetricsGoodGcmToTerraform(struct?: SloObjectiveCountMetricsGoodGcm | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodGcmToHclTerraform(struct?: SloObjectiveCountMetricsGoodGcm | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodGcmOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodGcm | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodGcm | cdktn.IResolvable | undefined);
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _promql?;
    get promql(): string;
    set promql(value: string);
    resetPromql(): void;
    get promqlInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodGcmList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodGcm[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodGcmOutputReference;
}
export interface SloObjectiveCountMetricsGoodGrafanaLoki {
    /**
    * Query for the logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#logql Slo#logql}
    */
    readonly logql: string;
}
export declare function sloObjectiveCountMetricsGoodGrafanaLokiToTerraform(struct?: SloObjectiveCountMetricsGoodGrafanaLoki | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodGrafanaLokiToHclTerraform(struct?: SloObjectiveCountMetricsGoodGrafanaLoki | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodGrafanaLokiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodGrafanaLoki | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodGrafanaLoki | cdktn.IResolvable | undefined);
    private _logql?;
    get logql(): string;
    set logql(value: string);
    get logqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodGrafanaLokiList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodGrafanaLoki[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodGrafanaLokiOutputReference;
}
export interface SloObjectiveCountMetricsGoodGraphite {
    /**
    * Path to the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_path Slo#metric_path}
    */
    readonly metricPath: string;
}
export declare function sloObjectiveCountMetricsGoodGraphiteToTerraform(struct?: SloObjectiveCountMetricsGoodGraphite | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodGraphiteToHclTerraform(struct?: SloObjectiveCountMetricsGoodGraphite | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodGraphiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodGraphite | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodGraphite | cdktn.IResolvable | undefined);
    private _metricPath?;
    get metricPath(): string;
    set metricPath(value: string);
    get metricPathInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodGraphiteList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodGraphite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodGraphiteOutputReference;
}
export interface SloObjectiveCountMetricsGoodHoneycomb {
    /**
    * Column name - required for all calculation types besides 'CONCURRENCY' and 'COUNT'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#attribute Slo#attribute}
    */
    readonly attribute?: string;
    /**
    * Calculation type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#calculation Slo#calculation}
    */
    readonly calculation: string;
}
export declare function sloObjectiveCountMetricsGoodHoneycombToTerraform(struct?: SloObjectiveCountMetricsGoodHoneycomb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodHoneycombToHclTerraform(struct?: SloObjectiveCountMetricsGoodHoneycomb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodHoneycombOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodHoneycomb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodHoneycomb | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _calculation?;
    get calculation(): string;
    set calculation(value: string);
    get calculationInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodHoneycombList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodHoneycomb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodHoneycombOutputReference;
}
export interface SloObjectiveCountMetricsGoodInfluxdb {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodInfluxdbToTerraform(struct?: SloObjectiveCountMetricsGoodInfluxdb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodInfluxdbToHclTerraform(struct?: SloObjectiveCountMetricsGoodInfluxdb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodInfluxdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodInfluxdb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodInfluxdb | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodInfluxdbList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodInfluxdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodInfluxdbOutputReference;
}
export interface SloObjectiveCountMetricsGoodInstanaApplicationGroupBy {
    /**
    * Group by tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag Slo#tag}
    */
    readonly tag: string;
    /**
    * Tag entity - one of 'DESTINATION', 'SOURCE', 'NOT_APPLICABLE'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag_entity Slo#tag_entity}
    */
    readonly tagEntity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag_second_level_key Slo#tag_second_level_key}
    */
    readonly tagSecondLevelKey?: string;
}
export declare function sloObjectiveCountMetricsGoodInstanaApplicationGroupByToTerraform(struct?: SloObjectiveCountMetricsGoodInstanaApplicationGroupBy | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodInstanaApplicationGroupByToHclTerraform(struct?: SloObjectiveCountMetricsGoodInstanaApplicationGroupBy | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodInstanaApplicationGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodInstanaApplicationGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodInstanaApplicationGroupBy | cdktn.IResolvable | undefined);
    private _tag?;
    get tag(): string;
    set tag(value: string);
    get tagInput(): string | undefined;
    private _tagEntity?;
    get tagEntity(): string;
    set tagEntity(value: string);
    get tagEntityInput(): string | undefined;
    private _tagSecondLevelKey?;
    get tagSecondLevelKey(): string;
    set tagSecondLevelKey(value: string);
    resetTagSecondLevelKey(): void;
    get tagSecondLevelKeyInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodInstanaApplicationGroupByList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodInstanaApplicationGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodInstanaApplicationGroupByOutputReference;
}
export interface SloObjectiveCountMetricsGoodInstanaApplication {
    /**
    * Depends on the value specified for 'metric_id'- more info in N9 docs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#aggregation Slo#aggregation}
    */
    readonly aggregation: string;
    /**
    * API query user passes in a JSON format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#api_query Slo#api_query}
    */
    readonly apiQuery: string;
    /**
    * Include internal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#include_internal Slo#include_internal}
    */
    readonly includeInternal?: boolean | cdktn.IResolvable;
    /**
    * Include synthetic
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#include_synthetic Slo#include_synthetic}
    */
    readonly includeSynthetic?: boolean | cdktn.IResolvable;
    /**
    * Metric ID one of 'calls', 'erroneousCalls', 'errors', 'latency'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_id Slo#metric_id}
    */
    readonly metricId: string;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#group_by Slo#group_by}
    */
    readonly groupBy: SloObjectiveCountMetricsGoodInstanaApplicationGroupBy[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsGoodInstanaApplicationToTerraform(struct?: SloObjectiveCountMetricsGoodInstanaApplication | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodInstanaApplicationToHclTerraform(struct?: SloObjectiveCountMetricsGoodInstanaApplication | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodInstanaApplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodInstanaApplication | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodInstanaApplication | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _apiQuery?;
    get apiQuery(): string;
    set apiQuery(value: string);
    get apiQueryInput(): string | undefined;
    private _includeInternal?;
    get includeInternal(): boolean | cdktn.IResolvable;
    set includeInternal(value: boolean | cdktn.IResolvable);
    resetIncludeInternal(): void;
    get includeInternalInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSynthetic?;
    get includeSynthetic(): boolean | cdktn.IResolvable;
    set includeSynthetic(value: boolean | cdktn.IResolvable);
    resetIncludeSynthetic(): void;
    get includeSyntheticInput(): boolean | cdktn.IResolvable | undefined;
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    get metricIdInput(): string | undefined;
    private _groupBy;
    get groupBy(): SloObjectiveCountMetricsGoodInstanaApplicationGroupByList;
    putGroupBy(value: SloObjectiveCountMetricsGoodInstanaApplicationGroupBy[] | cdktn.IResolvable): void;
    get groupByInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodInstanaApplicationGroupBy[] | undefined;
}
export declare class SloObjectiveCountMetricsGoodInstanaApplicationList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodInstanaApplication[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodInstanaApplicationOutputReference;
}
export interface SloObjectiveCountMetricsGoodInstanaInfrastructure {
    /**
    * Metric ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_id Slo#metric_id}
    */
    readonly metricId: string;
    /**
    * Metric retrieval method 'query' or 'snapshot'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_retrieval_method Slo#metric_retrieval_method}
    */
    readonly metricRetrievalMethod: string;
    /**
    * Plugin ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#plugin_id Slo#plugin_id}
    */
    readonly pluginId: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query?: string;
    /**
    * Snapshot ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#snapshot_id Slo#snapshot_id}
    */
    readonly snapshotId?: string;
}
export declare function sloObjectiveCountMetricsGoodInstanaInfrastructureToTerraform(struct?: SloObjectiveCountMetricsGoodInstanaInfrastructure | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodInstanaInfrastructureToHclTerraform(struct?: SloObjectiveCountMetricsGoodInstanaInfrastructure | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodInstanaInfrastructureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodInstanaInfrastructure | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodInstanaInfrastructure | cdktn.IResolvable | undefined);
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    get metricIdInput(): string | undefined;
    private _metricRetrievalMethod?;
    get metricRetrievalMethod(): string;
    set metricRetrievalMethod(value: string);
    get metricRetrievalMethodInput(): string | undefined;
    private _pluginId?;
    get pluginId(): string;
    set pluginId(value: string);
    get pluginIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _snapshotId?;
    get snapshotId(): string;
    set snapshotId(value: string);
    resetSnapshotId(): void;
    get snapshotIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodInstanaInfrastructureList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodInstanaInfrastructure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodInstanaInfrastructureOutputReference;
}
export interface SloObjectiveCountMetricsGoodInstana {
    /**
    * Instana metric type 'application' or 'infrastructure'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_type Slo#metric_type}
    */
    readonly metricType: string;
    /**
    * application block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#application Slo#application}
    */
    readonly application?: SloObjectiveCountMetricsGoodInstanaApplication[] | cdktn.IResolvable;
    /**
    * infrastructure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#infrastructure Slo#infrastructure}
    */
    readonly infrastructure?: SloObjectiveCountMetricsGoodInstanaInfrastructure[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsGoodInstanaToTerraform(struct?: SloObjectiveCountMetricsGoodInstana | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodInstanaToHclTerraform(struct?: SloObjectiveCountMetricsGoodInstana | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodInstanaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodInstana | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodInstana | cdktn.IResolvable | undefined);
    private _metricType?;
    get metricType(): string;
    set metricType(value: string);
    get metricTypeInput(): string | undefined;
    private _application;
    get application(): SloObjectiveCountMetricsGoodInstanaApplicationList;
    putApplication(value: SloObjectiveCountMetricsGoodInstanaApplication[] | cdktn.IResolvable): void;
    resetApplication(): void;
    get applicationInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodInstanaApplication[] | undefined;
    private _infrastructure;
    get infrastructure(): SloObjectiveCountMetricsGoodInstanaInfrastructureList;
    putInfrastructure(value: SloObjectiveCountMetricsGoodInstanaInfrastructure[] | cdktn.IResolvable): void;
    resetInfrastructure(): void;
    get infrastructureInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodInstanaInfrastructure[] | undefined;
}
export declare class SloObjectiveCountMetricsGoodInstanaList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodInstana[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodInstanaOutputReference;
}
export interface SloObjectiveCountMetricsGoodLightstep {
    /**
    * Optional value to filter by percentiles
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#percentile Slo#percentile}
    */
    readonly percentile?: number;
    /**
    * ID of the metrics stream
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#stream_id Slo#stream_id}
    */
    readonly streamId?: string;
    /**
    * Type of data to filter by
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#type_of_data Slo#type_of_data}
    */
    readonly typeOfData: string;
    /**
    * UQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#uql Slo#uql}
    */
    readonly uql?: string;
}
export declare function sloObjectiveCountMetricsGoodLightstepToTerraform(struct?: SloObjectiveCountMetricsGoodLightstep | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodLightstepToHclTerraform(struct?: SloObjectiveCountMetricsGoodLightstep | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodLightstepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodLightstep | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodLightstep | cdktn.IResolvable | undefined);
    private _percentile?;
    get percentile(): number;
    set percentile(value: number);
    resetPercentile(): void;
    get percentileInput(): number | undefined;
    private _streamId?;
    get streamId(): string;
    set streamId(value: string);
    resetStreamId(): void;
    get streamIdInput(): string | undefined;
    private _typeOfData?;
    get typeOfData(): string;
    set typeOfData(value: string);
    get typeOfDataInput(): string | undefined;
    private _uql?;
    get uql(): string;
    set uql(value: string);
    resetUql(): void;
    get uqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodLightstepList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodLightstep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodLightstepOutputReference;
}
export interface SloObjectiveCountMetricsGoodLogicMonitor {
    /**
    * Checkpoint ID. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#checkpoint_id Slo#checkpoint_id}
    */
    readonly checkpointId?: string;
    /**
    * Device Datasource Instance ID. Used by Query type = device_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#device_data_source_instance_id Slo#device_data_source_instance_id}
    */
    readonly deviceDataSourceInstanceId?: number;
    /**
    * Graph ID. Used by Query type = device_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graph_id Slo#graph_id}
    */
    readonly graphId?: number;
    /**
    * Graph Name. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graph_name Slo#graph_name}
    */
    readonly graphName?: string;
    /**
    * Line
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#line Slo#line}
    */
    readonly line: string;
    /**
    * Query type: device_metrics or website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query_type Slo#query_type}
    */
    readonly queryType: string;
    /**
    * Website ID. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#website_id Slo#website_id}
    */
    readonly websiteId?: string;
}
export declare function sloObjectiveCountMetricsGoodLogicMonitorToTerraform(struct?: SloObjectiveCountMetricsGoodLogicMonitor | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodLogicMonitorToHclTerraform(struct?: SloObjectiveCountMetricsGoodLogicMonitor | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodLogicMonitorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodLogicMonitor | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodLogicMonitor | cdktn.IResolvable | undefined);
    private _checkpointId?;
    get checkpointId(): string;
    set checkpointId(value: string);
    resetCheckpointId(): void;
    get checkpointIdInput(): string | undefined;
    private _deviceDataSourceInstanceId?;
    get deviceDataSourceInstanceId(): number;
    set deviceDataSourceInstanceId(value: number);
    resetDeviceDataSourceInstanceId(): void;
    get deviceDataSourceInstanceIdInput(): number | undefined;
    private _graphId?;
    get graphId(): number;
    set graphId(value: number);
    resetGraphId(): void;
    get graphIdInput(): number | undefined;
    private _graphName?;
    get graphName(): string;
    set graphName(value: string);
    resetGraphName(): void;
    get graphNameInput(): string | undefined;
    private _line?;
    get line(): string;
    set line(value: string);
    get lineInput(): string | undefined;
    private _queryType?;
    get queryType(): string;
    set queryType(value: string);
    get queryTypeInput(): string | undefined;
    private _websiteId?;
    get websiteId(): string;
    set websiteId(value: string);
    resetWebsiteId(): void;
    get websiteIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodLogicMonitorList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodLogicMonitor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodLogicMonitorOutputReference;
}
export interface SloObjectiveCountMetricsGoodNewrelic {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#nrql Slo#nrql}
    */
    readonly nrql: string;
}
export declare function sloObjectiveCountMetricsGoodNewrelicToTerraform(struct?: SloObjectiveCountMetricsGoodNewrelic | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodNewrelicToHclTerraform(struct?: SloObjectiveCountMetricsGoodNewrelic | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodNewrelicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodNewrelic | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodNewrelic | cdktn.IResolvable | undefined);
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodNewrelicList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodNewrelic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodNewrelicOutputReference;
}
export interface SloObjectiveCountMetricsGoodOpentsdb {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodOpentsdbToTerraform(struct?: SloObjectiveCountMetricsGoodOpentsdb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodOpentsdbToHclTerraform(struct?: SloObjectiveCountMetricsGoodOpentsdb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodOpentsdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodOpentsdb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodOpentsdb | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodOpentsdbList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodOpentsdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodOpentsdbOutputReference;
}
export interface SloObjectiveCountMetricsGoodPingdom {
    /**
    * Pingdom uptime or transaction check's ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#check_id Slo#check_id}
    */
    readonly checkId: string;
    /**
    * Pingdom check type - uptime or transaction
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#check_type Slo#check_type}
    */
    readonly checkType?: string;
    /**
    * Optional for the Uptime checks. Use it to filter the Pingdom check results by status
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#status Slo#status}
    */
    readonly status?: string;
}
export declare function sloObjectiveCountMetricsGoodPingdomToTerraform(struct?: SloObjectiveCountMetricsGoodPingdom | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodPingdomToHclTerraform(struct?: SloObjectiveCountMetricsGoodPingdom | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodPingdomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodPingdom | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodPingdom | cdktn.IResolvable | undefined);
    private _checkId?;
    get checkId(): string;
    set checkId(value: string);
    get checkIdInput(): string | undefined;
    private _checkType?;
    get checkType(): string;
    set checkType(value: string);
    resetCheckType(): void;
    get checkTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodPingdomList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodPingdom[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodPingdomOutputReference;
}
export interface SloObjectiveCountMetricsGoodPrometheus {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql: string;
}
export declare function sloObjectiveCountMetricsGoodPrometheusToTerraform(struct?: SloObjectiveCountMetricsGoodPrometheus | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodPrometheusToHclTerraform(struct?: SloObjectiveCountMetricsGoodPrometheus | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodPrometheusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodPrometheus | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodPrometheus | cdktn.IResolvable | undefined);
    private _promql?;
    get promql(): string;
    set promql(value: string);
    get promqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodPrometheusList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodPrometheus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodPrometheusOutputReference;
}
export interface SloObjectiveCountMetricsGoodRedshift {
    /**
    * Redshift custer ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#cluster_id Slo#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Database name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#database_name Slo#database_name}
    */
    readonly databaseName: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
    /**
    * Region of the Redshift instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#region Slo#region}
    */
    readonly region: string;
}
export declare function sloObjectiveCountMetricsGoodRedshiftToTerraform(struct?: SloObjectiveCountMetricsGoodRedshift | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodRedshiftToHclTerraform(struct?: SloObjectiveCountMetricsGoodRedshift | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodRedshiftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodRedshift | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodRedshift | cdktn.IResolvable | undefined);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodRedshiftList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodRedshift[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodRedshiftOutputReference;
}
export interface SloObjectiveCountMetricsGoodSplunk {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodSplunkToTerraform(struct?: SloObjectiveCountMetricsGoodSplunk | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodSplunkToHclTerraform(struct?: SloObjectiveCountMetricsGoodSplunk | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodSplunkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodSplunk | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodSplunk | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodSplunkList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodSplunk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodSplunkOutputReference;
}
export interface SloObjectiveCountMetricsGoodSplunkObservability {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#program Slo#program}
    */
    readonly program: string;
}
export declare function sloObjectiveCountMetricsGoodSplunkObservabilityToTerraform(struct?: SloObjectiveCountMetricsGoodSplunkObservability | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodSplunkObservabilityToHclTerraform(struct?: SloObjectiveCountMetricsGoodSplunkObservability | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodSplunkObservabilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodSplunkObservability | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodSplunkObservability | cdktn.IResolvable | undefined);
    private _program?;
    get program(): string;
    set program(value: string);
    get programInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodSplunkObservabilityList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodSplunkObservability[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodSplunkObservabilityOutputReference;
}
export interface SloObjectiveCountMetricsGoodSumologic {
    /**
    * Period of data aggregation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#quantization Slo#quantization}
    */
    readonly quantization?: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
    /**
    * Aggregation function - avg, sum, min, max, count, none
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#rollup Slo#rollup}
    */
    readonly rollup?: string;
    /**
    * Sumologic source - metrics or logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#type Slo#type}
    */
    readonly type: string;
}
export declare function sloObjectiveCountMetricsGoodSumologicToTerraform(struct?: SloObjectiveCountMetricsGoodSumologic | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodSumologicToHclTerraform(struct?: SloObjectiveCountMetricsGoodSumologic | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodSumologicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodSumologic | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodSumologic | cdktn.IResolvable | undefined);
    private _quantization?;
    get quantization(): string;
    set quantization(value: string);
    resetQuantization(): void;
    get quantizationInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _rollup?;
    get rollup(): string;
    set rollup(value: string);
    resetRollup(): void;
    get rollupInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodSumologicList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodSumologic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodSumologicOutputReference;
}
export interface SloObjectiveCountMetricsGoodThousandeyes {
    /**
    * ID of the test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#test_id Slo#test_id}
    */
    readonly testId: number;
    /**
    * Type of the test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#test_type Slo#test_type}
    */
    readonly testType?: string;
}
export declare function sloObjectiveCountMetricsGoodThousandeyesToTerraform(struct?: SloObjectiveCountMetricsGoodThousandeyes | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodThousandeyesToHclTerraform(struct?: SloObjectiveCountMetricsGoodThousandeyes | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodThousandeyesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodThousandeyes | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodThousandeyes | cdktn.IResolvable | undefined);
    private _testId?;
    get testId(): number;
    set testId(value: number);
    get testIdInput(): number | undefined;
    private _testType?;
    get testType(): string;
    set testType(value: string);
    resetTestType(): void;
    get testTypeInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodThousandeyesList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodThousandeyes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodThousandeyesOutputReference;
}
export interface SloObjectiveCountMetricsGood {
    /**
    * amazon_prometheus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#amazon_prometheus Slo#amazon_prometheus}
    */
    readonly amazonPrometheus?: SloObjectiveCountMetricsGoodAmazonPrometheus[] | cdktn.IResolvable;
    /**
    * appdynamics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#appdynamics Slo#appdynamics}
    */
    readonly appdynamics?: SloObjectiveCountMetricsGoodAppdynamics[] | cdktn.IResolvable;
    /**
    * azure_monitor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#azure_monitor Slo#azure_monitor}
    */
    readonly azureMonitor?: SloObjectiveCountMetricsGoodAzureMonitor[] | cdktn.IResolvable;
    /**
    * bigquery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#bigquery Slo#bigquery}
    */
    readonly bigquery?: SloObjectiveCountMetricsGoodBigquery[] | cdktn.IResolvable;
    /**
    * cloudwatch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#cloudwatch Slo#cloudwatch}
    */
    readonly cloudwatch?: SloObjectiveCountMetricsGoodCloudwatch[] | cdktn.IResolvable;
    /**
    * datadog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#datadog Slo#datadog}
    */
    readonly datadog?: SloObjectiveCountMetricsGoodDatadog[] | cdktn.IResolvable;
    /**
    * dynatrace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dynatrace Slo#dynatrace}
    */
    readonly dynatrace?: SloObjectiveCountMetricsGoodDynatrace[] | cdktn.IResolvable;
    /**
    * elasticsearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#elasticsearch Slo#elasticsearch}
    */
    readonly elasticsearch?: SloObjectiveCountMetricsGoodElasticsearch[] | cdktn.IResolvable;
    /**
    * gcm block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#gcm Slo#gcm}
    */
    readonly gcm?: SloObjectiveCountMetricsGoodGcm[] | cdktn.IResolvable;
    /**
    * grafana_loki block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#grafana_loki Slo#grafana_loki}
    */
    readonly grafanaLoki?: SloObjectiveCountMetricsGoodGrafanaLoki[] | cdktn.IResolvable;
    /**
    * graphite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graphite Slo#graphite}
    */
    readonly graphite?: SloObjectiveCountMetricsGoodGraphite[] | cdktn.IResolvable;
    /**
    * honeycomb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#honeycomb Slo#honeycomb}
    */
    readonly honeycomb?: SloObjectiveCountMetricsGoodHoneycomb[] | cdktn.IResolvable;
    /**
    * influxdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#influxdb Slo#influxdb}
    */
    readonly influxdb?: SloObjectiveCountMetricsGoodInfluxdb[] | cdktn.IResolvable;
    /**
    * instana block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#instana Slo#instana}
    */
    readonly instana?: SloObjectiveCountMetricsGoodInstana[] | cdktn.IResolvable;
    /**
    * lightstep block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#lightstep Slo#lightstep}
    */
    readonly lightstep?: SloObjectiveCountMetricsGoodLightstep[] | cdktn.IResolvable;
    /**
    * logic_monitor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#logic_monitor Slo#logic_monitor}
    */
    readonly logicMonitor?: SloObjectiveCountMetricsGoodLogicMonitor[] | cdktn.IResolvable;
    /**
    * newrelic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#newrelic Slo#newrelic}
    */
    readonly newrelic?: SloObjectiveCountMetricsGoodNewrelic[] | cdktn.IResolvable;
    /**
    * opentsdb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#opentsdb Slo#opentsdb}
    */
    readonly opentsdb?: SloObjectiveCountMetricsGoodOpentsdb[] | cdktn.IResolvable;
    /**
    * pingdom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#pingdom Slo#pingdom}
    */
    readonly pingdom?: SloObjectiveCountMetricsGoodPingdom[] | cdktn.IResolvable;
    /**
    * prometheus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#prometheus Slo#prometheus}
    */
    readonly prometheus?: SloObjectiveCountMetricsGoodPrometheus[] | cdktn.IResolvable;
    /**
    * redshift block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#redshift Slo#redshift}
    */
    readonly redshift?: SloObjectiveCountMetricsGoodRedshift[] | cdktn.IResolvable;
    /**
    * splunk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#splunk Slo#splunk}
    */
    readonly splunk?: SloObjectiveCountMetricsGoodSplunk[] | cdktn.IResolvable;
    /**
    * splunk_observability block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#splunk_observability Slo#splunk_observability}
    */
    readonly splunkObservability?: SloObjectiveCountMetricsGoodSplunkObservability[] | cdktn.IResolvable;
    /**
    * sumologic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#sumologic Slo#sumologic}
    */
    readonly sumologic?: SloObjectiveCountMetricsGoodSumologic[] | cdktn.IResolvable;
    /**
    * thousandeyes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#thousandeyes Slo#thousandeyes}
    */
    readonly thousandeyes?: SloObjectiveCountMetricsGoodThousandeyes[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsGoodToTerraform(struct?: SloObjectiveCountMetricsGood | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodToHclTerraform(struct?: SloObjectiveCountMetricsGood | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGood | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGood | cdktn.IResolvable | undefined);
    private _amazonPrometheus;
    get amazonPrometheus(): SloObjectiveCountMetricsGoodAmazonPrometheusList;
    putAmazonPrometheus(value: SloObjectiveCountMetricsGoodAmazonPrometheus[] | cdktn.IResolvable): void;
    resetAmazonPrometheus(): void;
    get amazonPrometheusInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodAmazonPrometheus[] | undefined;
    private _appdynamics;
    get appdynamics(): SloObjectiveCountMetricsGoodAppdynamicsList;
    putAppdynamics(value: SloObjectiveCountMetricsGoodAppdynamics[] | cdktn.IResolvable): void;
    resetAppdynamics(): void;
    get appdynamicsInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodAppdynamics[] | undefined;
    private _azureMonitor;
    get azureMonitor(): SloObjectiveCountMetricsGoodAzureMonitorList;
    putAzureMonitor(value: SloObjectiveCountMetricsGoodAzureMonitor[] | cdktn.IResolvable): void;
    resetAzureMonitor(): void;
    get azureMonitorInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodAzureMonitor[] | undefined;
    private _bigquery;
    get bigquery(): SloObjectiveCountMetricsGoodBigqueryList;
    putBigquery(value: SloObjectiveCountMetricsGoodBigquery[] | cdktn.IResolvable): void;
    resetBigquery(): void;
    get bigqueryInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodBigquery[] | undefined;
    private _cloudwatch;
    get cloudwatch(): SloObjectiveCountMetricsGoodCloudwatchList;
    putCloudwatch(value: SloObjectiveCountMetricsGoodCloudwatch[] | cdktn.IResolvable): void;
    resetCloudwatch(): void;
    get cloudwatchInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodCloudwatch[] | undefined;
    private _datadog;
    get datadog(): SloObjectiveCountMetricsGoodDatadogList;
    putDatadog(value: SloObjectiveCountMetricsGoodDatadog[] | cdktn.IResolvable): void;
    resetDatadog(): void;
    get datadogInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodDatadog[] | undefined;
    private _dynatrace;
    get dynatrace(): SloObjectiveCountMetricsGoodDynatraceList;
    putDynatrace(value: SloObjectiveCountMetricsGoodDynatrace[] | cdktn.IResolvable): void;
    resetDynatrace(): void;
    get dynatraceInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodDynatrace[] | undefined;
    private _elasticsearch;
    get elasticsearch(): SloObjectiveCountMetricsGoodElasticsearchList;
    putElasticsearch(value: SloObjectiveCountMetricsGoodElasticsearch[] | cdktn.IResolvable): void;
    resetElasticsearch(): void;
    get elasticsearchInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodElasticsearch[] | undefined;
    private _gcm;
    get gcm(): SloObjectiveCountMetricsGoodGcmList;
    putGcm(value: SloObjectiveCountMetricsGoodGcm[] | cdktn.IResolvable): void;
    resetGcm(): void;
    get gcmInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodGcm[] | undefined;
    private _grafanaLoki;
    get grafanaLoki(): SloObjectiveCountMetricsGoodGrafanaLokiList;
    putGrafanaLoki(value: SloObjectiveCountMetricsGoodGrafanaLoki[] | cdktn.IResolvable): void;
    resetGrafanaLoki(): void;
    get grafanaLokiInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodGrafanaLoki[] | undefined;
    private _graphite;
    get graphite(): SloObjectiveCountMetricsGoodGraphiteList;
    putGraphite(value: SloObjectiveCountMetricsGoodGraphite[] | cdktn.IResolvable): void;
    resetGraphite(): void;
    get graphiteInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodGraphite[] | undefined;
    private _honeycomb;
    get honeycomb(): SloObjectiveCountMetricsGoodHoneycombList;
    putHoneycomb(value: SloObjectiveCountMetricsGoodHoneycomb[] | cdktn.IResolvable): void;
    resetHoneycomb(): void;
    get honeycombInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodHoneycomb[] | undefined;
    private _influxdb;
    get influxdb(): SloObjectiveCountMetricsGoodInfluxdbList;
    putInfluxdb(value: SloObjectiveCountMetricsGoodInfluxdb[] | cdktn.IResolvable): void;
    resetInfluxdb(): void;
    get influxdbInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodInfluxdb[] | undefined;
    private _instana;
    get instana(): SloObjectiveCountMetricsGoodInstanaList;
    putInstana(value: SloObjectiveCountMetricsGoodInstana[] | cdktn.IResolvable): void;
    resetInstana(): void;
    get instanaInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodInstana[] | undefined;
    private _lightstep;
    get lightstep(): SloObjectiveCountMetricsGoodLightstepList;
    putLightstep(value: SloObjectiveCountMetricsGoodLightstep[] | cdktn.IResolvable): void;
    resetLightstep(): void;
    get lightstepInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodLightstep[] | undefined;
    private _logicMonitor;
    get logicMonitor(): SloObjectiveCountMetricsGoodLogicMonitorList;
    putLogicMonitor(value: SloObjectiveCountMetricsGoodLogicMonitor[] | cdktn.IResolvable): void;
    resetLogicMonitor(): void;
    get logicMonitorInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodLogicMonitor[] | undefined;
    private _newrelic;
    get newrelic(): SloObjectiveCountMetricsGoodNewrelicList;
    putNewrelic(value: SloObjectiveCountMetricsGoodNewrelic[] | cdktn.IResolvable): void;
    resetNewrelic(): void;
    get newrelicInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodNewrelic[] | undefined;
    private _opentsdb;
    get opentsdb(): SloObjectiveCountMetricsGoodOpentsdbList;
    putOpentsdb(value: SloObjectiveCountMetricsGoodOpentsdb[] | cdktn.IResolvable): void;
    resetOpentsdb(): void;
    get opentsdbInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodOpentsdb[] | undefined;
    private _pingdom;
    get pingdom(): SloObjectiveCountMetricsGoodPingdomList;
    putPingdom(value: SloObjectiveCountMetricsGoodPingdom[] | cdktn.IResolvable): void;
    resetPingdom(): void;
    get pingdomInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodPingdom[] | undefined;
    private _prometheus;
    get prometheus(): SloObjectiveCountMetricsGoodPrometheusList;
    putPrometheus(value: SloObjectiveCountMetricsGoodPrometheus[] | cdktn.IResolvable): void;
    resetPrometheus(): void;
    get prometheusInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodPrometheus[] | undefined;
    private _redshift;
    get redshift(): SloObjectiveCountMetricsGoodRedshiftList;
    putRedshift(value: SloObjectiveCountMetricsGoodRedshift[] | cdktn.IResolvable): void;
    resetRedshift(): void;
    get redshiftInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodRedshift[] | undefined;
    private _splunk;
    get splunk(): SloObjectiveCountMetricsGoodSplunkList;
    putSplunk(value: SloObjectiveCountMetricsGoodSplunk[] | cdktn.IResolvable): void;
    resetSplunk(): void;
    get splunkInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodSplunk[] | undefined;
    private _splunkObservability;
    get splunkObservability(): SloObjectiveCountMetricsGoodSplunkObservabilityList;
    putSplunkObservability(value: SloObjectiveCountMetricsGoodSplunkObservability[] | cdktn.IResolvable): void;
    resetSplunkObservability(): void;
    get splunkObservabilityInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodSplunkObservability[] | undefined;
    private _sumologic;
    get sumologic(): SloObjectiveCountMetricsGoodSumologicList;
    putSumologic(value: SloObjectiveCountMetricsGoodSumologic[] | cdktn.IResolvable): void;
    resetSumologic(): void;
    get sumologicInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodSumologic[] | undefined;
    private _thousandeyes;
    get thousandeyes(): SloObjectiveCountMetricsGoodThousandeyesList;
    putThousandeyes(value: SloObjectiveCountMetricsGoodThousandeyes[] | cdktn.IResolvable): void;
    resetThousandeyes(): void;
    get thousandeyesInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodThousandeyes[] | undefined;
}
export declare class SloObjectiveCountMetricsGoodList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGood[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalAmazonPrometheus {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql: string;
}
export declare function sloObjectiveCountMetricsGoodTotalAmazonPrometheusToTerraform(struct?: SloObjectiveCountMetricsGoodTotalAmazonPrometheus | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalAmazonPrometheusToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalAmazonPrometheus | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalAmazonPrometheusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalAmazonPrometheus | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalAmazonPrometheus | cdktn.IResolvable | undefined);
    private _promql?;
    get promql(): string;
    set promql(value: string);
    get promqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalAmazonPrometheusList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalAmazonPrometheus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalAmazonPrometheusOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalAppdynamics {
    /**
    * Name of the added application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#application_name Slo#application_name}
    */
    readonly applicationName: string;
    /**
    * Path to the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_path Slo#metric_path}
    */
    readonly metricPath: string;
}
export declare function sloObjectiveCountMetricsGoodTotalAppdynamicsToTerraform(struct?: SloObjectiveCountMetricsGoodTotalAppdynamics | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalAppdynamicsToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalAppdynamics | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalAppdynamicsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalAppdynamics | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalAppdynamics | cdktn.IResolvable | undefined);
    private _applicationName?;
    get applicationName(): string;
    set applicationName(value: string);
    get applicationNameInput(): string | undefined;
    private _metricPath?;
    get metricPath(): string;
    set metricPath(value: string);
    get metricPathInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalAppdynamicsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalAppdynamics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalAppdynamicsOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalAzureMonitorDimensions {
    /**
    * Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: string;
}
export declare function sloObjectiveCountMetricsGoodTotalAzureMonitorDimensionsToTerraform(struct?: SloObjectiveCountMetricsGoodTotalAzureMonitorDimensions | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalAzureMonitorDimensionsToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalAzureMonitorDimensions | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalAzureMonitorDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalAzureMonitorDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalAzureMonitorDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalAzureMonitorDimensionsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalAzureMonitorDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalAzureMonitorDimensionsOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspace {
    /**
    * Resource group of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#resource_group Slo#resource_group}
    */
    readonly resourceGroup: string;
    /**
    * Subscription ID of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#subscription_id Slo#subscription_id}
    */
    readonly subscriptionId: string;
    /**
    * ID of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#workspace_id Slo#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function sloObjectiveCountMetricsGoodTotalAzureMonitorWorkspaceToTerraform(struct?: SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspace | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalAzureMonitorWorkspaceToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspace | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspace | cdktn.IResolvable | undefined);
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    get subscriptionIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspaceList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspaceOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalAzureMonitor {
    /**
    * Aggregation type [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#aggregation Slo#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Specifies source: 'metrics' or 'logs'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#data_type Slo#data_type}
    */
    readonly dataType: string;
    /**
    * Logs query in Kusto Query Language [Required for logs]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#kql_query Slo#kql_query}
    */
    readonly kqlQuery?: string;
    /**
    * Name of the metric [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_name Slo#metric_name}
    */
    readonly metricName?: string;
    /**
    * Namespace of the metric [Optional for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_namespace Slo#metric_namespace}
    */
    readonly metricNamespace?: string;
    /**
    * Identifier of the Azure Cloud resource [Required for metrics]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#resource_id Slo#resource_id}
    */
    readonly resourceId?: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dimensions Slo#dimensions}
    */
    readonly dimensions?: SloObjectiveCountMetricsGoodTotalAzureMonitorDimensions[] | cdktn.IResolvable;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#workspace Slo#workspace}
    */
    readonly workspace?: SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspace[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsGoodTotalAzureMonitorToTerraform(struct?: SloObjectiveCountMetricsGoodTotalAzureMonitor | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalAzureMonitorToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalAzureMonitor | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalAzureMonitorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalAzureMonitor | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalAzureMonitor | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _kqlQuery?;
    get kqlQuery(): string;
    set kqlQuery(value: string);
    resetKqlQuery(): void;
    get kqlQueryInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _metricNamespace?;
    get metricNamespace(): string;
    set metricNamespace(value: string);
    resetMetricNamespace(): void;
    get metricNamespaceInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _dimensions;
    get dimensions(): SloObjectiveCountMetricsGoodTotalAzureMonitorDimensionsList;
    putDimensions(value: SloObjectiveCountMetricsGoodTotalAzureMonitorDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalAzureMonitorDimensions[] | undefined;
    private _workspace;
    get workspace(): SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspaceList;
    putWorkspace(value: SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspace[] | cdktn.IResolvable): void;
    resetWorkspace(): void;
    get workspaceInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalAzureMonitorWorkspace[] | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalAzureMonitorList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalAzureMonitor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalAzureMonitorOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalBigquery {
    /**
    * Location of you BigQuery
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#location Slo#location}
    */
    readonly location: string;
    /**
    * Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project_id Slo#project_id}
    */
    readonly projectId: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodTotalBigqueryToTerraform(struct?: SloObjectiveCountMetricsGoodTotalBigquery | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalBigqueryToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalBigquery | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalBigqueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalBigquery | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalBigquery | cdktn.IResolvable | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalBigqueryList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalBigquery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalBigqueryOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalCloudwatchDimensions {
    /**
    * Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#value Slo#value}
    */
    readonly value: string;
}
export declare function sloObjectiveCountMetricsGoodTotalCloudwatchDimensionsToTerraform(struct?: SloObjectiveCountMetricsGoodTotalCloudwatchDimensions | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalCloudwatchDimensionsToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalCloudwatchDimensions | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalCloudwatchDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalCloudwatchDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalCloudwatchDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalCloudwatchDimensionsList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalCloudwatchDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalCloudwatchDimensionsOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalCloudwatch {
    /**
    * AccountID used with cross-account observability feature
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#account_id Slo#account_id}
    */
    readonly accountId?: string;
    /**
    * JSON query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#json Slo#json}
    */
    readonly json?: string;
    /**
    * Metric name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_name Slo#metric_name}
    */
    readonly metricName?: string;
    /**
    * Namespace of the metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#namespace Slo#namespace}
    */
    readonly namespace?: string;
    /**
    * Region of the CloudWatch instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#region Slo#region}
    */
    readonly region: string;
    /**
    * SQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#sql Slo#sql}
    */
    readonly sql?: string;
    /**
    * Metric data aggregations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#stat Slo#stat}
    */
    readonly stat?: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#dimensions Slo#dimensions}
    */
    readonly dimensions?: SloObjectiveCountMetricsGoodTotalCloudwatchDimensions[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsGoodTotalCloudwatchToTerraform(struct?: SloObjectiveCountMetricsGoodTotalCloudwatch | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalCloudwatchToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalCloudwatch | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalCloudwatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalCloudwatch | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalCloudwatch | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _json?;
    get json(): string;
    set json(value: string);
    resetJson(): void;
    get jsonInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    resetSql(): void;
    get sqlInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _dimensions;
    get dimensions(): SloObjectiveCountMetricsGoodTotalCloudwatchDimensionsList;
    putDimensions(value: SloObjectiveCountMetricsGoodTotalCloudwatchDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalCloudwatchDimensions[] | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalCloudwatchList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalCloudwatch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalCloudwatchOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalDatadog {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodTotalDatadogToTerraform(struct?: SloObjectiveCountMetricsGoodTotalDatadog | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalDatadogToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalDatadog | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalDatadog | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalDatadog | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalDatadogList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalDatadog[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalDatadogOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalDynatrace {
    /**
    * Selector for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_selector Slo#metric_selector}
    */
    readonly metricSelector: string;
}
export declare function sloObjectiveCountMetricsGoodTotalDynatraceToTerraform(struct?: SloObjectiveCountMetricsGoodTotalDynatrace | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalDynatraceToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalDynatrace | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalDynatraceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalDynatrace | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalDynatrace | cdktn.IResolvable | undefined);
    private _metricSelector?;
    get metricSelector(): string;
    set metricSelector(value: string);
    get metricSelectorInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalDynatraceList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalDynatrace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalDynatraceOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalElasticsearch {
    /**
    * Index of metrics we want to query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#index Slo#index}
    */
    readonly index: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodTotalElasticsearchToTerraform(struct?: SloObjectiveCountMetricsGoodTotalElasticsearch | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalElasticsearchToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalElasticsearch | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalElasticsearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalElasticsearch | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalElasticsearch | cdktn.IResolvable | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalElasticsearchList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalElasticsearch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalElasticsearchOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalGcm {
    /**
    * Project ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project_id Slo#project_id}
    */
    readonly projectId: string;
    /**
    * Query for the metrics in PromQL format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#promql Slo#promql}
    */
    readonly promql?: string;
    /**
    * Query for the metrics in MQL format ([deprecated](https://cloud.google.com/stackdriver/docs/deprecations/mql))
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query?: string;
}
export declare function sloObjectiveCountMetricsGoodTotalGcmToTerraform(struct?: SloObjectiveCountMetricsGoodTotalGcm | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalGcmToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalGcm | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalGcmOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalGcm | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalGcm | cdktn.IResolvable | undefined);
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _promql?;
    get promql(): string;
    set promql(value: string);
    resetPromql(): void;
    get promqlInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalGcmList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalGcm[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalGcmOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalGrafanaLoki {
    /**
    * Query for the logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#logql Slo#logql}
    */
    readonly logql: string;
}
export declare function sloObjectiveCountMetricsGoodTotalGrafanaLokiToTerraform(struct?: SloObjectiveCountMetricsGoodTotalGrafanaLoki | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalGrafanaLokiToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalGrafanaLoki | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalGrafanaLokiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalGrafanaLoki | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalGrafanaLoki | cdktn.IResolvable | undefined);
    private _logql?;
    get logql(): string;
    set logql(value: string);
    get logqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalGrafanaLokiList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalGrafanaLoki[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalGrafanaLokiOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalGraphite {
    /**
    * Path to the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_path Slo#metric_path}
    */
    readonly metricPath: string;
}
export declare function sloObjectiveCountMetricsGoodTotalGraphiteToTerraform(struct?: SloObjectiveCountMetricsGoodTotalGraphite | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalGraphiteToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalGraphite | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalGraphiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalGraphite | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalGraphite | cdktn.IResolvable | undefined);
    private _metricPath?;
    get metricPath(): string;
    set metricPath(value: string);
    get metricPathInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalGraphiteList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalGraphite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalGraphiteOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalHoneycomb {
    /**
    * Column name - required for all calculation types besides 'CONCURRENCY' and 'COUNT'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#attribute Slo#attribute}
    */
    readonly attribute?: string;
    /**
    * Calculation type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#calculation Slo#calculation}
    */
    readonly calculation: string;
}
export declare function sloObjectiveCountMetricsGoodTotalHoneycombToTerraform(struct?: SloObjectiveCountMetricsGoodTotalHoneycomb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalHoneycombToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalHoneycomb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalHoneycombOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalHoneycomb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalHoneycomb | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _calculation?;
    get calculation(): string;
    set calculation(value: string);
    get calculationInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalHoneycombList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalHoneycomb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalHoneycombOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalInfluxdb {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodTotalInfluxdbToTerraform(struct?: SloObjectiveCountMetricsGoodTotalInfluxdb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalInfluxdbToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalInfluxdb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalInfluxdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalInfluxdb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalInfluxdb | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalInfluxdbList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalInfluxdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalInfluxdbOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupBy {
    /**
    * Group by tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag Slo#tag}
    */
    readonly tag: string;
    /**
    * Tag entity - one of 'DESTINATION', 'SOURCE', 'NOT_APPLICABLE'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag_entity Slo#tag_entity}
    */
    readonly tagEntity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tag_second_level_key Slo#tag_second_level_key}
    */
    readonly tagSecondLevelKey?: string;
}
export declare function sloObjectiveCountMetricsGoodTotalInstanaApplicationGroupByToTerraform(struct?: SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupBy | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalInstanaApplicationGroupByToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupBy | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupBy | cdktn.IResolvable | undefined);
    private _tag?;
    get tag(): string;
    set tag(value: string);
    get tagInput(): string | undefined;
    private _tagEntity?;
    get tagEntity(): string;
    set tagEntity(value: string);
    get tagEntityInput(): string | undefined;
    private _tagSecondLevelKey?;
    get tagSecondLevelKey(): string;
    set tagSecondLevelKey(value: string);
    resetTagSecondLevelKey(): void;
    get tagSecondLevelKeyInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupByList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupByOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalInstanaApplication {
    /**
    * Depends on the value specified for 'metric_id'- more info in N9 docs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#aggregation Slo#aggregation}
    */
    readonly aggregation: string;
    /**
    * API query user passes in a JSON format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#api_query Slo#api_query}
    */
    readonly apiQuery: string;
    /**
    * Include internal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#include_internal Slo#include_internal}
    */
    readonly includeInternal?: boolean | cdktn.IResolvable;
    /**
    * Include synthetic
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#include_synthetic Slo#include_synthetic}
    */
    readonly includeSynthetic?: boolean | cdktn.IResolvable;
    /**
    * Metric ID one of 'calls', 'erroneousCalls', 'errors', 'latency'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_id Slo#metric_id}
    */
    readonly metricId: string;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#group_by Slo#group_by}
    */
    readonly groupBy: SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupBy[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsGoodTotalInstanaApplicationToTerraform(struct?: SloObjectiveCountMetricsGoodTotalInstanaApplication | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalInstanaApplicationToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalInstanaApplication | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalInstanaApplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalInstanaApplication | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalInstanaApplication | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _apiQuery?;
    get apiQuery(): string;
    set apiQuery(value: string);
    get apiQueryInput(): string | undefined;
    private _includeInternal?;
    get includeInternal(): boolean | cdktn.IResolvable;
    set includeInternal(value: boolean | cdktn.IResolvable);
    resetIncludeInternal(): void;
    get includeInternalInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSynthetic?;
    get includeSynthetic(): boolean | cdktn.IResolvable;
    set includeSynthetic(value: boolean | cdktn.IResolvable);
    resetIncludeSynthetic(): void;
    get includeSyntheticInput(): boolean | cdktn.IResolvable | undefined;
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    get metricIdInput(): string | undefined;
    private _groupBy;
    get groupBy(): SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupByList;
    putGroupBy(value: SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupBy[] | cdktn.IResolvable): void;
    get groupByInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalInstanaApplicationGroupBy[] | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalInstanaApplicationList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalInstanaApplication[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalInstanaApplicationOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalInstanaInfrastructure {
    /**
    * Metric ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_id Slo#metric_id}
    */
    readonly metricId: string;
    /**
    * Metric retrieval method 'query' or 'snapshot'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_retrieval_method Slo#metric_retrieval_method}
    */
    readonly metricRetrievalMethod: string;
    /**
    * Plugin ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#plugin_id Slo#plugin_id}
    */
    readonly pluginId: string;
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query?: string;
    /**
    * Snapshot ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#snapshot_id Slo#snapshot_id}
    */
    readonly snapshotId?: string;
}
export declare function sloObjectiveCountMetricsGoodTotalInstanaInfrastructureToTerraform(struct?: SloObjectiveCountMetricsGoodTotalInstanaInfrastructure | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalInstanaInfrastructureToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalInstanaInfrastructure | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalInstanaInfrastructureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalInstanaInfrastructure | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalInstanaInfrastructure | cdktn.IResolvable | undefined);
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    get metricIdInput(): string | undefined;
    private _metricRetrievalMethod?;
    get metricRetrievalMethod(): string;
    set metricRetrievalMethod(value: string);
    get metricRetrievalMethodInput(): string | undefined;
    private _pluginId?;
    get pluginId(): string;
    set pluginId(value: string);
    get pluginIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _snapshotId?;
    get snapshotId(): string;
    set snapshotId(value: string);
    resetSnapshotId(): void;
    get snapshotIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalInstanaInfrastructureList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalInstanaInfrastructure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalInstanaInfrastructureOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalInstana {
    /**
    * Instana metric type 'application' or 'infrastructure'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#metric_type Slo#metric_type}
    */
    readonly metricType: string;
    /**
    * application block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#application Slo#application}
    */
    readonly application?: SloObjectiveCountMetricsGoodTotalInstanaApplication[] | cdktn.IResolvable;
    /**
    * infrastructure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#infrastructure Slo#infrastructure}
    */
    readonly infrastructure?: SloObjectiveCountMetricsGoodTotalInstanaInfrastructure[] | cdktn.IResolvable;
}
export declare function sloObjectiveCountMetricsGoodTotalInstanaToTerraform(struct?: SloObjectiveCountMetricsGoodTotalInstana | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalInstanaToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalInstana | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalInstanaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalInstana | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalInstana | cdktn.IResolvable | undefined);
    private _metricType?;
    get metricType(): string;
    set metricType(value: string);
    get metricTypeInput(): string | undefined;
    private _application;
    get application(): SloObjectiveCountMetricsGoodTotalInstanaApplicationList;
    putApplication(value: SloObjectiveCountMetricsGoodTotalInstanaApplication[] | cdktn.IResolvable): void;
    resetApplication(): void;
    get applicationInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalInstanaApplication[] | undefined;
    private _infrastructure;
    get infrastructure(): SloObjectiveCountMetricsGoodTotalInstanaInfrastructureList;
    putInfrastructure(value: SloObjectiveCountMetricsGoodTotalInstanaInfrastructure[] | cdktn.IResolvable): void;
    resetInfrastructure(): void;
    get infrastructureInput(): cdktn.IResolvable | SloObjectiveCountMetricsGoodTotalInstanaInfrastructure[] | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalInstanaList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalInstana[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalInstanaOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalLightstep {
    /**
    * Optional value to filter by percentiles
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#percentile Slo#percentile}
    */
    readonly percentile?: number;
    /**
    * ID of the metrics stream
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#stream_id Slo#stream_id}
    */
    readonly streamId?: string;
    /**
    * Type of data to filter by
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#type_of_data Slo#type_of_data}
    */
    readonly typeOfData: string;
    /**
    * UQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#uql Slo#uql}
    */
    readonly uql?: string;
}
export declare function sloObjectiveCountMetricsGoodTotalLightstepToTerraform(struct?: SloObjectiveCountMetricsGoodTotalLightstep | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalLightstepToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalLightstep | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalLightstepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalLightstep | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalLightstep | cdktn.IResolvable | undefined);
    private _percentile?;
    get percentile(): number;
    set percentile(value: number);
    resetPercentile(): void;
    get percentileInput(): number | undefined;
    private _streamId?;
    get streamId(): string;
    set streamId(value: string);
    resetStreamId(): void;
    get streamIdInput(): string | undefined;
    private _typeOfData?;
    get typeOfData(): string;
    set typeOfData(value: string);
    get typeOfDataInput(): string | undefined;
    private _uql?;
    get uql(): string;
    set uql(value: string);
    resetUql(): void;
    get uqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalLightstepList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalLightstep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalLightstepOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalLogicMonitor {
    /**
    * Checkpoint ID. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#checkpoint_id Slo#checkpoint_id}
    */
    readonly checkpointId?: string;
    /**
    * Device Datasource Instance ID. Used by Query type = device_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#device_data_source_instance_id Slo#device_data_source_instance_id}
    */
    readonly deviceDataSourceInstanceId?: number;
    /**
    * Graph ID. Used by Query type = device_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graph_id Slo#graph_id}
    */
    readonly graphId?: number;
    /**
    * Graph Name. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#graph_name Slo#graph_name}
    */
    readonly graphName?: string;
    /**
    * Line
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#line Slo#line}
    */
    readonly line: string;
    /**
    * Query type: device_metrics or website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query_type Slo#query_type}
    */
    readonly queryType: string;
    /**
    * Website ID. Used by Query type = website_metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#website_id Slo#website_id}
    */
    readonly websiteId?: string;
}
export declare function sloObjectiveCountMetricsGoodTotalLogicMonitorToTerraform(struct?: SloObjectiveCountMetricsGoodTotalLogicMonitor | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalLogicMonitorToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalLogicMonitor | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalLogicMonitorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalLogicMonitor | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalLogicMonitor | cdktn.IResolvable | undefined);
    private _checkpointId?;
    get checkpointId(): string;
    set checkpointId(value: string);
    resetCheckpointId(): void;
    get checkpointIdInput(): string | undefined;
    private _deviceDataSourceInstanceId?;
    get deviceDataSourceInstanceId(): number;
    set deviceDataSourceInstanceId(value: number);
    resetDeviceDataSourceInstanceId(): void;
    get deviceDataSourceInstanceIdInput(): number | undefined;
    private _graphId?;
    get graphId(): number;
    set graphId(value: number);
    resetGraphId(): void;
    get graphIdInput(): number | undefined;
    private _graphName?;
    get graphName(): string;
    set graphName(value: string);
    resetGraphName(): void;
    get graphNameInput(): string | undefined;
    private _line?;
    get line(): string;
    set line(value: string);
    get lineInput(): string | undefined;
    private _queryType?;
    get queryType(): string;
    set queryType(value: string);
    get queryTypeInput(): string | undefined;
    private _websiteId?;
    get websiteId(): string;
    set websiteId(value: string);
    resetWebsiteId(): void;
    get websiteIdInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalLogicMonitorList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalLogicMonitor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalLogicMonitorOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalNewrelic {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#nrql Slo#nrql}
    */
    readonly nrql: string;
}
export declare function sloObjectiveCountMetricsGoodTotalNewrelicToTerraform(struct?: SloObjectiveCountMetricsGoodTotalNewrelic | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalNewrelicToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalNewrelic | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalNewrelicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalNewrelic | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalNewrelic | cdktn.IResolvable | undefined);
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalNewrelicList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalNewrelic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalNewrelicOutputReference;
}
export interface SloObjectiveCountMetricsGoodTotalOpentsdb {
    /**
    * Query for the metrics
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#query Slo#query}
    */
    readonly query: string;
}
export declare function sloObjectiveCountMetricsGoodTotalOpentsdbToTerraform(struct?: SloObjectiveCountMetricsGoodTotalOpentsdb | cdktn.IResolvable): any;
export declare function sloObjectiveCountMetricsGoodTotalOpentsdbToHclTerraform(struct?: SloObjectiveCountMetricsGoodTotalOpentsdb | cdktn.IResolvable): any;
export declare class SloObjectiveCountMetricsGoodTotalOpentsdbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SloObjectiveCountMetricsGoodTotalOpentsdb | cdktn.IResolvable | undefined;
    set internalValue(value: SloObjectiveCountMetricsGoodTotalOpentsdb | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SloObjectiveCountMetricsGoodTotalOpentsdbList extends cdktn.ComplexList {
    internalValue?: SloObjectiveCountMetricsGoodTotalOpentsdb[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SloObjectiveCountMetricsGoodTotalOpentsdbOutputReference;
}
