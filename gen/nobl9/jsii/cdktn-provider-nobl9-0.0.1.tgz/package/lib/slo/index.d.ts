import { SloAnomalyConfig, SloAnomalyConfigOutputReference, SloAttachment, SloAttachmentList, SloAttachments, SloAttachmentsList, SloComposite, SloCompositeOutputReference, SloIndicator, SloIndicatorOutputReference, SloLabel, SloLabelList, SloObjective, SloObjectiveList, SloTimeWindow, SloTimeWindowOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SloConfig extends cdktn.TerraformMetaArguments {
    /**
    * Alert Policies attached to SLO.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#alert_policies Slo#alert_policies}
    */
    readonly alertPolicies?: string[];
    /**
    * [Metadata annotations](https://docs.nobl9.com/features/labels/#metadata-annotations) attached to the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#annotations Slo#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Method which will be use to calculate budget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#budgeting_method Slo#budgeting_method}
    */
    readonly budgetingMethod: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#description Slo#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#display_name Slo#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#id Slo#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#name Slo#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#project Slo#project}
    */
    readonly project: string;
    /**
    * If set, the retrieval of historical data for a newly created SLO will be triggered, starting from the specified date. Needs to be RFC3339 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#retrieve_historical_data_from Slo#retrieve_historical_data_from}
    */
    readonly retrieveHistoricalDataFrom?: string;
    /**
    * Name of the service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#service Slo#service}
    */
    readonly service: string;
    /**
    * Internal field, do not use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#tier Slo#tier}
    */
    readonly tier?: string;
    /**
    * anomaly_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#anomaly_config Slo#anomaly_config}
    */
    readonly anomalyConfig?: SloAnomalyConfig;
    /**
    * attachment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#attachment Slo#attachment}
    */
    readonly attachment?: SloAttachment[] | cdktn.IResolvable;
    /**
    * attachments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#attachments Slo#attachments}
    */
    readonly attachments?: SloAttachments[] | cdktn.IResolvable;
    /**
    * composite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#composite Slo#composite}
    */
    readonly composite?: SloComposite;
    /**
    * indicator block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#indicator Slo#indicator}
    */
    readonly indicator?: SloIndicator;
    /**
    * label block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#label Slo#label}
    */
    readonly label?: SloLabel[] | cdktn.IResolvable;
    /**
    * objective block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#objective Slo#objective}
    */
    readonly objective: SloObjective[] | cdktn.IResolvable;
    /**
    * time_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#time_window Slo#time_window}
    */
    readonly timeWindow: SloTimeWindow;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo nobl9_slo}
*/
export declare class Slo extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_slo";
    /**
    * Generates CDKTN code for importing a Slo resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Slo to import
    * @param importFromId The id of the existing Slo that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Slo to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/slo nobl9_slo} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SloConfig
    */
    constructor(scope: Construct, id: string, config: SloConfig);
    private _alertPolicies?;
    get alertPolicies(): string[];
    set alertPolicies(value: string[]);
    resetAlertPolicies(): void;
    get alertPoliciesInput(): string[] | undefined;
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _budgetingMethod?;
    get budgetingMethod(): string;
    set budgetingMethod(value: string);
    get budgetingMethodInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _retrieveHistoricalDataFrom?;
    get retrieveHistoricalDataFrom(): string;
    set retrieveHistoricalDataFrom(value: string);
    resetRetrieveHistoricalDataFrom(): void;
    get retrieveHistoricalDataFromInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    resetTier(): void;
    get tierInput(): string | undefined;
    private _anomalyConfig;
    get anomalyConfig(): SloAnomalyConfigOutputReference;
    putAnomalyConfig(value: SloAnomalyConfig): void;
    resetAnomalyConfig(): void;
    get anomalyConfigInput(): SloAnomalyConfig | undefined;
    private _attachment;
    get attachment(): SloAttachmentList;
    putAttachment(value: SloAttachment[] | cdktn.IResolvable): void;
    resetAttachment(): void;
    get attachmentInput(): cdktn.IResolvable | SloAttachment[] | undefined;
    private _attachments;
    get attachments(): SloAttachmentsList;
    putAttachments(value: SloAttachments[] | cdktn.IResolvable): void;
    resetAttachments(): void;
    get attachmentsInput(): cdktn.IResolvable | SloAttachments[] | undefined;
    private _composite;
    get composite(): SloCompositeOutputReference;
    putComposite(value: SloComposite): void;
    resetComposite(): void;
    get compositeInput(): SloComposite | undefined;
    private _indicator;
    get indicator(): SloIndicatorOutputReference;
    putIndicator(value: SloIndicator): void;
    resetIndicator(): void;
    get indicatorInput(): SloIndicator | undefined;
    private _label;
    get label(): SloLabelList;
    putLabel(value: SloLabel[] | cdktn.IResolvable): void;
    resetLabel(): void;
    get labelInput(): cdktn.IResolvable | SloLabel[] | undefined;
    private _objective;
    get objective(): SloObjectiveList;
    putObjective(value: SloObjective[] | cdktn.IResolvable): void;
    get objectiveInput(): cdktn.IResolvable | SloObjective[] | undefined;
    private _timeWindow;
    get timeWindow(): SloTimeWindowOutputReference;
    putTimeWindow(value: SloTimeWindow): void;
    get timeWindowInput(): SloTimeWindow | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
