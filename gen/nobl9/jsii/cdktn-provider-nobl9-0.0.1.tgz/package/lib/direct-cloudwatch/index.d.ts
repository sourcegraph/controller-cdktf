import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectCloudwatchConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#description DirectCloudwatch#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#display_name DirectCloudwatch#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#id DirectCloudwatch#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#log_collection_enabled DirectCloudwatch#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#name DirectCloudwatch#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#project DirectCloudwatch#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#release_channel DirectCloudwatch#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * [required] | ARN of the AWS IAM Role to assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#role_arn DirectCloudwatch#role_arn}
    */
    readonly roleArn?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#source_of DirectCloudwatch#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#historical_data_retrieval DirectCloudwatch#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: DirectCloudwatchHistoricalDataRetrieval;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#query_delay DirectCloudwatch#query_delay}
    */
    readonly queryDelay?: DirectCloudwatchQueryDelay;
}
export interface DirectCloudwatchHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#unit DirectCloudwatch#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#value DirectCloudwatch#value}
    */
    readonly value: number;
}
export declare function directCloudwatchHistoricalDataRetrievalDefaultDurationToTerraform(struct?: DirectCloudwatchHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function directCloudwatchHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: DirectCloudwatchHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class DirectCloudwatchHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectCloudwatchHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectCloudwatchHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectCloudwatchHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: DirectCloudwatchHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectCloudwatchHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface DirectCloudwatchHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#unit DirectCloudwatch#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#value DirectCloudwatch#value}
    */
    readonly value: number;
}
export declare function directCloudwatchHistoricalDataRetrievalMaxDurationToTerraform(struct?: DirectCloudwatchHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function directCloudwatchHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: DirectCloudwatchHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class DirectCloudwatchHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectCloudwatchHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectCloudwatchHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectCloudwatchHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: DirectCloudwatchHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectCloudwatchHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface DirectCloudwatchHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#default_duration DirectCloudwatch#default_duration}
    */
    readonly defaultDuration: DirectCloudwatchHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#max_duration DirectCloudwatch#max_duration}
    */
    readonly maxDuration: DirectCloudwatchHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function directCloudwatchHistoricalDataRetrievalToTerraform(struct?: DirectCloudwatchHistoricalDataRetrievalOutputReference | DirectCloudwatchHistoricalDataRetrieval): any;
export declare function directCloudwatchHistoricalDataRetrievalToHclTerraform(struct?: DirectCloudwatchHistoricalDataRetrievalOutputReference | DirectCloudwatchHistoricalDataRetrieval): any;
export declare class DirectCloudwatchHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectCloudwatchHistoricalDataRetrieval | undefined;
    set internalValue(value: DirectCloudwatchHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): DirectCloudwatchHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: DirectCloudwatchHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | DirectCloudwatchHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): DirectCloudwatchHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: DirectCloudwatchHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | DirectCloudwatchHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface DirectCloudwatchQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#unit DirectCloudwatch#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#value DirectCloudwatch#value}
    */
    readonly value: number;
}
export declare function directCloudwatchQueryDelayToTerraform(struct?: DirectCloudwatchQueryDelayOutputReference | DirectCloudwatchQueryDelay): any;
export declare function directCloudwatchQueryDelayToHclTerraform(struct?: DirectCloudwatchQueryDelayOutputReference | DirectCloudwatchQueryDelay): any;
export declare class DirectCloudwatchQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectCloudwatchQueryDelay | undefined;
    set internalValue(value: DirectCloudwatchQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch nobl9_direct_cloudwatch}
*/
export declare class DirectCloudwatch extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_cloudwatch";
    /**
    * Generates CDKTN code for importing a DirectCloudwatch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectCloudwatch to import
    * @param importFromId The id of the existing DirectCloudwatch that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectCloudwatch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_cloudwatch nobl9_direct_cloudwatch} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectCloudwatchConfig
    */
    constructor(scope: Construct, id: string, config: DirectCloudwatchConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): DirectCloudwatchHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: DirectCloudwatchHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): DirectCloudwatchHistoricalDataRetrieval | undefined;
    private _queryDelay;
    get queryDelay(): DirectCloudwatchQueryDelayOutputReference;
    putQueryDelay(value: DirectCloudwatchQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectCloudwatchQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
