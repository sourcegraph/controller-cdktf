import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectLogicMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * [required] | Logic Monitor Application access key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#access_key DirectLogicMonitor#access_key}
    */
    readonly accessKey?: string;
    /**
    * Account name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#account DirectLogicMonitor#account}
    */
    readonly account: string;
    /**
    * [required] | Logic Monitor Application account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#account_id DirectLogicMonitor#account_id}
    */
    readonly accountId?: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#description DirectLogicMonitor#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#display_name DirectLogicMonitor#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#id DirectLogicMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#log_collection_enabled DirectLogicMonitor#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#name DirectLogicMonitor#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#project DirectLogicMonitor#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#release_channel DirectLogicMonitor#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#source_of DirectLogicMonitor#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#historical_data_retrieval DirectLogicMonitor#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: DirectLogicMonitorHistoricalDataRetrieval;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#query_delay DirectLogicMonitor#query_delay}
    */
    readonly queryDelay?: DirectLogicMonitorQueryDelay;
}
export interface DirectLogicMonitorHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#unit DirectLogicMonitor#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#value DirectLogicMonitor#value}
    */
    readonly value: number;
}
export declare function directLogicMonitorHistoricalDataRetrievalDefaultDurationToTerraform(struct?: DirectLogicMonitorHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function directLogicMonitorHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: DirectLogicMonitorHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class DirectLogicMonitorHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectLogicMonitorHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectLogicMonitorHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectLogicMonitorHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: DirectLogicMonitorHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectLogicMonitorHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface DirectLogicMonitorHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#unit DirectLogicMonitor#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#value DirectLogicMonitor#value}
    */
    readonly value: number;
}
export declare function directLogicMonitorHistoricalDataRetrievalMaxDurationToTerraform(struct?: DirectLogicMonitorHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function directLogicMonitorHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: DirectLogicMonitorHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class DirectLogicMonitorHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectLogicMonitorHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectLogicMonitorHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectLogicMonitorHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: DirectLogicMonitorHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectLogicMonitorHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface DirectLogicMonitorHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#default_duration DirectLogicMonitor#default_duration}
    */
    readonly defaultDuration: DirectLogicMonitorHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#max_duration DirectLogicMonitor#max_duration}
    */
    readonly maxDuration: DirectLogicMonitorHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function directLogicMonitorHistoricalDataRetrievalToTerraform(struct?: DirectLogicMonitorHistoricalDataRetrievalOutputReference | DirectLogicMonitorHistoricalDataRetrieval): any;
export declare function directLogicMonitorHistoricalDataRetrievalToHclTerraform(struct?: DirectLogicMonitorHistoricalDataRetrievalOutputReference | DirectLogicMonitorHistoricalDataRetrieval): any;
export declare class DirectLogicMonitorHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectLogicMonitorHistoricalDataRetrieval | undefined;
    set internalValue(value: DirectLogicMonitorHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): DirectLogicMonitorHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: DirectLogicMonitorHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | DirectLogicMonitorHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): DirectLogicMonitorHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: DirectLogicMonitorHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | DirectLogicMonitorHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface DirectLogicMonitorQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#unit DirectLogicMonitor#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#value DirectLogicMonitor#value}
    */
    readonly value: number;
}
export declare function directLogicMonitorQueryDelayToTerraform(struct?: DirectLogicMonitorQueryDelayOutputReference | DirectLogicMonitorQueryDelay): any;
export declare function directLogicMonitorQueryDelayToHclTerraform(struct?: DirectLogicMonitorQueryDelayOutputReference | DirectLogicMonitorQueryDelay): any;
export declare class DirectLogicMonitorQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectLogicMonitorQueryDelay | undefined;
    set internalValue(value: DirectLogicMonitorQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor nobl9_direct_logic_monitor}
*/
export declare class DirectLogicMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_logic_monitor";
    /**
    * Generates CDKTN code for importing a DirectLogicMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectLogicMonitor to import
    * @param importFromId The id of the existing DirectLogicMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectLogicMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_logic_monitor nobl9_direct_logic_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectLogicMonitorConfig
    */
    constructor(scope: Construct, id: string, config: DirectLogicMonitorConfig);
    private _accessKey?;
    get accessKey(): string;
    set accessKey(value: string);
    resetAccessKey(): void;
    get accessKeyInput(): string | undefined;
    private _account?;
    get account(): string;
    set account(value: string);
    get accountInput(): string | undefined;
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): DirectLogicMonitorHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: DirectLogicMonitorHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): DirectLogicMonitorHistoricalDataRetrieval | undefined;
    private _queryDelay;
    get queryDelay(): DirectLogicMonitorQueryDelayOutputReference;
    putQueryDelay(value: DirectLogicMonitorQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectLogicMonitorQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
