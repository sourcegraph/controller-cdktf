import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * [Metadata annotations](https://docs.nobl9.com/features/labels/#metadata-annotations) attached to the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#annotations AlertPolicy#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * An interval measured from the last time stamp when all alert policy conditions were satisfied before alert is marked as resolved
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#cooldown AlertPolicy#cooldown}
    */
    readonly cooldown?: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#description AlertPolicy#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#display_name AlertPolicy#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#id AlertPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#name AlertPolicy#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#project AlertPolicy#project}
    */
    readonly project: string;
    /**
    * Alert severity. One of `Low` | `Medium` | `High`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#severity AlertPolicy#severity}
    */
    readonly severity: string;
    /**
    * alert_method block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#alert_method AlertPolicy#alert_method}
    */
    readonly alertMethod?: AlertPolicyAlertMethod[] | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#condition AlertPolicy#condition}
    */
    readonly condition: AlertPolicyCondition[] | cdktn.IResolvable;
}
export interface AlertPolicyAlertMethod {
    /**
    * The name of the previously defined alert method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#name AlertPolicy#name}
    */
    readonly name: string;
    /**
    * Project name the Alert Method is in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names). If not defined, Nobl9 returns a default value for this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#project AlertPolicy#project}
    */
    readonly project?: string;
}
export declare function alertPolicyAlertMethodToTerraform(struct?: AlertPolicyAlertMethod | cdktn.IResolvable): any;
export declare function alertPolicyAlertMethodToHclTerraform(struct?: AlertPolicyAlertMethod | cdktn.IResolvable): any;
export declare class AlertPolicyAlertMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertPolicyAlertMethod | cdktn.IResolvable | undefined;
    set internalValue(value: AlertPolicyAlertMethod | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
}
export declare class AlertPolicyAlertMethodList extends cdktn.ComplexList {
    internalValue?: AlertPolicyAlertMethod[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertPolicyAlertMethodOutputReference;
}
export interface AlertPolicyCondition {
    /**
    * Duration over which the burn rate is evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#alerting_window AlertPolicy#alerting_window}
    */
    readonly alertingWindow?: string;
    /**
    * Indicates how long a given condition needs to be valid to mark the condition as true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#lasts_for AlertPolicy#lasts_for}
    */
    readonly lastsFor?: string;
    /**
    * One of `timeToBurnBudget` | `timeToBurnEntireBudget` | `averageBurnRate` | `burnedBudget` | `budgetDrop`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#measurement AlertPolicy#measurement}
    */
    readonly measurement: string;
    /**
    * A mathematical inequality operator. One of `lt` | `lte` | `gt` | `gte`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#op AlertPolicy#op}
    */
    readonly op?: string;
    /**
    * For `averageBurnRate`, it indicates how fast the error budget is burning. For `burnedBudget`, it tells how much error budget is already burned. For `budgetDrop`, it tells how much budget dropped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#value AlertPolicy#value}
    */
    readonly value?: number;
    /**
    * Used with `timeToBurnBudget` or `timeToBurnEntireBudget`, indicates when the budget would be exhausted. The expected value is a string in time duration string format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#value_string AlertPolicy#value_string}
    */
    readonly valueString?: string;
}
export declare function alertPolicyConditionToTerraform(struct?: AlertPolicyCondition | cdktn.IResolvable): any;
export declare function alertPolicyConditionToHclTerraform(struct?: AlertPolicyCondition | cdktn.IResolvable): any;
export declare class AlertPolicyConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertPolicyCondition | cdktn.IResolvable | undefined;
    set internalValue(value: AlertPolicyCondition | cdktn.IResolvable | undefined);
    private _alertingWindow?;
    get alertingWindow(): string;
    set alertingWindow(value: string);
    resetAlertingWindow(): void;
    get alertingWindowInput(): string | undefined;
    private _lastsFor?;
    get lastsFor(): string;
    set lastsFor(value: string);
    resetLastsFor(): void;
    get lastsForInput(): string | undefined;
    private _measurement?;
    get measurement(): string;
    set measurement(value: string);
    get measurementInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    resetOp(): void;
    get opInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
    private _valueString?;
    get valueString(): string;
    set valueString(value: string);
    resetValueString(): void;
    get valueStringInput(): string | undefined;
}
export declare class AlertPolicyConditionList extends cdktn.ComplexList {
    internalValue?: AlertPolicyCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertPolicyConditionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy nobl9_alert_policy}
*/
export declare class AlertPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_alert_policy";
    /**
    * Generates CDKTN code for importing a AlertPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertPolicy to import
    * @param importFromId The id of the existing AlertPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_policy nobl9_alert_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AlertPolicyConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _cooldown?;
    get cooldown(): string;
    set cooldown(value: string);
    resetCooldown(): void;
    get cooldownInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    get severityInput(): string | undefined;
    private _alertMethod;
    get alertMethod(): AlertPolicyAlertMethodList;
    putAlertMethod(value: AlertPolicyAlertMethod[] | cdktn.IResolvable): void;
    resetAlertMethod(): void;
    get alertMethodInput(): cdktn.IResolvable | AlertPolicyAlertMethod[] | undefined;
    private _condition;
    get condition(): AlertPolicyConditionList;
    putCondition(value: AlertPolicyCondition[] | cdktn.IResolvable): void;
    get conditionInput(): cdktn.IResolvable | AlertPolicyCondition[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
