import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The type of the Agent. Check [Supported Agent types | Nobl9 Documentation](https://docs.nobl9.com/Sources/)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#agent_type Agent#agent_type}
    */
    readonly agentType: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#description Agent#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#display_name Agent#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#id Agent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#name Agent#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#project Agent#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#release_channel Agent#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#source_of Agent#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * amazon_prometheus_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#amazon_prometheus_config Agent#amazon_prometheus_config}
    */
    readonly amazonPrometheusConfig?: AgentAmazonPrometheusConfig;
    /**
    * appdynamics_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#appdynamics_config Agent#appdynamics_config}
    */
    readonly appdynamicsConfig?: AgentAppdynamicsConfig;
    /**
    * azure_monitor_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#azure_monitor_config Agent#azure_monitor_config}
    */
    readonly azureMonitorConfig?: AgentAzureMonitorConfig;
    /**
    * bigquery_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#bigquery_config Agent#bigquery_config}
    */
    readonly bigqueryConfig?: AgentBigqueryConfig;
    /**
    * cloudwatch_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#cloudwatch_config Agent#cloudwatch_config}
    */
    readonly cloudwatchConfig?: AgentCloudwatchConfig;
    /**
    * datadog_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#datadog_config Agent#datadog_config}
    */
    readonly datadogConfig?: AgentDatadogConfig;
    /**
    * dynatrace_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#dynatrace_config Agent#dynatrace_config}
    */
    readonly dynatraceConfig?: AgentDynatraceConfig;
    /**
    * elasticsearch_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#elasticsearch_config Agent#elasticsearch_config}
    */
    readonly elasticsearchConfig?: AgentElasticsearchConfig;
    /**
    * gcm_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#gcm_config Agent#gcm_config}
    */
    readonly gcmConfig?: AgentGcmConfig;
    /**
    * grafana_loki_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#grafana_loki_config Agent#grafana_loki_config}
    */
    readonly grafanaLokiConfig?: AgentGrafanaLokiConfig;
    /**
    * graphite_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#graphite_config Agent#graphite_config}
    */
    readonly graphiteConfig?: AgentGraphiteConfig;
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#historical_data_retrieval Agent#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: AgentHistoricalDataRetrieval;
    /**
    * honeycomb_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#honeycomb_config Agent#honeycomb_config}
    */
    readonly honeycombConfig?: AgentHoneycombConfig;
    /**
    * influxdb_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#influxdb_config Agent#influxdb_config}
    */
    readonly influxdbConfig?: AgentInfluxdbConfig;
    /**
    * instana_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#instana_config Agent#instana_config}
    */
    readonly instanaConfig?: AgentInstanaConfig;
    /**
    * lightstep_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#lightstep_config Agent#lightstep_config}
    */
    readonly lightstepConfig?: AgentLightstepConfig;
    /**
    * logic_monitor_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#logic_monitor_config Agent#logic_monitor_config}
    */
    readonly logicMonitorConfig?: AgentLogicMonitorConfig;
    /**
    * newrelic_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#newrelic_config Agent#newrelic_config}
    */
    readonly newrelicConfig?: AgentNewrelicConfig;
    /**
    * opentsdb_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#opentsdb_config Agent#opentsdb_config}
    */
    readonly opentsdbConfig?: AgentOpentsdbConfig;
    /**
    * pingdom_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#pingdom_config Agent#pingdom_config}
    */
    readonly pingdomConfig?: AgentPingdomConfig;
    /**
    * prometheus_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#prometheus_config Agent#prometheus_config}
    */
    readonly prometheusConfig?: AgentPrometheusConfig;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#query_delay Agent#query_delay}
    */
    readonly queryDelay?: AgentQueryDelay;
    /**
    * redshift_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#redshift_config Agent#redshift_config}
    */
    readonly redshiftConfig?: AgentRedshiftConfig;
    /**
    * splunk_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#splunk_config Agent#splunk_config}
    */
    readonly splunkConfig?: AgentSplunkConfig;
    /**
    * splunk_observability_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#splunk_observability_config Agent#splunk_observability_config}
    */
    readonly splunkObservabilityConfig?: AgentSplunkObservabilityConfig;
    /**
    * sumologic_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#sumologic_config Agent#sumologic_config}
    */
    readonly sumologicConfig?: AgentSumologicConfig;
    /**
    * thousandeyes_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#thousandeyes_config Agent#thousandeyes_config}
    */
    readonly thousandeyesConfig?: AgentThousandeyesConfig;
}
export interface AgentAmazonPrometheusConfig {
    /**
    * AWS region e.g., eu-central-1
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#region Agent#region}
    */
    readonly region: string;
    /**
    * Base URL to Amazon Prometheus server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentAmazonPrometheusConfigToTerraform(struct?: AgentAmazonPrometheusConfigOutputReference | AgentAmazonPrometheusConfig): any;
export declare function agentAmazonPrometheusConfigToHclTerraform(struct?: AgentAmazonPrometheusConfigOutputReference | AgentAmazonPrometheusConfig): any;
export declare class AgentAmazonPrometheusConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentAmazonPrometheusConfig | undefined;
    set internalValue(value: AgentAmazonPrometheusConfig | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentAppdynamicsConfig {
    /**
    * Base URL to the AppDynamics Controller.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentAppdynamicsConfigToTerraform(struct?: AgentAppdynamicsConfigOutputReference | AgentAppdynamicsConfig): any;
export declare function agentAppdynamicsConfigToHclTerraform(struct?: AgentAppdynamicsConfigOutputReference | AgentAppdynamicsConfig): any;
export declare class AgentAppdynamicsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentAppdynamicsConfig | undefined;
    set internalValue(value: AgentAppdynamicsConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentAzureMonitorConfig {
    /**
    * Azure Tenant Id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#tenant_id Agent#tenant_id}
    */
    readonly tenantId: string;
}
export declare function agentAzureMonitorConfigToTerraform(struct?: AgentAzureMonitorConfigOutputReference | AgentAzureMonitorConfig): any;
export declare function agentAzureMonitorConfigToHclTerraform(struct?: AgentAzureMonitorConfigOutputReference | AgentAzureMonitorConfig): any;
export declare class AgentAzureMonitorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentAzureMonitorConfig | undefined;
    set internalValue(value: AgentAzureMonitorConfig | undefined);
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
}
export interface AgentBigqueryConfig {
}
export declare function agentBigqueryConfigToTerraform(struct?: AgentBigqueryConfigOutputReference | AgentBigqueryConfig): any;
export declare function agentBigqueryConfigToHclTerraform(struct?: AgentBigqueryConfigOutputReference | AgentBigqueryConfig): any;
export declare class AgentBigqueryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentBigqueryConfig | undefined;
    set internalValue(value: AgentBigqueryConfig | undefined);
}
export interface AgentCloudwatchConfig {
}
export declare function agentCloudwatchConfigToTerraform(struct?: AgentCloudwatchConfigOutputReference | AgentCloudwatchConfig): any;
export declare function agentCloudwatchConfigToHclTerraform(struct?: AgentCloudwatchConfigOutputReference | AgentCloudwatchConfig): any;
export declare class AgentCloudwatchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentCloudwatchConfig | undefined;
    set internalValue(value: AgentCloudwatchConfig | undefined);
}
export interface AgentDatadogConfig {
    /**
    * Datadog SaaS instance that corresponds to one of Datadog's available locations (see [Datadog docs](https://docs.datadoghq.com/getting_started/site/#access-the-datadog-site)for an up to date list):
    *   - `datadoghq.com` (formerly referred to as `com`)
    *   - `us3.datadoghq.com`
    *   - `us5.datadoghq.com`
    *   - `datadoghq.eu` (formerly referred to as `eu`)
    *   - `ddog-gov.com`
    *   - `ap1.datadoghq.com`
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#site Agent#site}
    */
    readonly site: string;
}
export declare function agentDatadogConfigToTerraform(struct?: AgentDatadogConfigOutputReference | AgentDatadogConfig): any;
export declare function agentDatadogConfigToHclTerraform(struct?: AgentDatadogConfigOutputReference | AgentDatadogConfig): any;
export declare class AgentDatadogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentDatadogConfig | undefined;
    set internalValue(value: AgentDatadogConfig | undefined);
    private _site?;
    get site(): string;
    set site(value: string);
    get siteInput(): string | undefined;
}
export interface AgentDynatraceConfig {
    /**
    * Dynatrace API URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentDynatraceConfigToTerraform(struct?: AgentDynatraceConfigOutputReference | AgentDynatraceConfig): any;
export declare function agentDynatraceConfigToHclTerraform(struct?: AgentDynatraceConfigOutputReference | AgentDynatraceConfig): any;
export declare class AgentDynatraceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentDynatraceConfig | undefined;
    set internalValue(value: AgentDynatraceConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentElasticsearchConfig {
    /**
    * API URL endpoint to the Elasticsearch's instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentElasticsearchConfigToTerraform(struct?: AgentElasticsearchConfigOutputReference | AgentElasticsearchConfig): any;
export declare function agentElasticsearchConfigToHclTerraform(struct?: AgentElasticsearchConfigOutputReference | AgentElasticsearchConfig): any;
export declare class AgentElasticsearchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentElasticsearchConfig | undefined;
    set internalValue(value: AgentElasticsearchConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentGcmConfig {
}
export declare function agentGcmConfigToTerraform(struct?: AgentGcmConfigOutputReference | AgentGcmConfig): any;
export declare function agentGcmConfigToHclTerraform(struct?: AgentGcmConfigOutputReference | AgentGcmConfig): any;
export declare class AgentGcmConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentGcmConfig | undefined;
    set internalValue(value: AgentGcmConfig | undefined);
}
export interface AgentGrafanaLokiConfig {
    /**
    * API URL endpoint to the Grafana Loki instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentGrafanaLokiConfigToTerraform(struct?: AgentGrafanaLokiConfigOutputReference | AgentGrafanaLokiConfig): any;
export declare function agentGrafanaLokiConfigToHclTerraform(struct?: AgentGrafanaLokiConfigOutputReference | AgentGrafanaLokiConfig): any;
export declare class AgentGrafanaLokiConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentGrafanaLokiConfig | undefined;
    set internalValue(value: AgentGrafanaLokiConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentGraphiteConfig {
    /**
    * API URL endpoint to the Graphite's instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentGraphiteConfigToTerraform(struct?: AgentGraphiteConfigOutputReference | AgentGraphiteConfig): any;
export declare function agentGraphiteConfigToHclTerraform(struct?: AgentGraphiteConfigOutputReference | AgentGraphiteConfig): any;
export declare class AgentGraphiteConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentGraphiteConfig | undefined;
    set internalValue(value: AgentGraphiteConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#unit Agent#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#value Agent#value}
    */
    readonly value: number;
}
export declare function agentHistoricalDataRetrievalDefaultDurationToTerraform(struct?: AgentHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function agentHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: AgentHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class AgentHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgentHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: AgentHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class AgentHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: AgentHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgentHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface AgentHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#unit Agent#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#value Agent#value}
    */
    readonly value: number;
}
export declare function agentHistoricalDataRetrievalMaxDurationToTerraform(struct?: AgentHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function agentHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: AgentHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class AgentHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgentHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: AgentHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class AgentHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: AgentHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgentHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface AgentHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#default_duration Agent#default_duration}
    */
    readonly defaultDuration: AgentHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#max_duration Agent#max_duration}
    */
    readonly maxDuration: AgentHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function agentHistoricalDataRetrievalToTerraform(struct?: AgentHistoricalDataRetrievalOutputReference | AgentHistoricalDataRetrieval): any;
export declare function agentHistoricalDataRetrievalToHclTerraform(struct?: AgentHistoricalDataRetrievalOutputReference | AgentHistoricalDataRetrieval): any;
export declare class AgentHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentHistoricalDataRetrieval | undefined;
    set internalValue(value: AgentHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): AgentHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: AgentHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | AgentHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): AgentHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: AgentHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | AgentHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface AgentHoneycombConfig {
}
export declare function agentHoneycombConfigToTerraform(struct?: AgentHoneycombConfigOutputReference | AgentHoneycombConfig): any;
export declare function agentHoneycombConfigToHclTerraform(struct?: AgentHoneycombConfigOutputReference | AgentHoneycombConfig): any;
export declare class AgentHoneycombConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentHoneycombConfig | undefined;
    set internalValue(value: AgentHoneycombConfig | undefined);
}
export interface AgentInfluxdbConfig {
    /**
    * API URL endpoint to the InfluxDB's instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentInfluxdbConfigToTerraform(struct?: AgentInfluxdbConfigOutputReference | AgentInfluxdbConfig): any;
export declare function agentInfluxdbConfigToHclTerraform(struct?: AgentInfluxdbConfigOutputReference | AgentInfluxdbConfig): any;
export declare class AgentInfluxdbConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentInfluxdbConfig | undefined;
    set internalValue(value: AgentInfluxdbConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentInstanaConfig {
    /**
    * API URL endpoint to the InfluxDB's instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentInstanaConfigToTerraform(struct?: AgentInstanaConfigOutputReference | AgentInstanaConfig): any;
export declare function agentInstanaConfigToHclTerraform(struct?: AgentInstanaConfigOutputReference | AgentInstanaConfig): any;
export declare class AgentInstanaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentInstanaConfig | undefined;
    set internalValue(value: AgentInstanaConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentLightstepConfig {
    /**
    * Organization name registered in Lightstep.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#organization Agent#organization}
    */
    readonly organization: string;
    /**
    * Name of the Lightstep project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#project Agent#project}
    */
    readonly project: string;
    /**
    * Lightstep API URL. Nobl9 will use https://api.lightstep.com if empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url?: string;
}
export declare function agentLightstepConfigToTerraform(struct?: AgentLightstepConfigOutputReference | AgentLightstepConfig): any;
export declare function agentLightstepConfigToHclTerraform(struct?: AgentLightstepConfigOutputReference | AgentLightstepConfig): any;
export declare class AgentLightstepConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentLightstepConfig | undefined;
    set internalValue(value: AgentLightstepConfig | undefined);
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface AgentLogicMonitorConfig {
    /**
    * LogicMonitor Account name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#account Agent#account}
    */
    readonly account: string;
}
export declare function agentLogicMonitorConfigToTerraform(struct?: AgentLogicMonitorConfigOutputReference | AgentLogicMonitorConfig): any;
export declare function agentLogicMonitorConfigToHclTerraform(struct?: AgentLogicMonitorConfigOutputReference | AgentLogicMonitorConfig): any;
export declare class AgentLogicMonitorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentLogicMonitorConfig | undefined;
    set internalValue(value: AgentLogicMonitorConfig | undefined);
    private _account?;
    get account(): string;
    set account(value: string);
    get accountInput(): string | undefined;
}
export interface AgentNewrelicConfig {
    /**
    * ID number assigned to the New Relic user account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#account_id Agent#account_id}
    */
    readonly accountId: string;
}
export declare function agentNewrelicConfigToTerraform(struct?: AgentNewrelicConfigOutputReference | AgentNewrelicConfig): any;
export declare function agentNewrelicConfigToHclTerraform(struct?: AgentNewrelicConfigOutputReference | AgentNewrelicConfig): any;
export declare class AgentNewrelicConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentNewrelicConfig | undefined;
    set internalValue(value: AgentNewrelicConfig | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
}
export interface AgentOpentsdbConfig {
    /**
    * OpenTSDB cluster URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentOpentsdbConfigToTerraform(struct?: AgentOpentsdbConfigOutputReference | AgentOpentsdbConfig): any;
export declare function agentOpentsdbConfigToHclTerraform(struct?: AgentOpentsdbConfigOutputReference | AgentOpentsdbConfig): any;
export declare class AgentOpentsdbConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentOpentsdbConfig | undefined;
    set internalValue(value: AgentOpentsdbConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentPingdomConfig {
}
export declare function agentPingdomConfigToTerraform(struct?: AgentPingdomConfigOutputReference | AgentPingdomConfig): any;
export declare function agentPingdomConfigToHclTerraform(struct?: AgentPingdomConfigOutputReference | AgentPingdomConfig): any;
export declare class AgentPingdomConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentPingdomConfig | undefined;
    set internalValue(value: AgentPingdomConfig | undefined);
}
export interface AgentPrometheusConfig {
    /**
    * Base URL to Prometheus server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentPrometheusConfigToTerraform(struct?: AgentPrometheusConfigOutputReference | AgentPrometheusConfig): any;
export declare function agentPrometheusConfigToHclTerraform(struct?: AgentPrometheusConfigOutputReference | AgentPrometheusConfig): any;
export declare class AgentPrometheusConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentPrometheusConfig | undefined;
    set internalValue(value: AgentPrometheusConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#unit Agent#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#value Agent#value}
    */
    readonly value: number;
}
export declare function agentQueryDelayToTerraform(struct?: AgentQueryDelayOutputReference | AgentQueryDelay): any;
export declare function agentQueryDelayToHclTerraform(struct?: AgentQueryDelayOutputReference | AgentQueryDelay): any;
export declare class AgentQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentQueryDelay | undefined;
    set internalValue(value: AgentQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AgentRedshiftConfig {
}
export declare function agentRedshiftConfigToTerraform(struct?: AgentRedshiftConfigOutputReference | AgentRedshiftConfig): any;
export declare function agentRedshiftConfigToHclTerraform(struct?: AgentRedshiftConfigOutputReference | AgentRedshiftConfig): any;
export declare class AgentRedshiftConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentRedshiftConfig | undefined;
    set internalValue(value: AgentRedshiftConfig | undefined);
}
export interface AgentSplunkConfig {
    /**
    * Base API URL to the Splunk Search app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentSplunkConfigToTerraform(struct?: AgentSplunkConfigOutputReference | AgentSplunkConfig): any;
export declare function agentSplunkConfigToHclTerraform(struct?: AgentSplunkConfigOutputReference | AgentSplunkConfig): any;
export declare class AgentSplunkConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentSplunkConfig | undefined;
    set internalValue(value: AgentSplunkConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentSplunkObservabilityConfig {
    /**
    * SplunkObservability Realm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#realm Agent#realm}
    */
    readonly realm: string;
}
export declare function agentSplunkObservabilityConfigToTerraform(struct?: AgentSplunkObservabilityConfigOutputReference | AgentSplunkObservabilityConfig): any;
export declare function agentSplunkObservabilityConfigToHclTerraform(struct?: AgentSplunkObservabilityConfigOutputReference | AgentSplunkObservabilityConfig): any;
export declare class AgentSplunkObservabilityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentSplunkObservabilityConfig | undefined;
    set internalValue(value: AgentSplunkObservabilityConfig | undefined);
    private _realm?;
    get realm(): string;
    set realm(value: string);
    get realmInput(): string | undefined;
}
export interface AgentSumologicConfig {
    /**
    * Sumo Logic API URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#url Agent#url}
    */
    readonly url: string;
}
export declare function agentSumologicConfigToTerraform(struct?: AgentSumologicConfigOutputReference | AgentSumologicConfig): any;
export declare function agentSumologicConfigToHclTerraform(struct?: AgentSumologicConfigOutputReference | AgentSumologicConfig): any;
export declare class AgentSumologicConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentSumologicConfig | undefined;
    set internalValue(value: AgentSumologicConfig | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AgentThousandeyesConfig {
}
export declare function agentThousandeyesConfigToTerraform(struct?: AgentThousandeyesConfigOutputReference | AgentThousandeyesConfig): any;
export declare function agentThousandeyesConfigToHclTerraform(struct?: AgentThousandeyesConfigOutputReference | AgentThousandeyesConfig): any;
export declare class AgentThousandeyesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentThousandeyesConfig | undefined;
    set internalValue(value: AgentThousandeyesConfig | undefined);
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent nobl9_agent}
*/
export declare class Agent extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_agent";
    /**
    * Generates CDKTN code for importing a Agent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Agent to import
    * @param importFromId The id of the existing Agent that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Agent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/agent nobl9_agent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgentConfig
    */
    constructor(scope: Construct, id: string, config: AgentConfig);
    private _agentType?;
    get agentType(): string;
    set agentType(value: string);
    get agentTypeInput(): string | undefined;
    get clientId(): string;
    get clientSecret(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    private _status;
    get status(): cdktn.StringMap;
    private _amazonPrometheusConfig;
    get amazonPrometheusConfig(): AgentAmazonPrometheusConfigOutputReference;
    putAmazonPrometheusConfig(value: AgentAmazonPrometheusConfig): void;
    resetAmazonPrometheusConfig(): void;
    get amazonPrometheusConfigInput(): AgentAmazonPrometheusConfig | undefined;
    private _appdynamicsConfig;
    get appdynamicsConfig(): AgentAppdynamicsConfigOutputReference;
    putAppdynamicsConfig(value: AgentAppdynamicsConfig): void;
    resetAppdynamicsConfig(): void;
    get appdynamicsConfigInput(): AgentAppdynamicsConfig | undefined;
    private _azureMonitorConfig;
    get azureMonitorConfig(): AgentAzureMonitorConfigOutputReference;
    putAzureMonitorConfig(value: AgentAzureMonitorConfig): void;
    resetAzureMonitorConfig(): void;
    get azureMonitorConfigInput(): AgentAzureMonitorConfig | undefined;
    private _bigqueryConfig;
    get bigqueryConfig(): AgentBigqueryConfigOutputReference;
    putBigqueryConfig(value: AgentBigqueryConfig): void;
    resetBigqueryConfig(): void;
    get bigqueryConfigInput(): AgentBigqueryConfig | undefined;
    private _cloudwatchConfig;
    get cloudwatchConfig(): AgentCloudwatchConfigOutputReference;
    putCloudwatchConfig(value: AgentCloudwatchConfig): void;
    resetCloudwatchConfig(): void;
    get cloudwatchConfigInput(): AgentCloudwatchConfig | undefined;
    private _datadogConfig;
    get datadogConfig(): AgentDatadogConfigOutputReference;
    putDatadogConfig(value: AgentDatadogConfig): void;
    resetDatadogConfig(): void;
    get datadogConfigInput(): AgentDatadogConfig | undefined;
    private _dynatraceConfig;
    get dynatraceConfig(): AgentDynatraceConfigOutputReference;
    putDynatraceConfig(value: AgentDynatraceConfig): void;
    resetDynatraceConfig(): void;
    get dynatraceConfigInput(): AgentDynatraceConfig | undefined;
    private _elasticsearchConfig;
    get elasticsearchConfig(): AgentElasticsearchConfigOutputReference;
    putElasticsearchConfig(value: AgentElasticsearchConfig): void;
    resetElasticsearchConfig(): void;
    get elasticsearchConfigInput(): AgentElasticsearchConfig | undefined;
    private _gcmConfig;
    get gcmConfig(): AgentGcmConfigOutputReference;
    putGcmConfig(value: AgentGcmConfig): void;
    resetGcmConfig(): void;
    get gcmConfigInput(): AgentGcmConfig | undefined;
    private _grafanaLokiConfig;
    get grafanaLokiConfig(): AgentGrafanaLokiConfigOutputReference;
    putGrafanaLokiConfig(value: AgentGrafanaLokiConfig): void;
    resetGrafanaLokiConfig(): void;
    get grafanaLokiConfigInput(): AgentGrafanaLokiConfig | undefined;
    private _graphiteConfig;
    get graphiteConfig(): AgentGraphiteConfigOutputReference;
    putGraphiteConfig(value: AgentGraphiteConfig): void;
    resetGraphiteConfig(): void;
    get graphiteConfigInput(): AgentGraphiteConfig | undefined;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): AgentHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: AgentHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): AgentHistoricalDataRetrieval | undefined;
    private _honeycombConfig;
    get honeycombConfig(): AgentHoneycombConfigOutputReference;
    putHoneycombConfig(value: AgentHoneycombConfig): void;
    resetHoneycombConfig(): void;
    get honeycombConfigInput(): AgentHoneycombConfig | undefined;
    private _influxdbConfig;
    get influxdbConfig(): AgentInfluxdbConfigOutputReference;
    putInfluxdbConfig(value: AgentInfluxdbConfig): void;
    resetInfluxdbConfig(): void;
    get influxdbConfigInput(): AgentInfluxdbConfig | undefined;
    private _instanaConfig;
    get instanaConfig(): AgentInstanaConfigOutputReference;
    putInstanaConfig(value: AgentInstanaConfig): void;
    resetInstanaConfig(): void;
    get instanaConfigInput(): AgentInstanaConfig | undefined;
    private _lightstepConfig;
    get lightstepConfig(): AgentLightstepConfigOutputReference;
    putLightstepConfig(value: AgentLightstepConfig): void;
    resetLightstepConfig(): void;
    get lightstepConfigInput(): AgentLightstepConfig | undefined;
    private _logicMonitorConfig;
    get logicMonitorConfig(): AgentLogicMonitorConfigOutputReference;
    putLogicMonitorConfig(value: AgentLogicMonitorConfig): void;
    resetLogicMonitorConfig(): void;
    get logicMonitorConfigInput(): AgentLogicMonitorConfig | undefined;
    private _newrelicConfig;
    get newrelicConfig(): AgentNewrelicConfigOutputReference;
    putNewrelicConfig(value: AgentNewrelicConfig): void;
    resetNewrelicConfig(): void;
    get newrelicConfigInput(): AgentNewrelicConfig | undefined;
    private _opentsdbConfig;
    get opentsdbConfig(): AgentOpentsdbConfigOutputReference;
    putOpentsdbConfig(value: AgentOpentsdbConfig): void;
    resetOpentsdbConfig(): void;
    get opentsdbConfigInput(): AgentOpentsdbConfig | undefined;
    private _pingdomConfig;
    get pingdomConfig(): AgentPingdomConfigOutputReference;
    putPingdomConfig(value: AgentPingdomConfig): void;
    resetPingdomConfig(): void;
    get pingdomConfigInput(): AgentPingdomConfig | undefined;
    private _prometheusConfig;
    get prometheusConfig(): AgentPrometheusConfigOutputReference;
    putPrometheusConfig(value: AgentPrometheusConfig): void;
    resetPrometheusConfig(): void;
    get prometheusConfigInput(): AgentPrometheusConfig | undefined;
    private _queryDelay;
    get queryDelay(): AgentQueryDelayOutputReference;
    putQueryDelay(value: AgentQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): AgentQueryDelay | undefined;
    private _redshiftConfig;
    get redshiftConfig(): AgentRedshiftConfigOutputReference;
    putRedshiftConfig(value: AgentRedshiftConfig): void;
    resetRedshiftConfig(): void;
    get redshiftConfigInput(): AgentRedshiftConfig | undefined;
    private _splunkConfig;
    get splunkConfig(): AgentSplunkConfigOutputReference;
    putSplunkConfig(value: AgentSplunkConfig): void;
    resetSplunkConfig(): void;
    get splunkConfigInput(): AgentSplunkConfig | undefined;
    private _splunkObservabilityConfig;
    get splunkObservabilityConfig(): AgentSplunkObservabilityConfigOutputReference;
    putSplunkObservabilityConfig(value: AgentSplunkObservabilityConfig): void;
    resetSplunkObservabilityConfig(): void;
    get splunkObservabilityConfigInput(): AgentSplunkObservabilityConfig | undefined;
    private _sumologicConfig;
    get sumologicConfig(): AgentSumologicConfigOutputReference;
    putSumologicConfig(value: AgentSumologicConfig): void;
    resetSumologicConfig(): void;
    get sumologicConfigInput(): AgentSumologicConfig | undefined;
    private _thousandeyesConfig;
    get thousandeyesConfig(): AgentThousandeyesConfigOutputReference;
    putThousandeyesConfig(value: AgentThousandeyesConfig): void;
    resetThousandeyesConfig(): void;
    get thousandeyesConfigInput(): AgentThousandeyesConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
