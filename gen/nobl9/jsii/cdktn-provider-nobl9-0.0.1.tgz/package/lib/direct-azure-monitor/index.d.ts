import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectAzureMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * [required] | Azure Application (client) ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#client_id DirectAzureMonitor#client_id}
    */
    readonly clientId?: string;
    /**
    * [required] | Azure Application (client) Secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#client_secret DirectAzureMonitor#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#description DirectAzureMonitor#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#display_name DirectAzureMonitor#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#id DirectAzureMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#log_collection_enabled DirectAzureMonitor#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#name DirectAzureMonitor#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#project DirectAzureMonitor#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#release_channel DirectAzureMonitor#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#source_of DirectAzureMonitor#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * [required] | Azure Tenant ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#tenant_id DirectAzureMonitor#tenant_id}
    */
    readonly tenantId: string;
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#historical_data_retrieval DirectAzureMonitor#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: DirectAzureMonitorHistoricalDataRetrieval;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#query_delay DirectAzureMonitor#query_delay}
    */
    readonly queryDelay?: DirectAzureMonitorQueryDelay;
}
export interface DirectAzureMonitorHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#unit DirectAzureMonitor#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#value DirectAzureMonitor#value}
    */
    readonly value: number;
}
export declare function directAzureMonitorHistoricalDataRetrievalDefaultDurationToTerraform(struct?: DirectAzureMonitorHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function directAzureMonitorHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: DirectAzureMonitorHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class DirectAzureMonitorHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectAzureMonitorHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectAzureMonitorHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectAzureMonitorHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: DirectAzureMonitorHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectAzureMonitorHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface DirectAzureMonitorHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#unit DirectAzureMonitor#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#value DirectAzureMonitor#value}
    */
    readonly value: number;
}
export declare function directAzureMonitorHistoricalDataRetrievalMaxDurationToTerraform(struct?: DirectAzureMonitorHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function directAzureMonitorHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: DirectAzureMonitorHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class DirectAzureMonitorHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectAzureMonitorHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectAzureMonitorHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectAzureMonitorHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: DirectAzureMonitorHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectAzureMonitorHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface DirectAzureMonitorHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#default_duration DirectAzureMonitor#default_duration}
    */
    readonly defaultDuration: DirectAzureMonitorHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#max_duration DirectAzureMonitor#max_duration}
    */
    readonly maxDuration: DirectAzureMonitorHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function directAzureMonitorHistoricalDataRetrievalToTerraform(struct?: DirectAzureMonitorHistoricalDataRetrievalOutputReference | DirectAzureMonitorHistoricalDataRetrieval): any;
export declare function directAzureMonitorHistoricalDataRetrievalToHclTerraform(struct?: DirectAzureMonitorHistoricalDataRetrievalOutputReference | DirectAzureMonitorHistoricalDataRetrieval): any;
export declare class DirectAzureMonitorHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectAzureMonitorHistoricalDataRetrieval | undefined;
    set internalValue(value: DirectAzureMonitorHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): DirectAzureMonitorHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: DirectAzureMonitorHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | DirectAzureMonitorHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): DirectAzureMonitorHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: DirectAzureMonitorHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | DirectAzureMonitorHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface DirectAzureMonitorQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#unit DirectAzureMonitor#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#value DirectAzureMonitor#value}
    */
    readonly value: number;
}
export declare function directAzureMonitorQueryDelayToTerraform(struct?: DirectAzureMonitorQueryDelayOutputReference | DirectAzureMonitorQueryDelay): any;
export declare function directAzureMonitorQueryDelayToHclTerraform(struct?: DirectAzureMonitorQueryDelayOutputReference | DirectAzureMonitorQueryDelay): any;
export declare class DirectAzureMonitorQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectAzureMonitorQueryDelay | undefined;
    set internalValue(value: DirectAzureMonitorQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor nobl9_direct_azure_monitor}
*/
export declare class DirectAzureMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_azure_monitor";
    /**
    * Generates CDKTN code for importing a DirectAzureMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectAzureMonitor to import
    * @param importFromId The id of the existing DirectAzureMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectAzureMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_azure_monitor nobl9_direct_azure_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectAzureMonitorConfig
    */
    constructor(scope: Construct, id: string, config: DirectAzureMonitorConfig);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): DirectAzureMonitorHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: DirectAzureMonitorHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): DirectAzureMonitorHistoricalDataRetrieval | undefined;
    private _queryDelay;
    get queryDelay(): DirectAzureMonitorQueryDelayOutputReference;
    putQueryDelay(value: DirectAzureMonitorQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectAzureMonitorQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
