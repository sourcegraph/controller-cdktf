import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RoleBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/role_binding#display_name RoleBinding#display_name}
    */
    readonly displayName?: string;
    /**
    * Group name that can be retrieved from the Nobl9 UI (**Settings** > **Access Controls** > **Groups**) or using sloctl `get usergroups` command.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/role_binding#group_ref RoleBinding#group_ref}
    */
    readonly groupRef?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/role_binding#id RoleBinding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Automatically generated, unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/role_binding#name RoleBinding#name}
    */
    readonly name?: string;
    /**
    * Project name, the project in which we want the user or group to assume the specified role. When `project_ref` is empty, `role_ref` must contain an Organization Role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/role_binding#project_ref RoleBinding#project_ref}
    */
    readonly projectRef?: string;
    /**
    * Role name; the role that you want the user or group to assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/role_binding#role_ref RoleBinding#role_ref}
    */
    readonly roleRef: string;
    /**
    * Okta User ID that can be retrieved from the Nobl9 UI (**Settings** > **Access Controls** > **Users**).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/role_binding#user RoleBinding#user}
    */
    readonly user?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/role_binding nobl9_role_binding}
*/
export declare class RoleBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_role_binding";
    /**
    * Generates CDKTN code for importing a RoleBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RoleBinding to import
    * @param importFromId The id of the existing RoleBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/role_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RoleBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/role_binding nobl9_role_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RoleBindingConfig
    */
    constructor(scope: Construct, id: string, config: RoleBindingConfig);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _groupRef?;
    get groupRef(): string;
    set groupRef(value: string);
    resetGroupRef(): void;
    get groupRefInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectRef?;
    get projectRef(): string;
    set projectRef(value: string);
    resetProjectRef(): void;
    get projectRefInput(): string | undefined;
    private _roleRef?;
    get roleRef(): string;
    set roleRef(value: string);
    get roleRefInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
