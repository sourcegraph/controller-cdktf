import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectAppdynamicsConfig extends cdktn.TerraformMetaArguments {
    /**
    * AppDynamics Account Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#account_name DirectAppdynamics#account_name}
    */
    readonly accountName: string;
    /**
    * AppDynamics Client Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#client_name DirectAppdynamics#client_name}
    */
    readonly clientName: string;
    /**
    * [required] | AppDynamics Client Secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#client_secret DirectAppdynamics#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#description DirectAppdynamics#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#display_name DirectAppdynamics#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#id DirectAppdynamics#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#log_collection_enabled DirectAppdynamics#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#name DirectAppdynamics#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#project DirectAppdynamics#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#release_channel DirectAppdynamics#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#source_of DirectAppdynamics#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * Base URL to the AppDynamics Controller.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#url DirectAppdynamics#url}
    */
    readonly url: string;
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#historical_data_retrieval DirectAppdynamics#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: DirectAppdynamicsHistoricalDataRetrieval;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#query_delay DirectAppdynamics#query_delay}
    */
    readonly queryDelay?: DirectAppdynamicsQueryDelay;
}
export interface DirectAppdynamicsHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#unit DirectAppdynamics#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#value DirectAppdynamics#value}
    */
    readonly value: number;
}
export declare function directAppdynamicsHistoricalDataRetrievalDefaultDurationToTerraform(struct?: DirectAppdynamicsHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function directAppdynamicsHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: DirectAppdynamicsHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class DirectAppdynamicsHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectAppdynamicsHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectAppdynamicsHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectAppdynamicsHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: DirectAppdynamicsHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectAppdynamicsHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface DirectAppdynamicsHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#unit DirectAppdynamics#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#value DirectAppdynamics#value}
    */
    readonly value: number;
}
export declare function directAppdynamicsHistoricalDataRetrievalMaxDurationToTerraform(struct?: DirectAppdynamicsHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function directAppdynamicsHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: DirectAppdynamicsHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class DirectAppdynamicsHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectAppdynamicsHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectAppdynamicsHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectAppdynamicsHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: DirectAppdynamicsHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectAppdynamicsHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface DirectAppdynamicsHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#default_duration DirectAppdynamics#default_duration}
    */
    readonly defaultDuration: DirectAppdynamicsHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#max_duration DirectAppdynamics#max_duration}
    */
    readonly maxDuration: DirectAppdynamicsHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function directAppdynamicsHistoricalDataRetrievalToTerraform(struct?: DirectAppdynamicsHistoricalDataRetrievalOutputReference | DirectAppdynamicsHistoricalDataRetrieval): any;
export declare function directAppdynamicsHistoricalDataRetrievalToHclTerraform(struct?: DirectAppdynamicsHistoricalDataRetrievalOutputReference | DirectAppdynamicsHistoricalDataRetrieval): any;
export declare class DirectAppdynamicsHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectAppdynamicsHistoricalDataRetrieval | undefined;
    set internalValue(value: DirectAppdynamicsHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): DirectAppdynamicsHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: DirectAppdynamicsHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | DirectAppdynamicsHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): DirectAppdynamicsHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: DirectAppdynamicsHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | DirectAppdynamicsHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface DirectAppdynamicsQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#unit DirectAppdynamics#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#value DirectAppdynamics#value}
    */
    readonly value: number;
}
export declare function directAppdynamicsQueryDelayToTerraform(struct?: DirectAppdynamicsQueryDelayOutputReference | DirectAppdynamicsQueryDelay): any;
export declare function directAppdynamicsQueryDelayToHclTerraform(struct?: DirectAppdynamicsQueryDelayOutputReference | DirectAppdynamicsQueryDelay): any;
export declare class DirectAppdynamicsQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectAppdynamicsQueryDelay | undefined;
    set internalValue(value: DirectAppdynamicsQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics nobl9_direct_appdynamics}
*/
export declare class DirectAppdynamics extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_appdynamics";
    /**
    * Generates CDKTN code for importing a DirectAppdynamics resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectAppdynamics to import
    * @param importFromId The id of the existing DirectAppdynamics that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectAppdynamics to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_appdynamics nobl9_direct_appdynamics} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectAppdynamicsConfig
    */
    constructor(scope: Construct, id: string, config: DirectAppdynamicsConfig);
    private _accountName?;
    get accountName(): string;
    set accountName(value: string);
    get accountNameInput(): string | undefined;
    get clientId(): string;
    private _clientName?;
    get clientName(): string;
    set clientName(value: string);
    get clientNameInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): DirectAppdynamicsHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: DirectAppdynamicsHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): DirectAppdynamicsHistoricalDataRetrieval | undefined;
    private _queryDelay;
    get queryDelay(): DirectAppdynamicsQueryDelayOutputReference;
    putQueryDelay(value: DirectAppdynamicsQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectAppdynamicsQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
