import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectDatadogConfig extends cdktn.TerraformMetaArguments {
    /**
    * [required] | Datadog API Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#api_key DirectDatadog#api_key}
    */
    readonly apiKey?: string;
    /**
    * [required] | Datadog Application Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#application_key DirectDatadog#application_key}
    */
    readonly applicationKey?: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#description DirectDatadog#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#display_name DirectDatadog#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#id DirectDatadog#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#log_collection_enabled DirectDatadog#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#name DirectDatadog#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#project DirectDatadog#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#release_channel DirectDatadog#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * Datadog SaaS instance that corresponds to one of Datadog's available locations (see [Datadog docs](https://docs.datadoghq.com/getting_started/site/#access-the-datadog-site)for an up to date list):
    *   - `datadoghq.com` (formerly referred to as `com`)
    *   - `us3.datadoghq.com`
    *   - `us5.datadoghq.com`
    *   - `datadoghq.eu` (formerly referred to as `eu`)
    *   - `ddog-gov.com`
    *   - `ap1.datadoghq.com`
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#site DirectDatadog#site}
    */
    readonly site: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#source_of DirectDatadog#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#historical_data_retrieval DirectDatadog#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: DirectDatadogHistoricalDataRetrieval;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#query_delay DirectDatadog#query_delay}
    */
    readonly queryDelay?: DirectDatadogQueryDelay;
}
export interface DirectDatadogHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#unit DirectDatadog#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#value DirectDatadog#value}
    */
    readonly value: number;
}
export declare function directDatadogHistoricalDataRetrievalDefaultDurationToTerraform(struct?: DirectDatadogHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function directDatadogHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: DirectDatadogHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class DirectDatadogHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectDatadogHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectDatadogHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectDatadogHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: DirectDatadogHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectDatadogHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface DirectDatadogHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#unit DirectDatadog#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#value DirectDatadog#value}
    */
    readonly value: number;
}
export declare function directDatadogHistoricalDataRetrievalMaxDurationToTerraform(struct?: DirectDatadogHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function directDatadogHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: DirectDatadogHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class DirectDatadogHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectDatadogHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectDatadogHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectDatadogHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: DirectDatadogHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectDatadogHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface DirectDatadogHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#default_duration DirectDatadog#default_duration}
    */
    readonly defaultDuration: DirectDatadogHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#max_duration DirectDatadog#max_duration}
    */
    readonly maxDuration: DirectDatadogHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function directDatadogHistoricalDataRetrievalToTerraform(struct?: DirectDatadogHistoricalDataRetrievalOutputReference | DirectDatadogHistoricalDataRetrieval): any;
export declare function directDatadogHistoricalDataRetrievalToHclTerraform(struct?: DirectDatadogHistoricalDataRetrievalOutputReference | DirectDatadogHistoricalDataRetrieval): any;
export declare class DirectDatadogHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectDatadogHistoricalDataRetrieval | undefined;
    set internalValue(value: DirectDatadogHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): DirectDatadogHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: DirectDatadogHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | DirectDatadogHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): DirectDatadogHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: DirectDatadogHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | DirectDatadogHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface DirectDatadogQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#unit DirectDatadog#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#value DirectDatadog#value}
    */
    readonly value: number;
}
export declare function directDatadogQueryDelayToTerraform(struct?: DirectDatadogQueryDelayOutputReference | DirectDatadogQueryDelay): any;
export declare function directDatadogQueryDelayToHclTerraform(struct?: DirectDatadogQueryDelayOutputReference | DirectDatadogQueryDelay): any;
export declare class DirectDatadogQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectDatadogQueryDelay | undefined;
    set internalValue(value: DirectDatadogQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog nobl9_direct_datadog}
*/
export declare class DirectDatadog extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_datadog";
    /**
    * Generates CDKTN code for importing a DirectDatadog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectDatadog to import
    * @param importFromId The id of the existing DirectDatadog that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectDatadog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_datadog nobl9_direct_datadog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectDatadogConfig
    */
    constructor(scope: Construct, id: string, config: DirectDatadogConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _applicationKey?;
    get applicationKey(): string;
    set applicationKey(value: string);
    resetApplicationKey(): void;
    get applicationKeyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _site?;
    get site(): string;
    set site(value: string);
    get siteInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): DirectDatadogHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: DirectDatadogHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): DirectDatadogHistoricalDataRetrieval | undefined;
    private _queryDelay;
    get queryDelay(): DirectDatadogQueryDelayOutputReference;
    putQueryDelay(value: DirectDatadogQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectDatadogQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
