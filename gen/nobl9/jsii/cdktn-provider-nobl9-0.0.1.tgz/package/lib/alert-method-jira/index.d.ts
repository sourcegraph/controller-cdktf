import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertMethodJiraConfig extends cdktn.TerraformMetaArguments {
    /**
    * [API Token](https://support.atlassian.com/atlassian-account/docs/manage-api-tokens-for-your-atlassian-account/) with access rights to the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira#apitoken AlertMethodJira#apitoken}
    */
    readonly apitoken?: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira#description AlertMethodJira#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira#display_name AlertMethodJira#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira#id AlertMethodJira#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira#name AlertMethodJira#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira#project AlertMethodJira#project}
    */
    readonly project: string;
    /**
    * The code of the Jira project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira#project_key AlertMethodJira#project_key}
    */
    readonly projectKey: string;
    /**
    * Jira instance URL. The `https://` prefix is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira#url AlertMethodJira#url}
    */
    readonly url: string;
    /**
    * Jira username for the owner of the API Token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira#username AlertMethodJira#username}
    */
    readonly username: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira nobl9_alert_method_jira}
*/
export declare class AlertMethodJira extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_alert_method_jira";
    /**
    * Generates CDKTN code for importing a AlertMethodJira resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertMethodJira to import
    * @param importFromId The id of the existing AlertMethodJira that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertMethodJira to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_jira nobl9_alert_method_jira} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertMethodJiraConfig
    */
    constructor(scope: Construct, id: string, config: AlertMethodJiraConfig);
    private _apitoken?;
    get apitoken(): string;
    set apitoken(value: string);
    resetApitoken(): void;
    get apitokenInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _projectKey?;
    get projectKey(): string;
    set projectKey(value: string);
    get projectKeyInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
