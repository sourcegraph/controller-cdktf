import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ReportSystemHealthReviewConfig extends cdktn.TerraformMetaArguments {
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#display_name ReportSystemHealthReview#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#id ReportSystemHealthReview#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#name ReportSystemHealthReview#name}
    */
    readonly name: string;
    /**
    * Grouping methods of report table rows [project/service]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#row_group_by ReportSystemHealthReview#row_group_by}
    */
    readonly rowGroupBy: string;
    /**
    * Is report shared for all users with access to included projects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#shared ReportSystemHealthReview#shared}
    */
    readonly shared?: boolean | cdktn.IResolvable;
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#column ReportSystemHealthReview#column}
    */
    readonly column: ReportSystemHealthReviewColumn[] | cdktn.IResolvable;
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#filters ReportSystemHealthReview#filters}
    */
    readonly filters?: ReportSystemHealthReviewFilters;
    /**
    * thresholds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#thresholds ReportSystemHealthReview#thresholds}
    */
    readonly thresholds: ReportSystemHealthReviewThresholds;
    /**
    * time_frame block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#time_frame ReportSystemHealthReview#time_frame}
    */
    readonly timeFrame: ReportSystemHealthReviewTimeFrame;
}
export interface ReportSystemHealthReviewColumnLabel {
    /**
    * A key for the label, unique within the associated resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#key ReportSystemHealthReview#key}
    */
    readonly key: string;
    /**
    * A list of unique values for a single key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#values ReportSystemHealthReview#values}
    */
    readonly values: string[];
}
export declare function reportSystemHealthReviewColumnLabelToTerraform(struct?: ReportSystemHealthReviewColumnLabel | cdktn.IResolvable): any;
export declare function reportSystemHealthReviewColumnLabelToHclTerraform(struct?: ReportSystemHealthReviewColumnLabel | cdktn.IResolvable): any;
export declare class ReportSystemHealthReviewColumnLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReportSystemHealthReviewColumnLabel | cdktn.IResolvable | undefined;
    set internalValue(value: ReportSystemHealthReviewColumnLabel | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class ReportSystemHealthReviewColumnLabelList extends cdktn.ComplexList {
    internalValue?: ReportSystemHealthReviewColumnLabel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReportSystemHealthReviewColumnLabelOutputReference;
}
export interface ReportSystemHealthReviewColumn {
    /**
    * Column display name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#display_name ReportSystemHealthReview#display_name}
    */
    readonly displayName: string;
    /**
    * label block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#label ReportSystemHealthReview#label}
    */
    readonly label: ReportSystemHealthReviewColumnLabel[] | cdktn.IResolvable;
}
export declare function reportSystemHealthReviewColumnToTerraform(struct?: ReportSystemHealthReviewColumn | cdktn.IResolvable): any;
export declare function reportSystemHealthReviewColumnToHclTerraform(struct?: ReportSystemHealthReviewColumn | cdktn.IResolvable): any;
export declare class ReportSystemHealthReviewColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReportSystemHealthReviewColumn | cdktn.IResolvable | undefined;
    set internalValue(value: ReportSystemHealthReviewColumn | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _label;
    get label(): ReportSystemHealthReviewColumnLabelList;
    putLabel(value: ReportSystemHealthReviewColumnLabel[] | cdktn.IResolvable): void;
    get labelInput(): cdktn.IResolvable | ReportSystemHealthReviewColumnLabel[] | undefined;
}
export declare class ReportSystemHealthReviewColumnList extends cdktn.ComplexList {
    internalValue?: ReportSystemHealthReviewColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReportSystemHealthReviewColumnOutputReference;
}
export interface ReportSystemHealthReviewFiltersLabel {
    /**
    * A key for the label, unique within the associated resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#key ReportSystemHealthReview#key}
    */
    readonly key: string;
    /**
    * A list of unique values for a single key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#values ReportSystemHealthReview#values}
    */
    readonly values: string[];
}
export declare function reportSystemHealthReviewFiltersLabelToTerraform(struct?: ReportSystemHealthReviewFiltersLabel | cdktn.IResolvable): any;
export declare function reportSystemHealthReviewFiltersLabelToHclTerraform(struct?: ReportSystemHealthReviewFiltersLabel | cdktn.IResolvable): any;
export declare class ReportSystemHealthReviewFiltersLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReportSystemHealthReviewFiltersLabel | cdktn.IResolvable | undefined;
    set internalValue(value: ReportSystemHealthReviewFiltersLabel | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class ReportSystemHealthReviewFiltersLabelList extends cdktn.ComplexList {
    internalValue?: ReportSystemHealthReviewFiltersLabel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReportSystemHealthReviewFiltersLabelOutputReference;
}
export interface ReportSystemHealthReviewFiltersService {
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#name ReportSystemHealthReview#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#project ReportSystemHealthReview#project}
    */
    readonly project: string;
}
export declare function reportSystemHealthReviewFiltersServiceToTerraform(struct?: ReportSystemHealthReviewFiltersService | cdktn.IResolvable): any;
export declare function reportSystemHealthReviewFiltersServiceToHclTerraform(struct?: ReportSystemHealthReviewFiltersService | cdktn.IResolvable): any;
export declare class ReportSystemHealthReviewFiltersServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReportSystemHealthReviewFiltersService | cdktn.IResolvable | undefined;
    set internalValue(value: ReportSystemHealthReviewFiltersService | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
}
export declare class ReportSystemHealthReviewFiltersServiceList extends cdktn.ComplexList {
    internalValue?: ReportSystemHealthReviewFiltersService[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReportSystemHealthReviewFiltersServiceOutputReference;
}
export interface ReportSystemHealthReviewFiltersSlo {
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#name ReportSystemHealthReview#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#project ReportSystemHealthReview#project}
    */
    readonly project: string;
}
export declare function reportSystemHealthReviewFiltersSloToTerraform(struct?: ReportSystemHealthReviewFiltersSlo | cdktn.IResolvable): any;
export declare function reportSystemHealthReviewFiltersSloToHclTerraform(struct?: ReportSystemHealthReviewFiltersSlo | cdktn.IResolvable): any;
export declare class ReportSystemHealthReviewFiltersSloOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReportSystemHealthReviewFiltersSlo | cdktn.IResolvable | undefined;
    set internalValue(value: ReportSystemHealthReviewFiltersSlo | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
}
export declare class ReportSystemHealthReviewFiltersSloList extends cdktn.ComplexList {
    internalValue?: ReportSystemHealthReviewFiltersSlo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReportSystemHealthReviewFiltersSloOutputReference;
}
export interface ReportSystemHealthReviewFilters {
    /**
    * Projects to pull data for report from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#projects ReportSystemHealthReview#projects}
    */
    readonly projects?: string[];
    /**
    * label block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#label ReportSystemHealthReview#label}
    */
    readonly label?: ReportSystemHealthReviewFiltersLabel[] | cdktn.IResolvable;
    /**
    * service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#service ReportSystemHealthReview#service}
    */
    readonly service?: ReportSystemHealthReviewFiltersService[] | cdktn.IResolvable;
    /**
    * slo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#slo ReportSystemHealthReview#slo}
    */
    readonly slo?: ReportSystemHealthReviewFiltersSlo[] | cdktn.IResolvable;
}
export declare function reportSystemHealthReviewFiltersToTerraform(struct?: ReportSystemHealthReviewFiltersOutputReference | ReportSystemHealthReviewFilters): any;
export declare function reportSystemHealthReviewFiltersToHclTerraform(struct?: ReportSystemHealthReviewFiltersOutputReference | ReportSystemHealthReviewFilters): any;
export declare class ReportSystemHealthReviewFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReportSystemHealthReviewFilters | undefined;
    set internalValue(value: ReportSystemHealthReviewFilters | undefined);
    private _projects?;
    get projects(): string[];
    set projects(value: string[]);
    resetProjects(): void;
    get projectsInput(): string[] | undefined;
    private _label;
    get label(): ReportSystemHealthReviewFiltersLabelList;
    putLabel(value: ReportSystemHealthReviewFiltersLabel[] | cdktn.IResolvable): void;
    resetLabel(): void;
    get labelInput(): cdktn.IResolvable | ReportSystemHealthReviewFiltersLabel[] | undefined;
    private _service;
    get service(): ReportSystemHealthReviewFiltersServiceList;
    putService(value: ReportSystemHealthReviewFiltersService[] | cdktn.IResolvable): void;
    resetService(): void;
    get serviceInput(): cdktn.IResolvable | ReportSystemHealthReviewFiltersService[] | undefined;
    private _slo;
    get slo(): ReportSystemHealthReviewFiltersSloList;
    putSlo(value: ReportSystemHealthReviewFiltersSlo[] | cdktn.IResolvable): void;
    resetSlo(): void;
    get sloInput(): cdktn.IResolvable | ReportSystemHealthReviewFiltersSlo[] | undefined;
}
export interface ReportSystemHealthReviewThresholds {
    /**
    * Min value for the Green status (e.g. healthy).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#green_gt ReportSystemHealthReview#green_gt}
    */
    readonly greenGt: number;
    /**
    * Max value for the Red status (e.g. exhausted budget).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#red_lte ReportSystemHealthReview#red_lte}
    */
    readonly redLte: number;
    /**
    * ShowNoData customizes the report to either show or hide rows with no data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#show_no_data ReportSystemHealthReview#show_no_data}
    */
    readonly showNoData?: boolean | cdktn.IResolvable;
}
export declare function reportSystemHealthReviewThresholdsToTerraform(struct?: ReportSystemHealthReviewThresholdsOutputReference | ReportSystemHealthReviewThresholds): any;
export declare function reportSystemHealthReviewThresholdsToHclTerraform(struct?: ReportSystemHealthReviewThresholdsOutputReference | ReportSystemHealthReviewThresholds): any;
export declare class ReportSystemHealthReviewThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReportSystemHealthReviewThresholds | undefined;
    set internalValue(value: ReportSystemHealthReviewThresholds | undefined);
    private _greenGt?;
    get greenGt(): number;
    set greenGt(value: number);
    get greenGtInput(): number | undefined;
    private _redLte?;
    get redLte(): number;
    set redLte(value: number);
    get redLteInput(): number | undefined;
    private _showNoData?;
    get showNoData(): boolean | cdktn.IResolvable;
    set showNoData(value: boolean | cdktn.IResolvable);
    resetShowNoData(): void;
    get showNoDataInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ReportSystemHealthReviewTimeFrameSnapshot {
    /**
    * Date and time of the past snapshot in RFC3339 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#date_time ReportSystemHealthReview#date_time}
    */
    readonly dateTime?: string;
    /**
    * The method of reporting time frame [past/latest]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#point ReportSystemHealthReview#point}
    */
    readonly point: string;
    /**
    * The recurrence rule for the report past snapshot. The expected value is a string in RRULE format. Example: `FREQ=MONTHLY;BYMONTHDAY=1`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#rrule ReportSystemHealthReview#rrule}
    */
    readonly rrule?: string;
}
export declare function reportSystemHealthReviewTimeFrameSnapshotToTerraform(struct?: ReportSystemHealthReviewTimeFrameSnapshotOutputReference | ReportSystemHealthReviewTimeFrameSnapshot): any;
export declare function reportSystemHealthReviewTimeFrameSnapshotToHclTerraform(struct?: ReportSystemHealthReviewTimeFrameSnapshotOutputReference | ReportSystemHealthReviewTimeFrameSnapshot): any;
export declare class ReportSystemHealthReviewTimeFrameSnapshotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReportSystemHealthReviewTimeFrameSnapshot | undefined;
    set internalValue(value: ReportSystemHealthReviewTimeFrameSnapshot | undefined);
    private _dateTime?;
    get dateTime(): string;
    set dateTime(value: string);
    resetDateTime(): void;
    get dateTimeInput(): string | undefined;
    private _point?;
    get point(): string;
    set point(value: string);
    get pointInput(): string | undefined;
    private _rrule?;
    get rrule(): string;
    set rrule(value: string);
    resetRrule(): void;
    get rruleInput(): string | undefined;
}
export interface ReportSystemHealthReviewTimeFrame {
    /**
    * Timezone name in IANA Time Zone Database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#time_zone ReportSystemHealthReview#time_zone}
    */
    readonly timeZone: string;
    /**
    * snapshot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#snapshot ReportSystemHealthReview#snapshot}
    */
    readonly snapshot: ReportSystemHealthReviewTimeFrameSnapshot;
}
export declare function reportSystemHealthReviewTimeFrameToTerraform(struct?: ReportSystemHealthReviewTimeFrameOutputReference | ReportSystemHealthReviewTimeFrame): any;
export declare function reportSystemHealthReviewTimeFrameToHclTerraform(struct?: ReportSystemHealthReviewTimeFrameOutputReference | ReportSystemHealthReviewTimeFrame): any;
export declare class ReportSystemHealthReviewTimeFrameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReportSystemHealthReviewTimeFrame | undefined;
    set internalValue(value: ReportSystemHealthReviewTimeFrame | undefined);
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
    private _snapshot;
    get snapshot(): ReportSystemHealthReviewTimeFrameSnapshotOutputReference;
    putSnapshot(value: ReportSystemHealthReviewTimeFrameSnapshot): void;
    get snapshotInput(): ReportSystemHealthReviewTimeFrameSnapshot | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review nobl9_report_system_health_review}
*/
export declare class ReportSystemHealthReview extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_report_system_health_review";
    /**
    * Generates CDKTN code for importing a ReportSystemHealthReview resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ReportSystemHealthReview to import
    * @param importFromId The id of the existing ReportSystemHealthReview that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ReportSystemHealthReview to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/report_system_health_review nobl9_report_system_health_review} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ReportSystemHealthReviewConfig
    */
    constructor(scope: Construct, id: string, config: ReportSystemHealthReviewConfig);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rowGroupBy?;
    get rowGroupBy(): string;
    set rowGroupBy(value: string);
    get rowGroupByInput(): string | undefined;
    private _shared?;
    get shared(): boolean | cdktn.IResolvable;
    set shared(value: boolean | cdktn.IResolvable);
    resetShared(): void;
    get sharedInput(): boolean | cdktn.IResolvable | undefined;
    private _column;
    get column(): ReportSystemHealthReviewColumnList;
    putColumn(value: ReportSystemHealthReviewColumn[] | cdktn.IResolvable): void;
    get columnInput(): cdktn.IResolvable | ReportSystemHealthReviewColumn[] | undefined;
    private _filters;
    get filters(): ReportSystemHealthReviewFiltersOutputReference;
    putFilters(value: ReportSystemHealthReviewFilters): void;
    resetFilters(): void;
    get filtersInput(): ReportSystemHealthReviewFilters | undefined;
    private _thresholds;
    get thresholds(): ReportSystemHealthReviewThresholdsOutputReference;
    putThresholds(value: ReportSystemHealthReviewThresholds): void;
    get thresholdsInput(): ReportSystemHealthReviewThresholds | undefined;
    private _timeFrame;
    get timeFrame(): ReportSystemHealthReviewTimeFrameOutputReference;
    putTimeFrame(value: ReportSystemHealthReviewTimeFrame): void;
    get timeFrameInput(): ReportSystemHealthReviewTimeFrame | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
