import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * [Metadata annotations](https://docs.nobl9.com/features/labels/#metadata-annotations) attached to the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#annotations Service#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#description Service#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#display_name Service#display_name}
    */
    readonly displayName?: string;
    /**
    * Unique name of the resource, must conform to the [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names) naming convention.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#name Service#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names) naming convention.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#project Service#project}
    */
    readonly project: string;
    /**
    * Status of created service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#status Service#status}
    */
    readonly status?: ServiceStatus;
    /**
    * label block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#label Service#label}
    */
    readonly label?: ServiceLabel[] | cdktn.IResolvable;
}
export interface ServiceStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#slo_count Service#slo_count}
    */
    readonly sloCount?: number;
}
export declare function serviceStatusToTerraform(struct?: ServiceStatus | cdktn.IResolvable): any;
export declare function serviceStatusToHclTerraform(struct?: ServiceStatus | cdktn.IResolvable): any;
export declare class ServiceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceStatus | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceStatus | cdktn.IResolvable | undefined);
    private _sloCount?;
    get sloCount(): number;
    set sloCount(value: number);
    resetSloCount(): void;
    get sloCountInput(): number | undefined;
}
export interface ServiceLabel {
    /**
    * A key for the label, unique within the associated resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#key Service#key}
    */
    readonly key: string;
    /**
    * A set of values for a single key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#values Service#values}
    */
    readonly values?: string[];
}
export declare function serviceLabelToTerraform(struct?: ServiceLabel | cdktn.IResolvable): any;
export declare function serviceLabelToHclTerraform(struct?: ServiceLabel | cdktn.IResolvable): any;
export declare class ServiceLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceLabel | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceLabel | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ServiceLabelList extends cdktn.ComplexList {
    internalValue?: ServiceLabel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceLabelOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service nobl9_service}
*/
export declare class Service extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_service";
    /**
    * Generates CDKTN code for importing a Service resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Service to import
    * @param importFromId The id of the existing Service that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Service to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/service nobl9_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceConfig
    */
    constructor(scope: Construct, id: string, config: ServiceConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _status;
    get status(): ServiceStatusOutputReference;
    putStatus(value: ServiceStatus): void;
    resetStatus(): void;
    get statusInput(): cdktn.IResolvable | ServiceStatus | undefined;
    private _label;
    get label(): ServiceLabelList;
    putLabel(value: ServiceLabel[] | cdktn.IResolvable): void;
    resetLabel(): void;
    get labelInput(): cdktn.IResolvable | ServiceLabel[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
