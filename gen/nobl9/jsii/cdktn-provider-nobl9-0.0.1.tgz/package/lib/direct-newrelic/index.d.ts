import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectNewrelicConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID number assigned to the New Relic user account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#account_id DirectNewrelic#account_id}
    */
    readonly accountId: number;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#description DirectNewrelic#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#display_name DirectNewrelic#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#id DirectNewrelic#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [required] | New Relic Insights Query Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#insights_query_key DirectNewrelic#insights_query_key}
    */
    readonly insightsQueryKey?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#log_collection_enabled DirectNewrelic#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#name DirectNewrelic#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#project DirectNewrelic#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#release_channel DirectNewrelic#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#source_of DirectNewrelic#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#historical_data_retrieval DirectNewrelic#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: DirectNewrelicHistoricalDataRetrieval;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#query_delay DirectNewrelic#query_delay}
    */
    readonly queryDelay?: DirectNewrelicQueryDelay;
}
export interface DirectNewrelicHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#unit DirectNewrelic#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#value DirectNewrelic#value}
    */
    readonly value: number;
}
export declare function directNewrelicHistoricalDataRetrievalDefaultDurationToTerraform(struct?: DirectNewrelicHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function directNewrelicHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: DirectNewrelicHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class DirectNewrelicHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectNewrelicHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectNewrelicHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectNewrelicHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: DirectNewrelicHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectNewrelicHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface DirectNewrelicHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#unit DirectNewrelic#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#value DirectNewrelic#value}
    */
    readonly value: number;
}
export declare function directNewrelicHistoricalDataRetrievalMaxDurationToTerraform(struct?: DirectNewrelicHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function directNewrelicHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: DirectNewrelicHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class DirectNewrelicHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectNewrelicHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectNewrelicHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectNewrelicHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: DirectNewrelicHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectNewrelicHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface DirectNewrelicHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#default_duration DirectNewrelic#default_duration}
    */
    readonly defaultDuration: DirectNewrelicHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#max_duration DirectNewrelic#max_duration}
    */
    readonly maxDuration: DirectNewrelicHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function directNewrelicHistoricalDataRetrievalToTerraform(struct?: DirectNewrelicHistoricalDataRetrievalOutputReference | DirectNewrelicHistoricalDataRetrieval): any;
export declare function directNewrelicHistoricalDataRetrievalToHclTerraform(struct?: DirectNewrelicHistoricalDataRetrievalOutputReference | DirectNewrelicHistoricalDataRetrieval): any;
export declare class DirectNewrelicHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectNewrelicHistoricalDataRetrieval | undefined;
    set internalValue(value: DirectNewrelicHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): DirectNewrelicHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: DirectNewrelicHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | DirectNewrelicHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): DirectNewrelicHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: DirectNewrelicHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | DirectNewrelicHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface DirectNewrelicQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#unit DirectNewrelic#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#value DirectNewrelic#value}
    */
    readonly value: number;
}
export declare function directNewrelicQueryDelayToTerraform(struct?: DirectNewrelicQueryDelayOutputReference | DirectNewrelicQueryDelay): any;
export declare function directNewrelicQueryDelayToHclTerraform(struct?: DirectNewrelicQueryDelayOutputReference | DirectNewrelicQueryDelay): any;
export declare class DirectNewrelicQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectNewrelicQueryDelay | undefined;
    set internalValue(value: DirectNewrelicQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic nobl9_direct_newrelic}
*/
export declare class DirectNewrelic extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_newrelic";
    /**
    * Generates CDKTN code for importing a DirectNewrelic resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectNewrelic to import
    * @param importFromId The id of the existing DirectNewrelic that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectNewrelic to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_newrelic nobl9_direct_newrelic} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectNewrelicConfig
    */
    constructor(scope: Construct, id: string, config: DirectNewrelicConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _insightsQueryKey?;
    get insightsQueryKey(): string;
    set insightsQueryKey(value: string);
    resetInsightsQueryKey(): void;
    get insightsQueryKeyInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): DirectNewrelicHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: DirectNewrelicHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): DirectNewrelicHistoricalDataRetrieval | undefined;
    private _queryDelay;
    get queryDelay(): DirectNewrelicQueryDelayOutputReference;
    putQueryDelay(value: DirectNewrelicQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectNewrelicQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
