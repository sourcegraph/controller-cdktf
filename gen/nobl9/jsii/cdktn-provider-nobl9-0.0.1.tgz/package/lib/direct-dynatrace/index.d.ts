import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectDynatraceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#description DirectDynatrace#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#display_name DirectDynatrace#display_name}
    */
    readonly displayName?: string;
    /**
    * [required] | Dynatrace Token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#dynatrace_token DirectDynatrace#dynatrace_token}
    */
    readonly dynatraceToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#id DirectDynatrace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#log_collection_enabled DirectDynatrace#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#name DirectDynatrace#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#project DirectDynatrace#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#release_channel DirectDynatrace#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#source_of DirectDynatrace#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * Dynatrace API URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#url DirectDynatrace#url}
    */
    readonly url: string;
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#historical_data_retrieval DirectDynatrace#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: DirectDynatraceHistoricalDataRetrieval;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#query_delay DirectDynatrace#query_delay}
    */
    readonly queryDelay?: DirectDynatraceQueryDelay;
}
export interface DirectDynatraceHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#unit DirectDynatrace#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#value DirectDynatrace#value}
    */
    readonly value: number;
}
export declare function directDynatraceHistoricalDataRetrievalDefaultDurationToTerraform(struct?: DirectDynatraceHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function directDynatraceHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: DirectDynatraceHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class DirectDynatraceHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectDynatraceHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectDynatraceHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectDynatraceHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: DirectDynatraceHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectDynatraceHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface DirectDynatraceHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#unit DirectDynatrace#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#value DirectDynatrace#value}
    */
    readonly value: number;
}
export declare function directDynatraceHistoricalDataRetrievalMaxDurationToTerraform(struct?: DirectDynatraceHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function directDynatraceHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: DirectDynatraceHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class DirectDynatraceHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectDynatraceHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectDynatraceHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectDynatraceHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: DirectDynatraceHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectDynatraceHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface DirectDynatraceHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#default_duration DirectDynatrace#default_duration}
    */
    readonly defaultDuration: DirectDynatraceHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#max_duration DirectDynatrace#max_duration}
    */
    readonly maxDuration: DirectDynatraceHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function directDynatraceHistoricalDataRetrievalToTerraform(struct?: DirectDynatraceHistoricalDataRetrievalOutputReference | DirectDynatraceHistoricalDataRetrieval): any;
export declare function directDynatraceHistoricalDataRetrievalToHclTerraform(struct?: DirectDynatraceHistoricalDataRetrievalOutputReference | DirectDynatraceHistoricalDataRetrieval): any;
export declare class DirectDynatraceHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectDynatraceHistoricalDataRetrieval | undefined;
    set internalValue(value: DirectDynatraceHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): DirectDynatraceHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: DirectDynatraceHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | DirectDynatraceHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): DirectDynatraceHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: DirectDynatraceHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | DirectDynatraceHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface DirectDynatraceQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#unit DirectDynatrace#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#value DirectDynatrace#value}
    */
    readonly value: number;
}
export declare function directDynatraceQueryDelayToTerraform(struct?: DirectDynatraceQueryDelayOutputReference | DirectDynatraceQueryDelay): any;
export declare function directDynatraceQueryDelayToHclTerraform(struct?: DirectDynatraceQueryDelayOutputReference | DirectDynatraceQueryDelay): any;
export declare class DirectDynatraceQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectDynatraceQueryDelay | undefined;
    set internalValue(value: DirectDynatraceQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace nobl9_direct_dynatrace}
*/
export declare class DirectDynatrace extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_dynatrace";
    /**
    * Generates CDKTN code for importing a DirectDynatrace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectDynatrace to import
    * @param importFromId The id of the existing DirectDynatrace that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectDynatrace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_dynatrace nobl9_direct_dynatrace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectDynatraceConfig
    */
    constructor(scope: Construct, id: string, config: DirectDynatraceConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _dynatraceToken?;
    get dynatraceToken(): string;
    set dynatraceToken(value: string);
    resetDynatraceToken(): void;
    get dynatraceTokenInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): DirectDynatraceHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: DirectDynatraceHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): DirectDynatraceHistoricalDataRetrieval | undefined;
    private _queryDelay;
    get queryDelay(): DirectDynatraceQueryDelayOutputReference;
    putQueryDelay(value: DirectDynatraceQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectDynatraceQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
