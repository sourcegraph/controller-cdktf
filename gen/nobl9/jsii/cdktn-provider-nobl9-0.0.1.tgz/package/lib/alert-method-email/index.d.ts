import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertMethodEmailConfig extends cdktn.TerraformMetaArguments {
    /**
    * Blind carbon copy recipients. The maximum number of recipients is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email#bcc AlertMethodEmail#bcc}
    */
    readonly bcc?: string[];
    /**
    * Carbon copy recipients. The maximum number of recipients is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email#cc AlertMethodEmail#cc}
    */
    readonly cc?: string[];
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email#description AlertMethodEmail#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email#display_name AlertMethodEmail#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email#id AlertMethodEmail#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email#name AlertMethodEmail#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email#project AlertMethodEmail#project}
    */
    readonly project: string;
    /**
    * Recipients. The maximum number of recipients is 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email#to AlertMethodEmail#to}
    */
    readonly to: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email nobl9_alert_method_email}
*/
export declare class AlertMethodEmail extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_alert_method_email";
    /**
    * Generates CDKTN code for importing a AlertMethodEmail resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertMethodEmail to import
    * @param importFromId The id of the existing AlertMethodEmail that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertMethodEmail to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_email nobl9_alert_method_email} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertMethodEmailConfig
    */
    constructor(scope: Construct, id: string, config: AlertMethodEmailConfig);
    private _bcc?;
    get bcc(): string[];
    set bcc(value: string[]);
    resetBcc(): void;
    get bccInput(): string[] | undefined;
    private _cc?;
    get cc(): string[];
    set cc(value: string[]);
    resetCc(): void;
    get ccInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _to?;
    get to(): string[];
    set to(value: string[]);
    get toInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
