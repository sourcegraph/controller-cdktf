import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectHoneycombConfig extends cdktn.TerraformMetaArguments {
    /**
    * [required] | Honeycomb API Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#api_key DirectHoneycomb#api_key}
    */
    readonly apiKey?: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#description DirectHoneycomb#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#display_name DirectHoneycomb#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#id DirectHoneycomb#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#log_collection_enabled DirectHoneycomb#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#name DirectHoneycomb#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#project DirectHoneycomb#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#release_channel DirectHoneycomb#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#source_of DirectHoneycomb#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#historical_data_retrieval DirectHoneycomb#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: DirectHoneycombHistoricalDataRetrieval;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#query_delay DirectHoneycomb#query_delay}
    */
    readonly queryDelay?: DirectHoneycombQueryDelay;
}
export interface DirectHoneycombHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#unit DirectHoneycomb#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#value DirectHoneycomb#value}
    */
    readonly value: number;
}
export declare function directHoneycombHistoricalDataRetrievalDefaultDurationToTerraform(struct?: DirectHoneycombHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function directHoneycombHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: DirectHoneycombHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class DirectHoneycombHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectHoneycombHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectHoneycombHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectHoneycombHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: DirectHoneycombHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectHoneycombHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface DirectHoneycombHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#unit DirectHoneycomb#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#value DirectHoneycomb#value}
    */
    readonly value: number;
}
export declare function directHoneycombHistoricalDataRetrievalMaxDurationToTerraform(struct?: DirectHoneycombHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function directHoneycombHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: DirectHoneycombHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class DirectHoneycombHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectHoneycombHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectHoneycombHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectHoneycombHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: DirectHoneycombHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectHoneycombHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface DirectHoneycombHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#default_duration DirectHoneycomb#default_duration}
    */
    readonly defaultDuration: DirectHoneycombHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#max_duration DirectHoneycomb#max_duration}
    */
    readonly maxDuration: DirectHoneycombHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function directHoneycombHistoricalDataRetrievalToTerraform(struct?: DirectHoneycombHistoricalDataRetrievalOutputReference | DirectHoneycombHistoricalDataRetrieval): any;
export declare function directHoneycombHistoricalDataRetrievalToHclTerraform(struct?: DirectHoneycombHistoricalDataRetrievalOutputReference | DirectHoneycombHistoricalDataRetrieval): any;
export declare class DirectHoneycombHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectHoneycombHistoricalDataRetrieval | undefined;
    set internalValue(value: DirectHoneycombHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): DirectHoneycombHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: DirectHoneycombHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | DirectHoneycombHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): DirectHoneycombHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: DirectHoneycombHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | DirectHoneycombHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface DirectHoneycombQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#unit DirectHoneycomb#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#value DirectHoneycomb#value}
    */
    readonly value: number;
}
export declare function directHoneycombQueryDelayToTerraform(struct?: DirectHoneycombQueryDelayOutputReference | DirectHoneycombQueryDelay): any;
export declare function directHoneycombQueryDelayToHclTerraform(struct?: DirectHoneycombQueryDelayOutputReference | DirectHoneycombQueryDelay): any;
export declare class DirectHoneycombQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectHoneycombQueryDelay | undefined;
    set internalValue(value: DirectHoneycombQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb nobl9_direct_honeycomb}
*/
export declare class DirectHoneycomb extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_honeycomb";
    /**
    * Generates CDKTN code for importing a DirectHoneycomb resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectHoneycomb to import
    * @param importFromId The id of the existing DirectHoneycomb that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectHoneycomb to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_honeycomb nobl9_direct_honeycomb} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectHoneycombConfig
    */
    constructor(scope: Construct, id: string, config: DirectHoneycombConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): DirectHoneycombHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: DirectHoneycombHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): DirectHoneycombHistoricalDataRetrieval | undefined;
    private _queryDelay;
    get queryDelay(): DirectHoneycombQueryDelayOutputReference;
    putQueryDelay(value: DirectHoneycombQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectHoneycombQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
