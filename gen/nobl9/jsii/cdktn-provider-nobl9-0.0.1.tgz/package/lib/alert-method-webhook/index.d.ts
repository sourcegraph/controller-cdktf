import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertMethodWebhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#description AlertMethodWebhook#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#display_name AlertMethodWebhook#display_name}
    */
    readonly displayName?: string;
    /**
    * Custom HTTP headers to include in the webhook request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#headers AlertMethodWebhook#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#id AlertMethodWebhook#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#name AlertMethodWebhook#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#project AlertMethodWebhook#project}
    */
    readonly project: string;
    /**
    * Custom HTTP headers to include in the webhook request. The values are treated as sensitive, will not be displayed in the Terraform state and will be encrypted by Nobl9 platform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#sensitive_headers AlertMethodWebhook#sensitive_headers}
    */
    readonly sensitiveHeaders?: {
        [key: string]: string;
    };
    /**
    * Webhook message template. See documentation for template format and samples.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#template AlertMethodWebhook#template}
    */
    readonly template?: string;
    /**
    * Webhook message fields. The message contains JSON payload with specified fields. See documentation for allowed fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#template_fields AlertMethodWebhook#template_fields}
    */
    readonly templateFields?: string[];
    /**
    * URL of the webhook endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#url AlertMethodWebhook#url}
    */
    readonly url?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook nobl9_alert_method_webhook}
*/
export declare class AlertMethodWebhook extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_alert_method_webhook";
    /**
    * Generates CDKTN code for importing a AlertMethodWebhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertMethodWebhook to import
    * @param importFromId The id of the existing AlertMethodWebhook that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertMethodWebhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/alert_method_webhook nobl9_alert_method_webhook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertMethodWebhookConfig
    */
    constructor(scope: Construct, id: string, config: AlertMethodWebhookConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _sensitiveHeaders?;
    get sensitiveHeaders(): {
        [key: string]: string;
    };
    set sensitiveHeaders(value: {
        [key: string]: string;
    });
    resetSensitiveHeaders(): void;
    get sensitiveHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
    private _templateFields?;
    get templateFields(): string[];
    set templateFields(value: string[]);
    resetTemplateFields(): void;
    get templateFieldsInput(): string[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
