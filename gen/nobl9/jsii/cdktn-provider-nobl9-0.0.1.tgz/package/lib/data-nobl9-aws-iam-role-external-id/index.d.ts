import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNobl9AwsIamRoleExternalIdConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/data-sources/aws_iam_role_external_id#id DataNobl9AwsIamRoleExternalId#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Data source name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/data-sources/aws_iam_role_external_id#name DataNobl9AwsIamRoleExternalId#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/data-sources/aws_iam_role_external_id nobl9_aws_iam_role_external_id}
*/
export declare class DataNobl9AwsIamRoleExternalId extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "nobl9_aws_iam_role_external_id";
    /**
    * Generates CDKTN code for importing a DataNobl9AwsIamRoleExternalId resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNobl9AwsIamRoleExternalId to import
    * @param importFromId The id of the existing DataNobl9AwsIamRoleExternalId that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/data-sources/aws_iam_role_external_id#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNobl9AwsIamRoleExternalId to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/data-sources/aws_iam_role_external_id nobl9_aws_iam_role_external_id} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNobl9AwsIamRoleExternalIdConfig
    */
    constructor(scope: Construct, id: string, config: DataNobl9AwsIamRoleExternalIdConfig);
    get accountId(): string;
    get externalId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
