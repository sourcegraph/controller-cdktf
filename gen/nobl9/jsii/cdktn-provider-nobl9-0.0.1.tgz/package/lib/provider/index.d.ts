import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Nobl9ProviderConfig {
    /**
    * The [Client ID](https://docs.nobl9.com/sloctl-user-guide/#configuration) of your Nobl9 account required to connect to Nobl9.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs#client_id Nobl9Provider#client_id}
    */
    readonly clientId?: string;
    /**
    * The [Client Secret](https://docs.nobl9.com/sloctl-user-guide/#configuration) of your Nobl9 account required to connect to Nobl9.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs#client_secret Nobl9Provider#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Nobl9 API URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs#ingest_url Nobl9Provider#ingest_url}
    */
    readonly ingestUrl?: string;
    /**
    * Authorization service configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs#okta_auth_server Nobl9Provider#okta_auth_server}
    */
    readonly oktaAuthServer?: string;
    /**
    * Authorization service URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs#okta_org_url Nobl9Provider#okta_org_url}
    */
    readonly oktaOrgUrl?: string;
    /**
    * Nobl9 Organization ID that contains resources managed by the provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs#organization Nobl9Provider#organization}
    */
    readonly organization?: string;
    /**
    * Nobl9 project used when importing resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs#project Nobl9Provider#project}
    */
    readonly project?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs#alias Nobl9Provider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs nobl9}
*/
export declare class Nobl9Provider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "nobl9";
    /**
    * Generates CDKTN code for importing a Nobl9Provider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Nobl9Provider to import
    * @param importFromId The id of the existing Nobl9Provider that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Nobl9Provider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs nobl9} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Nobl9ProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: Nobl9ProviderConfig);
    private _clientId?;
    get clientId(): string | undefined;
    set clientId(value: string | undefined);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string | undefined;
    set clientSecret(value: string | undefined);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _ingestUrl?;
    get ingestUrl(): string | undefined;
    set ingestUrl(value: string | undefined);
    resetIngestUrl(): void;
    get ingestUrlInput(): string | undefined;
    private _oktaAuthServer?;
    get oktaAuthServer(): string | undefined;
    set oktaAuthServer(value: string | undefined);
    resetOktaAuthServer(): void;
    get oktaAuthServerInput(): string | undefined;
    private _oktaOrgUrl?;
    get oktaOrgUrl(): string | undefined;
    set oktaOrgUrl(value: string | undefined);
    resetOktaOrgUrl(): void;
    get oktaOrgUrlInput(): string | undefined;
    private _organization?;
    get organization(): string | undefined;
    set organization(value: string | undefined);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _project?;
    get project(): string | undefined;
    set project(value: string | undefined);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
