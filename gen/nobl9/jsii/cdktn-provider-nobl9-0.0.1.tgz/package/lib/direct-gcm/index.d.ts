import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectGcmConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#description DirectGcm#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#display_name DirectGcm#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#id DirectGcm#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#log_collection_enabled DirectGcm#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#name DirectGcm#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#project DirectGcm#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#release_channel DirectGcm#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * [required] | Service Account Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#service_account_key DirectGcm#service_account_key}
    */
    readonly serviceAccountKey?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#source_of DirectGcm#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#historical_data_retrieval DirectGcm#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: DirectGcmHistoricalDataRetrieval;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#query_delay DirectGcm#query_delay}
    */
    readonly queryDelay?: DirectGcmQueryDelay;
}
export interface DirectGcmHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#unit DirectGcm#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#value DirectGcm#value}
    */
    readonly value: number;
}
export declare function directGcmHistoricalDataRetrievalDefaultDurationToTerraform(struct?: DirectGcmHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function directGcmHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: DirectGcmHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class DirectGcmHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectGcmHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectGcmHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectGcmHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: DirectGcmHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectGcmHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface DirectGcmHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#unit DirectGcm#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#value DirectGcm#value}
    */
    readonly value: number;
}
export declare function directGcmHistoricalDataRetrievalMaxDurationToTerraform(struct?: DirectGcmHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function directGcmHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: DirectGcmHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class DirectGcmHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectGcmHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectGcmHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectGcmHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: DirectGcmHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectGcmHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface DirectGcmHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#default_duration DirectGcm#default_duration}
    */
    readonly defaultDuration: DirectGcmHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#max_duration DirectGcm#max_duration}
    */
    readonly maxDuration: DirectGcmHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function directGcmHistoricalDataRetrievalToTerraform(struct?: DirectGcmHistoricalDataRetrievalOutputReference | DirectGcmHistoricalDataRetrieval): any;
export declare function directGcmHistoricalDataRetrievalToHclTerraform(struct?: DirectGcmHistoricalDataRetrievalOutputReference | DirectGcmHistoricalDataRetrieval): any;
export declare class DirectGcmHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectGcmHistoricalDataRetrieval | undefined;
    set internalValue(value: DirectGcmHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): DirectGcmHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: DirectGcmHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | DirectGcmHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): DirectGcmHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: DirectGcmHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | DirectGcmHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface DirectGcmQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#unit DirectGcm#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#value DirectGcm#value}
    */
    readonly value: number;
}
export declare function directGcmQueryDelayToTerraform(struct?: DirectGcmQueryDelayOutputReference | DirectGcmQueryDelay): any;
export declare function directGcmQueryDelayToHclTerraform(struct?: DirectGcmQueryDelayOutputReference | DirectGcmQueryDelay): any;
export declare class DirectGcmQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectGcmQueryDelay | undefined;
    set internalValue(value: DirectGcmQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm nobl9_direct_gcm}
*/
export declare class DirectGcm extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_gcm";
    /**
    * Generates CDKTN code for importing a DirectGcm resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectGcm to import
    * @param importFromId The id of the existing DirectGcm that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectGcm to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_gcm nobl9_direct_gcm} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectGcmConfig
    */
    constructor(scope: Construct, id: string, config: DirectGcmConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _serviceAccountKey?;
    get serviceAccountKey(): string;
    set serviceAccountKey(value: string);
    resetServiceAccountKey(): void;
    get serviceAccountKeyInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): DirectGcmHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: DirectGcmHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): DirectGcmHistoricalDataRetrieval | undefined;
    private _queryDelay;
    get queryDelay(): DirectGcmQueryDelayOutputReference;
    putQueryDelay(value: DirectGcmQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectGcmQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
