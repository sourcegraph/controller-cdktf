import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectLightstepConfig extends cdktn.TerraformMetaArguments {
    /**
    * [required] | Lightstep App Token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#app_token DirectLightstep#app_token}
    */
    readonly appToken?: string;
    /**
    * Optional description of the resource. Here, you can add details about who is responsible for the integration (team/owner) or the purpose of creating it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#description DirectLightstep#description}
    */
    readonly description?: string;
    /**
    * User-friendly display name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#display_name DirectLightstep#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#id DirectLightstep#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Organization name registered in Lightstep.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#lightstep_organization DirectLightstep#lightstep_organization}
    */
    readonly lightstepOrganization: string;
    /**
    * Name of the Lightstep project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#lightstep_project DirectLightstep#lightstep_project}
    */
    readonly lightstepProject: string;
    /**
    * [Logs documentation](https://docs.nobl9.com/features/slo-troubleshooting/event-logs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#log_collection_enabled DirectLightstep#log_collection_enabled}
    */
    readonly logCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Unique name of the resource, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#name DirectLightstep#name}
    */
    readonly name: string;
    /**
    * Name of the Nobl9 project the resource sits in, must conform to the naming convention from [DNS RFC1123](https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#project DirectLightstep#project}
    */
    readonly project: string;
    /**
    * Release channel of the created data source [stable/beta]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#release_channel DirectLightstep#release_channel}
    */
    readonly releaseChannel?: string;
    /**
    * This value indicated whether the field was a source of metrics and/or services. 'source_of' is deprecated and not used anywhere; however, it's kept for backward compatibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#source_of DirectLightstep#source_of}
    */
    readonly sourceOf?: string[];
    /**
    * Lightstep API URL. Nobl9 will use https://api.lightstep.com if empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#url DirectLightstep#url}
    */
    readonly url?: string;
    /**
    * historical_data_retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#historical_data_retrieval DirectLightstep#historical_data_retrieval}
    */
    readonly historicalDataRetrieval?: DirectLightstepHistoricalDataRetrieval;
    /**
    * query_delay block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#query_delay DirectLightstep#query_delay}
    */
    readonly queryDelay?: DirectLightstepQueryDelay;
}
export interface DirectLightstepHistoricalDataRetrievalDefaultDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#unit DirectLightstep#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#value DirectLightstep#value}
    */
    readonly value: number;
}
export declare function directLightstepHistoricalDataRetrievalDefaultDurationToTerraform(struct?: DirectLightstepHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare function directLightstepHistoricalDataRetrievalDefaultDurationToHclTerraform(struct?: DirectLightstepHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable): any;
export declare class DirectLightstepHistoricalDataRetrievalDefaultDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectLightstepHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectLightstepHistoricalDataRetrievalDefaultDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectLightstepHistoricalDataRetrievalDefaultDurationList extends cdktn.ComplexList {
    internalValue?: DirectLightstepHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectLightstepHistoricalDataRetrievalDefaultDurationOutputReference;
}
export interface DirectLightstepHistoricalDataRetrievalMaxDuration {
    /**
    * Must be one of Minute, Hour, or Day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#unit DirectLightstep#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#value DirectLightstep#value}
    */
    readonly value: number;
}
export declare function directLightstepHistoricalDataRetrievalMaxDurationToTerraform(struct?: DirectLightstepHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare function directLightstepHistoricalDataRetrievalMaxDurationToHclTerraform(struct?: DirectLightstepHistoricalDataRetrievalMaxDuration | cdktn.IResolvable): any;
export declare class DirectLightstepHistoricalDataRetrievalMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DirectLightstepHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined;
    set internalValue(value: DirectLightstepHistoricalDataRetrievalMaxDuration | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DirectLightstepHistoricalDataRetrievalMaxDurationList extends cdktn.ComplexList {
    internalValue?: DirectLightstepHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DirectLightstepHistoricalDataRetrievalMaxDurationOutputReference;
}
export interface DirectLightstepHistoricalDataRetrieval {
    /**
    * default_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#default_duration DirectLightstep#default_duration}
    */
    readonly defaultDuration: DirectLightstepHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable;
    /**
    * max_duration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#max_duration DirectLightstep#max_duration}
    */
    readonly maxDuration: DirectLightstepHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable;
}
export declare function directLightstepHistoricalDataRetrievalToTerraform(struct?: DirectLightstepHistoricalDataRetrievalOutputReference | DirectLightstepHistoricalDataRetrieval): any;
export declare function directLightstepHistoricalDataRetrievalToHclTerraform(struct?: DirectLightstepHistoricalDataRetrievalOutputReference | DirectLightstepHistoricalDataRetrieval): any;
export declare class DirectLightstepHistoricalDataRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectLightstepHistoricalDataRetrieval | undefined;
    set internalValue(value: DirectLightstepHistoricalDataRetrieval | undefined);
    private _defaultDuration;
    get defaultDuration(): DirectLightstepHistoricalDataRetrievalDefaultDurationList;
    putDefaultDuration(value: DirectLightstepHistoricalDataRetrievalDefaultDuration[] | cdktn.IResolvable): void;
    get defaultDurationInput(): cdktn.IResolvable | DirectLightstepHistoricalDataRetrievalDefaultDuration[] | undefined;
    private _maxDuration;
    get maxDuration(): DirectLightstepHistoricalDataRetrievalMaxDurationList;
    putMaxDuration(value: DirectLightstepHistoricalDataRetrievalMaxDuration[] | cdktn.IResolvable): void;
    get maxDurationInput(): cdktn.IResolvable | DirectLightstepHistoricalDataRetrievalMaxDuration[] | undefined;
}
export interface DirectLightstepQueryDelay {
    /**
    * Must be one of Minute or Second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#unit DirectLightstep#unit}
    */
    readonly unit: string;
    /**
    * Must be an integer greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#value DirectLightstep#value}
    */
    readonly value: number;
}
export declare function directLightstepQueryDelayToTerraform(struct?: DirectLightstepQueryDelayOutputReference | DirectLightstepQueryDelay): any;
export declare function directLightstepQueryDelayToHclTerraform(struct?: DirectLightstepQueryDelayOutputReference | DirectLightstepQueryDelay): any;
export declare class DirectLightstepQueryDelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectLightstepQueryDelay | undefined;
    set internalValue(value: DirectLightstepQueryDelay | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep nobl9_direct_lightstep}
*/
export declare class DirectLightstep extends cdktn.TerraformResource {
    static readonly tfResourceType = "nobl9_direct_lightstep";
    /**
    * Generates CDKTN code for importing a DirectLightstep resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectLightstep to import
    * @param importFromId The id of the existing DirectLightstep that should be imported. Refer to the {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectLightstep to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/nobl9/nobl9/0.37.0/docs/resources/direct_lightstep nobl9_direct_lightstep} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectLightstepConfig
    */
    constructor(scope: Construct, id: string, config: DirectLightstepConfig);
    private _appToken?;
    get appToken(): string;
    set appToken(value: string);
    resetAppToken(): void;
    get appTokenInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lightstepOrganization?;
    get lightstepOrganization(): string;
    set lightstepOrganization(value: string);
    get lightstepOrganizationInput(): string | undefined;
    private _lightstepProject?;
    get lightstepProject(): string;
    set lightstepProject(value: string);
    get lightstepProjectInput(): string | undefined;
    private _logCollectionEnabled?;
    get logCollectionEnabled(): boolean | cdktn.IResolvable;
    set logCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetLogCollectionEnabled(): void;
    get logCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _releaseChannel?;
    get releaseChannel(): string;
    set releaseChannel(value: string);
    resetReleaseChannel(): void;
    get releaseChannelInput(): string | undefined;
    private _sourceOf?;
    get sourceOf(): string[];
    set sourceOf(value: string[]);
    resetSourceOf(): void;
    get sourceOfInput(): string[] | undefined;
    get status(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _historicalDataRetrieval;
    get historicalDataRetrieval(): DirectLightstepHistoricalDataRetrievalOutputReference;
    putHistoricalDataRetrieval(value: DirectLightstepHistoricalDataRetrieval): void;
    resetHistoricalDataRetrieval(): void;
    get historicalDataRetrievalInput(): DirectLightstepHistoricalDataRetrieval | undefined;
    private _queryDelay;
    get queryDelay(): DirectLightstepQueryDelayOutputReference;
    putQueryDelay(value: DirectLightstepQueryDelay): void;
    resetQueryDelay(): void;
    get queryDelayInput(): DirectLightstepQueryDelay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
