# `kubernetes_pod_v1`

Refer to the Terraform Registry for docs: [`kubernetes_pod_v1`](https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/pod_v1).
