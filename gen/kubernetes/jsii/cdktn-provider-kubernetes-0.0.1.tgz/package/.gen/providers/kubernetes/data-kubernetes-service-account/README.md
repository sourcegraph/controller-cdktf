# `data_kubernetes_service_account`

Refer to the Terraform Registry for docs: [`data_kubernetes_service_account`](https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/data-sources/service_account).
