# `data_kubernetes_ingress_v1`

Refer to the Terraform Registry for docs: [`data_kubernetes_ingress_v1`](https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/data-sources/ingress_v1).
