# `data_kubernetes_mutating_webhook_configuration_v1`

Refer to the Terraform Registry for docs: [`data_kubernetes_mutating_webhook_configuration_v1`](https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/data-sources/mutating_webhook_configuration_v1).
