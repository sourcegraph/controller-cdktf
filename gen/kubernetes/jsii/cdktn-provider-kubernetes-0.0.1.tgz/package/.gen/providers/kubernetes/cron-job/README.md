# `kubernetes_cron_job`

Refer to the Terraform Registry for docs: [`kubernetes_cron_job`](https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/cron_job).
