# `data_kubernetes_resource`

Refer to the Terraform Registry for docs: [`data_kubernetes_resource`](https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/data-sources/resource).
