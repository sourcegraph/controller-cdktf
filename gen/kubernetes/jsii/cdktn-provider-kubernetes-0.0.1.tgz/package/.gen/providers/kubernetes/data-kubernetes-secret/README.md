# `data_kubernetes_secret`

Refer to the Terraform Registry for docs: [`data_kubernetes_secret`](https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/data-sources/secret).
