# `kubernetes_service_account`

Refer to the Terraform Registry for docs: [`kubernetes_service_account`](https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/service_account).
