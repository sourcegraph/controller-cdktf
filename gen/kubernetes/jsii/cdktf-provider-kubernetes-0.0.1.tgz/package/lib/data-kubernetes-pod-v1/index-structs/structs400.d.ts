import * as cdktf from 'cdktf';
import { DataKubernetesPodV1SpecInitContainerReadinessProbeExecList, DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetList, DataKubernetesPodV1SpecInitContainerEnvList, DataKubernetesPodV1SpecInitContainerEnvFromList, DataKubernetesPodV1SpecInitContainerLifecycleList, DataKubernetesPodV1SpecInitContainerLivenessProbeList, DataKubernetesPodV1SpecInitContainerPortList, DataKubernetesPodV1SpecAffinityList, DataKubernetesPodV1SpecContainerList, DataKubernetesPodV1SpecDnsConfigList, DataKubernetesPodV1SpecHostAliasesList, DataKubernetesPodV1SpecImagePullSecretsList } from './structs0';
export interface DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocket {
}
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocket): any;
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocket): any;
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerReadinessProbe {
}
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeToTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbe): any;
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbe): any;
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerReadinessProbe | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerReadinessProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecInitContainerReadinessProbeExecList;
    get failureThreshold(): number;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerReadinessProbeOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerResources {
}
export declare function dataKubernetesPodV1SpecInitContainerResourcesToTerraform(struct?: DataKubernetesPodV1SpecInitContainerResources): any;
export declare function dataKubernetesPodV1SpecInitContainerResourcesToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerResources): any;
export declare class DataKubernetesPodV1SpecInitContainerResourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerResources | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerResources | undefined);
    private _limits;
    get limits(): cdktf.StringMap;
    private _requests;
    get requests(): cdktf.StringMap;
}
export declare class DataKubernetesPodV1SpecInitContainerResourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerResourcesOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerSecurityContextCapabilities {
}
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesToTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextCapabilities): any;
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextCapabilities): any;
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerSecurityContextCapabilities | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerSecurityContextCapabilities | undefined);
    get add(): string[];
    get drop(): string[];
}
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptions {
}
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsToTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptions): any;
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptions): any;
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptions | undefined);
    get level(): string;
    get role(): string;
    get type(): string;
    get user(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfile {
}
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileToTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfile): any;
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfile): any;
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfile | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfile | undefined);
    get localhostProfile(): string;
    get type(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerSecurityContext {
}
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextToTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContext): any;
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContext): any;
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerSecurityContext | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerSecurityContext | undefined);
    get allowPrivilegeEscalation(): cdktf.IResolvable;
    private _capabilities;
    get capabilities(): DataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesList;
    get privileged(): cdktf.IResolvable;
    get readOnlyRootFilesystem(): cdktf.IResolvable;
    get runAsGroup(): string;
    get runAsNonRoot(): cdktf.IResolvable;
    get runAsUser(): string;
    private _seLinuxOptions;
    get seLinuxOptions(): DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsList;
    private _seccompProfile;
    get seccompProfile(): DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileList;
}
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerSecurityContextOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbeExec {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeExecToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeExec): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeExecToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeExec): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeExecOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbeExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeExecList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeExecOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbeHttpGet {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeHttpGetToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGet): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGet): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocket {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocket): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocket): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbe {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbe): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbe): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbe | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecInitContainerStartupProbeExecList;
    get failureThreshold(): number;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerVolumeMount {
}
export declare function dataKubernetesPodV1SpecInitContainerVolumeMountToTerraform(struct?: DataKubernetesPodV1SpecInitContainerVolumeMount): any;
export declare function dataKubernetesPodV1SpecInitContainerVolumeMountToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerVolumeMount): any;
export declare class DataKubernetesPodV1SpecInitContainerVolumeMountOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerVolumeMount | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerVolumeMount | undefined);
    get mountPath(): string;
    get mountPropagation(): string;
    get name(): string;
    get readOnly(): cdktf.IResolvable;
    get subPath(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerVolumeMountList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerVolumeMountOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainer {
}
export declare function dataKubernetesPodV1SpecInitContainerToTerraform(struct?: DataKubernetesPodV1SpecInitContainer): any;
export declare function dataKubernetesPodV1SpecInitContainerToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainer): any;
export declare class DataKubernetesPodV1SpecInitContainerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainer | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainer | undefined);
    get args(): string[];
    get command(): string[];
    private _env;
    get env(): DataKubernetesPodV1SpecInitContainerEnvList;
    private _envFrom;
    get envFrom(): DataKubernetesPodV1SpecInitContainerEnvFromList;
    get image(): string;
    get imagePullPolicy(): string;
    private _lifecycle;
    get lifecycle(): DataKubernetesPodV1SpecInitContainerLifecycleList;
    private _livenessProbe;
    get livenessProbe(): DataKubernetesPodV1SpecInitContainerLivenessProbeList;
    get name(): string;
    private _port;
    get port(): DataKubernetesPodV1SpecInitContainerPortList;
    private _readinessProbe;
    get readinessProbe(): DataKubernetesPodV1SpecInitContainerReadinessProbeList;
    private _resources;
    get resources(): DataKubernetesPodV1SpecInitContainerResourcesList;
    private _securityContext;
    get securityContext(): DataKubernetesPodV1SpecInitContainerSecurityContextList;
    private _startupProbe;
    get startupProbe(): DataKubernetesPodV1SpecInitContainerStartupProbeList;
    get stdin(): cdktf.IResolvable;
    get stdinOnce(): cdktf.IResolvable;
    get terminationMessagePath(): string;
    get terminationMessagePolicy(): string;
    get tty(): cdktf.IResolvable;
    private _volumeMount;
    get volumeMount(): DataKubernetesPodV1SpecInitContainerVolumeMountList;
    get workingDir(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerOutputReference;
}
export interface DataKubernetesPodV1SpecReadinessGate {
}
export declare function dataKubernetesPodV1SpecReadinessGateToTerraform(struct?: DataKubernetesPodV1SpecReadinessGate): any;
export declare function dataKubernetesPodV1SpecReadinessGateToHclTerraform(struct?: DataKubernetesPodV1SpecReadinessGate): any;
export declare class DataKubernetesPodV1SpecReadinessGateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecReadinessGate | undefined;
    set internalValue(value: DataKubernetesPodV1SpecReadinessGate | undefined);
    get conditionType(): string;
}
export declare class DataKubernetesPodV1SpecReadinessGateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecReadinessGateOutputReference;
}
export interface DataKubernetesPodV1SpecSecurityContextSeLinuxOptions {
}
export declare function dataKubernetesPodV1SpecSecurityContextSeLinuxOptionsToTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSeLinuxOptions): any;
export declare function dataKubernetesPodV1SpecSecurityContextSeLinuxOptionsToHclTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSeLinuxOptions): any;
export declare class DataKubernetesPodV1SpecSecurityContextSeLinuxOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecSecurityContextSeLinuxOptions | undefined);
    get level(): string;
    get role(): string;
    get type(): string;
    get user(): string;
}
export declare class DataKubernetesPodV1SpecSecurityContextSeLinuxOptionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecSecurityContextSeLinuxOptionsOutputReference;
}
export interface DataKubernetesPodV1SpecSecurityContextSeccompProfile {
}
export declare function dataKubernetesPodV1SpecSecurityContextSeccompProfileToTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSeccompProfile): any;
export declare function dataKubernetesPodV1SpecSecurityContextSeccompProfileToHclTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSeccompProfile): any;
export declare class DataKubernetesPodV1SpecSecurityContextSeccompProfileOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecSecurityContextSeccompProfile | undefined;
    set internalValue(value: DataKubernetesPodV1SpecSecurityContextSeccompProfile | undefined);
    get localhostProfile(): string;
    get type(): string;
}
export declare class DataKubernetesPodV1SpecSecurityContextSeccompProfileList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecSecurityContextSeccompProfileOutputReference;
}
export interface DataKubernetesPodV1SpecSecurityContextSysctl {
}
export declare function dataKubernetesPodV1SpecSecurityContextSysctlToTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSysctl): any;
export declare function dataKubernetesPodV1SpecSecurityContextSysctlToHclTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSysctl): any;
export declare class DataKubernetesPodV1SpecSecurityContextSysctlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecSecurityContextSysctl | undefined;
    set internalValue(value: DataKubernetesPodV1SpecSecurityContextSysctl | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecSecurityContextSysctlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecSecurityContextSysctlOutputReference;
}
export interface DataKubernetesPodV1SpecSecurityContext {
}
export declare function dataKubernetesPodV1SpecSecurityContextToTerraform(struct?: DataKubernetesPodV1SpecSecurityContext): any;
export declare function dataKubernetesPodV1SpecSecurityContextToHclTerraform(struct?: DataKubernetesPodV1SpecSecurityContext): any;
export declare class DataKubernetesPodV1SpecSecurityContextOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecSecurityContext | undefined;
    set internalValue(value: DataKubernetesPodV1SpecSecurityContext | undefined);
    get fsGroup(): string;
    get runAsGroup(): string;
    get runAsNonRoot(): cdktf.IResolvable;
    get runAsUser(): string;
    private _seLinuxOptions;
    get seLinuxOptions(): DataKubernetesPodV1SpecSecurityContextSeLinuxOptionsList;
    private _seccompProfile;
    get seccompProfile(): DataKubernetesPodV1SpecSecurityContextSeccompProfileList;
    get supplementalGroups(): number[];
    private _sysctl;
    get sysctl(): DataKubernetesPodV1SpecSecurityContextSysctlList;
}
export declare class DataKubernetesPodV1SpecSecurityContextList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecSecurityContextOutputReference;
}
export interface DataKubernetesPodV1SpecToleration {
}
export declare function dataKubernetesPodV1SpecTolerationToTerraform(struct?: DataKubernetesPodV1SpecToleration): any;
export declare function dataKubernetesPodV1SpecTolerationToHclTerraform(struct?: DataKubernetesPodV1SpecToleration): any;
export declare class DataKubernetesPodV1SpecTolerationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecToleration | undefined;
    set internalValue(value: DataKubernetesPodV1SpecToleration | undefined);
    get effect(): string;
    get key(): string;
    get operator(): string;
    get tolerationSeconds(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecTolerationList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecTolerationOutputReference;
}
export interface DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelector {
}
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorToTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelector): any;
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelector): any;
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktf.StringMap;
}
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecTopologySpreadConstraint {
}
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintToTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraint): any;
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintToHclTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraint): any;
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecTopologySpreadConstraint | undefined;
    set internalValue(value: DataKubernetesPodV1SpecTopologySpreadConstraint | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorList;
    get maxSkew(): number;
    get topologyKey(): string;
    get whenUnsatisfiable(): string;
}
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecTopologySpreadConstraintOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeAwsElasticBlockStore {
}
export declare function dataKubernetesPodV1SpecVolumeAwsElasticBlockStoreToTerraform(struct?: DataKubernetesPodV1SpecVolumeAwsElasticBlockStore): any;
export declare function dataKubernetesPodV1SpecVolumeAwsElasticBlockStoreToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeAwsElasticBlockStore): any;
export declare class DataKubernetesPodV1SpecVolumeAwsElasticBlockStoreOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeAwsElasticBlockStore | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeAwsElasticBlockStore | undefined);
    get fsType(): string;
    get partition(): number;
    get readOnly(): cdktf.IResolvable;
    get volumeId(): string;
}
export declare class DataKubernetesPodV1SpecVolumeAwsElasticBlockStoreList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeAwsElasticBlockStoreOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeAzureDisk {
}
export declare function dataKubernetesPodV1SpecVolumeAzureDiskToTerraform(struct?: DataKubernetesPodV1SpecVolumeAzureDisk): any;
export declare function dataKubernetesPodV1SpecVolumeAzureDiskToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeAzureDisk): any;
export declare class DataKubernetesPodV1SpecVolumeAzureDiskOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeAzureDisk | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeAzureDisk | undefined);
    get cachingMode(): string;
    get dataDiskUri(): string;
    get diskName(): string;
    get fsType(): string;
    get kind(): string;
    get readOnly(): cdktf.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeAzureDiskList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeAzureDiskOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeAzureFile {
}
export declare function dataKubernetesPodV1SpecVolumeAzureFileToTerraform(struct?: DataKubernetesPodV1SpecVolumeAzureFile): any;
export declare function dataKubernetesPodV1SpecVolumeAzureFileToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeAzureFile): any;
export declare class DataKubernetesPodV1SpecVolumeAzureFileOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeAzureFile | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeAzureFile | undefined);
    get readOnly(): cdktf.IResolvable;
    get secretName(): string;
    get secretNamespace(): string;
    get shareName(): string;
}
export declare class DataKubernetesPodV1SpecVolumeAzureFileList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeAzureFileOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeCephFsSecretRef {
}
export declare function dataKubernetesPodV1SpecVolumeCephFsSecretRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeCephFsSecretRef): any;
export declare function dataKubernetesPodV1SpecVolumeCephFsSecretRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeCephFsSecretRef): any;
export declare class DataKubernetesPodV1SpecVolumeCephFsSecretRefOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeCephFsSecretRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeCephFsSecretRef | undefined);
    get name(): string;
    get namespace(): string;
}
export declare class DataKubernetesPodV1SpecVolumeCephFsSecretRefList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeCephFsSecretRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeCephFs {
}
export declare function dataKubernetesPodV1SpecVolumeCephFsToTerraform(struct?: DataKubernetesPodV1SpecVolumeCephFs): any;
export declare function dataKubernetesPodV1SpecVolumeCephFsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeCephFs): any;
export declare class DataKubernetesPodV1SpecVolumeCephFsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeCephFs | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeCephFs | undefined);
    get monitors(): string[];
    get path(): string;
    get readOnly(): cdktf.IResolvable;
    get secretFile(): string;
    private _secretRef;
    get secretRef(): DataKubernetesPodV1SpecVolumeCephFsSecretRefList;
    get user(): string;
}
export declare class DataKubernetesPodV1SpecVolumeCephFsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeCephFsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeCinder {
}
export declare function dataKubernetesPodV1SpecVolumeCinderToTerraform(struct?: DataKubernetesPodV1SpecVolumeCinder): any;
export declare function dataKubernetesPodV1SpecVolumeCinderToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeCinder): any;
export declare class DataKubernetesPodV1SpecVolumeCinderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeCinder | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeCinder | undefined);
    get fsType(): string;
    get readOnly(): cdktf.IResolvable;
    get volumeId(): string;
}
export declare class DataKubernetesPodV1SpecVolumeCinderList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeCinderOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeConfigMapItems {
}
export declare function dataKubernetesPodV1SpecVolumeConfigMapItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeConfigMapItems): any;
export declare function dataKubernetesPodV1SpecVolumeConfigMapItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeConfigMapItems): any;
export declare class DataKubernetesPodV1SpecVolumeConfigMapItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeConfigMapItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeConfigMapItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeConfigMapItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeConfigMapItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeConfigMap {
}
export declare function dataKubernetesPodV1SpecVolumeConfigMapToTerraform(struct?: DataKubernetesPodV1SpecVolumeConfigMap): any;
export declare function dataKubernetesPodV1SpecVolumeConfigMapToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeConfigMap): any;
export declare class DataKubernetesPodV1SpecVolumeConfigMapOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeConfigMap | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeConfigMap | undefined);
    get defaultMode(): string;
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeConfigMapItemsList;
    get name(): string;
    get optional(): cdktf.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeConfigMapList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeConfigMapOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRef {
}
export declare function dataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRef): any;
export declare function dataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRef): any;
export declare class DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRef | undefined);
    get name(): string;
}
export declare class DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeCsi {
}
export declare function dataKubernetesPodV1SpecVolumeCsiToTerraform(struct?: DataKubernetesPodV1SpecVolumeCsi): any;
export declare function dataKubernetesPodV1SpecVolumeCsiToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeCsi): any;
export declare class DataKubernetesPodV1SpecVolumeCsiOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeCsi | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeCsi | undefined);
    get driver(): string;
    get fsType(): string;
    private _nodePublishSecretRef;
    get nodePublishSecretRef(): DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefList;
    get readOnly(): cdktf.IResolvable;
    private _volumeAttributes;
    get volumeAttributes(): cdktf.StringMap;
}
export declare class DataKubernetesPodV1SpecVolumeCsiList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeCsiOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRef {
}
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRef): any;
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRef): any;
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRef | undefined);
    get apiVersion(): string;
    get fieldPath(): string;
}
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRef {
}
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRef): any;
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRef): any;
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRef | undefined);
    get containerName(): string;
    get divisor(): string;
    get resource(): string;
}
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeDownwardApiItems {
}
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItems): any;
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItems): any;
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeDownwardApiItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeDownwardApiItems | undefined);
    private _fieldRef;
    get fieldRef(): DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefList;
    get mode(): string;
    get path(): string;
    private _resourceFieldRef;
    get resourceFieldRef(): DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefList;
}
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeDownwardApiItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeDownwardApi {
}
export declare function dataKubernetesPodV1SpecVolumeDownwardApiToTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApi): any;
export declare function dataKubernetesPodV1SpecVolumeDownwardApiToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApi): any;
export declare class DataKubernetesPodV1SpecVolumeDownwardApiOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeDownwardApi | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeDownwardApi | undefined);
    get defaultMode(): string;
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeDownwardApiItemsList;
}
export declare class DataKubernetesPodV1SpecVolumeDownwardApiList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeDownwardApiOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeEmptyDir {
}
export declare function dataKubernetesPodV1SpecVolumeEmptyDirToTerraform(struct?: DataKubernetesPodV1SpecVolumeEmptyDir): any;
export declare function dataKubernetesPodV1SpecVolumeEmptyDirToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeEmptyDir): any;
export declare class DataKubernetesPodV1SpecVolumeEmptyDirOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeEmptyDir | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeEmptyDir | undefined);
    get medium(): string;
    get sizeLimit(): string;
}
export declare class DataKubernetesPodV1SpecVolumeEmptyDirList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeEmptyDirOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeFc {
}
export declare function dataKubernetesPodV1SpecVolumeFcToTerraform(struct?: DataKubernetesPodV1SpecVolumeFc): any;
export declare function dataKubernetesPodV1SpecVolumeFcToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeFc): any;
export declare class DataKubernetesPodV1SpecVolumeFcOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeFc | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeFc | undefined);
    get fsType(): string;
    get lun(): number;
    get readOnly(): cdktf.IResolvable;
    get targetWwNs(): string[];
}
export declare class DataKubernetesPodV1SpecVolumeFcList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeFcOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeFlexVolumeSecretRef {
}
export declare function dataKubernetesPodV1SpecVolumeFlexVolumeSecretRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeFlexVolumeSecretRef): any;
export declare function dataKubernetesPodV1SpecVolumeFlexVolumeSecretRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeFlexVolumeSecretRef): any;
export declare class DataKubernetesPodV1SpecVolumeFlexVolumeSecretRefOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeFlexVolumeSecretRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeFlexVolumeSecretRef | undefined);
    get name(): string;
    get namespace(): string;
}
export declare class DataKubernetesPodV1SpecVolumeFlexVolumeSecretRefList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeFlexVolumeSecretRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeFlexVolume {
}
export declare function dataKubernetesPodV1SpecVolumeFlexVolumeToTerraform(struct?: DataKubernetesPodV1SpecVolumeFlexVolume): any;
export declare function dataKubernetesPodV1SpecVolumeFlexVolumeToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeFlexVolume): any;
export declare class DataKubernetesPodV1SpecVolumeFlexVolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeFlexVolume | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeFlexVolume | undefined);
    get driver(): string;
    get fsType(): string;
    private _options;
    get options(): cdktf.StringMap;
    get readOnly(): cdktf.IResolvable;
    private _secretRef;
    get secretRef(): DataKubernetesPodV1SpecVolumeFlexVolumeSecretRefList;
}
export declare class DataKubernetesPodV1SpecVolumeFlexVolumeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeFlexVolumeOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeFlocker {
}
export declare function dataKubernetesPodV1SpecVolumeFlockerToTerraform(struct?: DataKubernetesPodV1SpecVolumeFlocker): any;
export declare function dataKubernetesPodV1SpecVolumeFlockerToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeFlocker): any;
export declare class DataKubernetesPodV1SpecVolumeFlockerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeFlocker | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeFlocker | undefined);
    get datasetName(): string;
    get datasetUuid(): string;
}
export declare class DataKubernetesPodV1SpecVolumeFlockerList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeFlockerOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeGcePersistentDisk {
}
export declare function dataKubernetesPodV1SpecVolumeGcePersistentDiskToTerraform(struct?: DataKubernetesPodV1SpecVolumeGcePersistentDisk): any;
export declare function dataKubernetesPodV1SpecVolumeGcePersistentDiskToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeGcePersistentDisk): any;
export declare class DataKubernetesPodV1SpecVolumeGcePersistentDiskOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeGcePersistentDisk | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeGcePersistentDisk | undefined);
    get fsType(): string;
    get partition(): number;
    get pdName(): string;
    get readOnly(): cdktf.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeGcePersistentDiskList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeGcePersistentDiskOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeGitRepo {
}
export declare function dataKubernetesPodV1SpecVolumeGitRepoToTerraform(struct?: DataKubernetesPodV1SpecVolumeGitRepo): any;
export declare function dataKubernetesPodV1SpecVolumeGitRepoToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeGitRepo): any;
export declare class DataKubernetesPodV1SpecVolumeGitRepoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeGitRepo | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeGitRepo | undefined);
    get directory(): string;
    get repository(): string;
    get revision(): string;
}
export declare class DataKubernetesPodV1SpecVolumeGitRepoList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeGitRepoOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeGlusterfs {
}
export declare function dataKubernetesPodV1SpecVolumeGlusterfsToTerraform(struct?: DataKubernetesPodV1SpecVolumeGlusterfs): any;
export declare function dataKubernetesPodV1SpecVolumeGlusterfsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeGlusterfs): any;
export declare class DataKubernetesPodV1SpecVolumeGlusterfsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeGlusterfs | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeGlusterfs | undefined);
    get endpointsName(): string;
    get path(): string;
    get readOnly(): cdktf.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeGlusterfsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeGlusterfsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeHostPath {
}
export declare function dataKubernetesPodV1SpecVolumeHostPathToTerraform(struct?: DataKubernetesPodV1SpecVolumeHostPath): any;
export declare function dataKubernetesPodV1SpecVolumeHostPathToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeHostPath): any;
export declare class DataKubernetesPodV1SpecVolumeHostPathOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeHostPath | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeHostPath | undefined);
    get path(): string;
    get type(): string;
}
export declare class DataKubernetesPodV1SpecVolumeHostPathList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeHostPathOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeIscsi {
}
export declare function dataKubernetesPodV1SpecVolumeIscsiToTerraform(struct?: DataKubernetesPodV1SpecVolumeIscsi): any;
export declare function dataKubernetesPodV1SpecVolumeIscsiToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeIscsi): any;
export declare class DataKubernetesPodV1SpecVolumeIscsiOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeIscsi | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeIscsi | undefined);
    get fsType(): string;
    get iqn(): string;
    get iscsiInterface(): string;
    get lun(): number;
    get readOnly(): cdktf.IResolvable;
    get targetPortal(): string;
}
export declare class DataKubernetesPodV1SpecVolumeIscsiList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeIscsiOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeLocal {
}
export declare function dataKubernetesPodV1SpecVolumeLocalToTerraform(struct?: DataKubernetesPodV1SpecVolumeLocal): any;
export declare function dataKubernetesPodV1SpecVolumeLocalToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeLocal): any;
export declare class DataKubernetesPodV1SpecVolumeLocalOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeLocal | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeLocal | undefined);
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeLocalList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeLocalOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeNfs {
}
export declare function dataKubernetesPodV1SpecVolumeNfsToTerraform(struct?: DataKubernetesPodV1SpecVolumeNfs): any;
export declare function dataKubernetesPodV1SpecVolumeNfsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeNfs): any;
export declare class DataKubernetesPodV1SpecVolumeNfsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeNfs | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeNfs | undefined);
    get path(): string;
    get readOnly(): cdktf.IResolvable;
    get server(): string;
}
export declare class DataKubernetesPodV1SpecVolumeNfsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeNfsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumePersistentVolumeClaim {
}
export declare function dataKubernetesPodV1SpecVolumePersistentVolumeClaimToTerraform(struct?: DataKubernetesPodV1SpecVolumePersistentVolumeClaim): any;
export declare function dataKubernetesPodV1SpecVolumePersistentVolumeClaimToHclTerraform(struct?: DataKubernetesPodV1SpecVolumePersistentVolumeClaim): any;
export declare class DataKubernetesPodV1SpecVolumePersistentVolumeClaimOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumePersistentVolumeClaim | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumePersistentVolumeClaim | undefined);
    get claimName(): string;
    get readOnly(): cdktf.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumePersistentVolumeClaimList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumePersistentVolumeClaimOutputReference;
}
export interface DataKubernetesPodV1SpecVolumePhotonPersistentDisk {
}
export declare function dataKubernetesPodV1SpecVolumePhotonPersistentDiskToTerraform(struct?: DataKubernetesPodV1SpecVolumePhotonPersistentDisk): any;
export declare function dataKubernetesPodV1SpecVolumePhotonPersistentDiskToHclTerraform(struct?: DataKubernetesPodV1SpecVolumePhotonPersistentDisk): any;
export declare class DataKubernetesPodV1SpecVolumePhotonPersistentDiskOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumePhotonPersistentDisk | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumePhotonPersistentDisk | undefined);
    get fsType(): string;
    get pdId(): string;
}
export declare class DataKubernetesPodV1SpecVolumePhotonPersistentDiskList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumePhotonPersistentDiskOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItems {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItems): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItems): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMap {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMap): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMap): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMap | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMap | undefined);
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsList;
    get name(): string;
    get optional(): cdktf.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRef {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRef): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRef): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined);
    get apiVersion(): string;
    get fieldPath(): string;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined);
    get containerName(): string;
    get divisor(): string;
    get resource(): string;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItems {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItems): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItems): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItems | undefined);
    private _fieldRef;
    get fieldRef(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefList;
    get mode(): string;
    get path(): string;
    private _resourceFieldRef;
    get resourceFieldRef(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefList;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApi {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApi): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApi): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApi | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApi | undefined);
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsList;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItems {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItems): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItems): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesSecret {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesSecretToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesSecret): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesSecretToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesSecret): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesSecretOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesSecret | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesSecret | undefined);
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsList;
    get name(): string;
    get optional(): cdktf.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesSecretList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesSecretOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountToken {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountToken): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountToken): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountToken | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountToken | undefined);
    get audience(): string;
    get expirationSeconds(): number;
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSources {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSources): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSources): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSources | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSources | undefined);
    private _configMap;
    get configMap(): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapList;
    private _downwardApi;
    get downwardApi(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiList;
    private _secret;
    get secret(): DataKubernetesPodV1SpecVolumeProjectedSourcesSecretList;
    private _serviceAccountToken;
    get serviceAccountToken(): DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenList;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjected {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjected): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjected): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjected | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjected | undefined);
    get defaultMode(): string;
    private _sources;
    get sources(): DataKubernetesPodV1SpecVolumeProjectedSourcesList;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeQuobyte {
}
export declare function dataKubernetesPodV1SpecVolumeQuobyteToTerraform(struct?: DataKubernetesPodV1SpecVolumeQuobyte): any;
export declare function dataKubernetesPodV1SpecVolumeQuobyteToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeQuobyte): any;
export declare class DataKubernetesPodV1SpecVolumeQuobyteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeQuobyte | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeQuobyte | undefined);
    get group(): string;
    get readOnly(): cdktf.IResolvable;
    get registry(): string;
    get user(): string;
    get volume(): string;
}
export declare class DataKubernetesPodV1SpecVolumeQuobyteList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeQuobyteOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeRbdSecretRef {
}
export declare function dataKubernetesPodV1SpecVolumeRbdSecretRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeRbdSecretRef): any;
export declare function dataKubernetesPodV1SpecVolumeRbdSecretRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeRbdSecretRef): any;
export declare class DataKubernetesPodV1SpecVolumeRbdSecretRefOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeRbdSecretRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeRbdSecretRef | undefined);
    get name(): string;
    get namespace(): string;
}
export declare class DataKubernetesPodV1SpecVolumeRbdSecretRefList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeRbdSecretRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeRbd {
}
export declare function dataKubernetesPodV1SpecVolumeRbdToTerraform(struct?: DataKubernetesPodV1SpecVolumeRbd): any;
export declare function dataKubernetesPodV1SpecVolumeRbdToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeRbd): any;
export declare class DataKubernetesPodV1SpecVolumeRbdOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeRbd | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeRbd | undefined);
    get cephMonitors(): string[];
    get fsType(): string;
    get keyring(): string;
    get radosUser(): string;
    get rbdImage(): string;
    get rbdPool(): string;
    get readOnly(): cdktf.IResolvable;
    private _secretRef;
    get secretRef(): DataKubernetesPodV1SpecVolumeRbdSecretRefList;
}
export declare class DataKubernetesPodV1SpecVolumeRbdList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeRbdOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeSecretItems {
}
export declare function dataKubernetesPodV1SpecVolumeSecretItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeSecretItems): any;
export declare function dataKubernetesPodV1SpecVolumeSecretItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeSecretItems): any;
export declare class DataKubernetesPodV1SpecVolumeSecretItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeSecretItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeSecretItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeSecretItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeSecretItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeSecret {
}
export declare function dataKubernetesPodV1SpecVolumeSecretToTerraform(struct?: DataKubernetesPodV1SpecVolumeSecret): any;
export declare function dataKubernetesPodV1SpecVolumeSecretToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeSecret): any;
export declare class DataKubernetesPodV1SpecVolumeSecretOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeSecret | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeSecret | undefined);
    get defaultMode(): string;
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeSecretItemsList;
    get optional(): cdktf.IResolvable;
    get secretName(): string;
}
export declare class DataKubernetesPodV1SpecVolumeSecretList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeSecretOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeVsphereVolume {
}
export declare function dataKubernetesPodV1SpecVolumeVsphereVolumeToTerraform(struct?: DataKubernetesPodV1SpecVolumeVsphereVolume): any;
export declare function dataKubernetesPodV1SpecVolumeVsphereVolumeToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeVsphereVolume): any;
export declare class DataKubernetesPodV1SpecVolumeVsphereVolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeVsphereVolume | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeVsphereVolume | undefined);
    get fsType(): string;
    get volumePath(): string;
}
export declare class DataKubernetesPodV1SpecVolumeVsphereVolumeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeVsphereVolumeOutputReference;
}
export interface DataKubernetesPodV1SpecVolume {
}
export declare function dataKubernetesPodV1SpecVolumeToTerraform(struct?: DataKubernetesPodV1SpecVolume): any;
export declare function dataKubernetesPodV1SpecVolumeToHclTerraform(struct?: DataKubernetesPodV1SpecVolume): any;
export declare class DataKubernetesPodV1SpecVolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolume | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolume | undefined);
    private _awsElasticBlockStore;
    get awsElasticBlockStore(): DataKubernetesPodV1SpecVolumeAwsElasticBlockStoreList;
    private _azureDisk;
    get azureDisk(): DataKubernetesPodV1SpecVolumeAzureDiskList;
    private _azureFile;
    get azureFile(): DataKubernetesPodV1SpecVolumeAzureFileList;
    private _cephFs;
    get cephFs(): DataKubernetesPodV1SpecVolumeCephFsList;
    private _cinder;
    get cinder(): DataKubernetesPodV1SpecVolumeCinderList;
    private _configMap;
    get configMap(): DataKubernetesPodV1SpecVolumeConfigMapList;
    private _csi;
    get csi(): DataKubernetesPodV1SpecVolumeCsiList;
    private _downwardApi;
    get downwardApi(): DataKubernetesPodV1SpecVolumeDownwardApiList;
    private _emptyDir;
    get emptyDir(): DataKubernetesPodV1SpecVolumeEmptyDirList;
    private _fc;
    get fc(): DataKubernetesPodV1SpecVolumeFcList;
    private _flexVolume;
    get flexVolume(): DataKubernetesPodV1SpecVolumeFlexVolumeList;
    private _flocker;
    get flocker(): DataKubernetesPodV1SpecVolumeFlockerList;
    private _gcePersistentDisk;
    get gcePersistentDisk(): DataKubernetesPodV1SpecVolumeGcePersistentDiskList;
    private _gitRepo;
    get gitRepo(): DataKubernetesPodV1SpecVolumeGitRepoList;
    private _glusterfs;
    get glusterfs(): DataKubernetesPodV1SpecVolumeGlusterfsList;
    private _hostPath;
    get hostPath(): DataKubernetesPodV1SpecVolumeHostPathList;
    private _iscsi;
    get iscsi(): DataKubernetesPodV1SpecVolumeIscsiList;
    private _local;
    get local(): DataKubernetesPodV1SpecVolumeLocalList;
    get name(): string;
    private _nfs;
    get nfs(): DataKubernetesPodV1SpecVolumeNfsList;
    private _persistentVolumeClaim;
    get persistentVolumeClaim(): DataKubernetesPodV1SpecVolumePersistentVolumeClaimList;
    private _photonPersistentDisk;
    get photonPersistentDisk(): DataKubernetesPodV1SpecVolumePhotonPersistentDiskList;
    private _projected;
    get projected(): DataKubernetesPodV1SpecVolumeProjectedList;
    private _quobyte;
    get quobyte(): DataKubernetesPodV1SpecVolumeQuobyteList;
    private _rbd;
    get rbd(): DataKubernetesPodV1SpecVolumeRbdList;
    private _secret;
    get secret(): DataKubernetesPodV1SpecVolumeSecretList;
    private _vsphereVolume;
    get vsphereVolume(): DataKubernetesPodV1SpecVolumeVsphereVolumeList;
}
export declare class DataKubernetesPodV1SpecVolumeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeOutputReference;
}
export interface DataKubernetesPodV1Spec {
}
export declare function dataKubernetesPodV1SpecToTerraform(struct?: DataKubernetesPodV1Spec): any;
export declare function dataKubernetesPodV1SpecToHclTerraform(struct?: DataKubernetesPodV1Spec): any;
export declare class DataKubernetesPodV1SpecOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1Spec | undefined;
    set internalValue(value: DataKubernetesPodV1Spec | undefined);
    get activeDeadlineSeconds(): number;
    private _affinity;
    get affinity(): DataKubernetesPodV1SpecAffinityList;
    get automountServiceAccountToken(): cdktf.IResolvable;
    private _container;
    get container(): DataKubernetesPodV1SpecContainerList;
    private _dnsConfig;
    get dnsConfig(): DataKubernetesPodV1SpecDnsConfigList;
    get dnsPolicy(): string;
    get enableServiceLinks(): cdktf.IResolvable;
    private _hostAliases;
    get hostAliases(): DataKubernetesPodV1SpecHostAliasesList;
    get hostIpc(): cdktf.IResolvable;
    get hostNetwork(): cdktf.IResolvable;
    get hostPid(): cdktf.IResolvable;
    get hostname(): string;
    private _imagePullSecrets;
    get imagePullSecrets(): DataKubernetesPodV1SpecImagePullSecretsList;
    private _initContainer;
    get initContainer(): DataKubernetesPodV1SpecInitContainerList;
    get nodeName(): string;
    private _nodeSelector;
    get nodeSelector(): cdktf.StringMap;
    get priorityClassName(): string;
    private _readinessGate;
    get readinessGate(): DataKubernetesPodV1SpecReadinessGateList;
    get restartPolicy(): string;
    private _securityContext;
    get securityContext(): DataKubernetesPodV1SpecSecurityContextList;
    get serviceAccountName(): string;
    get shareProcessNamespace(): cdktf.IResolvable;
    get subdomain(): string;
    get terminationGracePeriodSeconds(): number;
    private _toleration;
    get toleration(): DataKubernetesPodV1SpecTolerationList;
    private _topologySpreadConstraint;
    get topologySpreadConstraint(): DataKubernetesPodV1SpecTopologySpreadConstraintList;
    private _volume;
    get volume(): DataKubernetesPodV1SpecVolumeList;
}
export declare class DataKubernetesPodV1SpecList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecOutputReference;
}
export interface DataKubernetesPodV1Metadata {
    /**
    * An unstructured key value map stored with the pod that may be used to store arbitrary metadata. More info: http://kubernetes.io/docs/user-guide/annotations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/data-sources/pod_v1#annotations DataKubernetesPodV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. Read more: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/data-sources/pod_v1#generate_name DataKubernetesPodV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the pod. May match selectors of replication controllers and services. More info: http://kubernetes.io/docs/user-guide/labels
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/data-sources/pod_v1#labels DataKubernetesPodV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the pod, must be unique. Cannot be updated. More info: http://kubernetes.io/docs/user-guide/identifiers#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/data-sources/pod_v1#name DataKubernetesPodV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the pod must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/data-sources/pod_v1#namespace DataKubernetesPodV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPodV1MetadataToTerraform(struct?: DataKubernetesPodV1MetadataOutputReference | DataKubernetesPodV1Metadata): any;
export declare function dataKubernetesPodV1MetadataToHclTerraform(struct?: DataKubernetesPodV1MetadataOutputReference | DataKubernetesPodV1Metadata): any;
export declare class DataKubernetesPodV1MetadataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPodV1Metadata | undefined;
    set internalValue(value: DataKubernetesPodV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
