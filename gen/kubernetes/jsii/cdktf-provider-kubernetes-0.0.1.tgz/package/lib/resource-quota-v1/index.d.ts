import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ResourceQuotaV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#id ResourceQuotaV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#metadata ResourceQuotaV1#metadata}
    */
    readonly metadata: ResourceQuotaV1Metadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#spec ResourceQuotaV1#spec}
    */
    readonly spec?: ResourceQuotaV1Spec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#timeouts ResourceQuotaV1#timeouts}
    */
    readonly timeouts?: ResourceQuotaV1Timeouts;
}
export interface ResourceQuotaV1Metadata {
    /**
    * An unstructured key value map stored with the resource quota that may be used to store arbitrary metadata. More info: http://kubernetes.io/docs/user-guide/annotations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#annotations ResourceQuotaV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. Read more: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#generate_name ResourceQuotaV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the resource quota. May match selectors of replication controllers and services. More info: http://kubernetes.io/docs/user-guide/labels
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#labels ResourceQuotaV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the resource quota, must be unique. Cannot be updated. More info: http://kubernetes.io/docs/user-guide/identifiers#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#name ResourceQuotaV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the resource quota must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#namespace ResourceQuotaV1#namespace}
    */
    readonly namespace?: string;
}
export declare function resourceQuotaV1MetadataToTerraform(struct?: ResourceQuotaV1MetadataOutputReference | ResourceQuotaV1Metadata): any;
export declare function resourceQuotaV1MetadataToHclTerraform(struct?: ResourceQuotaV1MetadataOutputReference | ResourceQuotaV1Metadata): any;
export declare class ResourceQuotaV1MetadataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ResourceQuotaV1Metadata | undefined;
    set internalValue(value: ResourceQuotaV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface ResourceQuotaV1SpecScopeSelectorMatchExpression {
    /**
    * Represents a scope's relationship to a set of values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#operator ResourceQuotaV1#operator}
    */
    readonly operator: string;
    /**
    * The name of the scope that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#scope_name ResourceQuotaV1#scope_name}
    */
    readonly scopeName: string;
    /**
    * A list of scope selector requirements by scope of the resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#values ResourceQuotaV1#values}
    */
    readonly values?: string[];
}
export declare function resourceQuotaV1SpecScopeSelectorMatchExpressionToTerraform(struct?: ResourceQuotaV1SpecScopeSelectorMatchExpression | cdktf.IResolvable): any;
export declare function resourceQuotaV1SpecScopeSelectorMatchExpressionToHclTerraform(struct?: ResourceQuotaV1SpecScopeSelectorMatchExpression | cdktf.IResolvable): any;
export declare class ResourceQuotaV1SpecScopeSelectorMatchExpressionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ResourceQuotaV1SpecScopeSelectorMatchExpression | cdktf.IResolvable | undefined;
    set internalValue(value: ResourceQuotaV1SpecScopeSelectorMatchExpression | cdktf.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _scopeName?;
    get scopeName(): string;
    set scopeName(value: string);
    get scopeNameInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ResourceQuotaV1SpecScopeSelectorMatchExpressionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ResourceQuotaV1SpecScopeSelectorMatchExpression[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ResourceQuotaV1SpecScopeSelectorMatchExpressionOutputReference;
}
export interface ResourceQuotaV1SpecScopeSelector {
    /**
    * match_expression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#match_expression ResourceQuotaV1#match_expression}
    */
    readonly matchExpression?: ResourceQuotaV1SpecScopeSelectorMatchExpression[] | cdktf.IResolvable;
}
export declare function resourceQuotaV1SpecScopeSelectorToTerraform(struct?: ResourceQuotaV1SpecScopeSelectorOutputReference | ResourceQuotaV1SpecScopeSelector): any;
export declare function resourceQuotaV1SpecScopeSelectorToHclTerraform(struct?: ResourceQuotaV1SpecScopeSelectorOutputReference | ResourceQuotaV1SpecScopeSelector): any;
export declare class ResourceQuotaV1SpecScopeSelectorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ResourceQuotaV1SpecScopeSelector | undefined;
    set internalValue(value: ResourceQuotaV1SpecScopeSelector | undefined);
    private _matchExpression;
    get matchExpression(): ResourceQuotaV1SpecScopeSelectorMatchExpressionList;
    putMatchExpression(value: ResourceQuotaV1SpecScopeSelectorMatchExpression[] | cdktf.IResolvable): void;
    resetMatchExpression(): void;
    get matchExpressionInput(): cdktf.IResolvable | ResourceQuotaV1SpecScopeSelectorMatchExpression[] | undefined;
}
export interface ResourceQuotaV1Spec {
    /**
    * The set of desired hard limits for each named resource. More info: http://releases.k8s.io/HEAD/docs/design/admission_control_resource_quota.md#admissioncontrol-plugin-resourcequota
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#hard ResourceQuotaV1#hard}
    */
    readonly hard?: {
        [key: string]: string;
    };
    /**
    * A collection of filters that must match each object tracked by a quota. If not specified, the quota matches all objects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#scopes ResourceQuotaV1#scopes}
    */
    readonly scopes?: string[];
    /**
    * scope_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#scope_selector ResourceQuotaV1#scope_selector}
    */
    readonly scopeSelector?: ResourceQuotaV1SpecScopeSelector;
}
export declare function resourceQuotaV1SpecToTerraform(struct?: ResourceQuotaV1SpecOutputReference | ResourceQuotaV1Spec): any;
export declare function resourceQuotaV1SpecToHclTerraform(struct?: ResourceQuotaV1SpecOutputReference | ResourceQuotaV1Spec): any;
export declare class ResourceQuotaV1SpecOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ResourceQuotaV1Spec | undefined;
    set internalValue(value: ResourceQuotaV1Spec | undefined);
    private _hard?;
    get hard(): {
        [key: string]: string;
    };
    set hard(value: {
        [key: string]: string;
    });
    resetHard(): void;
    get hardInput(): {
        [key: string]: string;
    } | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _scopeSelector;
    get scopeSelector(): ResourceQuotaV1SpecScopeSelectorOutputReference;
    putScopeSelector(value: ResourceQuotaV1SpecScopeSelector): void;
    resetScopeSelector(): void;
    get scopeSelectorInput(): ResourceQuotaV1SpecScopeSelector | undefined;
}
export interface ResourceQuotaV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#create ResourceQuotaV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#update ResourceQuotaV1#update}
    */
    readonly update?: string;
}
export declare function resourceQuotaV1TimeoutsToTerraform(struct?: ResourceQuotaV1Timeouts | cdktf.IResolvable): any;
export declare function resourceQuotaV1TimeoutsToHclTerraform(struct?: ResourceQuotaV1Timeouts | cdktf.IResolvable): any;
export declare class ResourceQuotaV1TimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ResourceQuotaV1Timeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ResourceQuotaV1Timeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1 kubernetes_resource_quota_v1}
*/
export declare class ResourceQuotaV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "kubernetes_resource_quota_v1";
    /**
    * Generates CDKTF code for importing a ResourceQuotaV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ResourceQuotaV1 to import
    * @param importFromId The id of the existing ResourceQuotaV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ResourceQuotaV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/resource_quota_v1 kubernetes_resource_quota_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ResourceQuotaV1Config
    */
    constructor(scope: Construct, id: string, config: ResourceQuotaV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): ResourceQuotaV1MetadataOutputReference;
    putMetadata(value: ResourceQuotaV1Metadata): void;
    get metadataInput(): ResourceQuotaV1Metadata | undefined;
    private _spec;
    get spec(): ResourceQuotaV1SpecOutputReference;
    putSpec(value: ResourceQuotaV1Spec): void;
    resetSpec(): void;
    get specInput(): ResourceQuotaV1Spec | undefined;
    private _timeouts;
    get timeouts(): ResourceQuotaV1TimeoutsOutputReference;
    putTimeouts(value: ResourceQuotaV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ResourceQuotaV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
