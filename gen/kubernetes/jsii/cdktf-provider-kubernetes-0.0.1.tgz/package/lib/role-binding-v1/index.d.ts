import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RoleBindingV1Config extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#id RoleBindingV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#metadata RoleBindingV1#metadata}
    */
    readonly metadata: RoleBindingV1Metadata;
    /**
    * role_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#role_ref RoleBindingV1#role_ref}
    */
    readonly roleRef: RoleBindingV1RoleRef;
    /**
    * subject block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#subject RoleBindingV1#subject}
    */
    readonly subject: RoleBindingV1Subject[] | cdktf.IResolvable;
}
export interface RoleBindingV1Metadata {
    /**
    * An unstructured key value map stored with the roleBinding that may be used to store arbitrary metadata. More info: http://kubernetes.io/docs/user-guide/annotations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#annotations RoleBindingV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the roleBinding. May match selectors of replication controllers and services. More info: http://kubernetes.io/docs/user-guide/labels
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#labels RoleBindingV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the roleBinding, must be unique. Cannot be updated. More info: http://kubernetes.io/docs/user-guide/identifiers#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#name RoleBindingV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the roleBinding must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#namespace RoleBindingV1#namespace}
    */
    readonly namespace?: string;
}
export declare function roleBindingV1MetadataToTerraform(struct?: RoleBindingV1MetadataOutputReference | RoleBindingV1Metadata): any;
export declare function roleBindingV1MetadataToHclTerraform(struct?: RoleBindingV1MetadataOutputReference | RoleBindingV1Metadata): any;
export declare class RoleBindingV1MetadataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RoleBindingV1Metadata | undefined;
    set internalValue(value: RoleBindingV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface RoleBindingV1RoleRef {
    /**
    * The API group of the user. The only value possible at the moment is `rbac.authorization.k8s.io`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#api_group RoleBindingV1#api_group}
    */
    readonly apiGroup: string;
    /**
    * The kind of resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#kind RoleBindingV1#kind}
    */
    readonly kind: string;
    /**
    * The name of the User to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#name RoleBindingV1#name}
    */
    readonly name: string;
}
export declare function roleBindingV1RoleRefToTerraform(struct?: RoleBindingV1RoleRefOutputReference | RoleBindingV1RoleRef): any;
export declare function roleBindingV1RoleRefToHclTerraform(struct?: RoleBindingV1RoleRefOutputReference | RoleBindingV1RoleRef): any;
export declare class RoleBindingV1RoleRefOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RoleBindingV1RoleRef | undefined;
    set internalValue(value: RoleBindingV1RoleRef | undefined);
    private _apiGroup?;
    get apiGroup(): string;
    set apiGroup(value: string);
    get apiGroupInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface RoleBindingV1Subject {
    /**
    * The API group of the subject resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#api_group RoleBindingV1#api_group}
    */
    readonly apiGroup?: string;
    /**
    * The kind of resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#kind RoleBindingV1#kind}
    */
    readonly kind: string;
    /**
    * The name of the resource to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#name RoleBindingV1#name}
    */
    readonly name: string;
    /**
    * The Namespace of the subject resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#namespace RoleBindingV1#namespace}
    */
    readonly namespace?: string;
}
export declare function roleBindingV1SubjectToTerraform(struct?: RoleBindingV1Subject | cdktf.IResolvable): any;
export declare function roleBindingV1SubjectToHclTerraform(struct?: RoleBindingV1Subject | cdktf.IResolvable): any;
export declare class RoleBindingV1SubjectOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RoleBindingV1Subject | cdktf.IResolvable | undefined;
    set internalValue(value: RoleBindingV1Subject | cdktf.IResolvable | undefined);
    private _apiGroup?;
    get apiGroup(): string;
    set apiGroup(value: string);
    resetApiGroup(): void;
    get apiGroupInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export declare class RoleBindingV1SubjectList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RoleBindingV1Subject[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RoleBindingV1SubjectOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1 kubernetes_role_binding_v1}
*/
export declare class RoleBindingV1 extends cdktf.TerraformResource {
    static readonly tfResourceType = "kubernetes_role_binding_v1";
    /**
    * Generates CDKTF code for importing a RoleBindingV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RoleBindingV1 to import
    * @param importFromId The id of the existing RoleBindingV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RoleBindingV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.15.0/docs/resources/role_binding_v1 kubernetes_role_binding_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RoleBindingV1Config
    */
    constructor(scope: Construct, id: string, config: RoleBindingV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): RoleBindingV1MetadataOutputReference;
    putMetadata(value: RoleBindingV1Metadata): void;
    get metadataInput(): RoleBindingV1Metadata | undefined;
    private _roleRef;
    get roleRef(): RoleBindingV1RoleRefOutputReference;
    putRoleRef(value: RoleBindingV1RoleRef): void;
    get roleRefInput(): RoleBindingV1RoleRef | undefined;
    private _subject;
    get subject(): RoleBindingV1SubjectList;
    putSubject(value: RoleBindingV1Subject[] | cdktf.IResolvable): void;
    get subjectInput(): cdktf.IResolvable | RoleBindingV1Subject[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
