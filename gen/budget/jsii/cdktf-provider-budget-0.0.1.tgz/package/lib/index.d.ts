import { TerraformModule, TerraformModuleUserConfig } from 'cdktf';
import { Construct } from 'constructs';
export interface BudgetConfig extends TerraformModuleUserConfig {
    /**
    * The name of the Cloud Pub/Sub topic where budget related messages will be published, in the form of `projects/{project_id}/topics/{topic_id}`
    */
    readonly alertPubsubTopic?: string;
    /**
    * The type of basis used to determine if spend has passed the threshold
    * CURRENT_SPEND
    */
    readonly alertSpendBasis?: string;
    /**
    * A list of percentages of the budget to alert on when threshold is exceeded
    * 0.5
    * 0.7
    * 1
    */
    readonly alertSpentPercents?: number[];
    /**
    * The amount to use as the budget
    */
    readonly amount: number;
    /**
    * ID of the billing account to set a budget on
    */
    readonly billingAccount: string;
    /**
    * Specifies the calendar period for the budget. Possible values are MONTH, QUARTER, YEAR, CALENDAR_PERIOD_UNSPECIFIED, CUSTOM. custom_period_start_date and custom_period_end_date must be set if CUSTOM
    */
    readonly calendarPeriod?: string;
    /**
    * If the budget should be created
    * true
    */
    readonly createBudget?: boolean;
    /**
    * Specifies how credits should be treated when determining spend for threshold calculations
    * INCLUDE_ALL_CREDITS
    */
    readonly creditTypesTreatment?: string;
    /**
    * Specifies the end date (DD-MM-YYYY) for the calendar_period CUSTOM
    */
    readonly customPeriodEndDate?: string;
    /**
    * Specifies the start date (DD-MM-YYYY) for the calendar_period CUSTOM
    */
    readonly customPeriodStartDate?: string;
    /**
    * The display name of the budget. If not set defaults to `Budget For <projects[0]|All Projects>`
    */
    readonly displayName?: string;
    /**
    * A single label and value pair specifying that usage from only this set of labeled resources should be included in the budget.
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * A list of monitoring notification channels in the form `[projects/{project_id}/notificationChannels/{channel_id}]`. A maximum of 5 channels are allowed.
    *
    */
    readonly monitoringNotificationChannels?: string[];
    /**
    * The project ids to include in this budget. If empty budget will include all projects
    */
    readonly projects: string[];
    /**
    * A list of services ids to be included in the budget. If omitted, all services will be included in the budget. Service ids can be found at https://cloud.google.com/skus/
    */
    readonly services?: string[];
}
/**
* Defines an Budget based on a Terraform module
*
* Docs at Terraform Registry: {@link https://registry.terraform.io/modules/terraform-google-modules/project-factory/google/18.2.0/submodules/budget terraform-google-modules/project-factory/google//modules/budget}
*/
export declare class Budget extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: BudgetConfig);
    get alertPubsubTopic(): string | undefined;
    set alertPubsubTopic(value: string | undefined);
    get alertSpendBasis(): string | undefined;
    set alertSpendBasis(value: string | undefined);
    get alertSpentPercents(): number[] | undefined;
    set alertSpentPercents(value: number[] | undefined);
    get amount(): number;
    set amount(value: number);
    get billingAccount(): string;
    set billingAccount(value: string);
    get calendarPeriod(): string | undefined;
    set calendarPeriod(value: string | undefined);
    get createBudget(): boolean | undefined;
    set createBudget(value: boolean | undefined);
    get creditTypesTreatment(): string | undefined;
    set creditTypesTreatment(value: string | undefined);
    get customPeriodEndDate(): string | undefined;
    set customPeriodEndDate(value: string | undefined);
    get customPeriodStartDate(): string | undefined;
    set customPeriodStartDate(value: string | undefined);
    get displayName(): string | undefined;
    set displayName(value: string | undefined);
    get labels(): {
        [key: string]: string;
    } | undefined;
    set labels(value: {
        [key: string]: string;
    } | undefined);
    get monitoringNotificationChannels(): string[] | undefined;
    set monitoringNotificationChannels(value: string[] | undefined);
    get projects(): string[];
    set projects(value: string[]);
    get services(): string[] | undefined;
    set services(value: string[] | undefined);
    get nameOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
