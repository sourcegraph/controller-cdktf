import { TerraformModule, type TerraformModuleUserConfig } from 'cdktn';
import { Construct } from 'constructs';
export interface ObservegcpConfig extends TerraformModuleUserConfig {
    /**
    * The number of days to wait before deleting AbortIncompleteMultipartUpload.
    * 7
    */
    readonly bucketLifecycleAbortUploadDays?: number;
    /**
    * The number of days to wait before Delete of temporary bucket files.
    * 14
    */
    readonly bucketLifecycleDeleteDays?: number;
    /**
    * The debug level for the GCP cloud functions
    * WARNING
    */
    readonly cloudFunctionDebugLevel?: string;
    /**
    * Whether to enable the Cloud function that tracks GCP assets.
    * true
    */
    readonly enableAssetTracking?: boolean;
    /**
    * DEPRECATED: This variable has been renamed to 'enable_asset_tracking'. Please update your configuration to use 'enable_asset_tracking' instead.
    */
    readonly enableFunction?: boolean;
    /**
    * Whether to include all children Projects of a Folder when collecting logs
    * true
    */
    readonly folderIncludeChildren?: boolean;
    /**
    * Memory (in MB), available to the function. Default value is 512. Possible values include 128, 256, 512, 1024, etc.
    * 4,096
    */
    readonly functionAvailableMemoryMb?: number;
    /**
    * GCS bucket containing the Cloud Function source code
    * observeinc
    */
    readonly functionBucket?: string;
    /**
    * Whether to disable function logging.
    */
    readonly functionDisableLogging?: boolean;
    /**
    * The limit on the maximum number of function instances that may coexist at a given time.
    * 100
    */
    readonly functionMaxInstances?: number;
    /**
    * GCS object key of the Cloud Function source code zip file. Will use the latest release unless modified.
    * google-cloud-functions-latest.zip
    */
    readonly functionObject?: string;
    /**
    * A list of IAM roles to give the Cloud Function.
    *
    * roles/compute.viewer
    * roles/iam.serviceAccountViewer
    * roles/cloudscheduler.viewer
    * roles/cloudasset.viewer
    * roles/browser
    * roles/logging.viewer
    * roles/monitoring.viewer
    * roles/storage.objectCreator
    * roles/storage.objectViewer
    * roles/storage.objectAdmin
    * roles/storage.admin
    * roles/cloudfunctions.invoker
    * roles/cloudtasks.enqueuer
    * roles/cloudtasks.viewer
    * roles/cloudtasks.taskDeleter
    * roles/iam.serviceAccountUser
    */
    readonly functionRoles?: string[];
    /**
    * Cron schedule for the job
    * 0 * * * *
    */
    readonly functionScheduleFrequency?: string;
    /**
    * Cron schedule for the job
    * * /5 * * * *
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly functionScheduleFrequencyRestOfAssets?: string;
    /**
    * Timeout (in seconds) for the function. Default value is 300 seconds. Cannot be more than 540 seconds.
    *
    * 300
    */
    readonly functionTimeout?: number;
    /**
    * The location where the Task Queue will be created.
    * us-central1
    */
    readonly gcpRegion?: string;
    /**
    * A map of labels to add to resources (https://cloud.google.com/resource-manager/docs/creating-managing-labels)"
    *
    * Note: Many, but not all, Google Cloud SDK resources support labels.
    *
    * The property type contains a map, they have special handling, please see {@link cdk.tf/module-map-inputs the docs}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Log entries that match any of these exclusion filters will not be exported.
    *
    * If a log entry is matched by both logging_filter and one of logging_exclusions it will not be exported.
    *
    * Relevant docs: https://cloud.google.com/logging/docs/reference/v2/rest/v2/billingAccounts.exclusions#LogExclusion
    *
    *
    */
    readonly loggingExclusions?: any;
    /**
    * An advanced logs filter. The only exported log entries are those that are
    * in the resource owning the sink and that match the filter.
    *
    * Relevant docs: https://cloud.google.com/logging/docs/view/building-queries
    *
    */
    readonly loggingFilter?: string;
    /**
    * The maximum number of retry attempts for a task in case of failure.
    * -1
    */
    readonly maxAttempts?: number;
    /**
    * The maximum number of tasks that can be dispatched concurrently.
    * 2
    */
    readonly maxConcurrentDispatches?: number;
    /**
    * The maximum rate at which tasks can be dispatched per second.
    * 2
    */
    readonly maxDispatchesPerSecond?: number;
    /**
    * The time limit for retrying a task in seconds
    * 7200s
    */
    readonly maxRetryDuration?: string;
    /**
    * The minimum amount of time to wait between retries in seconds
    * 30s
    */
    readonly minBackoff?: string;
    /**
    * Module name. Used as a name prefix.
    * obs
    */
    readonly name?: string;
    /**
    * A list of IAM roles to give the Observe poller (through the service account key output).
    *
    * roles/monitoring.viewer
    */
    readonly pollerRoles?: string[];
    /**
    * Billing Project ID needed for asset feed.
    */
    readonly projectId?: string;
    /**
    * Ack deadline for the Pub/Sub subscription (https://cloud.google.com/pubsub/docs/reference/rest/v1/projects.subscriptions)
    * 60
    */
    readonly pubsubAckDeadlineSeconds?: number;
    /**
    * Retry policy maximum backoff for the Pub/Sub subscription (https://cloud.google.com/pubsub/docs/reference/rest/v1/projects.subscriptions)
    * 600s
    */
    readonly pubsubMaximumBackoff?: string;
    /**
    * Message retention for the Pub/Sub subscription (https://cloud.google.com/pubsub/docs/reference/rest/v1/projects.subscriptions)
    * 86400s
    */
    readonly pubsubMessageRetentionDuration?: string;
    /**
    * Retry policy minimum backoff for the Pub/Sub subscription (https://cloud.google.com/pubsub/docs/reference/rest/v1/projects.subscriptions)
    * 10s
    */
    readonly pubsubMinimumBackoff?: string;
    /**
    * The identifier of the GCP Resource to monitor.
    *
    * The resource can be a project, folder, or organization.
    *
    * Examples: "projects/my_project-123", "folders/1234567899", "organizations/34739118321"
    *
    */
    readonly resource: string;
}
/**
* Defines an Observegcp based on a Terraform module
*
* Docs at Terraform Registry: {@link https://registry.terraform.io/modules/observeinc/collection/google/1.0.2 observeinc/collection/google}
*/
export declare class Observegcp extends TerraformModule {
    private readonly inputs;
    constructor(scope: Construct, id: string, config: ObservegcpConfig);
    get bucketLifecycleAbortUploadDays(): number | undefined;
    set bucketLifecycleAbortUploadDays(value: number | undefined);
    get bucketLifecycleDeleteDays(): number | undefined;
    set bucketLifecycleDeleteDays(value: number | undefined);
    get cloudFunctionDebugLevel(): string | undefined;
    set cloudFunctionDebugLevel(value: string | undefined);
    get enableAssetTracking(): boolean | undefined;
    set enableAssetTracking(value: boolean | undefined);
    get enableFunction(): boolean | undefined;
    set enableFunction(value: boolean | undefined);
    get folderIncludeChildren(): boolean | undefined;
    set folderIncludeChildren(value: boolean | undefined);
    get functionAvailableMemoryMb(): number | undefined;
    set functionAvailableMemoryMb(value: number | undefined);
    get functionBucket(): string | undefined;
    set functionBucket(value: string | undefined);
    get functionDisableLogging(): boolean | undefined;
    set functionDisableLogging(value: boolean | undefined);
    get functionMaxInstances(): number | undefined;
    set functionMaxInstances(value: number | undefined);
    get functionObject(): string | undefined;
    set functionObject(value: string | undefined);
    get functionRoles(): string[] | undefined;
    set functionRoles(value: string[] | undefined);
    get functionScheduleFrequency(): string | undefined;
    set functionScheduleFrequency(value: string | undefined);
    get functionScheduleFrequencyRestOfAssets(): string | undefined;
    set functionScheduleFrequencyRestOfAssets(value: string | undefined);
    get functionTimeout(): number | undefined;
    set functionTimeout(value: number | undefined);
    get gcpRegion(): string | undefined;
    set gcpRegion(value: string | undefined);
    get labels(): {
        [key: string]: string;
    } | undefined;
    set labels(value: {
        [key: string]: string;
    } | undefined);
    get loggingExclusions(): any | undefined;
    set loggingExclusions(value: any | undefined);
    get loggingFilter(): string | undefined;
    set loggingFilter(value: string | undefined);
    get maxAttempts(): number | undefined;
    set maxAttempts(value: number | undefined);
    get maxConcurrentDispatches(): number | undefined;
    set maxConcurrentDispatches(value: number | undefined);
    get maxDispatchesPerSecond(): number | undefined;
    set maxDispatchesPerSecond(value: number | undefined);
    get maxRetryDuration(): string | undefined;
    set maxRetryDuration(value: string | undefined);
    get minBackoff(): string | undefined;
    set minBackoff(value: string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get pollerRoles(): string[] | undefined;
    set pollerRoles(value: string[] | undefined);
    get projectId(): string | undefined;
    set projectId(value: string | undefined);
    get pubsubAckDeadlineSeconds(): number | undefined;
    set pubsubAckDeadlineSeconds(value: number | undefined);
    get pubsubMaximumBackoff(): string | undefined;
    set pubsubMaximumBackoff(value: string | undefined);
    get pubsubMessageRetentionDuration(): string | undefined;
    set pubsubMessageRetentionDuration(value: string | undefined);
    get pubsubMinimumBackoff(): string | undefined;
    set pubsubMinimumBackoff(value: string | undefined);
    get resource(): string;
    set resource(value: string);
    get projectOutput(): string;
    get serviceAccountKeyOutput(): string;
    get subscriptionOutput(): string;
    get topicOutput(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
