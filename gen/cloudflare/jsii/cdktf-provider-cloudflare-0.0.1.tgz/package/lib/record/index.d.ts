import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RecordConfig extends cdktf.TerraformMetaArguments {
    /**
    * Allow creation of this record in Terraform to overwrite an existing record, if any. This does not affect the ability to update the record in Terraform and does not prevent other resources within Terraform or manual changes outside Terraform from overwriting this record. **This configuration is not recommended for most environments**. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#allow_overwrite Record#allow_overwrite}
    */
    readonly allowOverwrite?: boolean | cdktf.IResolvable;
    /**
    * Comments or notes about the DNS record. This field has no effect on DNS responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#comment Record#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#id Record#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the record. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#name Record#name}
    */
    readonly name: string;
    /**
    * The priority of the record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#priority Record#priority}
    */
    readonly priority?: number;
    /**
    * Whether the record gets Cloudflare's origin protection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#proxied Record#proxied}
    */
    readonly proxied?: boolean | cdktf.IResolvable;
    /**
    * Custom tags for the DNS record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#tags Record#tags}
    */
    readonly tags?: string[];
    /**
    * The TTL of the record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#ttl Record#ttl}
    */
    readonly ttl?: number;
    /**
    * The type of the record. Available values: `A`, `AAAA`, `CAA`, `CNAME`, `TXT`, `SRV`, `LOC`, `MX`, `NS`, `SPF`, `CERT`, `DNSKEY`, `DS`, `NAPTR`, `SMIMEA`, `SSHFP`, `TLSA`, `URI`, `PTR`, `HTTPS`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#type Record#type}
    */
    readonly type: string;
    /**
    * The value of the record. Conflicts with `data`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#value Record#value}
    */
    readonly value?: string;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#zone_id Record#zone_id}
    */
    readonly zoneId: string;
    /**
    * data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#data Record#data}
    */
    readonly data?: RecordData;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#timeouts Record#timeouts}
    */
    readonly timeouts?: RecordTimeouts;
}
export interface RecordData {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#algorithm Record#algorithm}
    */
    readonly algorithm?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#altitude Record#altitude}
    */
    readonly altitude?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#certificate Record#certificate}
    */
    readonly certificate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#content Record#content}
    */
    readonly content?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#digest Record#digest}
    */
    readonly digest?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#digest_type Record#digest_type}
    */
    readonly digestType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#fingerprint Record#fingerprint}
    */
    readonly fingerprint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#flags Record#flags}
    */
    readonly flags?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#key_tag Record#key_tag}
    */
    readonly keyTag?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#lat_degrees Record#lat_degrees}
    */
    readonly latDegrees?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#lat_direction Record#lat_direction}
    */
    readonly latDirection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#lat_minutes Record#lat_minutes}
    */
    readonly latMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#lat_seconds Record#lat_seconds}
    */
    readonly latSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#long_degrees Record#long_degrees}
    */
    readonly longDegrees?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#long_direction Record#long_direction}
    */
    readonly longDirection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#long_minutes Record#long_minutes}
    */
    readonly longMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#long_seconds Record#long_seconds}
    */
    readonly longSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#matching_type Record#matching_type}
    */
    readonly matchingType?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#name Record#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#order Record#order}
    */
    readonly order?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#port Record#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#precision_horz Record#precision_horz}
    */
    readonly precisionHorz?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#precision_vert Record#precision_vert}
    */
    readonly precisionVert?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#preference Record#preference}
    */
    readonly preference?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#priority Record#priority}
    */
    readonly priority?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#proto Record#proto}
    */
    readonly proto?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#protocol Record#protocol}
    */
    readonly protocol?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#public_key Record#public_key}
    */
    readonly publicKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#regex Record#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#replacement Record#replacement}
    */
    readonly replacement?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#selector Record#selector}
    */
    readonly selector?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#service Record#service}
    */
    readonly service?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#size Record#size}
    */
    readonly size?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#tag Record#tag}
    */
    readonly tag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#target Record#target}
    */
    readonly target?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#type Record#type}
    */
    readonly type?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#usage Record#usage}
    */
    readonly usage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#value Record#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#weight Record#weight}
    */
    readonly weight?: number;
}
export declare function recordDataToTerraform(struct?: RecordDataOutputReference | RecordData): any;
export declare function recordDataToHclTerraform(struct?: RecordDataOutputReference | RecordData): any;
export declare class RecordDataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RecordData | undefined;
    set internalValue(value: RecordData | undefined);
    private _algorithm?;
    get algorithm(): number;
    set algorithm(value: number);
    resetAlgorithm(): void;
    get algorithmInput(): number | undefined;
    private _altitude?;
    get altitude(): number;
    set altitude(value: number);
    resetAltitude(): void;
    get altitudeInput(): number | undefined;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _digest?;
    get digest(): string;
    set digest(value: string);
    resetDigest(): void;
    get digestInput(): string | undefined;
    private _digestType?;
    get digestType(): number;
    set digestType(value: number);
    resetDigestType(): void;
    get digestTypeInput(): number | undefined;
    private _fingerprint?;
    get fingerprint(): string;
    set fingerprint(value: string);
    resetFingerprint(): void;
    get fingerprintInput(): string | undefined;
    private _flags?;
    get flags(): string;
    set flags(value: string);
    resetFlags(): void;
    get flagsInput(): string | undefined;
    private _keyTag?;
    get keyTag(): number;
    set keyTag(value: number);
    resetKeyTag(): void;
    get keyTagInput(): number | undefined;
    private _latDegrees?;
    get latDegrees(): number;
    set latDegrees(value: number);
    resetLatDegrees(): void;
    get latDegreesInput(): number | undefined;
    private _latDirection?;
    get latDirection(): string;
    set latDirection(value: string);
    resetLatDirection(): void;
    get latDirectionInput(): string | undefined;
    private _latMinutes?;
    get latMinutes(): number;
    set latMinutes(value: number);
    resetLatMinutes(): void;
    get latMinutesInput(): number | undefined;
    private _latSeconds?;
    get latSeconds(): number;
    set latSeconds(value: number);
    resetLatSeconds(): void;
    get latSecondsInput(): number | undefined;
    private _longDegrees?;
    get longDegrees(): number;
    set longDegrees(value: number);
    resetLongDegrees(): void;
    get longDegreesInput(): number | undefined;
    private _longDirection?;
    get longDirection(): string;
    set longDirection(value: string);
    resetLongDirection(): void;
    get longDirectionInput(): string | undefined;
    private _longMinutes?;
    get longMinutes(): number;
    set longMinutes(value: number);
    resetLongMinutes(): void;
    get longMinutesInput(): number | undefined;
    private _longSeconds?;
    get longSeconds(): number;
    set longSeconds(value: number);
    resetLongSeconds(): void;
    get longSecondsInput(): number | undefined;
    private _matchingType?;
    get matchingType(): number;
    set matchingType(value: number);
    resetMatchingType(): void;
    get matchingTypeInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): number;
    set order(value: number);
    resetOrder(): void;
    get orderInput(): number | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _precisionHorz?;
    get precisionHorz(): number;
    set precisionHorz(value: number);
    resetPrecisionHorz(): void;
    get precisionHorzInput(): number | undefined;
    private _precisionVert?;
    get precisionVert(): number;
    set precisionVert(value: number);
    resetPrecisionVert(): void;
    get precisionVertInput(): number | undefined;
    private _preference?;
    get preference(): number;
    set preference(value: number);
    resetPreference(): void;
    get preferenceInput(): number | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _proto?;
    get proto(): string;
    set proto(value: string);
    resetProto(): void;
    get protoInput(): string | undefined;
    private _protocol?;
    get protocol(): number;
    set protocol(value: number);
    resetProtocol(): void;
    get protocolInput(): number | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    resetPublicKey(): void;
    get publicKeyInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _replacement?;
    get replacement(): string;
    set replacement(value: string);
    resetReplacement(): void;
    get replacementInput(): string | undefined;
    private _selector?;
    get selector(): number;
    set selector(value: number);
    resetSelector(): void;
    get selectorInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _type?;
    get type(): number;
    set type(value: number);
    resetType(): void;
    get typeInput(): number | undefined;
    private _usage?;
    get usage(): number;
    set usage(value: number);
    resetUsage(): void;
    get usageInput(): number | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
}
export interface RecordTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#create Record#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#update Record#update}
    */
    readonly update?: string;
}
export declare function recordTimeoutsToTerraform(struct?: RecordTimeouts | cdktf.IResolvable): any;
export declare function recordTimeoutsToHclTerraform(struct?: RecordTimeouts | cdktf.IResolvable): any;
export declare class RecordTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RecordTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: RecordTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record cloudflare_record}
*/
export declare class Record extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_record";
    /**
    * Generates CDKTF code for importing a Record resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Record to import
    * @param importFromId The id of the existing Record that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Record to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/record cloudflare_record} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RecordConfig
    */
    constructor(scope: Construct, id: string, config: RecordConfig);
    private _allowOverwrite?;
    get allowOverwrite(): boolean | cdktf.IResolvable;
    set allowOverwrite(value: boolean | cdktf.IResolvable);
    resetAllowOverwrite(): void;
    get allowOverwriteInput(): boolean | cdktf.IResolvable | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createdOn(): string;
    get hostname(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): cdktf.StringMap;
    get modifiedOn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    get proxiable(): cdktf.IResolvable;
    private _proxied?;
    get proxied(): boolean | cdktf.IResolvable;
    set proxied(value: boolean | cdktf.IResolvable);
    resetProxied(): void;
    get proxiedInput(): boolean | cdktf.IResolvable | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _data;
    get data(): RecordDataOutputReference;
    putData(value: RecordData): void;
    resetData(): void;
    get dataInput(): RecordData | undefined;
    private _timeouts;
    get timeouts(): RecordTimeoutsOutputReference;
    putTimeouts(value: RecordTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | RecordTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
