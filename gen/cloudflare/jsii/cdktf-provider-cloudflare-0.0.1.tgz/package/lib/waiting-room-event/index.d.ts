import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WaitingRoomEventConfig extends cdktf.TerraformMetaArguments {
    /**
    * This is a templated html file that will be rendered at the edge.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#custom_page_html WaitingRoomEvent#custom_page_html}
    */
    readonly customPageHtml?: string;
    /**
    * A description to let users add more details about the event.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#description WaitingRoomEvent#description}
    */
    readonly description?: string;
    /**
    * Disables automatic renewal of session cookies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#disable_session_renewal WaitingRoomEvent#disable_session_renewal}
    */
    readonly disableSessionRenewal?: boolean | cdktf.IResolvable;
    /**
    * ISO 8601 timestamp that marks the end of the event. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#event_end_time WaitingRoomEvent#event_end_time}
    */
    readonly eventEndTime: string;
    /**
    * ISO 8601 timestamp that marks the start of the event. Must occur at least 1 minute before `event_end_time`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#event_start_time WaitingRoomEvent#event_start_time}
    */
    readonly eventStartTime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#id WaitingRoomEvent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A unique name to identify the event. Only alphanumeric characters, hyphens, and underscores are allowed. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#name WaitingRoomEvent#name}
    */
    readonly name: string;
    /**
    * The number of new users that will be let into the route every minute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#new_users_per_minute WaitingRoomEvent#new_users_per_minute}
    */
    readonly newUsersPerMinute?: number;
    /**
    * ISO 8601 timestamp that marks when to begin queueing all users before the event starts. Must occur at least 5 minutes before `event_start_time`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#prequeue_start_time WaitingRoomEvent#prequeue_start_time}
    */
    readonly prequeueStartTime?: string;
    /**
    * The queueing method used by the waiting room. Available values: `fifo`, `random`, `passthrough`, `reject`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#queueing_method WaitingRoomEvent#queueing_method}
    */
    readonly queueingMethod?: string;
    /**
    * Lifetime of a cookie (in minutes) set by Cloudflare for users who get access to the origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#session_duration WaitingRoomEvent#session_duration}
    */
    readonly sessionDuration?: number;
    /**
    * Users in the prequeue will be shuffled randomly at the `event_start_time`. Requires that `prequeue_start_time` is not null. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#shuffle_at_event_start WaitingRoomEvent#shuffle_at_event_start}
    */
    readonly shuffleAtEventStart?: boolean | cdktf.IResolvable;
    /**
    * If suspended, the event is ignored and traffic will be handled based on the waiting room configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#suspended WaitingRoomEvent#suspended}
    */
    readonly suspended?: boolean | cdktf.IResolvable;
    /**
    * The total number of active user sessions on the route at a point in time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#total_active_users WaitingRoomEvent#total_active_users}
    */
    readonly totalActiveUsers?: number;
    /**
    * The Waiting Room ID the event should apply to. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#waiting_room_id WaitingRoomEvent#waiting_room_id}
    */
    readonly waitingRoomId: string;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#zone_id WaitingRoomEvent#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event cloudflare_waiting_room_event}
*/
export declare class WaitingRoomEvent extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_waiting_room_event";
    /**
    * Generates CDKTF code for importing a WaitingRoomEvent resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WaitingRoomEvent to import
    * @param importFromId The id of the existing WaitingRoomEvent that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WaitingRoomEvent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_event cloudflare_waiting_room_event} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WaitingRoomEventConfig
    */
    constructor(scope: Construct, id: string, config: WaitingRoomEventConfig);
    get createdOn(): string;
    private _customPageHtml?;
    get customPageHtml(): string;
    set customPageHtml(value: string);
    resetCustomPageHtml(): void;
    get customPageHtmlInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableSessionRenewal?;
    get disableSessionRenewal(): boolean | cdktf.IResolvable;
    set disableSessionRenewal(value: boolean | cdktf.IResolvable);
    resetDisableSessionRenewal(): void;
    get disableSessionRenewalInput(): boolean | cdktf.IResolvable | undefined;
    private _eventEndTime?;
    get eventEndTime(): string;
    set eventEndTime(value: string);
    get eventEndTimeInput(): string | undefined;
    private _eventStartTime?;
    get eventStartTime(): string;
    set eventStartTime(value: string);
    get eventStartTimeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get modifiedOn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _newUsersPerMinute?;
    get newUsersPerMinute(): number;
    set newUsersPerMinute(value: number);
    resetNewUsersPerMinute(): void;
    get newUsersPerMinuteInput(): number | undefined;
    private _prequeueStartTime?;
    get prequeueStartTime(): string;
    set prequeueStartTime(value: string);
    resetPrequeueStartTime(): void;
    get prequeueStartTimeInput(): string | undefined;
    private _queueingMethod?;
    get queueingMethod(): string;
    set queueingMethod(value: string);
    resetQueueingMethod(): void;
    get queueingMethodInput(): string | undefined;
    private _sessionDuration?;
    get sessionDuration(): number;
    set sessionDuration(value: number);
    resetSessionDuration(): void;
    get sessionDurationInput(): number | undefined;
    private _shuffleAtEventStart?;
    get shuffleAtEventStart(): boolean | cdktf.IResolvable;
    set shuffleAtEventStart(value: boolean | cdktf.IResolvable);
    resetShuffleAtEventStart(): void;
    get shuffleAtEventStartInput(): boolean | cdktf.IResolvable | undefined;
    private _suspended?;
    get suspended(): boolean | cdktf.IResolvable;
    set suspended(value: boolean | cdktf.IResolvable);
    resetSuspended(): void;
    get suspendedInput(): boolean | cdktf.IResolvable | undefined;
    private _totalActiveUsers?;
    get totalActiveUsers(): number;
    set totalActiveUsers(value: number);
    resetTotalActiveUsers(): void;
    get totalActiveUsersInput(): number | undefined;
    private _waitingRoomId?;
    get waitingRoomId(): string;
    set waitingRoomId(value: string);
    get waitingRoomIdInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
