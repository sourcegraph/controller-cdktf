import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface UserAgentBlockingRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * An informative summary of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule#description UserAgentBlockingRule#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule#id UserAgentBlockingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The action to apply to a matched request. Available values: `block`, `challenge`, `js_challenge`, `managed_challenge`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule#mode UserAgentBlockingRule#mode}
    */
    readonly mode: string;
    /**
    * When true, indicates that the rule is currently paused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule#paused UserAgentBlockingRule#paused}
    */
    readonly paused: boolean | cdktf.IResolvable;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule#zone_id UserAgentBlockingRule#zone_id}
    */
    readonly zoneId: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule#configuration UserAgentBlockingRule#configuration}
    */
    readonly configuration: UserAgentBlockingRuleConfiguration;
}
export interface UserAgentBlockingRuleConfiguration {
    /**
    * The configuration target for this rule. You must set the target to ua for User Agent Blocking rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule#target UserAgentBlockingRule#target}
    */
    readonly target: string;
    /**
    * The exact user agent string to match. This value will be compared to the received User-Agent HTTP header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule#value UserAgentBlockingRule#value}
    */
    readonly value: string;
}
export declare function userAgentBlockingRuleConfigurationToTerraform(struct?: UserAgentBlockingRuleConfigurationOutputReference | UserAgentBlockingRuleConfiguration): any;
export declare function userAgentBlockingRuleConfigurationToHclTerraform(struct?: UserAgentBlockingRuleConfigurationOutputReference | UserAgentBlockingRuleConfiguration): any;
export declare class UserAgentBlockingRuleConfigurationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UserAgentBlockingRuleConfiguration | undefined;
    set internalValue(value: UserAgentBlockingRuleConfiguration | undefined);
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule cloudflare_user_agent_blocking_rule}
*/
export declare class UserAgentBlockingRule extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_user_agent_blocking_rule";
    /**
    * Generates CDKTF code for importing a UserAgentBlockingRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserAgentBlockingRule to import
    * @param importFromId The id of the existing UserAgentBlockingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserAgentBlockingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/user_agent_blocking_rule cloudflare_user_agent_blocking_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserAgentBlockingRuleConfig
    */
    constructor(scope: Construct, id: string, config: UserAgentBlockingRuleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _paused?;
    get paused(): boolean | cdktf.IResolvable;
    set paused(value: boolean | cdktf.IResolvable);
    get pausedInput(): boolean | cdktf.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _configuration;
    get configuration(): UserAgentBlockingRuleConfigurationOutputReference;
    putConfiguration(value: UserAgentBlockingRuleConfiguration): void;
    get configurationInput(): UserAgentBlockingRuleConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
