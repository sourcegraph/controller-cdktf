import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AccessPolicyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. Conflicts with `zone_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#account_id AccessPolicy#account_id}
    */
    readonly accountId?: string;
    /**
    * The ID of the application the policy is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#application_id AccessPolicy#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#approval_required AccessPolicy#approval_required}
    */
    readonly approvalRequired?: boolean | cdktf.IResolvable;
    /**
    * Defines the action Access will take if the policy matches the user. Available values: `allow`, `deny`, `non_identity`, `bypass`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#decision AccessPolicy#decision}
    */
    readonly decision: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#id AccessPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Friendly name of the Access Policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name: string;
    /**
    * The unique precedence for policies on a single application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#precedence AccessPolicy#precedence}
    */
    readonly precedence: number;
    /**
    * The prompt to display to the user for a justification for accessing the resource. Required when using `purpose_justification_required`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#purpose_justification_prompt AccessPolicy#purpose_justification_prompt}
    */
    readonly purposeJustificationPrompt?: string;
    /**
    * Whether to prompt the user for a justification for accessing the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#purpose_justification_required AccessPolicy#purpose_justification_required}
    */
    readonly purposeJustificationRequired?: boolean | cdktf.IResolvable;
    /**
    * The zone identifier to target for the resource. Conflicts with `account_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#zone_id AccessPolicy#zone_id}
    */
    readonly zoneId?: string;
    /**
    * approval_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#approval_group AccessPolicy#approval_group}
    */
    readonly approvalGroup?: AccessPolicyApprovalGroup[] | cdktf.IResolvable;
    /**
    * exclude block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#exclude AccessPolicy#exclude}
    */
    readonly exclude?: AccessPolicyExclude[] | cdktf.IResolvable;
    /**
    * include block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#include AccessPolicy#include}
    */
    readonly include: AccessPolicyInclude[] | cdktf.IResolvable;
    /**
    * require block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#require AccessPolicy#require}
    */
    readonly require?: AccessPolicyRequire[] | cdktf.IResolvable;
}
export interface AccessPolicyApprovalGroup {
    /**
    * Number of approvals needed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#approvals_needed AccessPolicy#approvals_needed}
    */
    readonly approvalsNeeded: number;
    /**
    * List of emails to request approval from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email_addresses AccessPolicy#email_addresses}
    */
    readonly emailAddresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email_list_uuid AccessPolicy#email_list_uuid}
    */
    readonly emailListUuid?: string;
}
export declare function accessPolicyApprovalGroupToTerraform(struct?: AccessPolicyApprovalGroup | cdktf.IResolvable): any;
export declare function accessPolicyApprovalGroupToHclTerraform(struct?: AccessPolicyApprovalGroup | cdktf.IResolvable): any;
export declare class AccessPolicyApprovalGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyApprovalGroup | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyApprovalGroup | cdktf.IResolvable | undefined);
    private _approvalsNeeded?;
    get approvalsNeeded(): number;
    set approvalsNeeded(value: number);
    get approvalsNeededInput(): number | undefined;
    private _emailAddresses?;
    get emailAddresses(): string[];
    set emailAddresses(value: string[]);
    resetEmailAddresses(): void;
    get emailAddressesInput(): string[] | undefined;
    private _emailListUuid?;
    get emailListUuid(): string;
    set emailListUuid(value: string);
    resetEmailListUuid(): void;
    get emailListUuidInput(): string | undefined;
}
export declare class AccessPolicyApprovalGroupList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyApprovalGroup[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyApprovalGroupOutputReference;
}
export interface AccessPolicyExcludeAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#id AccessPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyExcludeAzureToTerraform(struct?: AccessPolicyExcludeAzure | cdktf.IResolvable): any;
export declare function accessPolicyExcludeAzureToHclTerraform(struct?: AccessPolicyExcludeAzure | cdktf.IResolvable): any;
export declare class AccessPolicyExcludeAzureOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExcludeAzure | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyExcludeAzure | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyExcludeAzureList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyExcludeAzure[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeAzureOutputReference;
}
export interface AccessPolicyExcludeExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#evaluate_url AccessPolicy#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#keys_url AccessPolicy#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessPolicyExcludeExternalEvaluationToTerraform(struct?: AccessPolicyExcludeExternalEvaluationOutputReference | AccessPolicyExcludeExternalEvaluation): any;
export declare function accessPolicyExcludeExternalEvaluationToHclTerraform(struct?: AccessPolicyExcludeExternalEvaluationOutputReference | AccessPolicyExcludeExternalEvaluation): any;
export declare class AccessPolicyExcludeExternalEvaluationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPolicyExcludeExternalEvaluation | undefined;
    set internalValue(value: AccessPolicyExcludeExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessPolicyExcludeGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#teams AccessPolicy#teams}
    */
    readonly teams?: string[];
}
export declare function accessPolicyExcludeGithubToTerraform(struct?: AccessPolicyExcludeGithub | cdktf.IResolvable): any;
export declare function accessPolicyExcludeGithubToHclTerraform(struct?: AccessPolicyExcludeGithub | cdktf.IResolvable): any;
export declare class AccessPolicyExcludeGithubOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExcludeGithub | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyExcludeGithub | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessPolicyExcludeGithubList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyExcludeGithub[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeGithubOutputReference;
}
export interface AccessPolicyExcludeGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyExcludeGsuiteToTerraform(struct?: AccessPolicyExcludeGsuite | cdktf.IResolvable): any;
export declare function accessPolicyExcludeGsuiteToHclTerraform(struct?: AccessPolicyExcludeGsuite | cdktf.IResolvable): any;
export declare class AccessPolicyExcludeGsuiteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExcludeGsuite | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyExcludeGsuite | cdktf.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyExcludeGsuiteList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyExcludeGsuite[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeGsuiteOutputReference;
}
export interface AccessPolicyExcludeOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string[];
}
export declare function accessPolicyExcludeOktaToTerraform(struct?: AccessPolicyExcludeOkta | cdktf.IResolvable): any;
export declare function accessPolicyExcludeOktaToHclTerraform(struct?: AccessPolicyExcludeOkta | cdktf.IResolvable): any;
export declare class AccessPolicyExcludeOktaOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExcludeOkta | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyExcludeOkta | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessPolicyExcludeOktaList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyExcludeOkta[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeOktaOutputReference;
}
export interface AccessPolicyExcludeSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_name AccessPolicy#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_value AccessPolicy#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyExcludeSamlToTerraform(struct?: AccessPolicyExcludeSaml | cdktf.IResolvable): any;
export declare function accessPolicyExcludeSamlToHclTerraform(struct?: AccessPolicyExcludeSaml | cdktf.IResolvable): any;
export declare class AccessPolicyExcludeSamlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExcludeSaml | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyExcludeSaml | cdktf.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyExcludeSamlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyExcludeSaml[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeSamlOutputReference;
}
export interface AccessPolicyExclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#any_valid_service_token AccessPolicy#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#auth_method AccessPolicy#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#certificate AccessPolicy#certificate}
    */
    readonly certificate?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#common_name AccessPolicy#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#device_posture AccessPolicy#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email_domain AccessPolicy#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#everyone AccessPolicy#everyone}
    */
    readonly everyone?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#geo AccessPolicy#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#group AccessPolicy#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip AccessPolicy#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip_list AccessPolicy#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#login_method AccessPolicy#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#service_token AccessPolicy#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#azure AccessPolicy#azure}
    */
    readonly azure?: AccessPolicyExcludeAzure[] | cdktf.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#external_evaluation AccessPolicy#external_evaluation}
    */
    readonly externalEvaluation?: AccessPolicyExcludeExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#github AccessPolicy#github}
    */
    readonly github?: AccessPolicyExcludeGithub[] | cdktf.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#gsuite AccessPolicy#gsuite}
    */
    readonly gsuite?: AccessPolicyExcludeGsuite[] | cdktf.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#okta AccessPolicy#okta}
    */
    readonly okta?: AccessPolicyExcludeOkta[] | cdktf.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#saml AccessPolicy#saml}
    */
    readonly saml?: AccessPolicyExcludeSaml[] | cdktf.IResolvable;
}
export declare function accessPolicyExcludeToTerraform(struct?: AccessPolicyExclude | cdktf.IResolvable): any;
export declare function accessPolicyExcludeToHclTerraform(struct?: AccessPolicyExclude | cdktf.IResolvable): any;
export declare class AccessPolicyExcludeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExclude | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyExclude | cdktf.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktf.IResolvable;
    set anyValidServiceToken(value: boolean | cdktf.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktf.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktf.IResolvable;
    set certificate(value: boolean | cdktf.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktf.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktf.IResolvable;
    set everyone(value: boolean | cdktf.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktf.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessPolicyExcludeAzureList;
    putAzure(value: AccessPolicyExcludeAzure[] | cdktf.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktf.IResolvable | AccessPolicyExcludeAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessPolicyExcludeExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessPolicyExcludeExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessPolicyExcludeExternalEvaluation | undefined;
    private _github;
    get github(): AccessPolicyExcludeGithubList;
    putGithub(value: AccessPolicyExcludeGithub[] | cdktf.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktf.IResolvable | AccessPolicyExcludeGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessPolicyExcludeGsuiteList;
    putGsuite(value: AccessPolicyExcludeGsuite[] | cdktf.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktf.IResolvable | AccessPolicyExcludeGsuite[] | undefined;
    private _okta;
    get okta(): AccessPolicyExcludeOktaList;
    putOkta(value: AccessPolicyExcludeOkta[] | cdktf.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktf.IResolvable | AccessPolicyExcludeOkta[] | undefined;
    private _saml;
    get saml(): AccessPolicyExcludeSamlList;
    putSaml(value: AccessPolicyExcludeSaml[] | cdktf.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktf.IResolvable | AccessPolicyExcludeSaml[] | undefined;
}
export declare class AccessPolicyExcludeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyExclude[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeOutputReference;
}
export interface AccessPolicyIncludeAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#id AccessPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyIncludeAzureToTerraform(struct?: AccessPolicyIncludeAzure | cdktf.IResolvable): any;
export declare function accessPolicyIncludeAzureToHclTerraform(struct?: AccessPolicyIncludeAzure | cdktf.IResolvable): any;
export declare class AccessPolicyIncludeAzureOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyIncludeAzure | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyIncludeAzure | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyIncludeAzureList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyIncludeAzure[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeAzureOutputReference;
}
export interface AccessPolicyIncludeExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#evaluate_url AccessPolicy#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#keys_url AccessPolicy#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessPolicyIncludeExternalEvaluationToTerraform(struct?: AccessPolicyIncludeExternalEvaluationOutputReference | AccessPolicyIncludeExternalEvaluation): any;
export declare function accessPolicyIncludeExternalEvaluationToHclTerraform(struct?: AccessPolicyIncludeExternalEvaluationOutputReference | AccessPolicyIncludeExternalEvaluation): any;
export declare class AccessPolicyIncludeExternalEvaluationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPolicyIncludeExternalEvaluation | undefined;
    set internalValue(value: AccessPolicyIncludeExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessPolicyIncludeGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#teams AccessPolicy#teams}
    */
    readonly teams?: string[];
}
export declare function accessPolicyIncludeGithubToTerraform(struct?: AccessPolicyIncludeGithub | cdktf.IResolvable): any;
export declare function accessPolicyIncludeGithubToHclTerraform(struct?: AccessPolicyIncludeGithub | cdktf.IResolvable): any;
export declare class AccessPolicyIncludeGithubOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyIncludeGithub | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyIncludeGithub | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessPolicyIncludeGithubList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyIncludeGithub[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeGithubOutputReference;
}
export interface AccessPolicyIncludeGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyIncludeGsuiteToTerraform(struct?: AccessPolicyIncludeGsuite | cdktf.IResolvable): any;
export declare function accessPolicyIncludeGsuiteToHclTerraform(struct?: AccessPolicyIncludeGsuite | cdktf.IResolvable): any;
export declare class AccessPolicyIncludeGsuiteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyIncludeGsuite | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyIncludeGsuite | cdktf.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyIncludeGsuiteList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyIncludeGsuite[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeGsuiteOutputReference;
}
export interface AccessPolicyIncludeOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string[];
}
export declare function accessPolicyIncludeOktaToTerraform(struct?: AccessPolicyIncludeOkta | cdktf.IResolvable): any;
export declare function accessPolicyIncludeOktaToHclTerraform(struct?: AccessPolicyIncludeOkta | cdktf.IResolvable): any;
export declare class AccessPolicyIncludeOktaOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyIncludeOkta | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyIncludeOkta | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessPolicyIncludeOktaList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyIncludeOkta[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeOktaOutputReference;
}
export interface AccessPolicyIncludeSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_name AccessPolicy#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_value AccessPolicy#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyIncludeSamlToTerraform(struct?: AccessPolicyIncludeSaml | cdktf.IResolvable): any;
export declare function accessPolicyIncludeSamlToHclTerraform(struct?: AccessPolicyIncludeSaml | cdktf.IResolvable): any;
export declare class AccessPolicyIncludeSamlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyIncludeSaml | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyIncludeSaml | cdktf.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyIncludeSamlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyIncludeSaml[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeSamlOutputReference;
}
export interface AccessPolicyInclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#any_valid_service_token AccessPolicy#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#auth_method AccessPolicy#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#certificate AccessPolicy#certificate}
    */
    readonly certificate?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#common_name AccessPolicy#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#device_posture AccessPolicy#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email_domain AccessPolicy#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#everyone AccessPolicy#everyone}
    */
    readonly everyone?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#geo AccessPolicy#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#group AccessPolicy#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip AccessPolicy#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip_list AccessPolicy#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#login_method AccessPolicy#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#service_token AccessPolicy#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#azure AccessPolicy#azure}
    */
    readonly azure?: AccessPolicyIncludeAzure[] | cdktf.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#external_evaluation AccessPolicy#external_evaluation}
    */
    readonly externalEvaluation?: AccessPolicyIncludeExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#github AccessPolicy#github}
    */
    readonly github?: AccessPolicyIncludeGithub[] | cdktf.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#gsuite AccessPolicy#gsuite}
    */
    readonly gsuite?: AccessPolicyIncludeGsuite[] | cdktf.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#okta AccessPolicy#okta}
    */
    readonly okta?: AccessPolicyIncludeOkta[] | cdktf.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#saml AccessPolicy#saml}
    */
    readonly saml?: AccessPolicyIncludeSaml[] | cdktf.IResolvable;
}
export declare function accessPolicyIncludeToTerraform(struct?: AccessPolicyInclude | cdktf.IResolvable): any;
export declare function accessPolicyIncludeToHclTerraform(struct?: AccessPolicyInclude | cdktf.IResolvable): any;
export declare class AccessPolicyIncludeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyInclude | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyInclude | cdktf.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktf.IResolvable;
    set anyValidServiceToken(value: boolean | cdktf.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktf.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktf.IResolvable;
    set certificate(value: boolean | cdktf.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktf.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktf.IResolvable;
    set everyone(value: boolean | cdktf.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktf.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessPolicyIncludeAzureList;
    putAzure(value: AccessPolicyIncludeAzure[] | cdktf.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktf.IResolvable | AccessPolicyIncludeAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessPolicyIncludeExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessPolicyIncludeExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessPolicyIncludeExternalEvaluation | undefined;
    private _github;
    get github(): AccessPolicyIncludeGithubList;
    putGithub(value: AccessPolicyIncludeGithub[] | cdktf.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktf.IResolvable | AccessPolicyIncludeGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessPolicyIncludeGsuiteList;
    putGsuite(value: AccessPolicyIncludeGsuite[] | cdktf.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktf.IResolvable | AccessPolicyIncludeGsuite[] | undefined;
    private _okta;
    get okta(): AccessPolicyIncludeOktaList;
    putOkta(value: AccessPolicyIncludeOkta[] | cdktf.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktf.IResolvable | AccessPolicyIncludeOkta[] | undefined;
    private _saml;
    get saml(): AccessPolicyIncludeSamlList;
    putSaml(value: AccessPolicyIncludeSaml[] | cdktf.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktf.IResolvable | AccessPolicyIncludeSaml[] | undefined;
}
export declare class AccessPolicyIncludeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyInclude[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeOutputReference;
}
export interface AccessPolicyRequireAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#id AccessPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyRequireAzureToTerraform(struct?: AccessPolicyRequireAzure | cdktf.IResolvable): any;
export declare function accessPolicyRequireAzureToHclTerraform(struct?: AccessPolicyRequireAzure | cdktf.IResolvable): any;
export declare class AccessPolicyRequireAzureOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequireAzure | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequireAzure | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyRequireAzureList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyRequireAzure[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireAzureOutputReference;
}
export interface AccessPolicyRequireExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#evaluate_url AccessPolicy#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#keys_url AccessPolicy#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessPolicyRequireExternalEvaluationToTerraform(struct?: AccessPolicyRequireExternalEvaluationOutputReference | AccessPolicyRequireExternalEvaluation): any;
export declare function accessPolicyRequireExternalEvaluationToHclTerraform(struct?: AccessPolicyRequireExternalEvaluationOutputReference | AccessPolicyRequireExternalEvaluation): any;
export declare class AccessPolicyRequireExternalEvaluationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPolicyRequireExternalEvaluation | undefined;
    set internalValue(value: AccessPolicyRequireExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessPolicyRequireGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#teams AccessPolicy#teams}
    */
    readonly teams?: string[];
}
export declare function accessPolicyRequireGithubToTerraform(struct?: AccessPolicyRequireGithub | cdktf.IResolvable): any;
export declare function accessPolicyRequireGithubToHclTerraform(struct?: AccessPolicyRequireGithub | cdktf.IResolvable): any;
export declare class AccessPolicyRequireGithubOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequireGithub | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequireGithub | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessPolicyRequireGithubList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyRequireGithub[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireGithubOutputReference;
}
export interface AccessPolicyRequireGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyRequireGsuiteToTerraform(struct?: AccessPolicyRequireGsuite | cdktf.IResolvable): any;
export declare function accessPolicyRequireGsuiteToHclTerraform(struct?: AccessPolicyRequireGsuite | cdktf.IResolvable): any;
export declare class AccessPolicyRequireGsuiteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequireGsuite | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequireGsuite | cdktf.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyRequireGsuiteList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyRequireGsuite[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireGsuiteOutputReference;
}
export interface AccessPolicyRequireOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string[];
}
export declare function accessPolicyRequireOktaToTerraform(struct?: AccessPolicyRequireOkta | cdktf.IResolvable): any;
export declare function accessPolicyRequireOktaToHclTerraform(struct?: AccessPolicyRequireOkta | cdktf.IResolvable): any;
export declare class AccessPolicyRequireOktaOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequireOkta | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequireOkta | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessPolicyRequireOktaList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyRequireOkta[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireOktaOutputReference;
}
export interface AccessPolicyRequireSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_name AccessPolicy#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_value AccessPolicy#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyRequireSamlToTerraform(struct?: AccessPolicyRequireSaml | cdktf.IResolvable): any;
export declare function accessPolicyRequireSamlToHclTerraform(struct?: AccessPolicyRequireSaml | cdktf.IResolvable): any;
export declare class AccessPolicyRequireSamlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequireSaml | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequireSaml | cdktf.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyRequireSamlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyRequireSaml[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireSamlOutputReference;
}
export interface AccessPolicyRequire {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#any_valid_service_token AccessPolicy#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#auth_method AccessPolicy#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#certificate AccessPolicy#certificate}
    */
    readonly certificate?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#common_name AccessPolicy#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#device_posture AccessPolicy#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email_domain AccessPolicy#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#everyone AccessPolicy#everyone}
    */
    readonly everyone?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#geo AccessPolicy#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#group AccessPolicy#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip AccessPolicy#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip_list AccessPolicy#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#login_method AccessPolicy#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#service_token AccessPolicy#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#azure AccessPolicy#azure}
    */
    readonly azure?: AccessPolicyRequireAzure[] | cdktf.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#external_evaluation AccessPolicy#external_evaluation}
    */
    readonly externalEvaluation?: AccessPolicyRequireExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#github AccessPolicy#github}
    */
    readonly github?: AccessPolicyRequireGithub[] | cdktf.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#gsuite AccessPolicy#gsuite}
    */
    readonly gsuite?: AccessPolicyRequireGsuite[] | cdktf.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#okta AccessPolicy#okta}
    */
    readonly okta?: AccessPolicyRequireOkta[] | cdktf.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#saml AccessPolicy#saml}
    */
    readonly saml?: AccessPolicyRequireSaml[] | cdktf.IResolvable;
}
export declare function accessPolicyRequireToTerraform(struct?: AccessPolicyRequire | cdktf.IResolvable): any;
export declare function accessPolicyRequireToHclTerraform(struct?: AccessPolicyRequire | cdktf.IResolvable): any;
export declare class AccessPolicyRequireOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequire | cdktf.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequire | cdktf.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktf.IResolvable;
    set anyValidServiceToken(value: boolean | cdktf.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktf.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktf.IResolvable;
    set certificate(value: boolean | cdktf.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktf.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktf.IResolvable;
    set everyone(value: boolean | cdktf.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktf.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessPolicyRequireAzureList;
    putAzure(value: AccessPolicyRequireAzure[] | cdktf.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktf.IResolvable | AccessPolicyRequireAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessPolicyRequireExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessPolicyRequireExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessPolicyRequireExternalEvaluation | undefined;
    private _github;
    get github(): AccessPolicyRequireGithubList;
    putGithub(value: AccessPolicyRequireGithub[] | cdktf.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktf.IResolvable | AccessPolicyRequireGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessPolicyRequireGsuiteList;
    putGsuite(value: AccessPolicyRequireGsuite[] | cdktf.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktf.IResolvable | AccessPolicyRequireGsuite[] | undefined;
    private _okta;
    get okta(): AccessPolicyRequireOktaList;
    putOkta(value: AccessPolicyRequireOkta[] | cdktf.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktf.IResolvable | AccessPolicyRequireOkta[] | undefined;
    private _saml;
    get saml(): AccessPolicyRequireSamlList;
    putSaml(value: AccessPolicyRequireSaml[] | cdktf.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktf.IResolvable | AccessPolicyRequireSaml[] | undefined;
}
export declare class AccessPolicyRequireList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessPolicyRequire[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy cloudflare_access_policy}
*/
export declare class AccessPolicy extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_access_policy";
    /**
    * Generates CDKTF code for importing a AccessPolicy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessPolicy to import
    * @param importFromId The id of the existing AccessPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy cloudflare_access_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AccessPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _approvalRequired?;
    get approvalRequired(): boolean | cdktf.IResolvable;
    set approvalRequired(value: boolean | cdktf.IResolvable);
    resetApprovalRequired(): void;
    get approvalRequiredInput(): boolean | cdktf.IResolvable | undefined;
    private _decision?;
    get decision(): string;
    set decision(value: string);
    get decisionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precedence?;
    get precedence(): number;
    set precedence(value: number);
    get precedenceInput(): number | undefined;
    private _purposeJustificationPrompt?;
    get purposeJustificationPrompt(): string;
    set purposeJustificationPrompt(value: string);
    resetPurposeJustificationPrompt(): void;
    get purposeJustificationPromptInput(): string | undefined;
    private _purposeJustificationRequired?;
    get purposeJustificationRequired(): boolean | cdktf.IResolvable;
    set purposeJustificationRequired(value: boolean | cdktf.IResolvable);
    resetPurposeJustificationRequired(): void;
    get purposeJustificationRequiredInput(): boolean | cdktf.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _approvalGroup;
    get approvalGroup(): AccessPolicyApprovalGroupList;
    putApprovalGroup(value: AccessPolicyApprovalGroup[] | cdktf.IResolvable): void;
    resetApprovalGroup(): void;
    get approvalGroupInput(): cdktf.IResolvable | AccessPolicyApprovalGroup[] | undefined;
    private _exclude;
    get exclude(): AccessPolicyExcludeList;
    putExclude(value: AccessPolicyExclude[] | cdktf.IResolvable): void;
    resetExclude(): void;
    get excludeInput(): cdktf.IResolvable | AccessPolicyExclude[] | undefined;
    private _include;
    get include(): AccessPolicyIncludeList;
    putInclude(value: AccessPolicyInclude[] | cdktf.IResolvable): void;
    get includeInput(): cdktf.IResolvable | AccessPolicyInclude[] | undefined;
    private _require;
    get require(): AccessPolicyRequireList;
    putRequire(value: AccessPolicyRequire[] | cdktf.IResolvable): void;
    resetRequire(): void;
    get requireInput(): cdktf.IResolvable | AccessPolicyRequire[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
