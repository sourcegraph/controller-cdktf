import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataCloudflareZonesConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones#id DataCloudflareZones#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones#filter DataCloudflareZones#filter}
    */
    readonly filter: DataCloudflareZonesFilter;
}
export interface DataCloudflareZonesZones {
}
export declare function dataCloudflareZonesZonesToTerraform(struct?: DataCloudflareZonesZones): any;
export declare function dataCloudflareZonesZonesToHclTerraform(struct?: DataCloudflareZonesZones): any;
export declare class DataCloudflareZonesZonesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZonesZones | undefined;
    set internalValue(value: DataCloudflareZonesZones | undefined);
    get id(): string;
    get name(): string;
}
export declare class DataCloudflareZonesZonesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZonesZonesOutputReference;
}
export interface DataCloudflareZonesFilter {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones#account_id DataCloudflareZones#account_id}
    */
    readonly accountId?: string;
    /**
    * The type of search to perform for the `name` value when querying the zone API. Available values: `contains`, `exact`. Defaults to `exact`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones#lookup_type DataCloudflareZones#lookup_type}
    */
    readonly lookupType?: string;
    /**
    * A RE2 compatible regular expression to filter the	results. This is performed client side whereas the `name` and `lookup_type`	are performed on the Cloudflare server side.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones#match DataCloudflareZones#match}
    */
    readonly match?: string;
    /**
    * A string value to search for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones#name DataCloudflareZones#name}
    */
    readonly name?: string;
    /**
    * Paused status of the zone to lookup. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones#paused DataCloudflareZones#paused}
    */
    readonly paused?: boolean | cdktf.IResolvable;
    /**
    * Status of the zone to lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones#status DataCloudflareZones#status}
    */
    readonly status?: string;
}
export declare function dataCloudflareZonesFilterToTerraform(struct?: DataCloudflareZonesFilterOutputReference | DataCloudflareZonesFilter): any;
export declare function dataCloudflareZonesFilterToHclTerraform(struct?: DataCloudflareZonesFilterOutputReference | DataCloudflareZonesFilter): any;
export declare class DataCloudflareZonesFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZonesFilter | undefined;
    set internalValue(value: DataCloudflareZonesFilter | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _lookupType?;
    get lookupType(): string;
    set lookupType(value: string);
    resetLookupType(): void;
    get lookupTypeInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _paused?;
    get paused(): boolean | cdktf.IResolvable;
    set paused(value: boolean | cdktf.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktf.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones cloudflare_zones}
*/
export declare class DataCloudflareZones extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zones";
    /**
    * Generates CDKTF code for importing a DataCloudflareZones resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZones to import
    * @param importFromId The id of the existing DataCloudflareZones that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZones to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/zones cloudflare_zones} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZonesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZonesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _zones;
    get zones(): DataCloudflareZonesZonesList;
    private _filter;
    get filter(): DataCloudflareZonesFilterOutputReference;
    putFilter(value: DataCloudflareZonesFilter): void;
    get filterInput(): DataCloudflareZonesFilter | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
