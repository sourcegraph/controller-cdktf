import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataCloudflareDevicesConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/devices#account_id DataCloudflareDevices#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/devices#id DataCloudflareDevices#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataCloudflareDevicesDevices {
}
export declare function dataCloudflareDevicesDevicesToTerraform(struct?: DataCloudflareDevicesDevices): any;
export declare function dataCloudflareDevicesDevicesToHclTerraform(struct?: DataCloudflareDevicesDevices): any;
export declare class DataCloudflareDevicesDevicesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareDevicesDevices | undefined;
    set internalValue(value: DataCloudflareDevicesDevices | undefined);
    get created(): string;
    get deleted(): cdktf.IResolvable;
    get deviceType(): string;
    get id(): string;
    get ip(): string;
    get key(): string;
    get lastSeen(): string;
    get macAddress(): string;
    get manufacturer(): string;
    get model(): string;
    get name(): string;
    get osDistroName(): string;
    get osDistroRevision(): string;
    get osVersion(): string;
    get revokedAt(): string;
    get serialNumber(): string;
    get updated(): string;
    get userEmail(): string;
    get userId(): string;
    get userName(): string;
    get version(): string;
}
export declare class DataCloudflareDevicesDevicesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareDevicesDevicesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/devices cloudflare_devices}
*/
export declare class DataCloudflareDevices extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_devices";
    /**
    * Generates CDKTF code for importing a DataCloudflareDevices resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareDevices to import
    * @param importFromId The id of the existing DataCloudflareDevices that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/devices#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareDevices to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/devices cloudflare_devices} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareDevicesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareDevicesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _devices;
    get devices(): DataCloudflareDevicesDevicesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
