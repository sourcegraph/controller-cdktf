import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface MtlsCertificateConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/mtls_certificate#account_id MtlsCertificate#account_id}
    */
    readonly accountId: string;
    /**
    * Whether this is a CA or leaf certificate. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/mtls_certificate#ca MtlsCertificate#ca}
    */
    readonly ca: boolean | cdktf.IResolvable;
    /**
    * Certificate you intend to use with mTLS-enabled services. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/mtls_certificate#certificates MtlsCertificate#certificates}
    */
    readonly certificates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/mtls_certificate#id MtlsCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Optional unique name for the certificate. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/mtls_certificate#name MtlsCertificate#name}
    */
    readonly name?: string;
    /**
    * The certificate's private key. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/mtls_certificate#private_key MtlsCertificate#private_key}
    */
    readonly privateKey?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/mtls_certificate cloudflare_mtls_certificate}
*/
export declare class MtlsCertificate extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_mtls_certificate";
    /**
    * Generates CDKTF code for importing a MtlsCertificate resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MtlsCertificate to import
    * @param importFromId The id of the existing MtlsCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/mtls_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MtlsCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/mtls_certificate cloudflare_mtls_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MtlsCertificateConfig
    */
    constructor(scope: Construct, id: string, config: MtlsCertificateConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _ca?;
    get ca(): boolean | cdktf.IResolvable;
    set ca(value: boolean | cdktf.IResolvable);
    get caInput(): boolean | cdktf.IResolvable | undefined;
    private _certificates?;
    get certificates(): string;
    set certificates(value: string);
    get certificatesInput(): string | undefined;
    get expiresOn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuer(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    get serialNumber(): string;
    get signature(): string;
    get uploadedOn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
