import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AccessGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. Conflicts with `zone_id`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#account_id AccessGroup#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#id AccessGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name: string;
    /**
    * The zone identifier to target for the resource. Conflicts with `account_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#zone_id AccessGroup#zone_id}
    */
    readonly zoneId?: string;
    /**
    * exclude block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#exclude AccessGroup#exclude}
    */
    readonly exclude?: AccessGroupExclude[] | cdktf.IResolvable;
    /**
    * include block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#include AccessGroup#include}
    */
    readonly include: AccessGroupInclude[] | cdktf.IResolvable;
    /**
    * require block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#require AccessGroup#require}
    */
    readonly require?: AccessGroupRequire[] | cdktf.IResolvable;
}
export interface AccessGroupExcludeAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#id AccessGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupExcludeAzureToTerraform(struct?: AccessGroupExcludeAzure | cdktf.IResolvable): any;
export declare function accessGroupExcludeAzureToHclTerraform(struct?: AccessGroupExcludeAzure | cdktf.IResolvable): any;
export declare class AccessGroupExcludeAzureOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExcludeAzure | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupExcludeAzure | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupExcludeAzureList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupExcludeAzure[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeAzureOutputReference;
}
export interface AccessGroupExcludeExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#evaluate_url AccessGroup#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#keys_url AccessGroup#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessGroupExcludeExternalEvaluationToTerraform(struct?: AccessGroupExcludeExternalEvaluationOutputReference | AccessGroupExcludeExternalEvaluation): any;
export declare function accessGroupExcludeExternalEvaluationToHclTerraform(struct?: AccessGroupExcludeExternalEvaluationOutputReference | AccessGroupExcludeExternalEvaluation): any;
export declare class AccessGroupExcludeExternalEvaluationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessGroupExcludeExternalEvaluation | undefined;
    set internalValue(value: AccessGroupExcludeExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessGroupExcludeGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#teams AccessGroup#teams}
    */
    readonly teams?: string[];
}
export declare function accessGroupExcludeGithubToTerraform(struct?: AccessGroupExcludeGithub | cdktf.IResolvable): any;
export declare function accessGroupExcludeGithubToHclTerraform(struct?: AccessGroupExcludeGithub | cdktf.IResolvable): any;
export declare class AccessGroupExcludeGithubOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExcludeGithub | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupExcludeGithub | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessGroupExcludeGithubList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupExcludeGithub[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeGithubOutputReference;
}
export interface AccessGroupExcludeGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupExcludeGsuiteToTerraform(struct?: AccessGroupExcludeGsuite | cdktf.IResolvable): any;
export declare function accessGroupExcludeGsuiteToHclTerraform(struct?: AccessGroupExcludeGsuite | cdktf.IResolvable): any;
export declare class AccessGroupExcludeGsuiteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExcludeGsuite | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupExcludeGsuite | cdktf.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupExcludeGsuiteList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupExcludeGsuite[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeGsuiteOutputReference;
}
export interface AccessGroupExcludeOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string[];
}
export declare function accessGroupExcludeOktaToTerraform(struct?: AccessGroupExcludeOkta | cdktf.IResolvable): any;
export declare function accessGroupExcludeOktaToHclTerraform(struct?: AccessGroupExcludeOkta | cdktf.IResolvable): any;
export declare class AccessGroupExcludeOktaOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExcludeOkta | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupExcludeOkta | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessGroupExcludeOktaList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupExcludeOkta[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeOktaOutputReference;
}
export interface AccessGroupExcludeSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_name AccessGroup#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_value AccessGroup#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupExcludeSamlToTerraform(struct?: AccessGroupExcludeSaml | cdktf.IResolvable): any;
export declare function accessGroupExcludeSamlToHclTerraform(struct?: AccessGroupExcludeSaml | cdktf.IResolvable): any;
export declare class AccessGroupExcludeSamlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExcludeSaml | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupExcludeSaml | cdktf.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupExcludeSamlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupExcludeSaml[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeSamlOutputReference;
}
export interface AccessGroupExclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#any_valid_service_token AccessGroup#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#auth_method AccessGroup#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#certificate AccessGroup#certificate}
    */
    readonly certificate?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#common_name AccessGroup#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#device_posture AccessGroup#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email_domain AccessGroup#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#everyone AccessGroup#everyone}
    */
    readonly everyone?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#geo AccessGroup#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#group AccessGroup#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip AccessGroup#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip_list AccessGroup#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#login_method AccessGroup#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#service_token AccessGroup#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#azure AccessGroup#azure}
    */
    readonly azure?: AccessGroupExcludeAzure[] | cdktf.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#external_evaluation AccessGroup#external_evaluation}
    */
    readonly externalEvaluation?: AccessGroupExcludeExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#github AccessGroup#github}
    */
    readonly github?: AccessGroupExcludeGithub[] | cdktf.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#gsuite AccessGroup#gsuite}
    */
    readonly gsuite?: AccessGroupExcludeGsuite[] | cdktf.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#okta AccessGroup#okta}
    */
    readonly okta?: AccessGroupExcludeOkta[] | cdktf.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#saml AccessGroup#saml}
    */
    readonly saml?: AccessGroupExcludeSaml[] | cdktf.IResolvable;
}
export declare function accessGroupExcludeToTerraform(struct?: AccessGroupExclude | cdktf.IResolvable): any;
export declare function accessGroupExcludeToHclTerraform(struct?: AccessGroupExclude | cdktf.IResolvable): any;
export declare class AccessGroupExcludeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExclude | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupExclude | cdktf.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktf.IResolvable;
    set anyValidServiceToken(value: boolean | cdktf.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktf.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktf.IResolvable;
    set certificate(value: boolean | cdktf.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktf.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktf.IResolvable;
    set everyone(value: boolean | cdktf.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktf.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessGroupExcludeAzureList;
    putAzure(value: AccessGroupExcludeAzure[] | cdktf.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktf.IResolvable | AccessGroupExcludeAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessGroupExcludeExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessGroupExcludeExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessGroupExcludeExternalEvaluation | undefined;
    private _github;
    get github(): AccessGroupExcludeGithubList;
    putGithub(value: AccessGroupExcludeGithub[] | cdktf.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktf.IResolvable | AccessGroupExcludeGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessGroupExcludeGsuiteList;
    putGsuite(value: AccessGroupExcludeGsuite[] | cdktf.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktf.IResolvable | AccessGroupExcludeGsuite[] | undefined;
    private _okta;
    get okta(): AccessGroupExcludeOktaList;
    putOkta(value: AccessGroupExcludeOkta[] | cdktf.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktf.IResolvable | AccessGroupExcludeOkta[] | undefined;
    private _saml;
    get saml(): AccessGroupExcludeSamlList;
    putSaml(value: AccessGroupExcludeSaml[] | cdktf.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktf.IResolvable | AccessGroupExcludeSaml[] | undefined;
}
export declare class AccessGroupExcludeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupExclude[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeOutputReference;
}
export interface AccessGroupIncludeAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#id AccessGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupIncludeAzureToTerraform(struct?: AccessGroupIncludeAzure | cdktf.IResolvable): any;
export declare function accessGroupIncludeAzureToHclTerraform(struct?: AccessGroupIncludeAzure | cdktf.IResolvable): any;
export declare class AccessGroupIncludeAzureOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupIncludeAzure | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupIncludeAzure | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupIncludeAzureList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupIncludeAzure[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeAzureOutputReference;
}
export interface AccessGroupIncludeExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#evaluate_url AccessGroup#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#keys_url AccessGroup#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessGroupIncludeExternalEvaluationToTerraform(struct?: AccessGroupIncludeExternalEvaluationOutputReference | AccessGroupIncludeExternalEvaluation): any;
export declare function accessGroupIncludeExternalEvaluationToHclTerraform(struct?: AccessGroupIncludeExternalEvaluationOutputReference | AccessGroupIncludeExternalEvaluation): any;
export declare class AccessGroupIncludeExternalEvaluationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessGroupIncludeExternalEvaluation | undefined;
    set internalValue(value: AccessGroupIncludeExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessGroupIncludeGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#teams AccessGroup#teams}
    */
    readonly teams?: string[];
}
export declare function accessGroupIncludeGithubToTerraform(struct?: AccessGroupIncludeGithub | cdktf.IResolvable): any;
export declare function accessGroupIncludeGithubToHclTerraform(struct?: AccessGroupIncludeGithub | cdktf.IResolvable): any;
export declare class AccessGroupIncludeGithubOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupIncludeGithub | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupIncludeGithub | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessGroupIncludeGithubList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupIncludeGithub[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeGithubOutputReference;
}
export interface AccessGroupIncludeGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupIncludeGsuiteToTerraform(struct?: AccessGroupIncludeGsuite | cdktf.IResolvable): any;
export declare function accessGroupIncludeGsuiteToHclTerraform(struct?: AccessGroupIncludeGsuite | cdktf.IResolvable): any;
export declare class AccessGroupIncludeGsuiteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupIncludeGsuite | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupIncludeGsuite | cdktf.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupIncludeGsuiteList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupIncludeGsuite[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeGsuiteOutputReference;
}
export interface AccessGroupIncludeOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string[];
}
export declare function accessGroupIncludeOktaToTerraform(struct?: AccessGroupIncludeOkta | cdktf.IResolvable): any;
export declare function accessGroupIncludeOktaToHclTerraform(struct?: AccessGroupIncludeOkta | cdktf.IResolvable): any;
export declare class AccessGroupIncludeOktaOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupIncludeOkta | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupIncludeOkta | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessGroupIncludeOktaList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupIncludeOkta[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeOktaOutputReference;
}
export interface AccessGroupIncludeSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_name AccessGroup#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_value AccessGroup#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupIncludeSamlToTerraform(struct?: AccessGroupIncludeSaml | cdktf.IResolvable): any;
export declare function accessGroupIncludeSamlToHclTerraform(struct?: AccessGroupIncludeSaml | cdktf.IResolvable): any;
export declare class AccessGroupIncludeSamlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupIncludeSaml | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupIncludeSaml | cdktf.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupIncludeSamlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupIncludeSaml[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeSamlOutputReference;
}
export interface AccessGroupInclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#any_valid_service_token AccessGroup#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#auth_method AccessGroup#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#certificate AccessGroup#certificate}
    */
    readonly certificate?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#common_name AccessGroup#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#device_posture AccessGroup#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email_domain AccessGroup#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#everyone AccessGroup#everyone}
    */
    readonly everyone?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#geo AccessGroup#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#group AccessGroup#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip AccessGroup#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip_list AccessGroup#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#login_method AccessGroup#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#service_token AccessGroup#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#azure AccessGroup#azure}
    */
    readonly azure?: AccessGroupIncludeAzure[] | cdktf.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#external_evaluation AccessGroup#external_evaluation}
    */
    readonly externalEvaluation?: AccessGroupIncludeExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#github AccessGroup#github}
    */
    readonly github?: AccessGroupIncludeGithub[] | cdktf.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#gsuite AccessGroup#gsuite}
    */
    readonly gsuite?: AccessGroupIncludeGsuite[] | cdktf.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#okta AccessGroup#okta}
    */
    readonly okta?: AccessGroupIncludeOkta[] | cdktf.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#saml AccessGroup#saml}
    */
    readonly saml?: AccessGroupIncludeSaml[] | cdktf.IResolvable;
}
export declare function accessGroupIncludeToTerraform(struct?: AccessGroupInclude | cdktf.IResolvable): any;
export declare function accessGroupIncludeToHclTerraform(struct?: AccessGroupInclude | cdktf.IResolvable): any;
export declare class AccessGroupIncludeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupInclude | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupInclude | cdktf.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktf.IResolvable;
    set anyValidServiceToken(value: boolean | cdktf.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktf.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktf.IResolvable;
    set certificate(value: boolean | cdktf.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktf.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktf.IResolvable;
    set everyone(value: boolean | cdktf.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktf.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessGroupIncludeAzureList;
    putAzure(value: AccessGroupIncludeAzure[] | cdktf.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktf.IResolvable | AccessGroupIncludeAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessGroupIncludeExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessGroupIncludeExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessGroupIncludeExternalEvaluation | undefined;
    private _github;
    get github(): AccessGroupIncludeGithubList;
    putGithub(value: AccessGroupIncludeGithub[] | cdktf.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktf.IResolvable | AccessGroupIncludeGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessGroupIncludeGsuiteList;
    putGsuite(value: AccessGroupIncludeGsuite[] | cdktf.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktf.IResolvable | AccessGroupIncludeGsuite[] | undefined;
    private _okta;
    get okta(): AccessGroupIncludeOktaList;
    putOkta(value: AccessGroupIncludeOkta[] | cdktf.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktf.IResolvable | AccessGroupIncludeOkta[] | undefined;
    private _saml;
    get saml(): AccessGroupIncludeSamlList;
    putSaml(value: AccessGroupIncludeSaml[] | cdktf.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktf.IResolvable | AccessGroupIncludeSaml[] | undefined;
}
export declare class AccessGroupIncludeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupInclude[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeOutputReference;
}
export interface AccessGroupRequireAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#id AccessGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupRequireAzureToTerraform(struct?: AccessGroupRequireAzure | cdktf.IResolvable): any;
export declare function accessGroupRequireAzureToHclTerraform(struct?: AccessGroupRequireAzure | cdktf.IResolvable): any;
export declare class AccessGroupRequireAzureOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequireAzure | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupRequireAzure | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupRequireAzureList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupRequireAzure[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireAzureOutputReference;
}
export interface AccessGroupRequireExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#evaluate_url AccessGroup#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#keys_url AccessGroup#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessGroupRequireExternalEvaluationToTerraform(struct?: AccessGroupRequireExternalEvaluationOutputReference | AccessGroupRequireExternalEvaluation): any;
export declare function accessGroupRequireExternalEvaluationToHclTerraform(struct?: AccessGroupRequireExternalEvaluationOutputReference | AccessGroupRequireExternalEvaluation): any;
export declare class AccessGroupRequireExternalEvaluationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessGroupRequireExternalEvaluation | undefined;
    set internalValue(value: AccessGroupRequireExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessGroupRequireGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#teams AccessGroup#teams}
    */
    readonly teams?: string[];
}
export declare function accessGroupRequireGithubToTerraform(struct?: AccessGroupRequireGithub | cdktf.IResolvable): any;
export declare function accessGroupRequireGithubToHclTerraform(struct?: AccessGroupRequireGithub | cdktf.IResolvable): any;
export declare class AccessGroupRequireGithubOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequireGithub | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupRequireGithub | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessGroupRequireGithubList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupRequireGithub[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireGithubOutputReference;
}
export interface AccessGroupRequireGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupRequireGsuiteToTerraform(struct?: AccessGroupRequireGsuite | cdktf.IResolvable): any;
export declare function accessGroupRequireGsuiteToHclTerraform(struct?: AccessGroupRequireGsuite | cdktf.IResolvable): any;
export declare class AccessGroupRequireGsuiteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequireGsuite | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupRequireGsuite | cdktf.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupRequireGsuiteList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupRequireGsuite[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireGsuiteOutputReference;
}
export interface AccessGroupRequireOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string[];
}
export declare function accessGroupRequireOktaToTerraform(struct?: AccessGroupRequireOkta | cdktf.IResolvable): any;
export declare function accessGroupRequireOktaToHclTerraform(struct?: AccessGroupRequireOkta | cdktf.IResolvable): any;
export declare class AccessGroupRequireOktaOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequireOkta | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupRequireOkta | cdktf.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessGroupRequireOktaList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupRequireOkta[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireOktaOutputReference;
}
export interface AccessGroupRequireSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_name AccessGroup#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_value AccessGroup#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupRequireSamlToTerraform(struct?: AccessGroupRequireSaml | cdktf.IResolvable): any;
export declare function accessGroupRequireSamlToHclTerraform(struct?: AccessGroupRequireSaml | cdktf.IResolvable): any;
export declare class AccessGroupRequireSamlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequireSaml | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupRequireSaml | cdktf.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupRequireSamlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupRequireSaml[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireSamlOutputReference;
}
export interface AccessGroupRequire {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#any_valid_service_token AccessGroup#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#auth_method AccessGroup#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#certificate AccessGroup#certificate}
    */
    readonly certificate?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#common_name AccessGroup#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#device_posture AccessGroup#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email_domain AccessGroup#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#everyone AccessGroup#everyone}
    */
    readonly everyone?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#geo AccessGroup#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#group AccessGroup#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip AccessGroup#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip_list AccessGroup#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#login_method AccessGroup#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#service_token AccessGroup#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#azure AccessGroup#azure}
    */
    readonly azure?: AccessGroupRequireAzure[] | cdktf.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#external_evaluation AccessGroup#external_evaluation}
    */
    readonly externalEvaluation?: AccessGroupRequireExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#github AccessGroup#github}
    */
    readonly github?: AccessGroupRequireGithub[] | cdktf.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#gsuite AccessGroup#gsuite}
    */
    readonly gsuite?: AccessGroupRequireGsuite[] | cdktf.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#okta AccessGroup#okta}
    */
    readonly okta?: AccessGroupRequireOkta[] | cdktf.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#saml AccessGroup#saml}
    */
    readonly saml?: AccessGroupRequireSaml[] | cdktf.IResolvable;
}
export declare function accessGroupRequireToTerraform(struct?: AccessGroupRequire | cdktf.IResolvable): any;
export declare function accessGroupRequireToHclTerraform(struct?: AccessGroupRequire | cdktf.IResolvable): any;
export declare class AccessGroupRequireOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequire | cdktf.IResolvable | undefined;
    set internalValue(value: AccessGroupRequire | cdktf.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktf.IResolvable;
    set anyValidServiceToken(value: boolean | cdktf.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktf.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktf.IResolvable;
    set certificate(value: boolean | cdktf.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktf.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktf.IResolvable;
    set everyone(value: boolean | cdktf.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktf.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessGroupRequireAzureList;
    putAzure(value: AccessGroupRequireAzure[] | cdktf.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktf.IResolvable | AccessGroupRequireAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessGroupRequireExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessGroupRequireExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessGroupRequireExternalEvaluation | undefined;
    private _github;
    get github(): AccessGroupRequireGithubList;
    putGithub(value: AccessGroupRequireGithub[] | cdktf.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktf.IResolvable | AccessGroupRequireGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessGroupRequireGsuiteList;
    putGsuite(value: AccessGroupRequireGsuite[] | cdktf.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktf.IResolvable | AccessGroupRequireGsuite[] | undefined;
    private _okta;
    get okta(): AccessGroupRequireOktaList;
    putOkta(value: AccessGroupRequireOkta[] | cdktf.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktf.IResolvable | AccessGroupRequireOkta[] | undefined;
    private _saml;
    get saml(): AccessGroupRequireSamlList;
    putSaml(value: AccessGroupRequireSaml[] | cdktf.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktf.IResolvable | AccessGroupRequireSaml[] | undefined;
}
export declare class AccessGroupRequireList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessGroupRequire[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group cloudflare_access_group}
*/
export declare class AccessGroup extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_access_group";
    /**
    * Generates CDKTF code for importing a AccessGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessGroup to import
    * @param importFromId The id of the existing AccessGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group cloudflare_access_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessGroupConfig
    */
    constructor(scope: Construct, id: string, config: AccessGroupConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _exclude;
    get exclude(): AccessGroupExcludeList;
    putExclude(value: AccessGroupExclude[] | cdktf.IResolvable): void;
    resetExclude(): void;
    get excludeInput(): cdktf.IResolvable | AccessGroupExclude[] | undefined;
    private _include;
    get include(): AccessGroupIncludeList;
    putInclude(value: AccessGroupInclude[] | cdktf.IResolvable): void;
    get includeInput(): cdktf.IResolvable | AccessGroupInclude[] | undefined;
    private _require;
    get require(): AccessGroupRequireList;
    putRequire(value: AccessGroupRequire[] | cdktf.IResolvable): void;
    resetRequire(): void;
    get requireInput(): cdktf.IResolvable | AccessGroupRequire[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
