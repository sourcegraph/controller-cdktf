import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AddressMapConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#account_id AddressMap#account_id}
    */
    readonly accountId: string;
    /**
    * If you have legacy TLS clients which do not send the TLS server name indicator, then you can specify one default SNI on the map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#default_sni AddressMap#default_sni}
    */
    readonly defaultSni?: string;
    /**
    * Description of the address map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#description AddressMap#description}
    */
    readonly description?: string;
    /**
    * Whether the Address Map is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#enabled AddressMap#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#id AddressMap#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ips block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#ips AddressMap#ips}
    */
    readonly ips?: AddressMapIps[] | cdktf.IResolvable;
    /**
    * memberships block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#memberships AddressMap#memberships}
    */
    readonly memberships?: AddressMapMemberships[] | cdktf.IResolvable;
}
export interface AddressMapIps {
    /**
    * An IPv4 or IPv6 address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#ip AddressMap#ip}
    */
    readonly ip: string;
}
export declare function addressMapIpsToTerraform(struct?: AddressMapIps | cdktf.IResolvable): any;
export declare function addressMapIpsToHclTerraform(struct?: AddressMapIps | cdktf.IResolvable): any;
export declare class AddressMapIpsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AddressMapIps | cdktf.IResolvable | undefined;
    set internalValue(value: AddressMapIps | cdktf.IResolvable | undefined);
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
}
export declare class AddressMapIpsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AddressMapIps[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AddressMapIpsOutputReference;
}
export interface AddressMapMemberships {
    /**
    * Identifier of the account or zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#identifier AddressMap#identifier}
    */
    readonly identifier: string;
    /**
    * The type of the membership.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#kind AddressMap#kind}
    */
    readonly kind: string;
}
export declare function addressMapMembershipsToTerraform(struct?: AddressMapMemberships | cdktf.IResolvable): any;
export declare function addressMapMembershipsToHclTerraform(struct?: AddressMapMemberships | cdktf.IResolvable): any;
export declare class AddressMapMembershipsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AddressMapMemberships | cdktf.IResolvable | undefined;
    set internalValue(value: AddressMapMemberships | cdktf.IResolvable | undefined);
    get canDelete(): cdktf.IResolvable;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
}
export declare class AddressMapMembershipsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AddressMapMemberships[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AddressMapMembershipsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map cloudflare_address_map}
*/
export declare class AddressMap extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_address_map";
    /**
    * Generates CDKTF code for importing a AddressMap resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AddressMap to import
    * @param importFromId The id of the existing AddressMap that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AddressMap to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map cloudflare_address_map} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AddressMapConfig
    */
    constructor(scope: Construct, id: string, config: AddressMapConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get canDelete(): cdktf.IResolvable;
    get canModifyIps(): cdktf.IResolvable;
    private _defaultSni?;
    get defaultSni(): string;
    set defaultSni(value: string);
    resetDefaultSni(): void;
    get defaultSniInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ips;
    get ips(): AddressMapIpsList;
    putIps(value: AddressMapIps[] | cdktf.IResolvable): void;
    resetIps(): void;
    get ipsInput(): cdktf.IResolvable | AddressMapIps[] | undefined;
    private _memberships;
    get memberships(): AddressMapMembershipsList;
    putMemberships(value: AddressMapMemberships[] | cdktf.IResolvable): void;
    resetMemberships(): void;
    get membershipsInput(): cdktf.IResolvable | AddressMapMemberships[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
