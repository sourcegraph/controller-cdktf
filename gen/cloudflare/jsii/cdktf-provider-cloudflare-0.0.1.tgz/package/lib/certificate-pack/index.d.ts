import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CertificatePackConfig extends cdktf.TerraformMetaArguments {
    /**
    * Which certificate authority to issue the certificate pack. Available values: `digicert`, `lets_encrypt`, `google`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#certificate_authority CertificatePack#certificate_authority}
    */
    readonly certificateAuthority: string;
    /**
    * Whether or not to include Cloudflare branding. This will add `sni.cloudflaressl.com` as the Common Name if set to `true`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#cloudflare_branding CertificatePack#cloudflare_branding}
    */
    readonly cloudflareBranding?: boolean | cdktf.IResolvable;
    /**
    * List of hostnames to provision the certificate pack for. The zone name must be included as a host. Note: If using Let's Encrypt, you cannot use individual subdomains and only a wildcard for subdomain is available. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#hosts CertificatePack#hosts}
    */
    readonly hosts: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#id CertificatePack#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Certificate pack configuration type. Available values: `advanced`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#type CertificatePack#type}
    */
    readonly type: string;
    /**
    * Which validation method to use in order to prove domain ownership. Available values: `txt`, `http`, `email`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#validation_method CertificatePack#validation_method}
    */
    readonly validationMethod: string;
    /**
    * How long the certificate is valid for. Note: If using Let's Encrypt, this value can only be 90 days. Available values: `14`, `30`, `90`, `365`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#validity_days CertificatePack#validity_days}
    */
    readonly validityDays: number;
    /**
    * Whether or not to wait for a certificate pack to reach status `active` during creation. Defaults to `false`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#wait_for_active_status CertificatePack#wait_for_active_status}
    */
    readonly waitForActiveStatus?: boolean | cdktf.IResolvable;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#zone_id CertificatePack#zone_id}
    */
    readonly zoneId: string;
    /**
    * validation_errors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#validation_errors CertificatePack#validation_errors}
    */
    readonly validationErrors?: CertificatePackValidationErrors[] | cdktf.IResolvable;
    /**
    * validation_records block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#validation_records CertificatePack#validation_records}
    */
    readonly validationRecords?: CertificatePackValidationRecords[] | cdktf.IResolvable;
}
export interface CertificatePackValidationErrors {
}
export declare function certificatePackValidationErrorsToTerraform(struct?: CertificatePackValidationErrors | cdktf.IResolvable): any;
export declare function certificatePackValidationErrorsToHclTerraform(struct?: CertificatePackValidationErrors | cdktf.IResolvable): any;
export declare class CertificatePackValidationErrorsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificatePackValidationErrors | cdktf.IResolvable | undefined;
    set internalValue(value: CertificatePackValidationErrors | cdktf.IResolvable | undefined);
    get message(): string;
}
export declare class CertificatePackValidationErrorsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CertificatePackValidationErrors[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificatePackValidationErrorsOutputReference;
}
export interface CertificatePackValidationRecords {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#cname_name CertificatePack#cname_name}
    */
    readonly cnameName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#cname_target CertificatePack#cname_target}
    */
    readonly cnameTarget?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#emails CertificatePack#emails}
    */
    readonly emails?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#http_body CertificatePack#http_body}
    */
    readonly httpBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#http_url CertificatePack#http_url}
    */
    readonly httpUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#txt_name CertificatePack#txt_name}
    */
    readonly txtName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#txt_value CertificatePack#txt_value}
    */
    readonly txtValue?: string;
}
export declare function certificatePackValidationRecordsToTerraform(struct?: CertificatePackValidationRecords | cdktf.IResolvable): any;
export declare function certificatePackValidationRecordsToHclTerraform(struct?: CertificatePackValidationRecords | cdktf.IResolvable): any;
export declare class CertificatePackValidationRecordsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificatePackValidationRecords | cdktf.IResolvable | undefined;
    set internalValue(value: CertificatePackValidationRecords | cdktf.IResolvable | undefined);
    private _cnameName?;
    get cnameName(): string;
    set cnameName(value: string);
    resetCnameName(): void;
    get cnameNameInput(): string | undefined;
    private _cnameTarget?;
    get cnameTarget(): string;
    set cnameTarget(value: string);
    resetCnameTarget(): void;
    get cnameTargetInput(): string | undefined;
    private _emails?;
    get emails(): string[];
    set emails(value: string[]);
    resetEmails(): void;
    get emailsInput(): string[] | undefined;
    private _httpBody?;
    get httpBody(): string;
    set httpBody(value: string);
    resetHttpBody(): void;
    get httpBodyInput(): string | undefined;
    private _httpUrl?;
    get httpUrl(): string;
    set httpUrl(value: string);
    resetHttpUrl(): void;
    get httpUrlInput(): string | undefined;
    private _txtName?;
    get txtName(): string;
    set txtName(value: string);
    resetTxtName(): void;
    get txtNameInput(): string | undefined;
    private _txtValue?;
    get txtValue(): string;
    set txtValue(value: string);
    resetTxtValue(): void;
    get txtValueInput(): string | undefined;
}
export declare class CertificatePackValidationRecordsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CertificatePackValidationRecords[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificatePackValidationRecordsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack cloudflare_certificate_pack}
*/
export declare class CertificatePack extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_certificate_pack";
    /**
    * Generates CDKTF code for importing a CertificatePack resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificatePack to import
    * @param importFromId The id of the existing CertificatePack that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificatePack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/certificate_pack cloudflare_certificate_pack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificatePackConfig
    */
    constructor(scope: Construct, id: string, config: CertificatePackConfig);
    private _certificateAuthority?;
    get certificateAuthority(): string;
    set certificateAuthority(value: string);
    get certificateAuthorityInput(): string | undefined;
    private _cloudflareBranding?;
    get cloudflareBranding(): boolean | cdktf.IResolvable;
    set cloudflareBranding(value: boolean | cdktf.IResolvable);
    resetCloudflareBranding(): void;
    get cloudflareBrandingInput(): boolean | cdktf.IResolvable | undefined;
    private _hosts?;
    get hosts(): string[];
    set hosts(value: string[]);
    get hostsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _validationMethod?;
    get validationMethod(): string;
    set validationMethod(value: string);
    get validationMethodInput(): string | undefined;
    private _validityDays?;
    get validityDays(): number;
    set validityDays(value: number);
    get validityDaysInput(): number | undefined;
    private _waitForActiveStatus?;
    get waitForActiveStatus(): boolean | cdktf.IResolvable;
    set waitForActiveStatus(value: boolean | cdktf.IResolvable);
    resetWaitForActiveStatus(): void;
    get waitForActiveStatusInput(): boolean | cdktf.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _validationErrors;
    get validationErrors(): CertificatePackValidationErrorsList;
    putValidationErrors(value: CertificatePackValidationErrors[] | cdktf.IResolvable): void;
    resetValidationErrors(): void;
    get validationErrorsInput(): cdktf.IResolvable | CertificatePackValidationErrors[] | undefined;
    private _validationRecords;
    get validationRecords(): CertificatePackValidationRecordsList;
    putValidationRecords(value: CertificatePackValidationRecords[] | cdktf.IResolvable): void;
    resetValidationRecords(): void;
    get validationRecordsInput(): cdktf.IResolvable | CertificatePackValidationRecords[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
