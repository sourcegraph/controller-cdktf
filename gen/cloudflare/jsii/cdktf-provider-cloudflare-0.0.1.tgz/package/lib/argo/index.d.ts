import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ArgoConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/argo#id Argo#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether smart routing is enabled. Available values: `on`, `off`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/argo#smart_routing Argo#smart_routing}
    */
    readonly smartRouting?: string;
    /**
    * Whether tiered caching is enabled. Available values: `on`, `off`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/argo#tiered_caching Argo#tiered_caching}
    */
    readonly tieredCaching?: string;
    /**
    * The zone identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/argo#zone_id Argo#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/argo cloudflare_argo}
*/
export declare class Argo extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_argo";
    /**
    * Generates CDKTF code for importing a Argo resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Argo to import
    * @param importFromId The id of the existing Argo that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/argo#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Argo to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/argo cloudflare_argo} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArgoConfig
    */
    constructor(scope: Construct, id: string, config: ArgoConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _smartRouting?;
    get smartRouting(): string;
    set smartRouting(value: string);
    resetSmartRouting(): void;
    get smartRoutingInput(): string | undefined;
    private _tieredCaching?;
    get tieredCaching(): string;
    set tieredCaching(value: string);
    resetTieredCaching(): void;
    get tieredCachingInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
