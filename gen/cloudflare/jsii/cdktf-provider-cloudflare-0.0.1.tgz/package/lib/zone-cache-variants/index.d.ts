import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ZoneCacheVariantsConfig extends cdktf.TerraformMetaArguments {
    /**
    * List of strings with the MIME types of all the variants that should be served for avif.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#avif ZoneCacheVariants#avif}
    */
    readonly avif?: string[];
    /**
    * List of strings with the MIME types of all the variants that should be served for bmp.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#bmp ZoneCacheVariants#bmp}
    */
    readonly bmp?: string[];
    /**
    * List of strings with the MIME types of all the variants that should be served for gif.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#gif ZoneCacheVariants#gif}
    */
    readonly gif?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#id ZoneCacheVariants#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * List of strings with the MIME types of all the variants that should be served for jp2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#jp2 ZoneCacheVariants#jp2}
    */
    readonly jp2?: string[];
    /**
    * List of strings with the MIME types of all the variants that should be served for jpeg.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#jpeg ZoneCacheVariants#jpeg}
    */
    readonly jpeg?: string[];
    /**
    * List of strings with the MIME types of all the variants that should be served for jpg.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#jpg ZoneCacheVariants#jpg}
    */
    readonly jpg?: string[];
    /**
    * List of strings with the MIME types of all the variants that should be served for jpg2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#jpg2 ZoneCacheVariants#jpg2}
    */
    readonly jpg2?: string[];
    /**
    * List of strings with the MIME types of all the variants that should be served for png.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#png ZoneCacheVariants#png}
    */
    readonly png?: string[];
    /**
    * List of strings with the MIME types of all the variants that should be served for tif.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#tif ZoneCacheVariants#tif}
    */
    readonly tif?: string[];
    /**
    * List of strings with the MIME types of all the variants that should be served for tiff.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#tiff ZoneCacheVariants#tiff}
    */
    readonly tiff?: string[];
    /**
    * List of strings with the MIME types of all the variants that should be served for webp.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#webp ZoneCacheVariants#webp}
    */
    readonly webp?: string[];
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#zone_id ZoneCacheVariants#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants cloudflare_zone_cache_variants}
*/
export declare class ZoneCacheVariants extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_zone_cache_variants";
    /**
    * Generates CDKTF code for importing a ZoneCacheVariants resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ZoneCacheVariants to import
    * @param importFromId The id of the existing ZoneCacheVariants that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ZoneCacheVariants to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_cache_variants cloudflare_zone_cache_variants} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ZoneCacheVariantsConfig
    */
    constructor(scope: Construct, id: string, config: ZoneCacheVariantsConfig);
    private _avif?;
    get avif(): string[];
    set avif(value: string[]);
    resetAvif(): void;
    get avifInput(): string[] | undefined;
    private _bmp?;
    get bmp(): string[];
    set bmp(value: string[]);
    resetBmp(): void;
    get bmpInput(): string[] | undefined;
    private _gif?;
    get gif(): string[];
    set gif(value: string[]);
    resetGif(): void;
    get gifInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jp2?;
    get jp2(): string[];
    set jp2(value: string[]);
    resetJp2(): void;
    get jp2Input(): string[] | undefined;
    private _jpeg?;
    get jpeg(): string[];
    set jpeg(value: string[]);
    resetJpeg(): void;
    get jpegInput(): string[] | undefined;
    private _jpg?;
    get jpg(): string[];
    set jpg(value: string[]);
    resetJpg(): void;
    get jpgInput(): string[] | undefined;
    private _jpg2?;
    get jpg2(): string[];
    set jpg2(value: string[]);
    resetJpg2(): void;
    get jpg2Input(): string[] | undefined;
    private _png?;
    get png(): string[];
    set png(value: string[]);
    resetPng(): void;
    get pngInput(): string[] | undefined;
    private _tif?;
    get tif(): string[];
    set tif(value: string[]);
    resetTif(): void;
    get tifInput(): string[] | undefined;
    private _tiff?;
    get tiff(): string[];
    set tiff(value: string[]);
    resetTiff(): void;
    get tiffInput(): string[] | undefined;
    private _webp?;
    get webp(): string[];
    set webp(value: string[]);
    resetWebp(): void;
    get webpInput(): string[] | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
