import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataCloudflareRulesetsConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. Must provide only one of `zone_id`, `account_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#account_id DataCloudflareRulesets#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#id DataCloudflareRulesets#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Include rule data in response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#include_rules DataCloudflareRulesets#include_rules}
    */
    readonly includeRules?: boolean | cdktf.IResolvable;
    /**
    * The zone identifier to target for the resource. Must provide only one of `zone_id`, `account_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#zone_id DataCloudflareRulesets#zone_id}
    */
    readonly zoneId?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#filter DataCloudflareRulesets#filter}
    */
    readonly filter?: DataCloudflareRulesetsFilter;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersAutominify {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersAutominifyToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersAutominify): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersAutominifyToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersAutominify): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersAutominifyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersAutominify | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersAutominify | undefined);
    get css(): cdktf.IResolvable;
    get html(): cdktf.IResolvable;
    get js(): cdktf.IResolvable;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersAutominifyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersAutominifyOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtl {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtlToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtl): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtlToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtl): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtl | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtl | undefined);
    get default(): number;
    get mode(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtlOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookie {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookieToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookie): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookieToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookie): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookieOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookie | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookie | undefined);
    get checkPresence(): string[];
    get include(): string[];
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookieList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookieOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeader {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeaderToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeader): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeaderToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeader): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeaderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeader | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeader | undefined);
    get checkPresence(): string[];
    get excludeOrigin(): cdktf.IResolvable;
    get include(): string[];
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeaderList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeaderOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHost {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHostToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHost): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHostToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHost): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHostOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHost | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHost | undefined);
    get resolved(): cdktf.IResolvable;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHostList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHostOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryString {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryStringToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryString): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryStringToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryString): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryStringOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryString | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryString | undefined);
    get exclude(): string[];
    get include(): string[];
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryStringList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryStringOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUser {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUserToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUser): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUserToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUser): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUserOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUser | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUser | undefined);
    get deviceType(): cdktf.IResolvable;
    get geo(): cdktf.IResolvable;
    get lang(): cdktf.IResolvable;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUserList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUserOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKey {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKey): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKey): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKey | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKey | undefined);
    private _cookie;
    get cookie(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyCookieList;
    private _header;
    get header(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHeaderList;
    private _host;
    get host(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyHostList;
    private _queryString;
    get queryString(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyQueryStringList;
    private _user;
    get user(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyUserList;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersCacheKey {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKey): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKey): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKey | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersCacheKey | undefined);
    get cacheByDeviceType(): cdktf.IResolvable;
    get cacheDeceptionArmor(): cdktf.IResolvable;
    private _customKey;
    get customKey(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyCustomKeyList;
    get ignoreQueryStringsOrder(): cdktf.IResolvable;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | undefined);
    get from(): number;
    get to(): number;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtl {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtl): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtl): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtl | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtl | undefined);
    get statusCode(): number;
    private _statusCodeRange;
    get statusCodeRange(): DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeList;
    get value(): number;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtl {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtl): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtl): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtl | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtl | undefined);
    get default(): number;
    get mode(): string;
    private _statusCodeTtl;
    get statusCodeTtl(): DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlStatusCodeTtlList;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersFromListStruct {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersFromListStructToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersFromListStruct): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersFromListStructToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersFromListStruct): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersFromListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersFromListStruct | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersFromListStruct | undefined);
    get key(): string;
    get name(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersFromListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersFromListStructOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrl {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrlToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrl): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrlToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrl): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrl | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrl | undefined);
    get expression(): string;
    get value(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrlOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersFromValue {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersFromValueToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersFromValue): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersFromValueToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersFromValue): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersFromValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersFromValue | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersFromValue | undefined);
    get preserveQueryString(): cdktf.IResolvable;
    get statusCode(): number;
    private _targetUrl;
    get targetUrl(): DataCloudflareRulesetsRulesetsRulesActionParametersFromValueTargetUrlList;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersFromValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersFromValueOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersHeaders {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersHeadersToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersHeaders): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersHeadersToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersHeaders): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersHeadersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersHeaders | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersHeaders | undefined);
    get expression(): string;
    get name(): string;
    get operation(): string;
    get value(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersHeadersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersHeadersOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersMatchedData {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersMatchedDataToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersMatchedData): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersMatchedDataToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersMatchedData): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersMatchedDataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersMatchedData | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersMatchedData | undefined);
    get publicKey(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersMatchedDataList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersMatchedDataOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersOrigin {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersOriginToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersOrigin): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersOriginToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersOrigin): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersOriginOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersOrigin | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersOrigin | undefined);
    get host(): string;
    get port(): number;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersOriginList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersOriginOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategories {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategoriesToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategories): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategoriesToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategories): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategoriesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategories | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategories | undefined);
    get action(): string;
    get category(): string;
    get enabled(): cdktf.IResolvable;
    get status(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategoriesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategoriesOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersOverridesRules {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersOverridesRulesToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersOverridesRules): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersOverridesRulesToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersOverridesRules): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersOverridesRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersOverridesRules | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersOverridesRules | undefined);
    get action(): string;
    get enabled(): cdktf.IResolvable;
    get id(): string;
    get scoreThreshold(): number;
    get sensitivityLevel(): string;
    get status(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersOverridesRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersOverridesRulesOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersOverrides {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersOverridesToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersOverrides): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersOverridesToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersOverrides): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersOverridesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersOverrides | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersOverrides | undefined);
    get action(): string;
    private _categories;
    get categories(): DataCloudflareRulesetsRulesetsRulesActionParametersOverridesCategoriesList;
    get enabled(): cdktf.IResolvable;
    private _rules;
    get rules(): DataCloudflareRulesetsRulesetsRulesActionParametersOverridesRulesList;
    get sensitivityLevel(): string;
    get status(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersOverridesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersOverridesOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersResponse {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersResponseToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersResponse): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersResponseToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersResponse): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersResponseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersResponse | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersResponse | undefined);
    get content(): string;
    get contentType(): string;
    get statusCode(): number;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersResponseList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersResponseOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersServeStale {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersServeStaleToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersServeStale): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersServeStaleToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersServeStale): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersServeStaleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersServeStale | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersServeStale | undefined);
    get disableStaleWhileUpdating(): cdktf.IResolvable;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersServeStaleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersServeStaleOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersSni {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersSniToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersSni): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersSniToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersSni): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersSniOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersSni | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersSni | undefined);
    get value(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersSniList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersSniOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersUriPath {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersUriPathToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersUriPath): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersUriPathToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersUriPath): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersUriPathOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersUriPath | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersUriPath | undefined);
    get expression(): string;
    get value(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersUriPathList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersUriPathOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersUriQuery {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersUriQueryToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersUriQuery): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersUriQueryToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersUriQuery): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersUriQueryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersUriQuery | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersUriQuery | undefined);
    get expression(): string;
    get value(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersUriQueryList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersUriQueryOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParametersUri {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersUriToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersUri): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersUriToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParametersUri): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersUriOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParametersUri | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParametersUri | undefined);
    get origin(): cdktf.IResolvable;
    private _path;
    get path(): DataCloudflareRulesetsRulesetsRulesActionParametersUriPathList;
    private _query;
    get query(): DataCloudflareRulesetsRulesetsRulesActionParametersUriQueryList;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersUriList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersUriOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesActionParameters {
}
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParameters): any;
export declare function dataCloudflareRulesetsRulesetsRulesActionParametersToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesActionParameters): any;
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesActionParameters | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesActionParameters | undefined);
    get automaticHttpsRewrites(): cdktf.IResolvable;
    private _autominify;
    get autominify(): DataCloudflareRulesetsRulesetsRulesActionParametersAutominifyList;
    get bic(): cdktf.IResolvable;
    private _browserTtl;
    get browserTtl(): DataCloudflareRulesetsRulesetsRulesActionParametersBrowserTtlList;
    get cache(): cdktf.IResolvable;
    private _cacheKey;
    get cacheKey(): DataCloudflareRulesetsRulesetsRulesActionParametersCacheKeyList;
    get content(): string;
    get contentType(): string;
    get cookieFields(): string[];
    get disableApps(): cdktf.IResolvable;
    get disableRailgun(): cdktf.IResolvable;
    get disableZaraz(): cdktf.IResolvable;
    private _edgeTtl;
    get edgeTtl(): DataCloudflareRulesetsRulesetsRulesActionParametersEdgeTtlList;
    get emailObfuscation(): cdktf.IResolvable;
    private _fromList;
    get fromList(): DataCloudflareRulesetsRulesetsRulesActionParametersFromListStructList;
    private _fromValue;
    get fromValue(): DataCloudflareRulesetsRulesetsRulesActionParametersFromValueList;
    private _headers;
    get headers(): DataCloudflareRulesetsRulesetsRulesActionParametersHeadersList;
    get hostHeader(): string;
    get hotlinkProtection(): cdktf.IResolvable;
    get id(): string;
    get increment(): number;
    private _matchedData;
    get matchedData(): DataCloudflareRulesetsRulesetsRulesActionParametersMatchedDataList;
    get mirage(): cdktf.IResolvable;
    get opportunisticEncryption(): cdktf.IResolvable;
    private _origin;
    get origin(): DataCloudflareRulesetsRulesetsRulesActionParametersOriginList;
    get originErrorPagePassthru(): cdktf.IResolvable;
    private _overrides;
    get overrides(): DataCloudflareRulesetsRulesetsRulesActionParametersOverridesList;
    get phases(): string[];
    get polish(): string;
    get products(): string[];
    get requestFields(): string[];
    get respectStrongEtags(): cdktf.IResolvable;
    private _response;
    get response(): DataCloudflareRulesetsRulesetsRulesActionParametersResponseList;
    get responseFields(): string[];
    get rocketLoader(): cdktf.IResolvable;
    private _rules;
    get rules(): cdktf.StringMap;
    get ruleset(): string;
    get rulesets(): string[];
    get securityLevel(): string;
    private _serveStale;
    get serveStale(): DataCloudflareRulesetsRulesetsRulesActionParametersServeStaleList;
    get serverSideExcludes(): cdktf.IResolvable;
    private _sni;
    get sni(): DataCloudflareRulesetsRulesetsRulesActionParametersSniList;
    get ssl(): string;
    get statusCode(): number;
    get sxg(): cdktf.IResolvable;
    private _uri;
    get uri(): DataCloudflareRulesetsRulesetsRulesActionParametersUriList;
    get version(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesActionParametersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesActionParametersOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesExposedCredentialCheck {
}
export declare function dataCloudflareRulesetsRulesetsRulesExposedCredentialCheckToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesExposedCredentialCheck): any;
export declare function dataCloudflareRulesetsRulesetsRulesExposedCredentialCheckToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesExposedCredentialCheck): any;
export declare class DataCloudflareRulesetsRulesetsRulesExposedCredentialCheckOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesExposedCredentialCheck | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesExposedCredentialCheck | undefined);
    get passwordExpression(): string;
    get usernameExpression(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesExposedCredentialCheckList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesExposedCredentialCheckOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesLogging {
}
export declare function dataCloudflareRulesetsRulesetsRulesLoggingToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesLogging): any;
export declare function dataCloudflareRulesetsRulesetsRulesLoggingToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesLogging): any;
export declare class DataCloudflareRulesetsRulesetsRulesLoggingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesLogging | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesLogging | undefined);
    get enabled(): cdktf.IResolvable;
    get status(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesLoggingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesLoggingOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRulesRatelimit {
}
export declare function dataCloudflareRulesetsRulesetsRulesRatelimitToTerraform(struct?: DataCloudflareRulesetsRulesetsRulesRatelimit): any;
export declare function dataCloudflareRulesetsRulesetsRulesRatelimitToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRulesRatelimit): any;
export declare class DataCloudflareRulesetsRulesetsRulesRatelimitOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRulesRatelimit | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRulesRatelimit | undefined);
    get characteristics(): string[];
    get countingExpression(): string;
    get mitigationTimeout(): number;
    get period(): number;
    get requestsPerPeriod(): number;
    get requestsToOrigin(): cdktf.IResolvable;
    get scorePerPeriod(): number;
    get scoreResponseHeaderName(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesRatelimitList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesRatelimitOutputReference;
}
export interface DataCloudflareRulesetsRulesetsRules {
}
export declare function dataCloudflareRulesetsRulesetsRulesToTerraform(struct?: DataCloudflareRulesetsRulesetsRules): any;
export declare function dataCloudflareRulesetsRulesetsRulesToHclTerraform(struct?: DataCloudflareRulesetsRulesetsRules): any;
export declare class DataCloudflareRulesetsRulesetsRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesetsRules | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesetsRules | undefined);
    get action(): string;
    private _actionParameters;
    get actionParameters(): DataCloudflareRulesetsRulesetsRulesActionParametersList;
    get description(): string;
    get enabled(): cdktf.IResolvable;
    private _exposedCredentialCheck;
    get exposedCredentialCheck(): DataCloudflareRulesetsRulesetsRulesExposedCredentialCheckList;
    get expression(): string;
    get id(): string;
    get lastUpdated(): string;
    private _logging;
    get logging(): DataCloudflareRulesetsRulesetsRulesLoggingList;
    private _ratelimit;
    get ratelimit(): DataCloudflareRulesetsRulesetsRulesRatelimitList;
    get ref(): string;
    get version(): string;
}
export declare class DataCloudflareRulesetsRulesetsRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsRulesOutputReference;
}
export interface DataCloudflareRulesetsRulesets {
}
export declare function dataCloudflareRulesetsRulesetsToTerraform(struct?: DataCloudflareRulesetsRulesets): any;
export declare function dataCloudflareRulesetsRulesetsToHclTerraform(struct?: DataCloudflareRulesetsRulesets): any;
export declare class DataCloudflareRulesetsRulesetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetsRulesets | undefined;
    set internalValue(value: DataCloudflareRulesetsRulesets | undefined);
    get description(): string;
    get id(): string;
    get kind(): string;
    get name(): string;
    get phase(): string;
    private _rules;
    get rules(): DataCloudflareRulesetsRulesetsRulesList;
    get version(): string;
}
export declare class DataCloudflareRulesetsRulesetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetsRulesetsOutputReference;
}
export interface DataCloudflareRulesetsFilter {
    /**
    * The ID of the Ruleset to target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#id DataCloudflareRulesets#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Type of Ruleset to create. Available values: `custom`, `managed`, `root`, `schema`, `zone`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#kind DataCloudflareRulesets#kind}
    */
    readonly kind?: string;
    /**
    * Name of the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#name DataCloudflareRulesets#name}
    */
    readonly name?: string;
    /**
    * Point in the request/response lifecycle where the ruleset will be created. Available values: `ddos_l4`, `ddos_l7`, `http_custom_errors`, `http_log_custom_fields`, `http_request_cache_settings`, `http_request_firewall_custom`, `http_request_firewall_managed`, `http_request_late_transform`, `http_request_late_transform_managed`, `http_request_main`, `http_request_origin`, `http_request_dynamic_redirect`, `http_request_redirect`, `http_request_sanitize`, `http_request_transform`, `http_response_firewall_managed`, `http_response_headers_transform`, `http_response_headers_transform_managed`, `magic_transit`, `http_ratelimit`, `http_request_sbfm`, `http_config_settings`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#phase DataCloudflareRulesets#phase}
    */
    readonly phase?: string;
    /**
    * Version of the ruleset to filter on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#version DataCloudflareRulesets#version}
    */
    readonly version?: string;
}
export declare function dataCloudflareRulesetsFilterToTerraform(struct?: DataCloudflareRulesetsFilterOutputReference | DataCloudflareRulesetsFilter): any;
export declare function dataCloudflareRulesetsFilterToHclTerraform(struct?: DataCloudflareRulesetsFilterOutputReference | DataCloudflareRulesetsFilter): any;
export declare class DataCloudflareRulesetsFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetsFilter | undefined;
    set internalValue(value: DataCloudflareRulesetsFilter | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets cloudflare_rulesets}
*/
export declare class DataCloudflareRulesets extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_rulesets";
    /**
    * Generates CDKTF code for importing a DataCloudflareRulesets resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareRulesets to import
    * @param importFromId The id of the existing DataCloudflareRulesets that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareRulesets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/rulesets cloudflare_rulesets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareRulesetsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareRulesetsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeRules?;
    get includeRules(): boolean | cdktf.IResolvable;
    set includeRules(value: boolean | cdktf.IResolvable);
    resetIncludeRules(): void;
    get includeRulesInput(): boolean | cdktf.IResolvable | undefined;
    private _rulesets;
    get rulesets(): DataCloudflareRulesetsRulesetsList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _filter;
    get filter(): DataCloudflareRulesetsFilterOutputReference;
    putFilter(value: DataCloudflareRulesetsFilter): void;
    resetFilter(): void;
    get filterInput(): DataCloudflareRulesetsFilter | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
