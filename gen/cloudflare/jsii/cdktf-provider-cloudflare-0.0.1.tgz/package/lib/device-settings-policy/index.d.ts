import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DeviceSettingsPolicyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#account_id DeviceSettingsPolicy#account_id}
    */
    readonly accountId: string;
    /**
    * Whether to allow mode switch for this policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#allow_mode_switch DeviceSettingsPolicy#allow_mode_switch}
    */
    readonly allowModeSwitch?: boolean | cdktf.IResolvable;
    /**
    * Whether to allow updates under this policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#allow_updates DeviceSettingsPolicy#allow_updates}
    */
    readonly allowUpdates?: boolean | cdktf.IResolvable;
    /**
    * Whether to allow devices to leave the organization. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#allowed_to_leave DeviceSettingsPolicy#allowed_to_leave}
    */
    readonly allowedToLeave?: boolean | cdktf.IResolvable;
    /**
    * The amount of time in minutes to reconnect after having been disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#auto_connect DeviceSettingsPolicy#auto_connect}
    */
    readonly autoConnect?: number;
    /**
    * The captive portal value for this policy. Defaults to `180`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#captive_portal DeviceSettingsPolicy#captive_portal}
    */
    readonly captivePortal?: number;
    /**
    * Whether the policy refers to the default account policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#default DeviceSettingsPolicy#default}
    */
    readonly default?: boolean | cdktf.IResolvable;
    /**
    * Whether to disable auto fallback for this policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#disable_auto_fallback DeviceSettingsPolicy#disable_auto_fallback}
    */
    readonly disableAutoFallback?: boolean | cdktf.IResolvable;
    /**
    * Whether the policy is enabled (cannot be set for default policies). Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#enabled DeviceSettingsPolicy#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Whether to add Microsoft IPs to split tunnel exclusions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#exclude_office_ips DeviceSettingsPolicy#exclude_office_ips}
    */
    readonly excludeOfficeIps?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#id DeviceSettingsPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Wirefilter expression to match a device against when evaluating whether this policy should take effect for that device.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#match DeviceSettingsPolicy#match}
    */
    readonly match?: string;
    /**
    * Name of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#name DeviceSettingsPolicy#name}
    */
    readonly name: string;
    /**
    * The precedence of the policy. Lower values indicate higher precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#precedence DeviceSettingsPolicy#precedence}
    */
    readonly precedence?: number;
    /**
    * The service mode. Available values: `1dot1`, `warp`, `proxy`, `posture_only`, `warp_tunnel_only`. Defaults to `warp`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#service_mode_v2_mode DeviceSettingsPolicy#service_mode_v2_mode}
    */
    readonly serviceModeV2Mode?: string;
    /**
    * The port to use for the proxy service mode. Required when using `service_mode_v2_mode`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#service_mode_v2_port DeviceSettingsPolicy#service_mode_v2_port}
    */
    readonly serviceModeV2Port?: number;
    /**
    * The support URL that will be opened when sending feedback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#support_url DeviceSettingsPolicy#support_url}
    */
    readonly supportUrl?: string;
    /**
    * Enablement of the ZT client switch lock.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#switch_locked DeviceSettingsPolicy#switch_locked}
    */
    readonly switchLocked?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy cloudflare_device_settings_policy}
*/
export declare class DeviceSettingsPolicy extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_device_settings_policy";
    /**
    * Generates CDKTF code for importing a DeviceSettingsPolicy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DeviceSettingsPolicy to import
    * @param importFromId The id of the existing DeviceSettingsPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DeviceSettingsPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_settings_policy cloudflare_device_settings_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DeviceSettingsPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DeviceSettingsPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _allowModeSwitch?;
    get allowModeSwitch(): boolean | cdktf.IResolvable;
    set allowModeSwitch(value: boolean | cdktf.IResolvable);
    resetAllowModeSwitch(): void;
    get allowModeSwitchInput(): boolean | cdktf.IResolvable | undefined;
    private _allowUpdates?;
    get allowUpdates(): boolean | cdktf.IResolvable;
    set allowUpdates(value: boolean | cdktf.IResolvable);
    resetAllowUpdates(): void;
    get allowUpdatesInput(): boolean | cdktf.IResolvable | undefined;
    private _allowedToLeave?;
    get allowedToLeave(): boolean | cdktf.IResolvable;
    set allowedToLeave(value: boolean | cdktf.IResolvable);
    resetAllowedToLeave(): void;
    get allowedToLeaveInput(): boolean | cdktf.IResolvable | undefined;
    private _autoConnect?;
    get autoConnect(): number;
    set autoConnect(value: number);
    resetAutoConnect(): void;
    get autoConnectInput(): number | undefined;
    private _captivePortal?;
    get captivePortal(): number;
    set captivePortal(value: number);
    resetCaptivePortal(): void;
    get captivePortalInput(): number | undefined;
    private _default?;
    get default(): boolean | cdktf.IResolvable;
    set default(value: boolean | cdktf.IResolvable);
    resetDefault(): void;
    get defaultInput(): boolean | cdktf.IResolvable | undefined;
    private _disableAutoFallback?;
    get disableAutoFallback(): boolean | cdktf.IResolvable;
    set disableAutoFallback(value: boolean | cdktf.IResolvable);
    resetDisableAutoFallback(): void;
    get disableAutoFallbackInput(): boolean | cdktf.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _excludeOfficeIps?;
    get excludeOfficeIps(): boolean | cdktf.IResolvable;
    set excludeOfficeIps(value: boolean | cdktf.IResolvable);
    resetExcludeOfficeIps(): void;
    get excludeOfficeIpsInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precedence?;
    get precedence(): number;
    set precedence(value: number);
    resetPrecedence(): void;
    get precedenceInput(): number | undefined;
    private _serviceModeV2Mode?;
    get serviceModeV2Mode(): string;
    set serviceModeV2Mode(value: string);
    resetServiceModeV2Mode(): void;
    get serviceModeV2ModeInput(): string | undefined;
    private _serviceModeV2Port?;
    get serviceModeV2Port(): number;
    set serviceModeV2Port(value: number);
    resetServiceModeV2Port(): void;
    get serviceModeV2PortInput(): number | undefined;
    private _supportUrl?;
    get supportUrl(): string;
    set supportUrl(value: string);
    resetSupportUrl(): void;
    get supportUrlInput(): string | undefined;
    private _switchLocked?;
    get switchLocked(): boolean | cdktf.IResolvable;
    set switchLocked(value: boolean | cdktf.IResolvable);
    resetSwitchLocked(): void;
    get switchLockedInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
