import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TeamsAccountConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#account_id TeamsAccount#account_id}
    */
    readonly accountId: string;
    /**
    * Whether to enable the activity log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#activity_log_enabled TeamsAccount#activity_log_enabled}
    */
    readonly activityLogEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#id TeamsAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Indicator that decryption of TLS traffic is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#tls_decrypt_enabled TeamsAccount#tls_decrypt_enabled}
    */
    readonly tlsDecryptEnabled?: boolean | cdktf.IResolvable;
    /**
    * Safely browse websites in Browser Isolation through a URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#url_browser_isolation_enabled TeamsAccount#url_browser_isolation_enabled}
    */
    readonly urlBrowserIsolationEnabled?: boolean | cdktf.IResolvable;
    /**
    * antivirus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#antivirus TeamsAccount#antivirus}
    */
    readonly antivirus?: TeamsAccountAntivirus;
    /**
    * block_page block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#block_page TeamsAccount#block_page}
    */
    readonly blockPage?: TeamsAccountBlockPage;
    /**
    * fips block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#fips TeamsAccount#fips}
    */
    readonly fips?: TeamsAccountFips;
    /**
    * logging block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#logging TeamsAccount#logging}
    */
    readonly logging?: TeamsAccountLogging;
    /**
    * payload_log block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#payload_log TeamsAccount#payload_log}
    */
    readonly payloadLog?: TeamsAccountPayloadLog;
    /**
    * proxy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#proxy TeamsAccount#proxy}
    */
    readonly proxy?: TeamsAccountProxy;
}
export interface TeamsAccountAntivirus {
    /**
    * Scan on file download.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#enabled_download_phase TeamsAccount#enabled_download_phase}
    */
    readonly enabledDownloadPhase: boolean | cdktf.IResolvable;
    /**
    * Scan on file upload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#enabled_upload_phase TeamsAccount#enabled_upload_phase}
    */
    readonly enabledUploadPhase: boolean | cdktf.IResolvable;
    /**
    * Block requests for files that cannot be scanned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#fail_closed TeamsAccount#fail_closed}
    */
    readonly failClosed: boolean | cdktf.IResolvable;
}
export declare function teamsAccountAntivirusToTerraform(struct?: TeamsAccountAntivirusOutputReference | TeamsAccountAntivirus): any;
export declare function teamsAccountAntivirusToHclTerraform(struct?: TeamsAccountAntivirusOutputReference | TeamsAccountAntivirus): any;
export declare class TeamsAccountAntivirusOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsAccountAntivirus | undefined;
    set internalValue(value: TeamsAccountAntivirus | undefined);
    private _enabledDownloadPhase?;
    get enabledDownloadPhase(): boolean | cdktf.IResolvable;
    set enabledDownloadPhase(value: boolean | cdktf.IResolvable);
    get enabledDownloadPhaseInput(): boolean | cdktf.IResolvable | undefined;
    private _enabledUploadPhase?;
    get enabledUploadPhase(): boolean | cdktf.IResolvable;
    set enabledUploadPhase(value: boolean | cdktf.IResolvable);
    get enabledUploadPhaseInput(): boolean | cdktf.IResolvable | undefined;
    private _failClosed?;
    get failClosed(): boolean | cdktf.IResolvable;
    set failClosed(value: boolean | cdktf.IResolvable);
    get failClosedInput(): boolean | cdktf.IResolvable | undefined;
}
export interface TeamsAccountBlockPage {
    /**
    * Hex code of block page background color.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#background_color TeamsAccount#background_color}
    */
    readonly backgroundColor?: string;
    /**
    * Indicator of enablement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#enabled TeamsAccount#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Block page footer text.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#footer_text TeamsAccount#footer_text}
    */
    readonly footerText?: string;
    /**
    * Block page header text.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#header_text TeamsAccount#header_text}
    */
    readonly headerText?: string;
    /**
    * URL of block page logo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#logo_path TeamsAccount#logo_path}
    */
    readonly logoPath?: string;
    /**
    * Admin email for users to contact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#mailto_address TeamsAccount#mailto_address}
    */
    readonly mailtoAddress?: string;
    /**
    * Subject line for emails created from block page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#mailto_subject TeamsAccount#mailto_subject}
    */
    readonly mailtoSubject?: string;
    /**
    * Name of block page configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#name TeamsAccount#name}
    */
    readonly name?: string;
}
export declare function teamsAccountBlockPageToTerraform(struct?: TeamsAccountBlockPageOutputReference | TeamsAccountBlockPage): any;
export declare function teamsAccountBlockPageToHclTerraform(struct?: TeamsAccountBlockPageOutputReference | TeamsAccountBlockPage): any;
export declare class TeamsAccountBlockPageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsAccountBlockPage | undefined;
    set internalValue(value: TeamsAccountBlockPage | undefined);
    private _backgroundColor?;
    get backgroundColor(): string;
    set backgroundColor(value: string);
    resetBackgroundColor(): void;
    get backgroundColorInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _footerText?;
    get footerText(): string;
    set footerText(value: string);
    resetFooterText(): void;
    get footerTextInput(): string | undefined;
    private _headerText?;
    get headerText(): string;
    set headerText(value: string);
    resetHeaderText(): void;
    get headerTextInput(): string | undefined;
    private _logoPath?;
    get logoPath(): string;
    set logoPath(value: string);
    resetLogoPath(): void;
    get logoPathInput(): string | undefined;
    private _mailtoAddress?;
    get mailtoAddress(): string;
    set mailtoAddress(value: string);
    resetMailtoAddress(): void;
    get mailtoAddressInput(): string | undefined;
    private _mailtoSubject?;
    get mailtoSubject(): string;
    set mailtoSubject(value: string);
    resetMailtoSubject(): void;
    get mailtoSubjectInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface TeamsAccountFips {
    /**
    * Only allow FIPS-compliant TLS configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#tls TeamsAccount#tls}
    */
    readonly tls?: boolean | cdktf.IResolvable;
}
export declare function teamsAccountFipsToTerraform(struct?: TeamsAccountFipsOutputReference | TeamsAccountFips): any;
export declare function teamsAccountFipsToHclTerraform(struct?: TeamsAccountFipsOutputReference | TeamsAccountFips): any;
export declare class TeamsAccountFipsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsAccountFips | undefined;
    set internalValue(value: TeamsAccountFips | undefined);
    private _tls?;
    get tls(): boolean | cdktf.IResolvable;
    set tls(value: boolean | cdktf.IResolvable);
    resetTls(): void;
    get tlsInput(): boolean | cdktf.IResolvable | undefined;
}
export interface TeamsAccountLoggingSettingsByRuleTypeDns {
    /**
    * Whether to log all activity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#log_all TeamsAccount#log_all}
    */
    readonly logAll: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#log_blocks TeamsAccount#log_blocks}
    */
    readonly logBlocks: boolean | cdktf.IResolvable;
}
export declare function teamsAccountLoggingSettingsByRuleTypeDnsToTerraform(struct?: TeamsAccountLoggingSettingsByRuleTypeDnsOutputReference | TeamsAccountLoggingSettingsByRuleTypeDns): any;
export declare function teamsAccountLoggingSettingsByRuleTypeDnsToHclTerraform(struct?: TeamsAccountLoggingSettingsByRuleTypeDnsOutputReference | TeamsAccountLoggingSettingsByRuleTypeDns): any;
export declare class TeamsAccountLoggingSettingsByRuleTypeDnsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsAccountLoggingSettingsByRuleTypeDns | undefined;
    set internalValue(value: TeamsAccountLoggingSettingsByRuleTypeDns | undefined);
    private _logAll?;
    get logAll(): boolean | cdktf.IResolvable;
    set logAll(value: boolean | cdktf.IResolvable);
    get logAllInput(): boolean | cdktf.IResolvable | undefined;
    private _logBlocks?;
    get logBlocks(): boolean | cdktf.IResolvable;
    set logBlocks(value: boolean | cdktf.IResolvable);
    get logBlocksInput(): boolean | cdktf.IResolvable | undefined;
}
export interface TeamsAccountLoggingSettingsByRuleTypeHttp {
    /**
    * Whether to log all activity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#log_all TeamsAccount#log_all}
    */
    readonly logAll: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#log_blocks TeamsAccount#log_blocks}
    */
    readonly logBlocks: boolean | cdktf.IResolvable;
}
export declare function teamsAccountLoggingSettingsByRuleTypeHttpToTerraform(struct?: TeamsAccountLoggingSettingsByRuleTypeHttpOutputReference | TeamsAccountLoggingSettingsByRuleTypeHttp): any;
export declare function teamsAccountLoggingSettingsByRuleTypeHttpToHclTerraform(struct?: TeamsAccountLoggingSettingsByRuleTypeHttpOutputReference | TeamsAccountLoggingSettingsByRuleTypeHttp): any;
export declare class TeamsAccountLoggingSettingsByRuleTypeHttpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsAccountLoggingSettingsByRuleTypeHttp | undefined;
    set internalValue(value: TeamsAccountLoggingSettingsByRuleTypeHttp | undefined);
    private _logAll?;
    get logAll(): boolean | cdktf.IResolvable;
    set logAll(value: boolean | cdktf.IResolvable);
    get logAllInput(): boolean | cdktf.IResolvable | undefined;
    private _logBlocks?;
    get logBlocks(): boolean | cdktf.IResolvable;
    set logBlocks(value: boolean | cdktf.IResolvable);
    get logBlocksInput(): boolean | cdktf.IResolvable | undefined;
}
export interface TeamsAccountLoggingSettingsByRuleTypeL4 {
    /**
    * Whether to log all activity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#log_all TeamsAccount#log_all}
    */
    readonly logAll: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#log_blocks TeamsAccount#log_blocks}
    */
    readonly logBlocks: boolean | cdktf.IResolvable;
}
export declare function teamsAccountLoggingSettingsByRuleTypeL4ToTerraform(struct?: TeamsAccountLoggingSettingsByRuleTypeL4OutputReference | TeamsAccountLoggingSettingsByRuleTypeL4): any;
export declare function teamsAccountLoggingSettingsByRuleTypeL4ToHclTerraform(struct?: TeamsAccountLoggingSettingsByRuleTypeL4OutputReference | TeamsAccountLoggingSettingsByRuleTypeL4): any;
export declare class TeamsAccountLoggingSettingsByRuleTypeL4OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsAccountLoggingSettingsByRuleTypeL4 | undefined;
    set internalValue(value: TeamsAccountLoggingSettingsByRuleTypeL4 | undefined);
    private _logAll?;
    get logAll(): boolean | cdktf.IResolvable;
    set logAll(value: boolean | cdktf.IResolvable);
    get logAllInput(): boolean | cdktf.IResolvable | undefined;
    private _logBlocks?;
    get logBlocks(): boolean | cdktf.IResolvable;
    set logBlocks(value: boolean | cdktf.IResolvable);
    get logBlocksInput(): boolean | cdktf.IResolvable | undefined;
}
export interface TeamsAccountLoggingSettingsByRuleType {
    /**
    * dns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#dns TeamsAccount#dns}
    */
    readonly dns: TeamsAccountLoggingSettingsByRuleTypeDns;
    /**
    * http block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#http TeamsAccount#http}
    */
    readonly http: TeamsAccountLoggingSettingsByRuleTypeHttp;
    /**
    * l4 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#l4 TeamsAccount#l4}
    */
    readonly l4: TeamsAccountLoggingSettingsByRuleTypeL4;
}
export declare function teamsAccountLoggingSettingsByRuleTypeToTerraform(struct?: TeamsAccountLoggingSettingsByRuleTypeOutputReference | TeamsAccountLoggingSettingsByRuleType): any;
export declare function teamsAccountLoggingSettingsByRuleTypeToHclTerraform(struct?: TeamsAccountLoggingSettingsByRuleTypeOutputReference | TeamsAccountLoggingSettingsByRuleType): any;
export declare class TeamsAccountLoggingSettingsByRuleTypeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsAccountLoggingSettingsByRuleType | undefined;
    set internalValue(value: TeamsAccountLoggingSettingsByRuleType | undefined);
    private _dns;
    get dns(): TeamsAccountLoggingSettingsByRuleTypeDnsOutputReference;
    putDns(value: TeamsAccountLoggingSettingsByRuleTypeDns): void;
    get dnsInput(): TeamsAccountLoggingSettingsByRuleTypeDns | undefined;
    private _http;
    get http(): TeamsAccountLoggingSettingsByRuleTypeHttpOutputReference;
    putHttp(value: TeamsAccountLoggingSettingsByRuleTypeHttp): void;
    get httpInput(): TeamsAccountLoggingSettingsByRuleTypeHttp | undefined;
    private _l4;
    get l4(): TeamsAccountLoggingSettingsByRuleTypeL4OutputReference;
    putL4(value: TeamsAccountLoggingSettingsByRuleTypeL4): void;
    get l4Input(): TeamsAccountLoggingSettingsByRuleTypeL4 | undefined;
}
export interface TeamsAccountLogging {
    /**
    * Redact personally identifiable information from activity logging (PII fields are: source IP, user email, user ID, device ID, URL, referrer, user agent).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#redact_pii TeamsAccount#redact_pii}
    */
    readonly redactPii: boolean | cdktf.IResolvable;
    /**
    * settings_by_rule_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#settings_by_rule_type TeamsAccount#settings_by_rule_type}
    */
    readonly settingsByRuleType: TeamsAccountLoggingSettingsByRuleType;
}
export declare function teamsAccountLoggingToTerraform(struct?: TeamsAccountLoggingOutputReference | TeamsAccountLogging): any;
export declare function teamsAccountLoggingToHclTerraform(struct?: TeamsAccountLoggingOutputReference | TeamsAccountLogging): any;
export declare class TeamsAccountLoggingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsAccountLogging | undefined;
    set internalValue(value: TeamsAccountLogging | undefined);
    private _redactPii?;
    get redactPii(): boolean | cdktf.IResolvable;
    set redactPii(value: boolean | cdktf.IResolvable);
    get redactPiiInput(): boolean | cdktf.IResolvable | undefined;
    private _settingsByRuleType;
    get settingsByRuleType(): TeamsAccountLoggingSettingsByRuleTypeOutputReference;
    putSettingsByRuleType(value: TeamsAccountLoggingSettingsByRuleType): void;
    get settingsByRuleTypeInput(): TeamsAccountLoggingSettingsByRuleType | undefined;
}
export interface TeamsAccountPayloadLog {
    /**
    * Public key used to encrypt matched payloads.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#public_key TeamsAccount#public_key}
    */
    readonly publicKey: string;
}
export declare function teamsAccountPayloadLogToTerraform(struct?: TeamsAccountPayloadLogOutputReference | TeamsAccountPayloadLog): any;
export declare function teamsAccountPayloadLogToHclTerraform(struct?: TeamsAccountPayloadLogOutputReference | TeamsAccountPayloadLog): any;
export declare class TeamsAccountPayloadLogOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsAccountPayloadLog | undefined;
    set internalValue(value: TeamsAccountPayloadLog | undefined);
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    get publicKeyInput(): string | undefined;
}
export interface TeamsAccountProxy {
    /**
    * Whether gateway proxy is enabled on gateway devices for TCP traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#tcp TeamsAccount#tcp}
    */
    readonly tcp: boolean | cdktf.IResolvable;
    /**
    * Whether gateway proxy is enabled on gateway devices for UDP traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#udp TeamsAccount#udp}
    */
    readonly udp: boolean | cdktf.IResolvable;
}
export declare function teamsAccountProxyToTerraform(struct?: TeamsAccountProxyOutputReference | TeamsAccountProxy): any;
export declare function teamsAccountProxyToHclTerraform(struct?: TeamsAccountProxyOutputReference | TeamsAccountProxy): any;
export declare class TeamsAccountProxyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsAccountProxy | undefined;
    set internalValue(value: TeamsAccountProxy | undefined);
    private _tcp?;
    get tcp(): boolean | cdktf.IResolvable;
    set tcp(value: boolean | cdktf.IResolvable);
    get tcpInput(): boolean | cdktf.IResolvable | undefined;
    private _udp?;
    get udp(): boolean | cdktf.IResolvable;
    set udp(value: boolean | cdktf.IResolvable);
    get udpInput(): boolean | cdktf.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account cloudflare_teams_account}
*/
export declare class TeamsAccount extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_teams_account";
    /**
    * Generates CDKTF code for importing a TeamsAccount resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamsAccount to import
    * @param importFromId The id of the existing TeamsAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamsAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_account cloudflare_teams_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamsAccountConfig
    */
    constructor(scope: Construct, id: string, config: TeamsAccountConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _activityLogEnabled?;
    get activityLogEnabled(): boolean | cdktf.IResolvable;
    set activityLogEnabled(value: boolean | cdktf.IResolvable);
    resetActivityLogEnabled(): void;
    get activityLogEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _tlsDecryptEnabled?;
    get tlsDecryptEnabled(): boolean | cdktf.IResolvable;
    set tlsDecryptEnabled(value: boolean | cdktf.IResolvable);
    resetTlsDecryptEnabled(): void;
    get tlsDecryptEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _urlBrowserIsolationEnabled?;
    get urlBrowserIsolationEnabled(): boolean | cdktf.IResolvable;
    set urlBrowserIsolationEnabled(value: boolean | cdktf.IResolvable);
    resetUrlBrowserIsolationEnabled(): void;
    get urlBrowserIsolationEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _antivirus;
    get antivirus(): TeamsAccountAntivirusOutputReference;
    putAntivirus(value: TeamsAccountAntivirus): void;
    resetAntivirus(): void;
    get antivirusInput(): TeamsAccountAntivirus | undefined;
    private _blockPage;
    get blockPage(): TeamsAccountBlockPageOutputReference;
    putBlockPage(value: TeamsAccountBlockPage): void;
    resetBlockPage(): void;
    get blockPageInput(): TeamsAccountBlockPage | undefined;
    private _fips;
    get fips(): TeamsAccountFipsOutputReference;
    putFips(value: TeamsAccountFips): void;
    resetFips(): void;
    get fipsInput(): TeamsAccountFips | undefined;
    private _logging;
    get logging(): TeamsAccountLoggingOutputReference;
    putLogging(value: TeamsAccountLogging): void;
    resetLogging(): void;
    get loggingInput(): TeamsAccountLogging | undefined;
    private _payloadLog;
    get payloadLog(): TeamsAccountPayloadLogOutputReference;
    putPayloadLog(value: TeamsAccountPayloadLog): void;
    resetPayloadLog(): void;
    get payloadLogInput(): TeamsAccountPayloadLog | undefined;
    private _proxy;
    get proxy(): TeamsAccountProxyOutputReference;
    putProxy(value: TeamsAccountProxy): void;
    resetProxy(): void;
    get proxyInput(): TeamsAccountProxy | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
