import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TeamsRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#account_id TeamsRule#account_id}
    */
    readonly accountId: string;
    /**
    * The action executed by matched teams rule. Available values: `allow`, `block`, `safesearch`, `ytrestricted`, `on`, `off`, `scan`, `noscan`, `isolate`, `noisolate`, `override`, `l4_override`, `egress`, `audit_ssh`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#action TeamsRule#action}
    */
    readonly action: string;
    /**
    * The description of the teams rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#description TeamsRule#description}
    */
    readonly description: string;
    /**
    * The wirefilter expression to be used for device_posture check matching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#device_posture TeamsRule#device_posture}
    */
    readonly devicePosture?: string;
    /**
    * Indicator of rule enablement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#enabled TeamsRule#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * The protocol or layer to evaluate the traffic and identity expressions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#filters TeamsRule#filters}
    */
    readonly filters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#id TeamsRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The wirefilter expression to be used for identity matching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#identity TeamsRule#identity}
    */
    readonly identity?: string;
    /**
    * The name of the teams rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#name TeamsRule#name}
    */
    readonly name: string;
    /**
    * The evaluation precedence of the teams rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#precedence TeamsRule#precedence}
    */
    readonly precedence: number;
    /**
    * The wirefilter expression to be used for traffic matching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#traffic TeamsRule#traffic}
    */
    readonly traffic?: string;
    /**
    * rule_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#rule_settings TeamsRule#rule_settings}
    */
    readonly ruleSettings?: TeamsRuleRuleSettings;
}
export interface TeamsRuleRuleSettingsAuditSsh {
    /**
    * Log all SSH commands.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#command_logging TeamsRule#command_logging}
    */
    readonly commandLogging: boolean | cdktf.IResolvable;
}
export declare function teamsRuleRuleSettingsAuditSshToTerraform(struct?: TeamsRuleRuleSettingsAuditSshOutputReference | TeamsRuleRuleSettingsAuditSsh): any;
export declare function teamsRuleRuleSettingsAuditSshToHclTerraform(struct?: TeamsRuleRuleSettingsAuditSshOutputReference | TeamsRuleRuleSettingsAuditSsh): any;
export declare class TeamsRuleRuleSettingsAuditSshOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsRuleRuleSettingsAuditSsh | undefined;
    set internalValue(value: TeamsRuleRuleSettingsAuditSsh | undefined);
    private _commandLogging?;
    get commandLogging(): boolean | cdktf.IResolvable;
    set commandLogging(value: boolean | cdktf.IResolvable);
    get commandLoggingInput(): boolean | cdktf.IResolvable | undefined;
}
export interface TeamsRuleRuleSettingsBisoAdminControls {
    /**
    * Disable copy-paste.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#disable_copy_paste TeamsRule#disable_copy_paste}
    */
    readonly disableCopyPaste?: boolean | cdktf.IResolvable;
    /**
    * Disable download.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#disable_download TeamsRule#disable_download}
    */
    readonly disableDownload?: boolean | cdktf.IResolvable;
    /**
    * Disable keyboard usage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#disable_keyboard TeamsRule#disable_keyboard}
    */
    readonly disableKeyboard?: boolean | cdktf.IResolvable;
    /**
    * Disable printing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#disable_printing TeamsRule#disable_printing}
    */
    readonly disablePrinting?: boolean | cdktf.IResolvable;
    /**
    * Disable upload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#disable_upload TeamsRule#disable_upload}
    */
    readonly disableUpload?: boolean | cdktf.IResolvable;
}
export declare function teamsRuleRuleSettingsBisoAdminControlsToTerraform(struct?: TeamsRuleRuleSettingsBisoAdminControlsOutputReference | TeamsRuleRuleSettingsBisoAdminControls): any;
export declare function teamsRuleRuleSettingsBisoAdminControlsToHclTerraform(struct?: TeamsRuleRuleSettingsBisoAdminControlsOutputReference | TeamsRuleRuleSettingsBisoAdminControls): any;
export declare class TeamsRuleRuleSettingsBisoAdminControlsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsRuleRuleSettingsBisoAdminControls | undefined;
    set internalValue(value: TeamsRuleRuleSettingsBisoAdminControls | undefined);
    private _disableCopyPaste?;
    get disableCopyPaste(): boolean | cdktf.IResolvable;
    set disableCopyPaste(value: boolean | cdktf.IResolvable);
    resetDisableCopyPaste(): void;
    get disableCopyPasteInput(): boolean | cdktf.IResolvable | undefined;
    private _disableDownload?;
    get disableDownload(): boolean | cdktf.IResolvable;
    set disableDownload(value: boolean | cdktf.IResolvable);
    resetDisableDownload(): void;
    get disableDownloadInput(): boolean | cdktf.IResolvable | undefined;
    private _disableKeyboard?;
    get disableKeyboard(): boolean | cdktf.IResolvable;
    set disableKeyboard(value: boolean | cdktf.IResolvable);
    resetDisableKeyboard(): void;
    get disableKeyboardInput(): boolean | cdktf.IResolvable | undefined;
    private _disablePrinting?;
    get disablePrinting(): boolean | cdktf.IResolvable;
    set disablePrinting(value: boolean | cdktf.IResolvable);
    resetDisablePrinting(): void;
    get disablePrintingInput(): boolean | cdktf.IResolvable | undefined;
    private _disableUpload?;
    get disableUpload(): boolean | cdktf.IResolvable;
    set disableUpload(value: boolean | cdktf.IResolvable);
    resetDisableUpload(): void;
    get disableUploadInput(): boolean | cdktf.IResolvable | undefined;
}
export interface TeamsRuleRuleSettingsCheckSession {
    /**
    * Configure how fresh the session needs to be to be considered valid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#duration TeamsRule#duration}
    */
    readonly duration: string;
    /**
    * Enable session enforcement for this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#enforce TeamsRule#enforce}
    */
    readonly enforce: boolean | cdktf.IResolvable;
}
export declare function teamsRuleRuleSettingsCheckSessionToTerraform(struct?: TeamsRuleRuleSettingsCheckSessionOutputReference | TeamsRuleRuleSettingsCheckSession): any;
export declare function teamsRuleRuleSettingsCheckSessionToHclTerraform(struct?: TeamsRuleRuleSettingsCheckSessionOutputReference | TeamsRuleRuleSettingsCheckSession): any;
export declare class TeamsRuleRuleSettingsCheckSessionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsRuleRuleSettingsCheckSession | undefined;
    set internalValue(value: TeamsRuleRuleSettingsCheckSession | undefined);
    private _duration?;
    get duration(): string;
    set duration(value: string);
    get durationInput(): string | undefined;
    private _enforce?;
    get enforce(): boolean | cdktf.IResolvable;
    set enforce(value: boolean | cdktf.IResolvable);
    get enforceInput(): boolean | cdktf.IResolvable | undefined;
}
export interface TeamsRuleRuleSettingsEgress {
    /**
    * The IPv4 address to be used for egress.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#ipv4 TeamsRule#ipv4}
    */
    readonly ipv4: string;
    /**
    * The IPv4 address to be used for egress in the event of an error egressing with the primary IPv4. Can be '0.0.0.0' to indicate local egreass via Warp IPs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#ipv4_fallback TeamsRule#ipv4_fallback}
    */
    readonly ipv4Fallback?: string;
    /**
    * The IPv6 range to be used for egress.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#ipv6 TeamsRule#ipv6}
    */
    readonly ipv6: string;
}
export declare function teamsRuleRuleSettingsEgressToTerraform(struct?: TeamsRuleRuleSettingsEgressOutputReference | TeamsRuleRuleSettingsEgress): any;
export declare function teamsRuleRuleSettingsEgressToHclTerraform(struct?: TeamsRuleRuleSettingsEgressOutputReference | TeamsRuleRuleSettingsEgress): any;
export declare class TeamsRuleRuleSettingsEgressOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsRuleRuleSettingsEgress | undefined;
    set internalValue(value: TeamsRuleRuleSettingsEgress | undefined);
    private _ipv4?;
    get ipv4(): string;
    set ipv4(value: string);
    get ipv4Input(): string | undefined;
    private _ipv4Fallback?;
    get ipv4Fallback(): string;
    set ipv4Fallback(value: string);
    resetIpv4Fallback(): void;
    get ipv4FallbackInput(): string | undefined;
    private _ipv6?;
    get ipv6(): string;
    set ipv6(value: string);
    get ipv6Input(): string | undefined;
}
export interface TeamsRuleRuleSettingsL4Override {
    /**
    * Override IP to forward traffic to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#ip TeamsRule#ip}
    */
    readonly ip: string;
    /**
    * Override Port to forward traffic to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#port TeamsRule#port}
    */
    readonly port: number;
}
export declare function teamsRuleRuleSettingsL4OverrideToTerraform(struct?: TeamsRuleRuleSettingsL4OverrideOutputReference | TeamsRuleRuleSettingsL4Override): any;
export declare function teamsRuleRuleSettingsL4OverrideToHclTerraform(struct?: TeamsRuleRuleSettingsL4OverrideOutputReference | TeamsRuleRuleSettingsL4Override): any;
export declare class TeamsRuleRuleSettingsL4OverrideOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsRuleRuleSettingsL4Override | undefined;
    set internalValue(value: TeamsRuleRuleSettingsL4Override | undefined);
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
}
export interface TeamsRuleRuleSettingsPayloadLog {
    /**
    * Enable or disable DLP Payload Logging for this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#enabled TeamsRule#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
}
export declare function teamsRuleRuleSettingsPayloadLogToTerraform(struct?: TeamsRuleRuleSettingsPayloadLogOutputReference | TeamsRuleRuleSettingsPayloadLog): any;
export declare function teamsRuleRuleSettingsPayloadLogToHclTerraform(struct?: TeamsRuleRuleSettingsPayloadLogOutputReference | TeamsRuleRuleSettingsPayloadLog): any;
export declare class TeamsRuleRuleSettingsPayloadLogOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsRuleRuleSettingsPayloadLog | undefined;
    set internalValue(value: TeamsRuleRuleSettingsPayloadLog | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
}
export interface TeamsRuleRuleSettingsUntrustedCert {
    /**
    * Action to be taken when the SSL certificate of upstream is invalid. Available values: `pass_through`, `block`, `error`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#action TeamsRule#action}
    */
    readonly action?: string;
}
export declare function teamsRuleRuleSettingsUntrustedCertToTerraform(struct?: TeamsRuleRuleSettingsUntrustedCertOutputReference | TeamsRuleRuleSettingsUntrustedCert): any;
export declare function teamsRuleRuleSettingsUntrustedCertToHclTerraform(struct?: TeamsRuleRuleSettingsUntrustedCertOutputReference | TeamsRuleRuleSettingsUntrustedCert): any;
export declare class TeamsRuleRuleSettingsUntrustedCertOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsRuleRuleSettingsUntrustedCert | undefined;
    set internalValue(value: TeamsRuleRuleSettingsUntrustedCert | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
}
export interface TeamsRuleRuleSettings {
    /**
    * Add custom headers to allowed requests in the form of key-value pairs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#add_headers TeamsRule#add_headers}
    */
    readonly addHeaders?: {
        [key: string]: string;
    };
    /**
    * Allow parent MSP accounts to enable bypass their children's rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#allow_child_bypass TeamsRule#allow_child_bypass}
    */
    readonly allowChildBypass?: boolean | cdktf.IResolvable;
    /**
    * Indicator of block page enablement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#block_page_enabled TeamsRule#block_page_enabled}
    */
    readonly blockPageEnabled?: boolean | cdktf.IResolvable;
    /**
    * The displayed reason for a user being blocked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#block_page_reason TeamsRule#block_page_reason}
    */
    readonly blockPageReason?: string;
    /**
    * Allow child MSP accounts to bypass their parent's rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#bypass_parent_rule TeamsRule#bypass_parent_rule}
    */
    readonly bypassParentRule?: boolean | cdktf.IResolvable;
    /**
    * Disable DNSSEC validation (must be Allow rule).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#insecure_disable_dnssec_validation TeamsRule#insecure_disable_dnssec_validation}
    */
    readonly insecureDisableDnssecValidation?: boolean | cdktf.IResolvable;
    /**
    * Turns on IP category based filter on dns if the rule contains dns category checks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#ip_categories TeamsRule#ip_categories}
    */
    readonly ipCategories?: boolean | cdktf.IResolvable;
    /**
    * The host to override matching DNS queries with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#override_host TeamsRule#override_host}
    */
    readonly overrideHost?: string;
    /**
    * The IPs to override matching DNS queries with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#override_ips TeamsRule#override_ips}
    */
    readonly overrideIps?: string[];
    /**
    * audit_ssh block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#audit_ssh TeamsRule#audit_ssh}
    */
    readonly auditSsh?: TeamsRuleRuleSettingsAuditSsh;
    /**
    * biso_admin_controls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#biso_admin_controls TeamsRule#biso_admin_controls}
    */
    readonly bisoAdminControls?: TeamsRuleRuleSettingsBisoAdminControls;
    /**
    * check_session block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#check_session TeamsRule#check_session}
    */
    readonly checkSession?: TeamsRuleRuleSettingsCheckSession;
    /**
    * egress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#egress TeamsRule#egress}
    */
    readonly egress?: TeamsRuleRuleSettingsEgress;
    /**
    * l4override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#l4override TeamsRule#l4override}
    */
    readonly l4Override?: TeamsRuleRuleSettingsL4Override;
    /**
    * payload_log block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#payload_log TeamsRule#payload_log}
    */
    readonly payloadLog?: TeamsRuleRuleSettingsPayloadLog;
    /**
    * untrusted_cert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#untrusted_cert TeamsRule#untrusted_cert}
    */
    readonly untrustedCert?: TeamsRuleRuleSettingsUntrustedCert;
}
export declare function teamsRuleRuleSettingsToTerraform(struct?: TeamsRuleRuleSettingsOutputReference | TeamsRuleRuleSettings): any;
export declare function teamsRuleRuleSettingsToHclTerraform(struct?: TeamsRuleRuleSettingsOutputReference | TeamsRuleRuleSettings): any;
export declare class TeamsRuleRuleSettingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsRuleRuleSettings | undefined;
    set internalValue(value: TeamsRuleRuleSettings | undefined);
    private _addHeaders?;
    get addHeaders(): {
        [key: string]: string;
    };
    set addHeaders(value: {
        [key: string]: string;
    });
    resetAddHeaders(): void;
    get addHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _allowChildBypass?;
    get allowChildBypass(): boolean | cdktf.IResolvable;
    set allowChildBypass(value: boolean | cdktf.IResolvable);
    resetAllowChildBypass(): void;
    get allowChildBypassInput(): boolean | cdktf.IResolvable | undefined;
    private _blockPageEnabled?;
    get blockPageEnabled(): boolean | cdktf.IResolvable;
    set blockPageEnabled(value: boolean | cdktf.IResolvable);
    resetBlockPageEnabled(): void;
    get blockPageEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _blockPageReason?;
    get blockPageReason(): string;
    set blockPageReason(value: string);
    resetBlockPageReason(): void;
    get blockPageReasonInput(): string | undefined;
    private _bypassParentRule?;
    get bypassParentRule(): boolean | cdktf.IResolvable;
    set bypassParentRule(value: boolean | cdktf.IResolvable);
    resetBypassParentRule(): void;
    get bypassParentRuleInput(): boolean | cdktf.IResolvable | undefined;
    private _insecureDisableDnssecValidation?;
    get insecureDisableDnssecValidation(): boolean | cdktf.IResolvable;
    set insecureDisableDnssecValidation(value: boolean | cdktf.IResolvable);
    resetInsecureDisableDnssecValidation(): void;
    get insecureDisableDnssecValidationInput(): boolean | cdktf.IResolvable | undefined;
    private _ipCategories?;
    get ipCategories(): boolean | cdktf.IResolvable;
    set ipCategories(value: boolean | cdktf.IResolvable);
    resetIpCategories(): void;
    get ipCategoriesInput(): boolean | cdktf.IResolvable | undefined;
    private _overrideHost?;
    get overrideHost(): string;
    set overrideHost(value: string);
    resetOverrideHost(): void;
    get overrideHostInput(): string | undefined;
    private _overrideIps?;
    get overrideIps(): string[];
    set overrideIps(value: string[]);
    resetOverrideIps(): void;
    get overrideIpsInput(): string[] | undefined;
    private _auditSsh;
    get auditSsh(): TeamsRuleRuleSettingsAuditSshOutputReference;
    putAuditSsh(value: TeamsRuleRuleSettingsAuditSsh): void;
    resetAuditSsh(): void;
    get auditSshInput(): TeamsRuleRuleSettingsAuditSsh | undefined;
    private _bisoAdminControls;
    get bisoAdminControls(): TeamsRuleRuleSettingsBisoAdminControlsOutputReference;
    putBisoAdminControls(value: TeamsRuleRuleSettingsBisoAdminControls): void;
    resetBisoAdminControls(): void;
    get bisoAdminControlsInput(): TeamsRuleRuleSettingsBisoAdminControls | undefined;
    private _checkSession;
    get checkSession(): TeamsRuleRuleSettingsCheckSessionOutputReference;
    putCheckSession(value: TeamsRuleRuleSettingsCheckSession): void;
    resetCheckSession(): void;
    get checkSessionInput(): TeamsRuleRuleSettingsCheckSession | undefined;
    private _egress;
    get egress(): TeamsRuleRuleSettingsEgressOutputReference;
    putEgress(value: TeamsRuleRuleSettingsEgress): void;
    resetEgress(): void;
    get egressInput(): TeamsRuleRuleSettingsEgress | undefined;
    private _l4Override;
    get l4Override(): TeamsRuleRuleSettingsL4OverrideOutputReference;
    putL4Override(value: TeamsRuleRuleSettingsL4Override): void;
    resetL4Override(): void;
    get l4OverrideInput(): TeamsRuleRuleSettingsL4Override | undefined;
    private _payloadLog;
    get payloadLog(): TeamsRuleRuleSettingsPayloadLogOutputReference;
    putPayloadLog(value: TeamsRuleRuleSettingsPayloadLog): void;
    resetPayloadLog(): void;
    get payloadLogInput(): TeamsRuleRuleSettingsPayloadLog | undefined;
    private _untrustedCert;
    get untrustedCert(): TeamsRuleRuleSettingsUntrustedCertOutputReference;
    putUntrustedCert(value: TeamsRuleRuleSettingsUntrustedCert): void;
    resetUntrustedCert(): void;
    get untrustedCertInput(): TeamsRuleRuleSettingsUntrustedCert | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule cloudflare_teams_rule}
*/
export declare class TeamsRule extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_teams_rule";
    /**
    * Generates CDKTF code for importing a TeamsRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamsRule to import
    * @param importFromId The id of the existing TeamsRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamsRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_rule cloudflare_teams_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamsRuleConfig
    */
    constructor(scope: Construct, id: string, config: TeamsRuleConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string;
    set devicePosture(value: string);
    resetDevicePosture(): void;
    get devicePostureInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _filters?;
    get filters(): string[];
    set filters(value: string[]);
    resetFilters(): void;
    get filtersInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precedence?;
    get precedence(): number;
    set precedence(value: number);
    get precedenceInput(): number | undefined;
    private _traffic?;
    get traffic(): string;
    set traffic(value: string);
    resetTraffic(): void;
    get trafficInput(): string | undefined;
    get version(): number;
    private _ruleSettings;
    get ruleSettings(): TeamsRuleRuleSettingsOutputReference;
    putRuleSettings(value: TeamsRuleRuleSettings): void;
    resetRuleSettings(): void;
    get ruleSettingsInput(): TeamsRuleRuleSettings | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
