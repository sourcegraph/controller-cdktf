import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApiShieldConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_shield#id ApiShield#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_shield#zone_id ApiShield#zone_id}
    */
    readonly zoneId: string;
    /**
    * auth_id_characteristics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_shield#auth_id_characteristics ApiShield#auth_id_characteristics}
    */
    readonly authIdCharacteristics?: ApiShieldAuthIdCharacteristics[] | cdktf.IResolvable;
}
export interface ApiShieldAuthIdCharacteristics {
    /**
    * The name of the characteristic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_shield#name ApiShield#name}
    */
    readonly name?: string;
    /**
    * The type of characteristic. Available values: `header`, `cookie`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_shield#type ApiShield#type}
    */
    readonly type?: string;
}
export declare function apiShieldAuthIdCharacteristicsToTerraform(struct?: ApiShieldAuthIdCharacteristics | cdktf.IResolvable): any;
export declare function apiShieldAuthIdCharacteristicsToHclTerraform(struct?: ApiShieldAuthIdCharacteristics | cdktf.IResolvable): any;
export declare class ApiShieldAuthIdCharacteristicsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiShieldAuthIdCharacteristics | cdktf.IResolvable | undefined;
    set internalValue(value: ApiShieldAuthIdCharacteristics | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ApiShieldAuthIdCharacteristicsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApiShieldAuthIdCharacteristics[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiShieldAuthIdCharacteristicsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_shield cloudflare_api_shield}
*/
export declare class ApiShield extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_api_shield";
    /**
    * Generates CDKTF code for importing a ApiShield resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiShield to import
    * @param importFromId The id of the existing ApiShield that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_shield#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiShield to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_shield cloudflare_api_shield} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiShieldConfig
    */
    constructor(scope: Construct, id: string, config: ApiShieldConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _authIdCharacteristics;
    get authIdCharacteristics(): ApiShieldAuthIdCharacteristicsList;
    putAuthIdCharacteristics(value: ApiShieldAuthIdCharacteristics[] | cdktf.IResolvable): void;
    resetAuthIdCharacteristics(): void;
    get authIdCharacteristicsInput(): cdktf.IResolvable | ApiShieldAuthIdCharacteristics[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
