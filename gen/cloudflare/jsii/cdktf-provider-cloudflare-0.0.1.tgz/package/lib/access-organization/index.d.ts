import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AccessOrganizationConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. Conflicts with `zone_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#account_id AccessOrganization#account_id}
    */
    readonly accountId?: string;
    /**
    * The unique subdomain assigned to your Zero Trust organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#auth_domain AccessOrganization#auth_domain}
    */
    readonly authDomain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#id AccessOrganization#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * When set to true, this will disable all editing of Access resources via the Zero Trust Dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#is_ui_read_only AccessOrganization#is_ui_read_only}
    */
    readonly isUiReadOnly?: boolean | cdktf.IResolvable;
    /**
    * The name of your Zero Trust organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#name AccessOrganization#name}
    */
    readonly name?: string;
    /**
    * A description of the reason why the UI read only field is being toggled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#ui_read_only_toggle_reason AccessOrganization#ui_read_only_toggle_reason}
    */
    readonly uiReadOnlyToggleReason?: string;
    /**
    * The amount of time a user seat is inactive before it expires. When the user seat exceeds the set time of inactivity, the user is removed as an active seat and no longer counts against your Teams seat count. Must be in the format `300ms` or `2h45m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#user_seat_expiration_inactive_time AccessOrganization#user_seat_expiration_inactive_time}
    */
    readonly userSeatExpirationInactiveTime?: string;
    /**
    * The zone identifier to target for the resource. Conflicts with `account_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#zone_id AccessOrganization#zone_id}
    */
    readonly zoneId?: string;
    /**
    * login_design block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#login_design AccessOrganization#login_design}
    */
    readonly loginDesign?: AccessOrganizationLoginDesign[] | cdktf.IResolvable;
}
export interface AccessOrganizationLoginDesign {
    /**
    * The background color on the login page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#background_color AccessOrganization#background_color}
    */
    readonly backgroundColor?: string;
    /**
    * The text at the bottom of the login page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#footer_text AccessOrganization#footer_text}
    */
    readonly footerText?: string;
    /**
    * The text at the top of the login page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#header_text AccessOrganization#header_text}
    */
    readonly headerText?: string;
    /**
    * The URL of the logo on the login page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#logo_path AccessOrganization#logo_path}
    */
    readonly logoPath?: string;
    /**
    * The text color on the login page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#text_color AccessOrganization#text_color}
    */
    readonly textColor?: string;
}
export declare function accessOrganizationLoginDesignToTerraform(struct?: AccessOrganizationLoginDesign | cdktf.IResolvable): any;
export declare function accessOrganizationLoginDesignToHclTerraform(struct?: AccessOrganizationLoginDesign | cdktf.IResolvable): any;
export declare class AccessOrganizationLoginDesignOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessOrganizationLoginDesign | cdktf.IResolvable | undefined;
    set internalValue(value: AccessOrganizationLoginDesign | cdktf.IResolvable | undefined);
    private _backgroundColor?;
    get backgroundColor(): string;
    set backgroundColor(value: string);
    resetBackgroundColor(): void;
    get backgroundColorInput(): string | undefined;
    private _footerText?;
    get footerText(): string;
    set footerText(value: string);
    resetFooterText(): void;
    get footerTextInput(): string | undefined;
    private _headerText?;
    get headerText(): string;
    set headerText(value: string);
    resetHeaderText(): void;
    get headerTextInput(): string | undefined;
    private _logoPath?;
    get logoPath(): string;
    set logoPath(value: string);
    resetLogoPath(): void;
    get logoPathInput(): string | undefined;
    private _textColor?;
    get textColor(): string;
    set textColor(value: string);
    resetTextColor(): void;
    get textColorInput(): string | undefined;
}
export declare class AccessOrganizationLoginDesignList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AccessOrganizationLoginDesign[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessOrganizationLoginDesignOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization cloudflare_access_organization}
*/
export declare class AccessOrganization extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_access_organization";
    /**
    * Generates CDKTF code for importing a AccessOrganization resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessOrganization to import
    * @param importFromId The id of the existing AccessOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_organization cloudflare_access_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: AccessOrganizationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _authDomain?;
    get authDomain(): string;
    set authDomain(value: string);
    get authDomainInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isUiReadOnly?;
    get isUiReadOnly(): boolean | cdktf.IResolvable;
    set isUiReadOnly(value: boolean | cdktf.IResolvable);
    resetIsUiReadOnly(): void;
    get isUiReadOnlyInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _uiReadOnlyToggleReason?;
    get uiReadOnlyToggleReason(): string;
    set uiReadOnlyToggleReason(value: string);
    resetUiReadOnlyToggleReason(): void;
    get uiReadOnlyToggleReasonInput(): string | undefined;
    private _userSeatExpirationInactiveTime?;
    get userSeatExpirationInactiveTime(): string;
    set userSeatExpirationInactiveTime(value: string);
    resetUserSeatExpirationInactiveTime(): void;
    get userSeatExpirationInactiveTimeInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _loginDesign;
    get loginDesign(): AccessOrganizationLoginDesignList;
    putLoginDesign(value: AccessOrganizationLoginDesign[] | cdktf.IResolvable): void;
    resetLoginDesign(): void;
    get loginDesignInput(): cdktf.IResolvable | AccessOrganizationLoginDesign[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
