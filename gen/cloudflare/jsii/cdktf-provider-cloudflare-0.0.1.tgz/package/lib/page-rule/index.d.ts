import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PageRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#id PageRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#priority PageRule#priority}
    */
    readonly priority?: number;
    /**
    * Defaults to `active`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#status PageRule#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#target PageRule#target}
    */
    readonly target: string;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#zone_id PageRule#zone_id}
    */
    readonly zoneId: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#actions PageRule#actions}
    */
    readonly actions: PageRuleActions;
}
export interface PageRuleActionsCacheKeyFieldsCookie {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#check_presence PageRule#check_presence}
    */
    readonly checkPresence?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#include PageRule#include}
    */
    readonly include?: string[];
}
export declare function pageRuleActionsCacheKeyFieldsCookieToTerraform(struct?: PageRuleActionsCacheKeyFieldsCookieOutputReference | PageRuleActionsCacheKeyFieldsCookie): any;
export declare function pageRuleActionsCacheKeyFieldsCookieToHclTerraform(struct?: PageRuleActionsCacheKeyFieldsCookieOutputReference | PageRuleActionsCacheKeyFieldsCookie): any;
export declare class PageRuleActionsCacheKeyFieldsCookieOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PageRuleActionsCacheKeyFieldsCookie | undefined;
    set internalValue(value: PageRuleActionsCacheKeyFieldsCookie | undefined);
    private _checkPresence?;
    get checkPresence(): string[];
    set checkPresence(value: string[]);
    resetCheckPresence(): void;
    get checkPresenceInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export interface PageRuleActionsCacheKeyFieldsHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#check_presence PageRule#check_presence}
    */
    readonly checkPresence?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#exclude PageRule#exclude}
    */
    readonly exclude?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#include PageRule#include}
    */
    readonly include?: string[];
}
export declare function pageRuleActionsCacheKeyFieldsHeaderToTerraform(struct?: PageRuleActionsCacheKeyFieldsHeaderOutputReference | PageRuleActionsCacheKeyFieldsHeader): any;
export declare function pageRuleActionsCacheKeyFieldsHeaderToHclTerraform(struct?: PageRuleActionsCacheKeyFieldsHeaderOutputReference | PageRuleActionsCacheKeyFieldsHeader): any;
export declare class PageRuleActionsCacheKeyFieldsHeaderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PageRuleActionsCacheKeyFieldsHeader | undefined;
    set internalValue(value: PageRuleActionsCacheKeyFieldsHeader | undefined);
    private _checkPresence?;
    get checkPresence(): string[];
    set checkPresence(value: string[]);
    resetCheckPresence(): void;
    get checkPresenceInput(): string[] | undefined;
    private _exclude?;
    get exclude(): string[];
    set exclude(value: string[]);
    resetExclude(): void;
    get excludeInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export interface PageRuleActionsCacheKeyFieldsHost {
    /**
    * Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#resolved PageRule#resolved}
    */
    readonly resolved?: boolean | cdktf.IResolvable;
}
export declare function pageRuleActionsCacheKeyFieldsHostToTerraform(struct?: PageRuleActionsCacheKeyFieldsHostOutputReference | PageRuleActionsCacheKeyFieldsHost): any;
export declare function pageRuleActionsCacheKeyFieldsHostToHclTerraform(struct?: PageRuleActionsCacheKeyFieldsHostOutputReference | PageRuleActionsCacheKeyFieldsHost): any;
export declare class PageRuleActionsCacheKeyFieldsHostOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PageRuleActionsCacheKeyFieldsHost | undefined;
    set internalValue(value: PageRuleActionsCacheKeyFieldsHost | undefined);
    private _resolved?;
    get resolved(): boolean | cdktf.IResolvable;
    set resolved(value: boolean | cdktf.IResolvable);
    resetResolved(): void;
    get resolvedInput(): boolean | cdktf.IResolvable | undefined;
}
export interface PageRuleActionsCacheKeyFieldsQueryString {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#exclude PageRule#exclude}
    */
    readonly exclude?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#ignore PageRule#ignore}
    */
    readonly ignore?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#include PageRule#include}
    */
    readonly include?: string[];
}
export declare function pageRuleActionsCacheKeyFieldsQueryStringToTerraform(struct?: PageRuleActionsCacheKeyFieldsQueryStringOutputReference | PageRuleActionsCacheKeyFieldsQueryString): any;
export declare function pageRuleActionsCacheKeyFieldsQueryStringToHclTerraform(struct?: PageRuleActionsCacheKeyFieldsQueryStringOutputReference | PageRuleActionsCacheKeyFieldsQueryString): any;
export declare class PageRuleActionsCacheKeyFieldsQueryStringOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PageRuleActionsCacheKeyFieldsQueryString | undefined;
    set internalValue(value: PageRuleActionsCacheKeyFieldsQueryString | undefined);
    private _exclude?;
    get exclude(): string[];
    set exclude(value: string[]);
    resetExclude(): void;
    get excludeInput(): string[] | undefined;
    private _ignore?;
    get ignore(): boolean | cdktf.IResolvable;
    set ignore(value: boolean | cdktf.IResolvable);
    resetIgnore(): void;
    get ignoreInput(): boolean | cdktf.IResolvable | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export interface PageRuleActionsCacheKeyFieldsUser {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#device_type PageRule#device_type}
    */
    readonly deviceType?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#geo PageRule#geo}
    */
    readonly geo?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#lang PageRule#lang}
    */
    readonly lang?: boolean | cdktf.IResolvable;
}
export declare function pageRuleActionsCacheKeyFieldsUserToTerraform(struct?: PageRuleActionsCacheKeyFieldsUserOutputReference | PageRuleActionsCacheKeyFieldsUser): any;
export declare function pageRuleActionsCacheKeyFieldsUserToHclTerraform(struct?: PageRuleActionsCacheKeyFieldsUserOutputReference | PageRuleActionsCacheKeyFieldsUser): any;
export declare class PageRuleActionsCacheKeyFieldsUserOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PageRuleActionsCacheKeyFieldsUser | undefined;
    set internalValue(value: PageRuleActionsCacheKeyFieldsUser | undefined);
    private _deviceType?;
    get deviceType(): boolean | cdktf.IResolvable;
    set deviceType(value: boolean | cdktf.IResolvable);
    resetDeviceType(): void;
    get deviceTypeInput(): boolean | cdktf.IResolvable | undefined;
    private _geo?;
    get geo(): boolean | cdktf.IResolvable;
    set geo(value: boolean | cdktf.IResolvable);
    resetGeo(): void;
    get geoInput(): boolean | cdktf.IResolvable | undefined;
    private _lang?;
    get lang(): boolean | cdktf.IResolvable;
    set lang(value: boolean | cdktf.IResolvable);
    resetLang(): void;
    get langInput(): boolean | cdktf.IResolvable | undefined;
}
export interface PageRuleActionsCacheKeyFields {
    /**
    * cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#cookie PageRule#cookie}
    */
    readonly cookie?: PageRuleActionsCacheKeyFieldsCookie;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#header PageRule#header}
    */
    readonly header?: PageRuleActionsCacheKeyFieldsHeader;
    /**
    * host block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#host PageRule#host}
    */
    readonly host: PageRuleActionsCacheKeyFieldsHost;
    /**
    * query_string block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#query_string PageRule#query_string}
    */
    readonly queryString: PageRuleActionsCacheKeyFieldsQueryString;
    /**
    * user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#user PageRule#user}
    */
    readonly user: PageRuleActionsCacheKeyFieldsUser;
}
export declare function pageRuleActionsCacheKeyFieldsToTerraform(struct?: PageRuleActionsCacheKeyFieldsOutputReference | PageRuleActionsCacheKeyFields): any;
export declare function pageRuleActionsCacheKeyFieldsToHclTerraform(struct?: PageRuleActionsCacheKeyFieldsOutputReference | PageRuleActionsCacheKeyFields): any;
export declare class PageRuleActionsCacheKeyFieldsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PageRuleActionsCacheKeyFields | undefined;
    set internalValue(value: PageRuleActionsCacheKeyFields | undefined);
    private _cookie;
    get cookie(): PageRuleActionsCacheKeyFieldsCookieOutputReference;
    putCookie(value: PageRuleActionsCacheKeyFieldsCookie): void;
    resetCookie(): void;
    get cookieInput(): PageRuleActionsCacheKeyFieldsCookie | undefined;
    private _header;
    get header(): PageRuleActionsCacheKeyFieldsHeaderOutputReference;
    putHeader(value: PageRuleActionsCacheKeyFieldsHeader): void;
    resetHeader(): void;
    get headerInput(): PageRuleActionsCacheKeyFieldsHeader | undefined;
    private _host;
    get host(): PageRuleActionsCacheKeyFieldsHostOutputReference;
    putHost(value: PageRuleActionsCacheKeyFieldsHost): void;
    get hostInput(): PageRuleActionsCacheKeyFieldsHost | undefined;
    private _queryString;
    get queryString(): PageRuleActionsCacheKeyFieldsQueryStringOutputReference;
    putQueryString(value: PageRuleActionsCacheKeyFieldsQueryString): void;
    get queryStringInput(): PageRuleActionsCacheKeyFieldsQueryString | undefined;
    private _user;
    get user(): PageRuleActionsCacheKeyFieldsUserOutputReference;
    putUser(value: PageRuleActionsCacheKeyFieldsUser): void;
    get userInput(): PageRuleActionsCacheKeyFieldsUser | undefined;
}
export interface PageRuleActionsCacheTtlByStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#codes PageRule#codes}
    */
    readonly codes: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#ttl PageRule#ttl}
    */
    readonly ttl: number;
}
export declare function pageRuleActionsCacheTtlByStatusToTerraform(struct?: PageRuleActionsCacheTtlByStatus | cdktf.IResolvable): any;
export declare function pageRuleActionsCacheTtlByStatusToHclTerraform(struct?: PageRuleActionsCacheTtlByStatus | cdktf.IResolvable): any;
export declare class PageRuleActionsCacheTtlByStatusOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PageRuleActionsCacheTtlByStatus | cdktf.IResolvable | undefined;
    set internalValue(value: PageRuleActionsCacheTtlByStatus | cdktf.IResolvable | undefined);
    private _codes?;
    get codes(): string;
    set codes(value: string);
    get codesInput(): string | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    get ttlInput(): number | undefined;
}
export declare class PageRuleActionsCacheTtlByStatusList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PageRuleActionsCacheTtlByStatus[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PageRuleActionsCacheTtlByStatusOutputReference;
}
export interface PageRuleActionsForwardingUrl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#status_code PageRule#status_code}
    */
    readonly statusCode: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#url PageRule#url}
    */
    readonly url: string;
}
export declare function pageRuleActionsForwardingUrlToTerraform(struct?: PageRuleActionsForwardingUrlOutputReference | PageRuleActionsForwardingUrl): any;
export declare function pageRuleActionsForwardingUrlToHclTerraform(struct?: PageRuleActionsForwardingUrlOutputReference | PageRuleActionsForwardingUrl): any;
export declare class PageRuleActionsForwardingUrlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PageRuleActionsForwardingUrl | undefined;
    set internalValue(value: PageRuleActionsForwardingUrl | undefined);
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    get statusCodeInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface PageRuleActionsMinify {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#css PageRule#css}
    */
    readonly css: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#html PageRule#html}
    */
    readonly html: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#js PageRule#js}
    */
    readonly js: string;
}
export declare function pageRuleActionsMinifyToTerraform(struct?: PageRuleActionsMinify | cdktf.IResolvable): any;
export declare function pageRuleActionsMinifyToHclTerraform(struct?: PageRuleActionsMinify | cdktf.IResolvable): any;
export declare class PageRuleActionsMinifyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PageRuleActionsMinify | cdktf.IResolvable | undefined;
    set internalValue(value: PageRuleActionsMinify | cdktf.IResolvable | undefined);
    private _css?;
    get css(): string;
    set css(value: string);
    get cssInput(): string | undefined;
    private _html?;
    get html(): string;
    set html(value: string);
    get htmlInput(): string | undefined;
    private _js?;
    get js(): string;
    set js(value: string);
    get jsInput(): string | undefined;
}
export declare class PageRuleActionsMinifyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: PageRuleActionsMinify[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PageRuleActionsMinifyOutputReference;
}
export interface PageRuleActions {
    /**
    * Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#always_use_https PageRule#always_use_https}
    */
    readonly alwaysUseHttps?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#automatic_https_rewrites PageRule#automatic_https_rewrites}
    */
    readonly automaticHttpsRewrites?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#browser_cache_ttl PageRule#browser_cache_ttl}
    */
    readonly browserCacheTtl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#browser_check PageRule#browser_check}
    */
    readonly browserCheck?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#bypass_cache_on_cookie PageRule#bypass_cache_on_cookie}
    */
    readonly bypassCacheOnCookie?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#cache_by_device_type PageRule#cache_by_device_type}
    */
    readonly cacheByDeviceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#cache_deception_armor PageRule#cache_deception_armor}
    */
    readonly cacheDeceptionArmor?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#cache_level PageRule#cache_level}
    */
    readonly cacheLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#cache_on_cookie PageRule#cache_on_cookie}
    */
    readonly cacheOnCookie?: string;
    /**
    * Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#disable_apps PageRule#disable_apps}
    */
    readonly disableApps?: boolean | cdktf.IResolvable;
    /**
    * Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#disable_performance PageRule#disable_performance}
    */
    readonly disablePerformance?: boolean | cdktf.IResolvable;
    /**
    * Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#disable_railgun PageRule#disable_railgun}
    */
    readonly disableRailgun?: boolean | cdktf.IResolvable;
    /**
    * Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#disable_security PageRule#disable_security}
    */
    readonly disableSecurity?: boolean | cdktf.IResolvable;
    /**
    * Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#disable_zaraz PageRule#disable_zaraz}
    */
    readonly disableZaraz?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#edge_cache_ttl PageRule#edge_cache_ttl}
    */
    readonly edgeCacheTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#email_obfuscation PageRule#email_obfuscation}
    */
    readonly emailObfuscation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#explicit_cache_control PageRule#explicit_cache_control}
    */
    readonly explicitCacheControl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#host_header_override PageRule#host_header_override}
    */
    readonly hostHeaderOverride?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#ip_geolocation PageRule#ip_geolocation}
    */
    readonly ipGeolocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#mirage PageRule#mirage}
    */
    readonly mirage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#opportunistic_encryption PageRule#opportunistic_encryption}
    */
    readonly opportunisticEncryption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#origin_error_page_pass_thru PageRule#origin_error_page_pass_thru}
    */
    readonly originErrorPagePassThru?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#polish PageRule#polish}
    */
    readonly polish?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#resolve_override PageRule#resolve_override}
    */
    readonly resolveOverride?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#respect_strong_etag PageRule#respect_strong_etag}
    */
    readonly respectStrongEtag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#response_buffering PageRule#response_buffering}
    */
    readonly responseBuffering?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#rocket_loader PageRule#rocket_loader}
    */
    readonly rocketLoader?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#security_level PageRule#security_level}
    */
    readonly securityLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#server_side_exclude PageRule#server_side_exclude}
    */
    readonly serverSideExclude?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#sort_query_string_for_cache PageRule#sort_query_string_for_cache}
    */
    readonly sortQueryStringForCache?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#ssl PageRule#ssl}
    */
    readonly ssl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#true_client_ip_header PageRule#true_client_ip_header}
    */
    readonly trueClientIpHeader?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#waf PageRule#waf}
    */
    readonly waf?: string;
    /**
    * cache_key_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#cache_key_fields PageRule#cache_key_fields}
    */
    readonly cacheKeyFields?: PageRuleActionsCacheKeyFields;
    /**
    * cache_ttl_by_status block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#cache_ttl_by_status PageRule#cache_ttl_by_status}
    */
    readonly cacheTtlByStatus?: PageRuleActionsCacheTtlByStatus[] | cdktf.IResolvable;
    /**
    * forwarding_url block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#forwarding_url PageRule#forwarding_url}
    */
    readonly forwardingUrl?: PageRuleActionsForwardingUrl;
    /**
    * minify block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#minify PageRule#minify}
    */
    readonly minify?: PageRuleActionsMinify[] | cdktf.IResolvable;
}
export declare function pageRuleActionsToTerraform(struct?: PageRuleActionsOutputReference | PageRuleActions): any;
export declare function pageRuleActionsToHclTerraform(struct?: PageRuleActionsOutputReference | PageRuleActions): any;
export declare class PageRuleActionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PageRuleActions | undefined;
    set internalValue(value: PageRuleActions | undefined);
    private _alwaysUseHttps?;
    get alwaysUseHttps(): boolean | cdktf.IResolvable;
    set alwaysUseHttps(value: boolean | cdktf.IResolvable);
    resetAlwaysUseHttps(): void;
    get alwaysUseHttpsInput(): boolean | cdktf.IResolvable | undefined;
    private _automaticHttpsRewrites?;
    get automaticHttpsRewrites(): string;
    set automaticHttpsRewrites(value: string);
    resetAutomaticHttpsRewrites(): void;
    get automaticHttpsRewritesInput(): string | undefined;
    private _browserCacheTtl?;
    get browserCacheTtl(): string;
    set browserCacheTtl(value: string);
    resetBrowserCacheTtl(): void;
    get browserCacheTtlInput(): string | undefined;
    private _browserCheck?;
    get browserCheck(): string;
    set browserCheck(value: string);
    resetBrowserCheck(): void;
    get browserCheckInput(): string | undefined;
    private _bypassCacheOnCookie?;
    get bypassCacheOnCookie(): string;
    set bypassCacheOnCookie(value: string);
    resetBypassCacheOnCookie(): void;
    get bypassCacheOnCookieInput(): string | undefined;
    private _cacheByDeviceType?;
    get cacheByDeviceType(): string;
    set cacheByDeviceType(value: string);
    resetCacheByDeviceType(): void;
    get cacheByDeviceTypeInput(): string | undefined;
    private _cacheDeceptionArmor?;
    get cacheDeceptionArmor(): string;
    set cacheDeceptionArmor(value: string);
    resetCacheDeceptionArmor(): void;
    get cacheDeceptionArmorInput(): string | undefined;
    private _cacheLevel?;
    get cacheLevel(): string;
    set cacheLevel(value: string);
    resetCacheLevel(): void;
    get cacheLevelInput(): string | undefined;
    private _cacheOnCookie?;
    get cacheOnCookie(): string;
    set cacheOnCookie(value: string);
    resetCacheOnCookie(): void;
    get cacheOnCookieInput(): string | undefined;
    private _disableApps?;
    get disableApps(): boolean | cdktf.IResolvable;
    set disableApps(value: boolean | cdktf.IResolvable);
    resetDisableApps(): void;
    get disableAppsInput(): boolean | cdktf.IResolvable | undefined;
    private _disablePerformance?;
    get disablePerformance(): boolean | cdktf.IResolvable;
    set disablePerformance(value: boolean | cdktf.IResolvable);
    resetDisablePerformance(): void;
    get disablePerformanceInput(): boolean | cdktf.IResolvable | undefined;
    private _disableRailgun?;
    get disableRailgun(): boolean | cdktf.IResolvable;
    set disableRailgun(value: boolean | cdktf.IResolvable);
    resetDisableRailgun(): void;
    get disableRailgunInput(): boolean | cdktf.IResolvable | undefined;
    private _disableSecurity?;
    get disableSecurity(): boolean | cdktf.IResolvable;
    set disableSecurity(value: boolean | cdktf.IResolvable);
    resetDisableSecurity(): void;
    get disableSecurityInput(): boolean | cdktf.IResolvable | undefined;
    private _disableZaraz?;
    get disableZaraz(): boolean | cdktf.IResolvable;
    set disableZaraz(value: boolean | cdktf.IResolvable);
    resetDisableZaraz(): void;
    get disableZarazInput(): boolean | cdktf.IResolvable | undefined;
    private _edgeCacheTtl?;
    get edgeCacheTtl(): number;
    set edgeCacheTtl(value: number);
    resetEdgeCacheTtl(): void;
    get edgeCacheTtlInput(): number | undefined;
    private _emailObfuscation?;
    get emailObfuscation(): string;
    set emailObfuscation(value: string);
    resetEmailObfuscation(): void;
    get emailObfuscationInput(): string | undefined;
    private _explicitCacheControl?;
    get explicitCacheControl(): string;
    set explicitCacheControl(value: string);
    resetExplicitCacheControl(): void;
    get explicitCacheControlInput(): string | undefined;
    private _hostHeaderOverride?;
    get hostHeaderOverride(): string;
    set hostHeaderOverride(value: string);
    resetHostHeaderOverride(): void;
    get hostHeaderOverrideInput(): string | undefined;
    private _ipGeolocation?;
    get ipGeolocation(): string;
    set ipGeolocation(value: string);
    resetIpGeolocation(): void;
    get ipGeolocationInput(): string | undefined;
    private _mirage?;
    get mirage(): string;
    set mirage(value: string);
    resetMirage(): void;
    get mirageInput(): string | undefined;
    private _opportunisticEncryption?;
    get opportunisticEncryption(): string;
    set opportunisticEncryption(value: string);
    resetOpportunisticEncryption(): void;
    get opportunisticEncryptionInput(): string | undefined;
    private _originErrorPagePassThru?;
    get originErrorPagePassThru(): string;
    set originErrorPagePassThru(value: string);
    resetOriginErrorPagePassThru(): void;
    get originErrorPagePassThruInput(): string | undefined;
    private _polish?;
    get polish(): string;
    set polish(value: string);
    resetPolish(): void;
    get polishInput(): string | undefined;
    private _resolveOverride?;
    get resolveOverride(): string;
    set resolveOverride(value: string);
    resetResolveOverride(): void;
    get resolveOverrideInput(): string | undefined;
    private _respectStrongEtag?;
    get respectStrongEtag(): string;
    set respectStrongEtag(value: string);
    resetRespectStrongEtag(): void;
    get respectStrongEtagInput(): string | undefined;
    private _responseBuffering?;
    get responseBuffering(): string;
    set responseBuffering(value: string);
    resetResponseBuffering(): void;
    get responseBufferingInput(): string | undefined;
    private _rocketLoader?;
    get rocketLoader(): string;
    set rocketLoader(value: string);
    resetRocketLoader(): void;
    get rocketLoaderInput(): string | undefined;
    private _securityLevel?;
    get securityLevel(): string;
    set securityLevel(value: string);
    resetSecurityLevel(): void;
    get securityLevelInput(): string | undefined;
    private _serverSideExclude?;
    get serverSideExclude(): string;
    set serverSideExclude(value: string);
    resetServerSideExclude(): void;
    get serverSideExcludeInput(): string | undefined;
    private _sortQueryStringForCache?;
    get sortQueryStringForCache(): string;
    set sortQueryStringForCache(value: string);
    resetSortQueryStringForCache(): void;
    get sortQueryStringForCacheInput(): string | undefined;
    private _ssl?;
    get ssl(): string;
    set ssl(value: string);
    resetSsl(): void;
    get sslInput(): string | undefined;
    private _trueClientIpHeader?;
    get trueClientIpHeader(): string;
    set trueClientIpHeader(value: string);
    resetTrueClientIpHeader(): void;
    get trueClientIpHeaderInput(): string | undefined;
    private _waf?;
    get waf(): string;
    set waf(value: string);
    resetWaf(): void;
    get wafInput(): string | undefined;
    private _cacheKeyFields;
    get cacheKeyFields(): PageRuleActionsCacheKeyFieldsOutputReference;
    putCacheKeyFields(value: PageRuleActionsCacheKeyFields): void;
    resetCacheKeyFields(): void;
    get cacheKeyFieldsInput(): PageRuleActionsCacheKeyFields | undefined;
    private _cacheTtlByStatus;
    get cacheTtlByStatus(): PageRuleActionsCacheTtlByStatusList;
    putCacheTtlByStatus(value: PageRuleActionsCacheTtlByStatus[] | cdktf.IResolvable): void;
    resetCacheTtlByStatus(): void;
    get cacheTtlByStatusInput(): cdktf.IResolvable | PageRuleActionsCacheTtlByStatus[] | undefined;
    private _forwardingUrl;
    get forwardingUrl(): PageRuleActionsForwardingUrlOutputReference;
    putForwardingUrl(value: PageRuleActionsForwardingUrl): void;
    resetForwardingUrl(): void;
    get forwardingUrlInput(): PageRuleActionsForwardingUrl | undefined;
    private _minify;
    get minify(): PageRuleActionsMinifyList;
    putMinify(value: PageRuleActionsMinify[] | cdktf.IResolvable): void;
    resetMinify(): void;
    get minifyInput(): cdktf.IResolvable | PageRuleActionsMinify[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule cloudflare_page_rule}
*/
export declare class PageRule extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_page_rule";
    /**
    * Generates CDKTF code for importing a PageRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PageRule to import
    * @param importFromId The id of the existing PageRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PageRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/page_rule cloudflare_page_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PageRuleConfig
    */
    constructor(scope: Construct, id: string, config: PageRuleConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _actions;
    get actions(): PageRuleActionsOutputReference;
    putActions(value: PageRuleActions): void;
    get actionsInput(): PageRuleActions | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
