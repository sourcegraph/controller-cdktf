import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApiTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * The expiration time on or after which the token MUST NOT be accepted for processing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#expires_on ApiToken#expires_on}
    */
    readonly expiresOn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#id ApiToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the API Token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#name ApiToken#name}
    */
    readonly name: string;
    /**
    * The time before which the token MUST NOT be accepted for processing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#not_before ApiToken#not_before}
    */
    readonly notBefore?: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#condition ApiToken#condition}
    */
    readonly condition?: ApiTokenCondition;
    /**
    * policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#policy ApiToken#policy}
    */
    readonly policy: ApiTokenPolicy[] | cdktf.IResolvable;
}
export interface ApiTokenConditionRequestIp {
    /**
    * List of IP addresses or CIDR notation where the token may be used from. If not specified, the token will be valid for all IP addresses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#in ApiToken#in}
    */
    readonly in?: string[];
    /**
    * List of IP addresses or CIDR notation where the token should not be used from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#not_in ApiToken#not_in}
    */
    readonly notIn?: string[];
}
export declare function apiTokenConditionRequestIpToTerraform(struct?: ApiTokenConditionRequestIpOutputReference | ApiTokenConditionRequestIp): any;
export declare function apiTokenConditionRequestIpToHclTerraform(struct?: ApiTokenConditionRequestIpOutputReference | ApiTokenConditionRequestIp): any;
export declare class ApiTokenConditionRequestIpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiTokenConditionRequestIp | undefined;
    set internalValue(value: ApiTokenConditionRequestIp | undefined);
    private _in?;
    get in(): string[];
    set in(value: string[]);
    resetIn(): void;
    get inInput(): string[] | undefined;
    private _notIn?;
    get notIn(): string[];
    set notIn(value: string[]);
    resetNotIn(): void;
    get notInInput(): string[] | undefined;
}
export interface ApiTokenCondition {
    /**
    * request_ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#request_ip ApiToken#request_ip}
    */
    readonly requestIp?: ApiTokenConditionRequestIp;
}
export declare function apiTokenConditionToTerraform(struct?: ApiTokenConditionOutputReference | ApiTokenCondition): any;
export declare function apiTokenConditionToHclTerraform(struct?: ApiTokenConditionOutputReference | ApiTokenCondition): any;
export declare class ApiTokenConditionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiTokenCondition | undefined;
    set internalValue(value: ApiTokenCondition | undefined);
    private _requestIp;
    get requestIp(): ApiTokenConditionRequestIpOutputReference;
    putRequestIp(value: ApiTokenConditionRequestIp): void;
    resetRequestIp(): void;
    get requestIpInput(): ApiTokenConditionRequestIp | undefined;
}
export interface ApiTokenPolicy {
    /**
    * Effect of the policy. Available values: `allow`, `deny`. Defaults to `allow`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#effect ApiToken#effect}
    */
    readonly effect?: string;
    /**
    * List of permissions groups IDs. See [documentation](https://developers.cloudflare.com/api/tokens/create/permissions) for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#permission_groups ApiToken#permission_groups}
    */
    readonly permissionGroups: string[];
    /**
    * Describes what operations against which resources are allowed or denied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#resources ApiToken#resources}
    */
    readonly resources: {
        [key: string]: string;
    };
}
export declare function apiTokenPolicyToTerraform(struct?: ApiTokenPolicy | cdktf.IResolvable): any;
export declare function apiTokenPolicyToHclTerraform(struct?: ApiTokenPolicy | cdktf.IResolvable): any;
export declare class ApiTokenPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiTokenPolicy | cdktf.IResolvable | undefined;
    set internalValue(value: ApiTokenPolicy | cdktf.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    resetEffect(): void;
    get effectInput(): string | undefined;
    private _permissionGroups?;
    get permissionGroups(): string[];
    set permissionGroups(value: string[]);
    get permissionGroupsInput(): string[] | undefined;
    private _resources?;
    get resources(): {
        [key: string]: string;
    };
    set resources(value: {
        [key: string]: string;
    });
    get resourcesInput(): {
        [key: string]: string;
    } | undefined;
}
export declare class ApiTokenPolicyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApiTokenPolicy[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiTokenPolicyOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token cloudflare_api_token}
*/
export declare class ApiToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_api_token";
    /**
    * Generates CDKTF code for importing a ApiToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiToken to import
    * @param importFromId The id of the existing ApiToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/api_token cloudflare_api_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiTokenConfig
    */
    constructor(scope: Construct, id: string, config: ApiTokenConfig);
    private _expiresOn?;
    get expiresOn(): string;
    set expiresOn(value: string);
    resetExpiresOn(): void;
    get expiresOnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuedOn(): string;
    get modifiedOn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notBefore?;
    get notBefore(): string;
    set notBefore(value: string);
    resetNotBefore(): void;
    get notBeforeInput(): string | undefined;
    get status(): string;
    get value(): string;
    private _condition;
    get condition(): ApiTokenConditionOutputReference;
    putCondition(value: ApiTokenCondition): void;
    resetCondition(): void;
    get conditionInput(): ApiTokenCondition | undefined;
    private _policy;
    get policy(): ApiTokenPolicyList;
    putPolicy(value: ApiTokenPolicy[] | cdktf.IResolvable): void;
    get policyInput(): cdktf.IResolvable | ApiTokenPolicy[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
