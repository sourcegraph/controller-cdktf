import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WorkerScriptConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#account_id WorkerScript#account_id}
    */
    readonly accountId: string;
    /**
    * The date to use for the compatibility flag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#compatibility_date WorkerScript#compatibility_date}
    */
    readonly compatibilityDate?: string;
    /**
    * Compatibility flags used for Worker Scripts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#compatibility_flags WorkerScript#compatibility_flags}
    */
    readonly compatibilityFlags?: string[];
    /**
    * The script content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#content WorkerScript#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#id WorkerScript#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to upload Worker as a module.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#module WorkerScript#module}
    */
    readonly module?: boolean | cdktf.IResolvable;
    /**
    * The name for the script. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#name WorkerScript#name}
    */
    readonly name: string;
    /**
    * analytics_engine_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#analytics_engine_binding WorkerScript#analytics_engine_binding}
    */
    readonly analyticsEngineBinding?: WorkerScriptAnalyticsEngineBinding[] | cdktf.IResolvable;
    /**
    * kv_namespace_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#kv_namespace_binding WorkerScript#kv_namespace_binding}
    */
    readonly kvNamespaceBinding?: WorkerScriptKvNamespaceBinding[] | cdktf.IResolvable;
    /**
    * plain_text_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#plain_text_binding WorkerScript#plain_text_binding}
    */
    readonly plainTextBinding?: WorkerScriptPlainTextBinding[] | cdktf.IResolvable;
    /**
    * queue_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#queue_binding WorkerScript#queue_binding}
    */
    readonly queueBinding?: WorkerScriptQueueBinding[] | cdktf.IResolvable;
    /**
    * r2_bucket_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#r2_bucket_binding WorkerScript#r2_bucket_binding}
    */
    readonly r2BucketBinding?: WorkerScriptR2BucketBinding[] | cdktf.IResolvable;
    /**
    * secret_text_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#secret_text_binding WorkerScript#secret_text_binding}
    */
    readonly secretTextBinding?: WorkerScriptSecretTextBinding[] | cdktf.IResolvable;
    /**
    * service_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#service_binding WorkerScript#service_binding}
    */
    readonly serviceBinding?: WorkerScriptServiceBinding[] | cdktf.IResolvable;
    /**
    * webassembly_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#webassembly_binding WorkerScript#webassembly_binding}
    */
    readonly webassemblyBinding?: WorkerScriptWebassemblyBinding[] | cdktf.IResolvable;
}
export interface WorkerScriptAnalyticsEngineBinding {
    /**
    * The name of the Analytics Engine dataset to write to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#dataset WorkerScript#dataset}
    */
    readonly dataset: string;
    /**
    * The global variable for the binding in your Worker code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#name WorkerScript#name}
    */
    readonly name: string;
}
export declare function workerScriptAnalyticsEngineBindingToTerraform(struct?: WorkerScriptAnalyticsEngineBinding | cdktf.IResolvable): any;
export declare function workerScriptAnalyticsEngineBindingToHclTerraform(struct?: WorkerScriptAnalyticsEngineBinding | cdktf.IResolvable): any;
export declare class WorkerScriptAnalyticsEngineBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkerScriptAnalyticsEngineBinding | cdktf.IResolvable | undefined;
    set internalValue(value: WorkerScriptAnalyticsEngineBinding | cdktf.IResolvable | undefined);
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    get datasetInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class WorkerScriptAnalyticsEngineBindingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkerScriptAnalyticsEngineBinding[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkerScriptAnalyticsEngineBindingOutputReference;
}
export interface WorkerScriptKvNamespaceBinding {
    /**
    * The global variable for the binding in your Worker code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#name WorkerScript#name}
    */
    readonly name: string;
    /**
    * ID of the KV namespace you want to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#namespace_id WorkerScript#namespace_id}
    */
    readonly namespaceId: string;
}
export declare function workerScriptKvNamespaceBindingToTerraform(struct?: WorkerScriptKvNamespaceBinding | cdktf.IResolvable): any;
export declare function workerScriptKvNamespaceBindingToHclTerraform(struct?: WorkerScriptKvNamespaceBinding | cdktf.IResolvable): any;
export declare class WorkerScriptKvNamespaceBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkerScriptKvNamespaceBinding | cdktf.IResolvable | undefined;
    set internalValue(value: WorkerScriptKvNamespaceBinding | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespaceId?;
    get namespaceId(): string;
    set namespaceId(value: string);
    get namespaceIdInput(): string | undefined;
}
export declare class WorkerScriptKvNamespaceBindingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkerScriptKvNamespaceBinding[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkerScriptKvNamespaceBindingOutputReference;
}
export interface WorkerScriptPlainTextBinding {
    /**
    * The global variable for the binding in your Worker code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#name WorkerScript#name}
    */
    readonly name: string;
    /**
    * The plain text you want to store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#text WorkerScript#text}
    */
    readonly text: string;
}
export declare function workerScriptPlainTextBindingToTerraform(struct?: WorkerScriptPlainTextBinding | cdktf.IResolvable): any;
export declare function workerScriptPlainTextBindingToHclTerraform(struct?: WorkerScriptPlainTextBinding | cdktf.IResolvable): any;
export declare class WorkerScriptPlainTextBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkerScriptPlainTextBinding | cdktf.IResolvable | undefined;
    set internalValue(value: WorkerScriptPlainTextBinding | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    get textInput(): string | undefined;
}
export declare class WorkerScriptPlainTextBindingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkerScriptPlainTextBinding[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkerScriptPlainTextBindingOutputReference;
}
export interface WorkerScriptQueueBinding {
    /**
    * The name of the global variable for the binding in your Worker code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#binding WorkerScript#binding}
    */
    readonly binding: string;
    /**
    * Name of the queue you want to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#queue WorkerScript#queue}
    */
    readonly queue: string;
}
export declare function workerScriptQueueBindingToTerraform(struct?: WorkerScriptQueueBinding | cdktf.IResolvable): any;
export declare function workerScriptQueueBindingToHclTerraform(struct?: WorkerScriptQueueBinding | cdktf.IResolvable): any;
export declare class WorkerScriptQueueBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkerScriptQueueBinding | cdktf.IResolvable | undefined;
    set internalValue(value: WorkerScriptQueueBinding | cdktf.IResolvable | undefined);
    private _binding?;
    get binding(): string;
    set binding(value: string);
    get bindingInput(): string | undefined;
    private _queue?;
    get queue(): string;
    set queue(value: string);
    get queueInput(): string | undefined;
}
export declare class WorkerScriptQueueBindingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkerScriptQueueBinding[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkerScriptQueueBindingOutputReference;
}
export interface WorkerScriptR2BucketBinding {
    /**
    * The name of the Bucket to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#bucket_name WorkerScript#bucket_name}
    */
    readonly bucketName: string;
    /**
    * The global variable for the binding in your Worker code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#name WorkerScript#name}
    */
    readonly name: string;
}
export declare function workerScriptR2BucketBindingToTerraform(struct?: WorkerScriptR2BucketBinding | cdktf.IResolvable): any;
export declare function workerScriptR2BucketBindingToHclTerraform(struct?: WorkerScriptR2BucketBinding | cdktf.IResolvable): any;
export declare class WorkerScriptR2BucketBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkerScriptR2BucketBinding | cdktf.IResolvable | undefined;
    set internalValue(value: WorkerScriptR2BucketBinding | cdktf.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class WorkerScriptR2BucketBindingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkerScriptR2BucketBinding[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkerScriptR2BucketBindingOutputReference;
}
export interface WorkerScriptSecretTextBinding {
    /**
    * The global variable for the binding in your Worker code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#name WorkerScript#name}
    */
    readonly name: string;
    /**
    * The secret text you want to store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#text WorkerScript#text}
    */
    readonly text: string;
}
export declare function workerScriptSecretTextBindingToTerraform(struct?: WorkerScriptSecretTextBinding | cdktf.IResolvable): any;
export declare function workerScriptSecretTextBindingToHclTerraform(struct?: WorkerScriptSecretTextBinding | cdktf.IResolvable): any;
export declare class WorkerScriptSecretTextBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkerScriptSecretTextBinding | cdktf.IResolvable | undefined;
    set internalValue(value: WorkerScriptSecretTextBinding | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    get textInput(): string | undefined;
}
export declare class WorkerScriptSecretTextBindingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkerScriptSecretTextBinding[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkerScriptSecretTextBindingOutputReference;
}
export interface WorkerScriptServiceBinding {
    /**
    * The name of the Worker environment to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#environment WorkerScript#environment}
    */
    readonly environment?: string;
    /**
    * The global variable for the binding in your Worker code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#name WorkerScript#name}
    */
    readonly name: string;
    /**
    * The name of the Worker to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#service WorkerScript#service}
    */
    readonly service: string;
}
export declare function workerScriptServiceBindingToTerraform(struct?: WorkerScriptServiceBinding | cdktf.IResolvable): any;
export declare function workerScriptServiceBindingToHclTerraform(struct?: WorkerScriptServiceBinding | cdktf.IResolvable): any;
export declare class WorkerScriptServiceBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkerScriptServiceBinding | cdktf.IResolvable | undefined;
    set internalValue(value: WorkerScriptServiceBinding | cdktf.IResolvable | undefined);
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export declare class WorkerScriptServiceBindingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkerScriptServiceBinding[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkerScriptServiceBindingOutputReference;
}
export interface WorkerScriptWebassemblyBinding {
    /**
    * The base64 encoded wasm module you want to store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#module WorkerScript#module}
    */
    readonly module: string;
    /**
    * The global variable for the binding in your Worker code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#name WorkerScript#name}
    */
    readonly name: string;
}
export declare function workerScriptWebassemblyBindingToTerraform(struct?: WorkerScriptWebassemblyBinding | cdktf.IResolvable): any;
export declare function workerScriptWebassemblyBindingToHclTerraform(struct?: WorkerScriptWebassemblyBinding | cdktf.IResolvable): any;
export declare class WorkerScriptWebassemblyBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkerScriptWebassemblyBinding | cdktf.IResolvable | undefined;
    set internalValue(value: WorkerScriptWebassemblyBinding | cdktf.IResolvable | undefined);
    private _module?;
    get module(): string;
    set module(value: string);
    get moduleInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class WorkerScriptWebassemblyBindingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WorkerScriptWebassemblyBinding[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkerScriptWebassemblyBindingOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script cloudflare_worker_script}
*/
export declare class WorkerScript extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_worker_script";
    /**
    * Generates CDKTF code for importing a WorkerScript resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkerScript to import
    * @param importFromId The id of the existing WorkerScript that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkerScript to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_script cloudflare_worker_script} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkerScriptConfig
    */
    constructor(scope: Construct, id: string, config: WorkerScriptConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _compatibilityDate?;
    get compatibilityDate(): string;
    set compatibilityDate(value: string);
    resetCompatibilityDate(): void;
    get compatibilityDateInput(): string | undefined;
    private _compatibilityFlags?;
    get compatibilityFlags(): string[];
    set compatibilityFlags(value: string[]);
    resetCompatibilityFlags(): void;
    get compatibilityFlagsInput(): string[] | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _module?;
    get module(): boolean | cdktf.IResolvable;
    set module(value: boolean | cdktf.IResolvable);
    resetModule(): void;
    get moduleInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _analyticsEngineBinding;
    get analyticsEngineBinding(): WorkerScriptAnalyticsEngineBindingList;
    putAnalyticsEngineBinding(value: WorkerScriptAnalyticsEngineBinding[] | cdktf.IResolvable): void;
    resetAnalyticsEngineBinding(): void;
    get analyticsEngineBindingInput(): cdktf.IResolvable | WorkerScriptAnalyticsEngineBinding[] | undefined;
    private _kvNamespaceBinding;
    get kvNamespaceBinding(): WorkerScriptKvNamespaceBindingList;
    putKvNamespaceBinding(value: WorkerScriptKvNamespaceBinding[] | cdktf.IResolvable): void;
    resetKvNamespaceBinding(): void;
    get kvNamespaceBindingInput(): cdktf.IResolvable | WorkerScriptKvNamespaceBinding[] | undefined;
    private _plainTextBinding;
    get plainTextBinding(): WorkerScriptPlainTextBindingList;
    putPlainTextBinding(value: WorkerScriptPlainTextBinding[] | cdktf.IResolvable): void;
    resetPlainTextBinding(): void;
    get plainTextBindingInput(): cdktf.IResolvable | WorkerScriptPlainTextBinding[] | undefined;
    private _queueBinding;
    get queueBinding(): WorkerScriptQueueBindingList;
    putQueueBinding(value: WorkerScriptQueueBinding[] | cdktf.IResolvable): void;
    resetQueueBinding(): void;
    get queueBindingInput(): cdktf.IResolvable | WorkerScriptQueueBinding[] | undefined;
    private _r2BucketBinding;
    get r2BucketBinding(): WorkerScriptR2BucketBindingList;
    putR2BucketBinding(value: WorkerScriptR2BucketBinding[] | cdktf.IResolvable): void;
    resetR2BucketBinding(): void;
    get r2BucketBindingInput(): cdktf.IResolvable | WorkerScriptR2BucketBinding[] | undefined;
    private _secretTextBinding;
    get secretTextBinding(): WorkerScriptSecretTextBindingList;
    putSecretTextBinding(value: WorkerScriptSecretTextBinding[] | cdktf.IResolvable): void;
    resetSecretTextBinding(): void;
    get secretTextBindingInput(): cdktf.IResolvable | WorkerScriptSecretTextBinding[] | undefined;
    private _serviceBinding;
    get serviceBinding(): WorkerScriptServiceBindingList;
    putServiceBinding(value: WorkerScriptServiceBinding[] | cdktf.IResolvable): void;
    resetServiceBinding(): void;
    get serviceBindingInput(): cdktf.IResolvable | WorkerScriptServiceBinding[] | undefined;
    private _webassemblyBinding;
    get webassemblyBinding(): WorkerScriptWebassemblyBindingList;
    putWebassemblyBinding(value: WorkerScriptWebassemblyBinding[] | cdktf.IResolvable): void;
    resetWebassemblyBinding(): void;
    get webassemblyBindingInput(): cdktf.IResolvable | WorkerScriptWebassemblyBinding[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
