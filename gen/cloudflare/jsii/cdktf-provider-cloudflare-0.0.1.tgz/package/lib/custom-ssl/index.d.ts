import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CustomSslConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#id CustomSsl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The zone identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#zone_id CustomSsl#zone_id}
    */
    readonly zoneId: string;
    /**
    * custom_ssl_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#custom_ssl_options CustomSsl#custom_ssl_options}
    */
    readonly customSslOptions?: CustomSslCustomSslOptions;
    /**
    * custom_ssl_priority block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#custom_ssl_priority CustomSsl#custom_ssl_priority}
    */
    readonly customSslPriority?: CustomSslCustomSslPriority[] | cdktf.IResolvable;
}
export interface CustomSslCustomSslOptions {
    /**
    * Method of building intermediate certificate chain. A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. Available values: `ubiquitous`, `optimal`, `force`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#bundle_method CustomSsl#bundle_method}
    */
    readonly bundleMethod?: string;
    /**
    * Certificate certificate and the intermediate(s).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#certificate CustomSsl#certificate}
    */
    readonly certificate?: string;
    /**
    * Specifies the region where your private key can be held locally. Available values: `us`, `eu`, `highest_security`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#geo_restrictions CustomSsl#geo_restrictions}
    */
    readonly geoRestrictions?: string;
    /**
    * Certificate's private key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#private_key CustomSsl#private_key}
    */
    readonly privateKey?: string;
    /**
    * Whether to enable support for legacy clients which do not include SNI in the TLS handshake. Available values: `legacy_custom`, `sni_custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#type CustomSsl#type}
    */
    readonly type?: string;
}
export declare function customSslCustomSslOptionsToTerraform(struct?: CustomSslCustomSslOptionsOutputReference | CustomSslCustomSslOptions): any;
export declare function customSslCustomSslOptionsToHclTerraform(struct?: CustomSslCustomSslOptionsOutputReference | CustomSslCustomSslOptions): any;
export declare class CustomSslCustomSslOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomSslCustomSslOptions | undefined;
    set internalValue(value: CustomSslCustomSslOptions | undefined);
    private _bundleMethod?;
    get bundleMethod(): string;
    set bundleMethod(value: string);
    resetBundleMethod(): void;
    get bundleMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _geoRestrictions?;
    get geoRestrictions(): string;
    set geoRestrictions(value: string);
    resetGeoRestrictions(): void;
    get geoRestrictionsInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface CustomSslCustomSslPriority {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#id CustomSsl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#priority CustomSsl#priority}
    */
    readonly priority?: number;
}
export declare function customSslCustomSslPriorityToTerraform(struct?: CustomSslCustomSslPriority | cdktf.IResolvable): any;
export declare function customSslCustomSslPriorityToHclTerraform(struct?: CustomSslCustomSslPriority | cdktf.IResolvable): any;
export declare class CustomSslCustomSslPriorityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomSslCustomSslPriority | cdktf.IResolvable | undefined;
    set internalValue(value: CustomSslCustomSslPriority | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
}
export declare class CustomSslCustomSslPriorityList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CustomSslCustomSslPriority[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomSslCustomSslPriorityOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl cloudflare_custom_ssl}
*/
export declare class CustomSsl extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_custom_ssl";
    /**
    * Generates CDKTF code for importing a CustomSsl resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomSsl to import
    * @param importFromId The id of the existing CustomSsl that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomSsl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_ssl cloudflare_custom_ssl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomSslConfig
    */
    constructor(scope: Construct, id: string, config: CustomSslConfig);
    get expiresOn(): string;
    get hosts(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuer(): string;
    get modifiedOn(): string;
    get priority(): number;
    get signature(): string;
    get status(): string;
    get uploadedOn(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _customSslOptions;
    get customSslOptions(): CustomSslCustomSslOptionsOutputReference;
    putCustomSslOptions(value: CustomSslCustomSslOptions): void;
    resetCustomSslOptions(): void;
    get customSslOptionsInput(): CustomSslCustomSslOptions | undefined;
    private _customSslPriority;
    get customSslPriority(): CustomSslCustomSslPriorityList;
    putCustomSslPriority(value: CustomSslCustomSslPriority[] | cdktf.IResolvable): void;
    resetCustomSslPriority(): void;
    get customSslPriorityInput(): cdktf.IResolvable | CustomSslCustomSslPriority[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
