import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RulesetConfig extends cdktf.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#account_id Ruleset#account_id}
    */
    readonly accountId?: string;
    /**
    * Brief summary of the ruleset and its intended use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#description Ruleset#description}
    */
    readonly description?: string;
    /**
    * Type of Ruleset to create. Available values: `custom`, `managed`, `root`, `schema`, `zone`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#kind Ruleset#kind}
    */
    readonly kind: string;
    /**
    * Name of the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name: string;
    /**
    * Point in the request/response lifecycle where the ruleset will be created. Available values: `ddos_l4`, `ddos_l7`, `http_custom_errors`, `http_log_custom_fields`, `http_request_cache_settings`, `http_request_firewall_custom`, `http_request_firewall_managed`, `http_request_late_transform`, `http_request_late_transform_managed`, `http_request_main`, `http_request_origin`, `http_request_dynamic_redirect`, `http_request_redirect`, `http_request_sanitize`, `http_request_transform`, `http_response_firewall_managed`, `http_response_headers_transform`, `http_response_headers_transform_managed`, `magic_transit`, `http_ratelimit`, `http_request_sbfm`, `http_config_settings`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#phase Ruleset#phase}
    */
    readonly phase: string;
    /**
    * Name of entitlement that is shareable between entities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#shareable_entitlement_name Ruleset#shareable_entitlement_name}
    */
    readonly shareableEntitlementName?: string;
    /**
    * The zone identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#zone_id Ruleset#zone_id}
    */
    readonly zoneId?: string;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#rules Ruleset#rules}
    */
    readonly rules?: RulesetRules[] | cdktf.IResolvable;
}
export interface RulesetRulesActionParametersAutominify {
    /**
    * CSS minification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#css Ruleset#css}
    */
    readonly css?: boolean | cdktf.IResolvable;
    /**
    * HTML minification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#html Ruleset#html}
    */
    readonly html?: boolean | cdktf.IResolvable;
    /**
    * JS minification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#js Ruleset#js}
    */
    readonly js?: boolean | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersAutominifyToTerraform(struct?: RulesetRulesActionParametersAutominify | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersAutominifyToHclTerraform(struct?: RulesetRulesActionParametersAutominify | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersAutominifyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersAutominify | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersAutominify | cdktf.IResolvable | undefined);
    private _css?;
    get css(): boolean | cdktf.IResolvable;
    set css(value: boolean | cdktf.IResolvable);
    resetCss(): void;
    get cssInput(): boolean | cdktf.IResolvable | undefined;
    private _html?;
    get html(): boolean | cdktf.IResolvable;
    set html(value: boolean | cdktf.IResolvable);
    resetHtml(): void;
    get htmlInput(): boolean | cdktf.IResolvable | undefined;
    private _js?;
    get js(): boolean | cdktf.IResolvable;
    set js(value: boolean | cdktf.IResolvable);
    resetJs(): void;
    get jsInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersAutominifyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersAutominify[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersAutominifyOutputReference;
}
export interface RulesetRulesActionParametersBrowserTtl {
    /**
    * Default browser TTL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#default Ruleset#default}
    */
    readonly default?: number;
    /**
    * Mode of the browser TTL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#mode Ruleset#mode}
    */
    readonly mode?: string;
}
export declare function rulesetRulesActionParametersBrowserTtlToTerraform(struct?: RulesetRulesActionParametersBrowserTtl | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersBrowserTtlToHclTerraform(struct?: RulesetRulesActionParametersBrowserTtl | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersBrowserTtlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersBrowserTtl | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersBrowserTtl | cdktf.IResolvable | undefined);
    private _default?;
    get default(): number;
    set default(value: number);
    resetDefault(): void;
    get defaultInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export declare class RulesetRulesActionParametersBrowserTtlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersBrowserTtl[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersBrowserTtlOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyCookie {
    /**
    * List of cookies to check for presence in the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#check_presence Ruleset#check_presence}
    */
    readonly checkPresence?: string[];
    /**
    * List of cookies to include in the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#include Ruleset#include}
    */
    readonly include?: string[];
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyCookieToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyCookieToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyCookieOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktf.IResolvable | undefined);
    private _checkPresence?;
    get checkPresence(): string[];
    set checkPresence(value: string[]);
    resetCheckPresence(): void;
    get checkPresenceInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyCookieList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKeyCookie[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyCookieOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyHeader {
    /**
    * List of headers to check for presence in the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#check_presence Ruleset#check_presence}
    */
    readonly checkPresence?: string[];
    /**
    * Exclude the origin header from the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#exclude_origin Ruleset#exclude_origin}
    */
    readonly excludeOrigin?: boolean | cdktf.IResolvable;
    /**
    * List of headers to include in the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#include Ruleset#include}
    */
    readonly include?: string[];
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHeaderToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHeaderToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyHeaderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktf.IResolvable | undefined);
    private _checkPresence?;
    get checkPresence(): string[];
    set checkPresence(value: string[]);
    resetCheckPresence(): void;
    get checkPresenceInput(): string[] | undefined;
    private _excludeOrigin?;
    get excludeOrigin(): boolean | cdktf.IResolvable;
    set excludeOrigin(value: boolean | cdktf.IResolvable);
    resetExcludeOrigin(): void;
    get excludeOriginInput(): boolean | cdktf.IResolvable | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyHeaderList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKeyHeader[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyHeaderOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyHost {
    /**
    * Resolve hostname to IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#resolved Ruleset#resolved}
    */
    readonly resolved?: boolean | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHostToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHostToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyHostOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktf.IResolvable | undefined);
    private _resolved?;
    get resolved(): boolean | cdktf.IResolvable;
    set resolved(value: boolean | cdktf.IResolvable);
    resetResolved(): void;
    get resolvedInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyHostList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKeyHost[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyHostOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyQueryString {
    /**
    * List of query string parameters to exclude from the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#exclude Ruleset#exclude}
    */
    readonly exclude?: string[];
    /**
    * List of query string parameters to include in the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#include Ruleset#include}
    */
    readonly include?: string[];
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyQueryStringToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyQueryStringToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyQueryStringOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktf.IResolvable | undefined);
    private _exclude?;
    get exclude(): string[];
    set exclude(value: string[]);
    resetExclude(): void;
    get excludeInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyQueryStringList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyQueryStringOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyUser {
    /**
    * Add device type to the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#device_type Ruleset#device_type}
    */
    readonly deviceType?: boolean | cdktf.IResolvable;
    /**
    * Add geo data to the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#geo Ruleset#geo}
    */
    readonly geo?: boolean | cdktf.IResolvable;
    /**
    * Add language data to the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#lang Ruleset#lang}
    */
    readonly lang?: boolean | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyUserToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyUserToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyUserOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktf.IResolvable | undefined);
    private _deviceType?;
    get deviceType(): boolean | cdktf.IResolvable;
    set deviceType(value: boolean | cdktf.IResolvable);
    resetDeviceType(): void;
    get deviceTypeInput(): boolean | cdktf.IResolvable | undefined;
    private _geo?;
    get geo(): boolean | cdktf.IResolvable;
    set geo(value: boolean | cdktf.IResolvable);
    resetGeo(): void;
    get geoInput(): boolean | cdktf.IResolvable | undefined;
    private _lang?;
    get lang(): boolean | cdktf.IResolvable;
    set lang(value: boolean | cdktf.IResolvable);
    resetLang(): void;
    get langInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyUserList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKeyUser[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyUserOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKey {
    /**
    * cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cookie Ruleset#cookie}
    */
    readonly cookie?: RulesetRulesActionParametersCacheKeyCustomKeyCookie[] | cdktf.IResolvable;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#header Ruleset#header}
    */
    readonly header?: RulesetRulesActionParametersCacheKeyCustomKeyHeader[] | cdktf.IResolvable;
    /**
    * host block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#host Ruleset#host}
    */
    readonly host?: RulesetRulesActionParametersCacheKeyCustomKeyHost[] | cdktf.IResolvable;
    /**
    * query_string block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#query_string Ruleset#query_string}
    */
    readonly queryString?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString[] | cdktf.IResolvable;
    /**
    * user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#user Ruleset#user}
    */
    readonly user?: RulesetRulesActionParametersCacheKeyCustomKeyUser[] | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKey | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKey | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKey | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKey | cdktf.IResolvable | undefined);
    private _cookie;
    get cookie(): RulesetRulesActionParametersCacheKeyCustomKeyCookieList;
    putCookie(value: RulesetRulesActionParametersCacheKeyCustomKeyCookie[] | cdktf.IResolvable): void;
    resetCookie(): void;
    get cookieInput(): cdktf.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyCookie[] | undefined;
    private _header;
    get header(): RulesetRulesActionParametersCacheKeyCustomKeyHeaderList;
    putHeader(value: RulesetRulesActionParametersCacheKeyCustomKeyHeader[] | cdktf.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktf.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyHeader[] | undefined;
    private _host;
    get host(): RulesetRulesActionParametersCacheKeyCustomKeyHostList;
    putHost(value: RulesetRulesActionParametersCacheKeyCustomKeyHost[] | cdktf.IResolvable): void;
    resetHost(): void;
    get hostInput(): cdktf.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyHost[] | undefined;
    private _queryString;
    get queryString(): RulesetRulesActionParametersCacheKeyCustomKeyQueryStringList;
    putQueryString(value: RulesetRulesActionParametersCacheKeyCustomKeyQueryString[] | cdktf.IResolvable): void;
    resetQueryString(): void;
    get queryStringInput(): cdktf.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyQueryString[] | undefined;
    private _user;
    get user(): RulesetRulesActionParametersCacheKeyCustomKeyUserList;
    putUser(value: RulesetRulesActionParametersCacheKeyCustomKeyUser[] | cdktf.IResolvable): void;
    resetUser(): void;
    get userInput(): cdktf.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyUser[] | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKey[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyOutputReference;
}
export interface RulesetRulesActionParametersCacheKey {
    /**
    * Cache by device type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cache_by_device_type Ruleset#cache_by_device_type}
    */
    readonly cacheByDeviceType?: boolean | cdktf.IResolvable;
    /**
    * Cache deception armor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cache_deception_armor Ruleset#cache_deception_armor}
    */
    readonly cacheDeceptionArmor?: boolean | cdktf.IResolvable;
    /**
    * Ignore query strings order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#ignore_query_strings_order Ruleset#ignore_query_strings_order}
    */
    readonly ignoreQueryStringsOrder?: boolean | cdktf.IResolvable;
    /**
    * custom_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#custom_key Ruleset#custom_key}
    */
    readonly customKey?: RulesetRulesActionParametersCacheKeyCustomKey[] | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyToTerraform(struct?: RulesetRulesActionParametersCacheKey | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyToHclTerraform(struct?: RulesetRulesActionParametersCacheKey | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKey | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKey | cdktf.IResolvable | undefined);
    private _cacheByDeviceType?;
    get cacheByDeviceType(): boolean | cdktf.IResolvable;
    set cacheByDeviceType(value: boolean | cdktf.IResolvable);
    resetCacheByDeviceType(): void;
    get cacheByDeviceTypeInput(): boolean | cdktf.IResolvable | undefined;
    private _cacheDeceptionArmor?;
    get cacheDeceptionArmor(): boolean | cdktf.IResolvable;
    set cacheDeceptionArmor(value: boolean | cdktf.IResolvable);
    resetCacheDeceptionArmor(): void;
    get cacheDeceptionArmorInput(): boolean | cdktf.IResolvable | undefined;
    private _ignoreQueryStringsOrder?;
    get ignoreQueryStringsOrder(): boolean | cdktf.IResolvable;
    set ignoreQueryStringsOrder(value: boolean | cdktf.IResolvable);
    resetIgnoreQueryStringsOrder(): void;
    get ignoreQueryStringsOrderInput(): boolean | cdktf.IResolvable | undefined;
    private _customKey;
    get customKey(): RulesetRulesActionParametersCacheKeyCustomKeyList;
    putCustomKey(value: RulesetRulesActionParametersCacheKeyCustomKey[] | cdktf.IResolvable): void;
    resetCustomKey(): void;
    get customKeyInput(): cdktf.IResolvable | RulesetRulesActionParametersCacheKeyCustomKey[] | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersCacheKey[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyOutputReference;
}
export interface RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange {
    /**
    * From status code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#from Ruleset#from}
    */
    readonly from?: number;
    /**
    * To status code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#to Ruleset#to}
    */
    readonly to?: number;
}
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeToTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeToHclTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktf.IResolvable | undefined);
    private _from?;
    get from(): number;
    set from(value: number);
    resetFrom(): void;
    get fromInput(): number | undefined;
    private _to?;
    get to(): number;
    set to(value: number);
    resetTo(): void;
    get toInput(): number | undefined;
}
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeOutputReference;
}
export interface RulesetRulesActionParametersEdgeTtlStatusCodeTtl {
    /**
    * Status code for which the edge TTL is applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
    /**
    * Status code edge TTL value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: number;
    /**
    * status_code_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code_range Ruleset#status_code_range}
    */
    readonly statusCodeRange?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange[] | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlToTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlToHclTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktf.IResolvable | undefined);
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
    private _statusCodeRange;
    get statusCodeRange(): RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeList;
    putStatusCodeRange(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange[] | cdktf.IResolvable): void;
    resetStatusCodeRange(): void;
    get statusCodeRangeInput(): cdktf.IResolvable | RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange[] | undefined;
}
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersEdgeTtlStatusCodeTtlOutputReference;
}
export interface RulesetRulesActionParametersEdgeTtl {
    /**
    * Default edge TTL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#default Ruleset#default}
    */
    readonly default?: number;
    /**
    * Mode of the edge TTL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#mode Ruleset#mode}
    */
    readonly mode?: string;
    /**
    * status_code_ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code_ttl Ruleset#status_code_ttl}
    */
    readonly statusCodeTtl?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersEdgeTtlToTerraform(struct?: RulesetRulesActionParametersEdgeTtl | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersEdgeTtlToHclTerraform(struct?: RulesetRulesActionParametersEdgeTtl | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersEdgeTtlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersEdgeTtl | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersEdgeTtl | cdktf.IResolvable | undefined);
    private _default?;
    get default(): number;
    set default(value: number);
    resetDefault(): void;
    get defaultInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _statusCodeTtl;
    get statusCodeTtl(): RulesetRulesActionParametersEdgeTtlStatusCodeTtlList;
    putStatusCodeTtl(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | cdktf.IResolvable): void;
    resetStatusCodeTtl(): void;
    get statusCodeTtlInput(): cdktf.IResolvable | RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | undefined;
}
export declare class RulesetRulesActionParametersEdgeTtlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersEdgeTtl[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersEdgeTtlOutputReference;
}
export interface RulesetRulesActionParametersFromListStruct {
    /**
    * Expression to use for the list lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#key Ruleset#key}
    */
    readonly key?: string;
    /**
    * Name of the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name?: string;
}
export declare function rulesetRulesActionParametersFromListStructToTerraform(struct?: RulesetRulesActionParametersFromListStruct | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersFromListStructToHclTerraform(struct?: RulesetRulesActionParametersFromListStruct | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersFromListStructOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersFromListStruct | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersFromListStruct | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class RulesetRulesActionParametersFromListStructList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersFromListStruct[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersFromListStructOutputReference;
}
export interface RulesetRulesActionParametersFromValueTargetUrl {
    /**
    * Use a value dynamically determined by the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * Static value to provide as the HTTP request header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersFromValueTargetUrlToTerraform(struct?: RulesetRulesActionParametersFromValueTargetUrl | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersFromValueTargetUrlToHclTerraform(struct?: RulesetRulesActionParametersFromValueTargetUrl | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersFromValueTargetUrlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersFromValueTargetUrl | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersFromValueTargetUrl | cdktf.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersFromValueTargetUrlList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersFromValueTargetUrl[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersFromValueTargetUrlOutputReference;
}
export interface RulesetRulesActionParametersFromValue {
    /**
    * Preserve query string for redirect URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#preserve_query_string Ruleset#preserve_query_string}
    */
    readonly preserveQueryString?: boolean | cdktf.IResolvable;
    /**
    * Status code for redirect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
    /**
    * target_url block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#target_url Ruleset#target_url}
    */
    readonly targetUrl?: RulesetRulesActionParametersFromValueTargetUrl[] | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersFromValueToTerraform(struct?: RulesetRulesActionParametersFromValue | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersFromValueToHclTerraform(struct?: RulesetRulesActionParametersFromValue | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersFromValueOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersFromValue | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersFromValue | cdktf.IResolvable | undefined);
    private _preserveQueryString?;
    get preserveQueryString(): boolean | cdktf.IResolvable;
    set preserveQueryString(value: boolean | cdktf.IResolvable);
    resetPreserveQueryString(): void;
    get preserveQueryStringInput(): boolean | cdktf.IResolvable | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _targetUrl;
    get targetUrl(): RulesetRulesActionParametersFromValueTargetUrlList;
    putTargetUrl(value: RulesetRulesActionParametersFromValueTargetUrl[] | cdktf.IResolvable): void;
    resetTargetUrl(): void;
    get targetUrlInput(): cdktf.IResolvable | RulesetRulesActionParametersFromValueTargetUrl[] | undefined;
}
export declare class RulesetRulesActionParametersFromValueList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersFromValue[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersFromValueOutputReference;
}
export interface RulesetRulesActionParametersHeaders {
    /**
    * Use a value dynamically determined by the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * Name of the HTTP request header to target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name?: string;
    /**
    * Action to perform on the HTTP request header. Available values: `remove`, `set`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation?: string;
    /**
    * Static value to provide as the HTTP request header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersHeadersToTerraform(struct?: RulesetRulesActionParametersHeaders | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersHeadersToHclTerraform(struct?: RulesetRulesActionParametersHeaders | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersHeadersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersHeaders | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersHeaders | cdktf.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    resetOperation(): void;
    get operationInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersHeadersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersHeaders[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersHeadersOutputReference;
}
export interface RulesetRulesActionParametersMatchedData {
    /**
    * Public key to use within WAF Ruleset payload logging to view the HTTP request parameters. You can generate a public key [using the `matched-data-cli` command-line tool](https://developers.cloudflare.com/waf/managed-rulesets/payload-logging/command-line/generate-key-pair) or [in the Cloudflare dashboard](https://developers.cloudflare.com/waf/managed-rulesets/payload-logging/configure).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#public_key Ruleset#public_key}
    */
    readonly publicKey?: string;
}
export declare function rulesetRulesActionParametersMatchedDataToTerraform(struct?: RulesetRulesActionParametersMatchedData | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersMatchedDataToHclTerraform(struct?: RulesetRulesActionParametersMatchedData | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersMatchedDataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersMatchedData | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersMatchedData | cdktf.IResolvable | undefined);
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    resetPublicKey(): void;
    get publicKeyInput(): string | undefined;
}
export declare class RulesetRulesActionParametersMatchedDataList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersMatchedData[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersMatchedDataOutputReference;
}
export interface RulesetRulesActionParametersOrigin {
    /**
    * Origin Hostname where request is sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#host Ruleset#host}
    */
    readonly host?: string;
    /**
    * Origin Port where request is sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#port Ruleset#port}
    */
    readonly port?: number;
}
export declare function rulesetRulesActionParametersOriginToTerraform(struct?: RulesetRulesActionParametersOrigin | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersOriginToHclTerraform(struct?: RulesetRulesActionParametersOrigin | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersOriginOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersOrigin | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOrigin | cdktf.IResolvable | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export declare class RulesetRulesActionParametersOriginList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersOrigin[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOriginOutputReference;
}
export interface RulesetRulesActionParametersOverridesCategories {
    /**
    * Action to perform in the tag-level override. Available values: `allow`, `block`, `challenge`, `ddos_dynamic`, `execute`, `force_connection_close`, `js_challenge`, `log`, `log_custom_field`, `managed_challenge`, `redirect`, `rewrite`, `route`, `score`, `set_cache_settings`, `set_config`, `serve_error`, `skip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * Tag name to apply the ruleset rule override to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#category Ruleset#category}
    */
    readonly category?: string;
    /**
    * Defines if the current tag-level override enables or disables the ruleset rules with the specified tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersOverridesCategoriesToTerraform(struct?: RulesetRulesActionParametersOverridesCategories | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersOverridesCategoriesToHclTerraform(struct?: RulesetRulesActionParametersOverridesCategories | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersOverridesCategoriesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersOverridesCategories | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOverridesCategories | cdktf.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersOverridesCategoriesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersOverridesCategories[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOverridesCategoriesOutputReference;
}
export interface RulesetRulesActionParametersOverridesRules {
    /**
    * Action to perform in the rule-level override. Available values: `allow`, `block`, `challenge`, `ddos_dynamic`, `execute`, `force_connection_close`, `js_challenge`, `log`, `log_custom_field`, `managed_challenge`, `redirect`, `rewrite`, `route`, `score`, `set_cache_settings`, `set_config`, `serve_error`, `skip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * Defines if the current rule-level override enables or disables the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Rule ID to apply the override to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#id Ruleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Anomaly score threshold to apply in the ruleset rule override. Only applicable to modsecurity-based rulesets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#score_threshold Ruleset#score_threshold}
    */
    readonly scoreThreshold?: number;
    /**
    * Sensitivity level for a ruleset rule override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#sensitivity_level Ruleset#sensitivity_level}
    */
    readonly sensitivityLevel?: string;
}
export declare function rulesetRulesActionParametersOverridesRulesToTerraform(struct?: RulesetRulesActionParametersOverridesRules | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersOverridesRulesToHclTerraform(struct?: RulesetRulesActionParametersOverridesRules | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersOverridesRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersOverridesRules | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOverridesRules | cdktf.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _scoreThreshold?;
    get scoreThreshold(): number;
    set scoreThreshold(value: number);
    resetScoreThreshold(): void;
    get scoreThresholdInput(): number | undefined;
    private _sensitivityLevel?;
    get sensitivityLevel(): string;
    set sensitivityLevel(value: string);
    resetSensitivityLevel(): void;
    get sensitivityLevelInput(): string | undefined;
}
export declare class RulesetRulesActionParametersOverridesRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersOverridesRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOverridesRulesOutputReference;
}
export interface RulesetRulesActionParametersOverrides {
    /**
    * Action to perform in the rule-level override. Available values: `allow`, `block`, `challenge`, `ddos_dynamic`, `execute`, `force_connection_close`, `js_challenge`, `log`, `log_custom_field`, `managed_challenge`, `redirect`, `rewrite`, `route`, `score`, `set_cache_settings`, `set_config`, `serve_error`, `skip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * Defines if the current ruleset-level override enables or disables the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Sensitivity level to override for all ruleset rules. Available values: `default`, `medium`, `low`, `eoff`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#sensitivity_level Ruleset#sensitivity_level}
    */
    readonly sensitivityLevel?: string;
    /**
    * categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#categories Ruleset#categories}
    */
    readonly categories?: RulesetRulesActionParametersOverridesCategories[] | cdktf.IResolvable;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#rules Ruleset#rules}
    */
    readonly rules?: RulesetRulesActionParametersOverridesRules[] | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersOverridesToTerraform(struct?: RulesetRulesActionParametersOverrides | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersOverridesToHclTerraform(struct?: RulesetRulesActionParametersOverrides | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersOverridesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersOverrides | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOverrides | cdktf.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _sensitivityLevel?;
    get sensitivityLevel(): string;
    set sensitivityLevel(value: string);
    resetSensitivityLevel(): void;
    get sensitivityLevelInput(): string | undefined;
    private _categories;
    get categories(): RulesetRulesActionParametersOverridesCategoriesList;
    putCategories(value: RulesetRulesActionParametersOverridesCategories[] | cdktf.IResolvable): void;
    resetCategories(): void;
    get categoriesInput(): cdktf.IResolvable | RulesetRulesActionParametersOverridesCategories[] | undefined;
    private _rules;
    get rules(): RulesetRulesActionParametersOverridesRulesList;
    putRules(value: RulesetRulesActionParametersOverridesRules[] | cdktf.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktf.IResolvable | RulesetRulesActionParametersOverridesRules[] | undefined;
}
export declare class RulesetRulesActionParametersOverridesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersOverrides[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOverridesOutputReference;
}
export interface RulesetRulesActionParametersResponse {
    /**
    * Body content to include in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#content Ruleset#content}
    */
    readonly content?: string;
    /**
    * HTTP content type to send in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#content_type Ruleset#content_type}
    */
    readonly contentType?: string;
    /**
    * HTTP status code to send in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
}
export declare function rulesetRulesActionParametersResponseToTerraform(struct?: RulesetRulesActionParametersResponse | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersResponseToHclTerraform(struct?: RulesetRulesActionParametersResponse | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersResponseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersResponse | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersResponse | cdktf.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
}
export declare class RulesetRulesActionParametersResponseList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersResponse[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersResponseOutputReference;
}
export interface RulesetRulesActionParametersServeStale {
    /**
    * Disable stale while updating.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#disable_stale_while_updating Ruleset#disable_stale_while_updating}
    */
    readonly disableStaleWhileUpdating?: boolean | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersServeStaleToTerraform(struct?: RulesetRulesActionParametersServeStale | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersServeStaleToHclTerraform(struct?: RulesetRulesActionParametersServeStale | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersServeStaleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersServeStale | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersServeStale | cdktf.IResolvable | undefined);
    private _disableStaleWhileUpdating?;
    get disableStaleWhileUpdating(): boolean | cdktf.IResolvable;
    set disableStaleWhileUpdating(value: boolean | cdktf.IResolvable);
    resetDisableStaleWhileUpdating(): void;
    get disableStaleWhileUpdatingInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersServeStaleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersServeStale[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersServeStaleOutputReference;
}
export interface RulesetRulesActionParametersSni {
    /**
    * Value to define for SNI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersSniToTerraform(struct?: RulesetRulesActionParametersSni | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersSniToHclTerraform(struct?: RulesetRulesActionParametersSni | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersSniOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersSni | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersSni | cdktf.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersSniList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersSni[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersSniOutputReference;
}
export interface RulesetRulesActionParametersUriPath {
    /**
    * Expression that defines the updated (dynamic) value of the URI path or query string component. Uses the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * Static string value of the updated URI path or query string component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersUriPathToTerraform(struct?: RulesetRulesActionParametersUriPath | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersUriPathToHclTerraform(struct?: RulesetRulesActionParametersUriPath | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersUriPathOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersUriPath | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersUriPath | cdktf.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersUriPathList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersUriPath[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersUriPathOutputReference;
}
export interface RulesetRulesActionParametersUriQuery {
    /**
    * Expression that defines the updated (dynamic) value of the URI path or query string component. Uses the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * Static string value of the updated URI path or query string component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersUriQueryToTerraform(struct?: RulesetRulesActionParametersUriQuery | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersUriQueryToHclTerraform(struct?: RulesetRulesActionParametersUriQuery | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersUriQueryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersUriQuery | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersUriQuery | cdktf.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersUriQueryList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersUriQuery[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersUriQueryOutputReference;
}
export interface RulesetRulesActionParametersUri {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#origin Ruleset#origin}
    */
    readonly origin?: boolean | cdktf.IResolvable;
    /**
    * path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#path Ruleset#path}
    */
    readonly path?: RulesetRulesActionParametersUriPath[] | cdktf.IResolvable;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#query Ruleset#query}
    */
    readonly query?: RulesetRulesActionParametersUriQuery[] | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersUriToTerraform(struct?: RulesetRulesActionParametersUri | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersUriToHclTerraform(struct?: RulesetRulesActionParametersUri | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersUriOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersUri | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersUri | cdktf.IResolvable | undefined);
    private _origin?;
    get origin(): boolean | cdktf.IResolvable;
    set origin(value: boolean | cdktf.IResolvable);
    resetOrigin(): void;
    get originInput(): boolean | cdktf.IResolvable | undefined;
    private _path;
    get path(): RulesetRulesActionParametersUriPathList;
    putPath(value: RulesetRulesActionParametersUriPath[] | cdktf.IResolvable): void;
    resetPath(): void;
    get pathInput(): cdktf.IResolvable | RulesetRulesActionParametersUriPath[] | undefined;
    private _query;
    get query(): RulesetRulesActionParametersUriQueryList;
    putQuery(value: RulesetRulesActionParametersUriQuery[] | cdktf.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktf.IResolvable | RulesetRulesActionParametersUriQuery[] | undefined;
}
export declare class RulesetRulesActionParametersUriList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersUri[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersUriOutputReference;
}
export interface RulesetRulesActionParameters {
    /**
    * Turn on or off Cloudflare Automatic HTTPS rewrites.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#automatic_https_rewrites Ruleset#automatic_https_rewrites}
    */
    readonly automaticHttpsRewrites?: boolean | cdktf.IResolvable;
    /**
    * Inspect the visitor's browser for headers commonly associated with spammers and certain bots.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#bic Ruleset#bic}
    */
    readonly bic?: boolean | cdktf.IResolvable;
    /**
    * Whether to cache if expression matches.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cache Ruleset#cache}
    */
    readonly cache?: boolean | cdktf.IResolvable;
    /**
    * Content of the custom error response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#content Ruleset#content}
    */
    readonly content?: string;
    /**
    * Content-Type of the custom error response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#content_type Ruleset#content_type}
    */
    readonly contentType?: string;
    /**
    * List of cookie values to include as part of custom fields logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cookie_fields Ruleset#cookie_fields}
    */
    readonly cookieFields?: string[];
    /**
    * Turn off all active Cloudflare Apps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#disable_apps Ruleset#disable_apps}
    */
    readonly disableApps?: boolean | cdktf.IResolvable;
    /**
    * Turn off railgun feature of the Cloudflare Speed app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#disable_railgun Ruleset#disable_railgun}
    */
    readonly disableRailgun?: boolean | cdktf.IResolvable;
    /**
    * Turn off zaraz feature.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#disable_zaraz Ruleset#disable_zaraz}
    */
    readonly disableZaraz?: boolean | cdktf.IResolvable;
    /**
    * Turn on or off the Cloudflare Email Obfuscation feature of the Cloudflare Scrape Shield app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#email_obfuscation Ruleset#email_obfuscation}
    */
    readonly emailObfuscation?: boolean | cdktf.IResolvable;
    /**
    * Host Header that request origin receives.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#host_header Ruleset#host_header}
    */
    readonly hostHeader?: string;
    /**
    * Turn on or off the hotlink protection feature.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#hotlink_protection Ruleset#hotlink_protection}
    */
    readonly hotlinkProtection?: boolean | cdktf.IResolvable;
    /**
    * Identifier of the action parameter to modify.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#id Ruleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#increment Ruleset#increment}
    */
    readonly increment?: number;
    /**
    * Turn on or off Cloudflare Mirage of the Cloudflare Speed app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#mirage Ruleset#mirage}
    */
    readonly mirage?: boolean | cdktf.IResolvable;
    /**
    * Turn on or off the Cloudflare Opportunistic Encryption feature of the Edge Certificates tab in the Cloudflare SSL/TLS app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#opportunistic_encryption Ruleset#opportunistic_encryption}
    */
    readonly opportunisticEncryption?: boolean | cdktf.IResolvable;
    /**
    * Pass-through error page for origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#origin_error_page_passthru Ruleset#origin_error_page_passthru}
    */
    readonly originErrorPagePassthru?: boolean | cdktf.IResolvable;
    /**
    * Point in the request/response lifecycle where the ruleset will be created. Available values: `ddos_l4`, `ddos_l7`, `http_custom_errors`, `http_log_custom_fields`, `http_request_cache_settings`, `http_request_firewall_custom`, `http_request_firewall_managed`, `http_request_late_transform`, `http_request_late_transform_managed`, `http_request_main`, `http_request_origin`, `http_request_dynamic_redirect`, `http_request_redirect`, `http_request_sanitize`, `http_request_transform`, `http_response_firewall_managed`, `http_response_headers_transform`, `http_response_headers_transform_managed`, `magic_transit`, `http_ratelimit`, `http_request_sbfm`, `http_config_settings`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#phases Ruleset#phases}
    */
    readonly phases?: string[];
    /**
    * Apply options from the Polish feature of the Cloudflare Speed app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#polish Ruleset#polish}
    */
    readonly polish?: string;
    /**
    * Products to target with the actions. Available values: `bic`, `hot`, `ratelimit`, `securityLevel`, `uablock`, `waf`, `zonelockdown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#products Ruleset#products}
    */
    readonly products?: string[];
    /**
    * List of request headers to include as part of custom fields logging, in lowercase.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#request_fields Ruleset#request_fields}
    */
    readonly requestFields?: string[];
    /**
    * Respect strong ETags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#respect_strong_etags Ruleset#respect_strong_etags}
    */
    readonly respectStrongEtags?: boolean | cdktf.IResolvable;
    /**
    * List of response headers to include as part of custom fields logging, in lowercase.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#response_fields Ruleset#response_fields}
    */
    readonly responseFields?: string[];
    /**
    * Turn on or off Cloudflare Rocket Loader in the Cloudflare Speed app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#rocket_loader Ruleset#rocket_loader}
    */
    readonly rocketLoader?: boolean | cdktf.IResolvable;
    /**
    * Map of managed WAF rule ID to comma-delimited string of ruleset rule IDs. Example: `rules = { "efb7b8c949ac4650a09736fc376e9aee" = "5de7edfa648c4d6891dc3e7f84534ffa,e3a567afc347477d9702d9047e97d760" }`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#rules Ruleset#rules}
    */
    readonly rules?: {
        [key: string]: string;
    };
    /**
    * Which ruleset ID to target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#ruleset Ruleset#ruleset}
    */
    readonly ruleset?: string;
    /**
    * List of managed WAF rule IDs to target. Only valid when the `"action"` is set to skip.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#rulesets Ruleset#rulesets}
    */
    readonly rulesets?: string[];
    /**
    * Control options for the Security Level feature from the Security app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#security_level Ruleset#security_level}
    */
    readonly securityLevel?: string;
    /**
    * Turn on or off the Server Side Excludes feature of the Cloudflare Scrape Shield app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#server_side_excludes Ruleset#server_side_excludes}
    */
    readonly serverSideExcludes?: boolean | cdktf.IResolvable;
    /**
    * Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#ssl Ruleset#ssl}
    */
    readonly ssl?: string;
    /**
    * HTTP status code of the custom error response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
    /**
    * Turn on or off the SXG feature.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#sxg Ruleset#sxg}
    */
    readonly sxg?: boolean | cdktf.IResolvable;
    /**
    * Version of the ruleset to deploy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#version Ruleset#version}
    */
    readonly version?: string;
    /**
    * autominify block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#autominify Ruleset#autominify}
    */
    readonly autominify?: RulesetRulesActionParametersAutominify[] | cdktf.IResolvable;
    /**
    * browser_ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#browser_ttl Ruleset#browser_ttl}
    */
    readonly browserTtl?: RulesetRulesActionParametersBrowserTtl[] | cdktf.IResolvable;
    /**
    * cache_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cache_key Ruleset#cache_key}
    */
    readonly cacheKey?: RulesetRulesActionParametersCacheKey[] | cdktf.IResolvable;
    /**
    * edge_ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#edge_ttl Ruleset#edge_ttl}
    */
    readonly edgeTtl?: RulesetRulesActionParametersEdgeTtl[] | cdktf.IResolvable;
    /**
    * from_list block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#from_list Ruleset#from_list}
    */
    readonly fromList?: RulesetRulesActionParametersFromListStruct[] | cdktf.IResolvable;
    /**
    * from_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#from_value Ruleset#from_value}
    */
    readonly fromValue?: RulesetRulesActionParametersFromValue[] | cdktf.IResolvable;
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#headers Ruleset#headers}
    */
    readonly headers?: RulesetRulesActionParametersHeaders[] | cdktf.IResolvable;
    /**
    * matched_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#matched_data Ruleset#matched_data}
    */
    readonly matchedData?: RulesetRulesActionParametersMatchedData[] | cdktf.IResolvable;
    /**
    * origin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#origin Ruleset#origin}
    */
    readonly origin?: RulesetRulesActionParametersOrigin[] | cdktf.IResolvable;
    /**
    * overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#overrides Ruleset#overrides}
    */
    readonly overrides?: RulesetRulesActionParametersOverrides[] | cdktf.IResolvable;
    /**
    * response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#response Ruleset#response}
    */
    readonly response?: RulesetRulesActionParametersResponse[] | cdktf.IResolvable;
    /**
    * serve_stale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#serve_stale Ruleset#serve_stale}
    */
    readonly serveStale?: RulesetRulesActionParametersServeStale[] | cdktf.IResolvable;
    /**
    * sni block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#sni Ruleset#sni}
    */
    readonly sni?: RulesetRulesActionParametersSni[] | cdktf.IResolvable;
    /**
    * uri block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#uri Ruleset#uri}
    */
    readonly uri?: RulesetRulesActionParametersUri[] | cdktf.IResolvable;
}
export declare function rulesetRulesActionParametersToTerraform(struct?: RulesetRulesActionParameters | cdktf.IResolvable): any;
export declare function rulesetRulesActionParametersToHclTerraform(struct?: RulesetRulesActionParameters | cdktf.IResolvable): any;
export declare class RulesetRulesActionParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParameters | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParameters | cdktf.IResolvable | undefined);
    private _automaticHttpsRewrites?;
    get automaticHttpsRewrites(): boolean | cdktf.IResolvable;
    set automaticHttpsRewrites(value: boolean | cdktf.IResolvable);
    resetAutomaticHttpsRewrites(): void;
    get automaticHttpsRewritesInput(): boolean | cdktf.IResolvable | undefined;
    private _bic?;
    get bic(): boolean | cdktf.IResolvable;
    set bic(value: boolean | cdktf.IResolvable);
    resetBic(): void;
    get bicInput(): boolean | cdktf.IResolvable | undefined;
    private _cache?;
    get cache(): boolean | cdktf.IResolvable;
    set cache(value: boolean | cdktf.IResolvable);
    resetCache(): void;
    get cacheInput(): boolean | cdktf.IResolvable | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _cookieFields?;
    get cookieFields(): string[];
    set cookieFields(value: string[]);
    resetCookieFields(): void;
    get cookieFieldsInput(): string[] | undefined;
    private _disableApps?;
    get disableApps(): boolean | cdktf.IResolvable;
    set disableApps(value: boolean | cdktf.IResolvable);
    resetDisableApps(): void;
    get disableAppsInput(): boolean | cdktf.IResolvable | undefined;
    private _disableRailgun?;
    get disableRailgun(): boolean | cdktf.IResolvable;
    set disableRailgun(value: boolean | cdktf.IResolvable);
    resetDisableRailgun(): void;
    get disableRailgunInput(): boolean | cdktf.IResolvable | undefined;
    private _disableZaraz?;
    get disableZaraz(): boolean | cdktf.IResolvable;
    set disableZaraz(value: boolean | cdktf.IResolvable);
    resetDisableZaraz(): void;
    get disableZarazInput(): boolean | cdktf.IResolvable | undefined;
    private _emailObfuscation?;
    get emailObfuscation(): boolean | cdktf.IResolvable;
    set emailObfuscation(value: boolean | cdktf.IResolvable);
    resetEmailObfuscation(): void;
    get emailObfuscationInput(): boolean | cdktf.IResolvable | undefined;
    private _hostHeader?;
    get hostHeader(): string;
    set hostHeader(value: string);
    resetHostHeader(): void;
    get hostHeaderInput(): string | undefined;
    private _hotlinkProtection?;
    get hotlinkProtection(): boolean | cdktf.IResolvable;
    set hotlinkProtection(value: boolean | cdktf.IResolvable);
    resetHotlinkProtection(): void;
    get hotlinkProtectionInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _increment?;
    get increment(): number;
    set increment(value: number);
    resetIncrement(): void;
    get incrementInput(): number | undefined;
    private _mirage?;
    get mirage(): boolean | cdktf.IResolvable;
    set mirage(value: boolean | cdktf.IResolvable);
    resetMirage(): void;
    get mirageInput(): boolean | cdktf.IResolvable | undefined;
    private _opportunisticEncryption?;
    get opportunisticEncryption(): boolean | cdktf.IResolvable;
    set opportunisticEncryption(value: boolean | cdktf.IResolvable);
    resetOpportunisticEncryption(): void;
    get opportunisticEncryptionInput(): boolean | cdktf.IResolvable | undefined;
    private _originErrorPagePassthru?;
    get originErrorPagePassthru(): boolean | cdktf.IResolvable;
    set originErrorPagePassthru(value: boolean | cdktf.IResolvable);
    resetOriginErrorPagePassthru(): void;
    get originErrorPagePassthruInput(): boolean | cdktf.IResolvable | undefined;
    private _phases?;
    get phases(): string[];
    set phases(value: string[]);
    resetPhases(): void;
    get phasesInput(): string[] | undefined;
    private _polish?;
    get polish(): string;
    set polish(value: string);
    resetPolish(): void;
    get polishInput(): string | undefined;
    private _products?;
    get products(): string[];
    set products(value: string[]);
    resetProducts(): void;
    get productsInput(): string[] | undefined;
    private _requestFields?;
    get requestFields(): string[];
    set requestFields(value: string[]);
    resetRequestFields(): void;
    get requestFieldsInput(): string[] | undefined;
    private _respectStrongEtags?;
    get respectStrongEtags(): boolean | cdktf.IResolvable;
    set respectStrongEtags(value: boolean | cdktf.IResolvable);
    resetRespectStrongEtags(): void;
    get respectStrongEtagsInput(): boolean | cdktf.IResolvable | undefined;
    private _responseFields?;
    get responseFields(): string[];
    set responseFields(value: string[]);
    resetResponseFields(): void;
    get responseFieldsInput(): string[] | undefined;
    private _rocketLoader?;
    get rocketLoader(): boolean | cdktf.IResolvable;
    set rocketLoader(value: boolean | cdktf.IResolvable);
    resetRocketLoader(): void;
    get rocketLoaderInput(): boolean | cdktf.IResolvable | undefined;
    private _rules?;
    get rules(): {
        [key: string]: string;
    };
    set rules(value: {
        [key: string]: string;
    });
    resetRules(): void;
    get rulesInput(): {
        [key: string]: string;
    } | undefined;
    private _ruleset?;
    get ruleset(): string;
    set ruleset(value: string);
    resetRuleset(): void;
    get rulesetInput(): string | undefined;
    private _rulesets?;
    get rulesets(): string[];
    set rulesets(value: string[]);
    resetRulesets(): void;
    get rulesetsInput(): string[] | undefined;
    private _securityLevel?;
    get securityLevel(): string;
    set securityLevel(value: string);
    resetSecurityLevel(): void;
    get securityLevelInput(): string | undefined;
    private _serverSideExcludes?;
    get serverSideExcludes(): boolean | cdktf.IResolvable;
    set serverSideExcludes(value: boolean | cdktf.IResolvable);
    resetServerSideExcludes(): void;
    get serverSideExcludesInput(): boolean | cdktf.IResolvable | undefined;
    private _ssl?;
    get ssl(): string;
    set ssl(value: string);
    resetSsl(): void;
    get sslInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _sxg?;
    get sxg(): boolean | cdktf.IResolvable;
    set sxg(value: boolean | cdktf.IResolvable);
    resetSxg(): void;
    get sxgInput(): boolean | cdktf.IResolvable | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _autominify;
    get autominify(): RulesetRulesActionParametersAutominifyList;
    putAutominify(value: RulesetRulesActionParametersAutominify[] | cdktf.IResolvable): void;
    resetAutominify(): void;
    get autominifyInput(): cdktf.IResolvable | RulesetRulesActionParametersAutominify[] | undefined;
    private _browserTtl;
    get browserTtl(): RulesetRulesActionParametersBrowserTtlList;
    putBrowserTtl(value: RulesetRulesActionParametersBrowserTtl[] | cdktf.IResolvable): void;
    resetBrowserTtl(): void;
    get browserTtlInput(): cdktf.IResolvable | RulesetRulesActionParametersBrowserTtl[] | undefined;
    private _cacheKey;
    get cacheKey(): RulesetRulesActionParametersCacheKeyList;
    putCacheKey(value: RulesetRulesActionParametersCacheKey[] | cdktf.IResolvable): void;
    resetCacheKey(): void;
    get cacheKeyInput(): cdktf.IResolvable | RulesetRulesActionParametersCacheKey[] | undefined;
    private _edgeTtl;
    get edgeTtl(): RulesetRulesActionParametersEdgeTtlList;
    putEdgeTtl(value: RulesetRulesActionParametersEdgeTtl[] | cdktf.IResolvable): void;
    resetEdgeTtl(): void;
    get edgeTtlInput(): cdktf.IResolvable | RulesetRulesActionParametersEdgeTtl[] | undefined;
    private _fromList;
    get fromList(): RulesetRulesActionParametersFromListStructList;
    putFromList(value: RulesetRulesActionParametersFromListStruct[] | cdktf.IResolvable): void;
    resetFromList(): void;
    get fromListInput(): cdktf.IResolvable | RulesetRulesActionParametersFromListStruct[] | undefined;
    private _fromValue;
    get fromValue(): RulesetRulesActionParametersFromValueList;
    putFromValue(value: RulesetRulesActionParametersFromValue[] | cdktf.IResolvable): void;
    resetFromValue(): void;
    get fromValueInput(): cdktf.IResolvable | RulesetRulesActionParametersFromValue[] | undefined;
    private _headers;
    get headers(): RulesetRulesActionParametersHeadersList;
    putHeaders(value: RulesetRulesActionParametersHeaders[] | cdktf.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktf.IResolvable | RulesetRulesActionParametersHeaders[] | undefined;
    private _matchedData;
    get matchedData(): RulesetRulesActionParametersMatchedDataList;
    putMatchedData(value: RulesetRulesActionParametersMatchedData[] | cdktf.IResolvable): void;
    resetMatchedData(): void;
    get matchedDataInput(): cdktf.IResolvable | RulesetRulesActionParametersMatchedData[] | undefined;
    private _origin;
    get origin(): RulesetRulesActionParametersOriginList;
    putOrigin(value: RulesetRulesActionParametersOrigin[] | cdktf.IResolvable): void;
    resetOrigin(): void;
    get originInput(): cdktf.IResolvable | RulesetRulesActionParametersOrigin[] | undefined;
    private _overrides;
    get overrides(): RulesetRulesActionParametersOverridesList;
    putOverrides(value: RulesetRulesActionParametersOverrides[] | cdktf.IResolvable): void;
    resetOverrides(): void;
    get overridesInput(): cdktf.IResolvable | RulesetRulesActionParametersOverrides[] | undefined;
    private _response;
    get response(): RulesetRulesActionParametersResponseList;
    putResponse(value: RulesetRulesActionParametersResponse[] | cdktf.IResolvable): void;
    resetResponse(): void;
    get responseInput(): cdktf.IResolvable | RulesetRulesActionParametersResponse[] | undefined;
    private _serveStale;
    get serveStale(): RulesetRulesActionParametersServeStaleList;
    putServeStale(value: RulesetRulesActionParametersServeStale[] | cdktf.IResolvable): void;
    resetServeStale(): void;
    get serveStaleInput(): cdktf.IResolvable | RulesetRulesActionParametersServeStale[] | undefined;
    private _sni;
    get sni(): RulesetRulesActionParametersSniList;
    putSni(value: RulesetRulesActionParametersSni[] | cdktf.IResolvable): void;
    resetSni(): void;
    get sniInput(): cdktf.IResolvable | RulesetRulesActionParametersSni[] | undefined;
    private _uri;
    get uri(): RulesetRulesActionParametersUriList;
    putUri(value: RulesetRulesActionParametersUri[] | cdktf.IResolvable): void;
    resetUri(): void;
    get uriInput(): cdktf.IResolvable | RulesetRulesActionParametersUri[] | undefined;
}
export declare class RulesetRulesActionParametersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParameters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOutputReference;
}
export interface RulesetRulesExposedCredentialCheck {
    /**
    * Firewall Rules expression language based on Wireshark display filters for where to check for the "password" value. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#password_expression Ruleset#password_expression}
    */
    readonly passwordExpression?: string;
    /**
    * Firewall Rules expression language based on Wireshark display filters for where to check for the "username" value. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#username_expression Ruleset#username_expression}
    */
    readonly usernameExpression?: string;
}
export declare function rulesetRulesExposedCredentialCheckToTerraform(struct?: RulesetRulesExposedCredentialCheck | cdktf.IResolvable): any;
export declare function rulesetRulesExposedCredentialCheckToHclTerraform(struct?: RulesetRulesExposedCredentialCheck | cdktf.IResolvable): any;
export declare class RulesetRulesExposedCredentialCheckOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesExposedCredentialCheck | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesExposedCredentialCheck | cdktf.IResolvable | undefined);
    private _passwordExpression?;
    get passwordExpression(): string;
    set passwordExpression(value: string);
    resetPasswordExpression(): void;
    get passwordExpressionInput(): string | undefined;
    private _usernameExpression?;
    get usernameExpression(): string;
    set usernameExpression(value: string);
    resetUsernameExpression(): void;
    get usernameExpressionInput(): string | undefined;
}
export declare class RulesetRulesExposedCredentialCheckList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesExposedCredentialCheck[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesExposedCredentialCheckOutputReference;
}
export interface RulesetRulesLogging {
    /**
    * Override the default logging behavior when a rule is matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
}
export declare function rulesetRulesLoggingToTerraform(struct?: RulesetRulesLogging | cdktf.IResolvable): any;
export declare function rulesetRulesLoggingToHclTerraform(struct?: RulesetRulesLogging | cdktf.IResolvable): any;
export declare class RulesetRulesLoggingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesLogging | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesLogging | cdktf.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class RulesetRulesLoggingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesLogging[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesLoggingOutputReference;
}
export interface RulesetRulesRatelimit {
    /**
    * List of parameters that define how Cloudflare tracks the request rate for this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#characteristics Ruleset#characteristics}
    */
    readonly characteristics?: string[];
    /**
    * Criteria for counting HTTP requests to trigger the Rate Limiting action. Uses the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#counting_expression Ruleset#counting_expression}
    */
    readonly countingExpression?: string;
    /**
    * Once the request rate is reached, the Rate Limiting rule blocks further requests for the period of time defined in this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#mitigation_timeout Ruleset#mitigation_timeout}
    */
    readonly mitigationTimeout?: number;
    /**
    * The period of time to consider (in seconds) when evaluating the request rate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#period Ruleset#period}
    */
    readonly period?: number;
    /**
    * The number of requests over the period of time that will trigger the Rate Limiting rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#requests_per_period Ruleset#requests_per_period}
    */
    readonly requestsPerPeriod?: number;
    /**
    * Whether to include requests to origin within the Rate Limiting count.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#requests_to_origin Ruleset#requests_to_origin}
    */
    readonly requestsToOrigin?: boolean | cdktf.IResolvable;
    /**
    * The maximum aggregate score over the period of time that will trigger Rate Limiting rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#score_per_period Ruleset#score_per_period}
    */
    readonly scorePerPeriod?: number;
    /**
    * Name of HTTP header in the response, set by the origin server, with the score for the current request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#score_response_header_name Ruleset#score_response_header_name}
    */
    readonly scoreResponseHeaderName?: string;
}
export declare function rulesetRulesRatelimitToTerraform(struct?: RulesetRulesRatelimit | cdktf.IResolvable): any;
export declare function rulesetRulesRatelimitToHclTerraform(struct?: RulesetRulesRatelimit | cdktf.IResolvable): any;
export declare class RulesetRulesRatelimitOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesRatelimit | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRulesRatelimit | cdktf.IResolvable | undefined);
    private _characteristics?;
    get characteristics(): string[];
    set characteristics(value: string[]);
    resetCharacteristics(): void;
    get characteristicsInput(): string[] | undefined;
    private _countingExpression?;
    get countingExpression(): string;
    set countingExpression(value: string);
    resetCountingExpression(): void;
    get countingExpressionInput(): string | undefined;
    private _mitigationTimeout?;
    get mitigationTimeout(): number;
    set mitigationTimeout(value: number);
    resetMitigationTimeout(): void;
    get mitigationTimeoutInput(): number | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _requestsPerPeriod?;
    get requestsPerPeriod(): number;
    set requestsPerPeriod(value: number);
    resetRequestsPerPeriod(): void;
    get requestsPerPeriodInput(): number | undefined;
    private _requestsToOrigin?;
    get requestsToOrigin(): boolean | cdktf.IResolvable;
    set requestsToOrigin(value: boolean | cdktf.IResolvable);
    resetRequestsToOrigin(): void;
    get requestsToOriginInput(): boolean | cdktf.IResolvable | undefined;
    private _scorePerPeriod?;
    get scorePerPeriod(): number;
    set scorePerPeriod(value: number);
    resetScorePerPeriod(): void;
    get scorePerPeriodInput(): number | undefined;
    private _scoreResponseHeaderName?;
    get scoreResponseHeaderName(): string;
    set scoreResponseHeaderName(value: string);
    resetScoreResponseHeaderName(): void;
    get scoreResponseHeaderNameInput(): string | undefined;
}
export declare class RulesetRulesRatelimitList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesRatelimit[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesRatelimitOutputReference;
}
export interface RulesetRules {
    /**
    * Action to perform in the ruleset rule. Available values: `allow`, `block`, `challenge`, `ddos_dynamic`, `execute`, `force_connection_close`, `js_challenge`, `log`, `log_custom_field`, `managed_challenge`, `redirect`, `rewrite`, `route`, `score`, `set_cache_settings`, `set_config`, `serve_error`, `skip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * Brief summary of the ruleset rule and its intended use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#description Ruleset#description}
    */
    readonly description?: string;
    /**
    * Whether the rule is active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Criteria for an HTTP request to trigger the ruleset rule action. Uses the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression: string;
    /**
    * Unique rule identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#id Ruleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The most recent update to this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#last_updated Ruleset#last_updated}
    */
    readonly lastUpdated?: string;
    /**
    * Rule reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#ref Ruleset#ref}
    */
    readonly ref?: string;
    /**
    * Version of the ruleset to deploy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#version Ruleset#version}
    */
    readonly version?: string;
    /**
    * action_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#action_parameters Ruleset#action_parameters}
    */
    readonly actionParameters?: RulesetRulesActionParameters[] | cdktf.IResolvable;
    /**
    * exposed_credential_check block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#exposed_credential_check Ruleset#exposed_credential_check}
    */
    readonly exposedCredentialCheck?: RulesetRulesExposedCredentialCheck[] | cdktf.IResolvable;
    /**
    * logging block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#logging Ruleset#logging}
    */
    readonly logging?: RulesetRulesLogging[] | cdktf.IResolvable;
    /**
    * ratelimit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#ratelimit Ruleset#ratelimit}
    */
    readonly ratelimit?: RulesetRulesRatelimit[] | cdktf.IResolvable;
}
export declare function rulesetRulesToTerraform(struct?: RulesetRules | cdktf.IResolvable): any;
export declare function rulesetRulesToHclTerraform(struct?: RulesetRules | cdktf.IResolvable): any;
export declare class RulesetRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRules | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRules | cdktf.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lastUpdated?;
    get lastUpdated(): string;
    set lastUpdated(value: string);
    resetLastUpdated(): void;
    get lastUpdatedInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _actionParameters;
    get actionParameters(): RulesetRulesActionParametersList;
    putActionParameters(value: RulesetRulesActionParameters[] | cdktf.IResolvable): void;
    resetActionParameters(): void;
    get actionParametersInput(): cdktf.IResolvable | RulesetRulesActionParameters[] | undefined;
    private _exposedCredentialCheck;
    get exposedCredentialCheck(): RulesetRulesExposedCredentialCheckList;
    putExposedCredentialCheck(value: RulesetRulesExposedCredentialCheck[] | cdktf.IResolvable): void;
    resetExposedCredentialCheck(): void;
    get exposedCredentialCheckInput(): cdktf.IResolvable | RulesetRulesExposedCredentialCheck[] | undefined;
    private _logging;
    get logging(): RulesetRulesLoggingList;
    putLogging(value: RulesetRulesLogging[] | cdktf.IResolvable): void;
    resetLogging(): void;
    get loggingInput(): cdktf.IResolvable | RulesetRulesLogging[] | undefined;
    private _ratelimit;
    get ratelimit(): RulesetRulesRatelimitList;
    putRatelimit(value: RulesetRulesRatelimit[] | cdktf.IResolvable): void;
    resetRatelimit(): void;
    get ratelimitInput(): cdktf.IResolvable | RulesetRulesRatelimit[] | undefined;
}
export declare class RulesetRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset cloudflare_ruleset}
*/
export declare class Ruleset extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_ruleset";
    /**
    * Generates CDKTF code for importing a Ruleset resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Ruleset to import
    * @param importFromId The id of the existing Ruleset that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Ruleset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset cloudflare_ruleset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RulesetConfig
    */
    constructor(scope: Construct, id: string, config: RulesetConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    get phaseInput(): string | undefined;
    private _shareableEntitlementName?;
    get shareableEntitlementName(): string;
    set shareableEntitlementName(value: string);
    resetShareableEntitlementName(): void;
    get shareableEntitlementNameInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _rules;
    get rules(): RulesetRulesList;
    putRules(value: RulesetRules[] | cdktf.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktf.IResolvable | RulesetRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
