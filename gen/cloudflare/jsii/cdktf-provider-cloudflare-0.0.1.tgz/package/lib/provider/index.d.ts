import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CloudflareProviderConfig {
    /**
    * Configure the base path used by the API client. Alternatively, can be configured using the `CLOUDFLARE_API_BASE_PATH` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#api_base_path CloudflareProvider#api_base_path}
    */
    readonly apiBasePath?: string;
    /**
    * Whether to print logs from the API client (using the default log library logger). Alternatively, can be configured using the `CLOUDFLARE_API_CLIENT_LOGGING` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#api_client_logging CloudflareProvider#api_client_logging}
    */
    readonly apiClientLogging?: boolean | cdktf.IResolvable;
    /**
    * Configure the hostname used by the API client. Alternatively, can be configured using the `CLOUDFLARE_API_HOSTNAME` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#api_hostname CloudflareProvider#api_hostname}
    */
    readonly apiHostname?: string;
    /**
    * The API key for operations. Alternatively, can be configured using the `CLOUDFLARE_API_KEY` environment variable. API keys are [now considered legacy by Cloudflare](https://developers.cloudflare.com/fundamentals/api/get-started/keys/#limitations), API tokens should be used instead. Must provide only one of `api_key`, `api_token`, `api_user_service_key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#api_key CloudflareProvider#api_key}
    */
    readonly apiKey?: string;
    /**
    * The API Token for operations. Alternatively, can be configured using the `CLOUDFLARE_API_TOKEN` environment variable. Must provide only one of `api_key`, `api_token`, `api_user_service_key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#api_token CloudflareProvider#api_token}
    */
    readonly apiToken?: string;
    /**
    * A special Cloudflare API key good for a restricted set of endpoints. Alternatively, can be configured using the `CLOUDFLARE_API_USER_SERVICE_KEY` environment variable. Must provide only one of `api_key`, `api_token`, `api_user_service_key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#api_user_service_key CloudflareProvider#api_user_service_key}
    */
    readonly apiUserServiceKey?: string;
    /**
    * A registered Cloudflare email address. Alternatively, can be configured using the `CLOUDFLARE_EMAIL` environment variable. Required when using `api_key`. Conflicts with `api_token`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#email CloudflareProvider#email}
    */
    readonly email?: string;
    /**
    * Maximum backoff period in seconds after failed API calls. Alternatively, can be configured using the `CLOUDFLARE_MAX_BACKOFF` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#max_backoff CloudflareProvider#max_backoff}
    */
    readonly maxBackoff?: number;
    /**
    * Minimum backoff period in seconds after failed API calls. Alternatively, can be configured using the `CLOUDFLARE_MIN_BACKOFF` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#min_backoff CloudflareProvider#min_backoff}
    */
    readonly minBackoff?: number;
    /**
    * Maximum number of retries to perform when an API request fails. Alternatively, can be configured using the `CLOUDFLARE_RETRIES` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#retries CloudflareProvider#retries}
    */
    readonly retries?: number;
    /**
    * RPS limit to apply when making calls to the API. Alternatively, can be configured using the `CLOUDFLARE_RPS` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#rps CloudflareProvider#rps}
    */
    readonly rps?: number;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#alias CloudflareProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs cloudflare}
*/
export declare class CloudflareProvider extends cdktf.TerraformProvider {
    static readonly tfResourceType = "cloudflare";
    /**
    * Generates CDKTF code for importing a CloudflareProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudflareProvider to import
    * @param importFromId The id of the existing CloudflareProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudflareProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs cloudflare} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudflareProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudflareProviderConfig);
    private _apiBasePath?;
    get apiBasePath(): string | undefined;
    set apiBasePath(value: string | undefined);
    resetApiBasePath(): void;
    get apiBasePathInput(): string | undefined;
    private _apiClientLogging?;
    get apiClientLogging(): boolean | cdktf.IResolvable | undefined;
    set apiClientLogging(value: boolean | cdktf.IResolvable | undefined);
    resetApiClientLogging(): void;
    get apiClientLoggingInput(): boolean | cdktf.IResolvable | undefined;
    private _apiHostname?;
    get apiHostname(): string | undefined;
    set apiHostname(value: string | undefined);
    resetApiHostname(): void;
    get apiHostnameInput(): string | undefined;
    private _apiKey?;
    get apiKey(): string | undefined;
    set apiKey(value: string | undefined);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _apiToken?;
    get apiToken(): string | undefined;
    set apiToken(value: string | undefined);
    resetApiToken(): void;
    get apiTokenInput(): string | undefined;
    private _apiUserServiceKey?;
    get apiUserServiceKey(): string | undefined;
    set apiUserServiceKey(value: string | undefined);
    resetApiUserServiceKey(): void;
    get apiUserServiceKeyInput(): string | undefined;
    private _email?;
    get email(): string | undefined;
    set email(value: string | undefined);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _maxBackoff?;
    get maxBackoff(): number | undefined;
    set maxBackoff(value: number | undefined);
    resetMaxBackoff(): void;
    get maxBackoffInput(): number | undefined;
    private _minBackoff?;
    get minBackoff(): number | undefined;
    set minBackoff(value: number | undefined);
    resetMinBackoff(): void;
    get minBackoffInput(): number | undefined;
    private _retries?;
    get retries(): number | undefined;
    set retries(value: number | undefined);
    resetRetries(): void;
    get retriesInput(): number | undefined;
    private _rps?;
    get rps(): number | undefined;
    set rps(value: number | undefined);
    resetRps(): void;
    get rpsInput(): number | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
