import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RateLimitConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#bypass_url_patterns RateLimit#bypass_url_patterns}
    */
    readonly bypassUrlPatterns?: string[];
    /**
    * A note that you can use to describe the reason for a rate limit. This value is sanitized and all tags are removed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#description RateLimit#description}
    */
    readonly description?: string;
    /**
    * Whether this ratelimit is currently disabled. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#disabled RateLimit#disabled}
    */
    readonly disabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#id RateLimit#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The time in seconds to count matching traffic. If the count exceeds threshold within this period the action will be performed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#period RateLimit#period}
    */
    readonly period: number;
    /**
    * The threshold that triggers the rate limit mitigations, combine with period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#threshold RateLimit#threshold}
    */
    readonly threshold: number;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#zone_id RateLimit#zone_id}
    */
    readonly zoneId: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#action RateLimit#action}
    */
    readonly action: RateLimitAction;
    /**
    * correlate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#correlate RateLimit#correlate}
    */
    readonly correlate?: RateLimitCorrelate;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#match RateLimit#match}
    */
    readonly match?: RateLimitMatch;
}
export interface RateLimitActionResponse {
    /**
    * The body to return, the content here should conform to the `content_type`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#body RateLimit#body}
    */
    readonly body: string;
    /**
    * The content-type of the body. Available values: `text/plain`, `text/xml`, `application/json`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#content_type RateLimit#content_type}
    */
    readonly contentType: string;
}
export declare function rateLimitActionResponseToTerraform(struct?: RateLimitActionResponseOutputReference | RateLimitActionResponse): any;
export declare function rateLimitActionResponseToHclTerraform(struct?: RateLimitActionResponseOutputReference | RateLimitActionResponse): any;
export declare class RateLimitActionResponseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RateLimitActionResponse | undefined;
    set internalValue(value: RateLimitActionResponse | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    get bodyInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    get contentTypeInput(): string | undefined;
}
export interface RateLimitAction {
    /**
    * The type of action to perform. Available values: `simulate`, `ban`, `challenge`, `js_challenge`, `managed_challenge`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#mode RateLimit#mode}
    */
    readonly mode: string;
    /**
    * The time in seconds as an integer to perform the mitigation action. This field is required if the `mode` is either `simulate` or `ban`. Must be the same or greater than the period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#timeout RateLimit#timeout}
    */
    readonly timeout?: number;
    /**
    * response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#response RateLimit#response}
    */
    readonly response?: RateLimitActionResponse;
}
export declare function rateLimitActionToTerraform(struct?: RateLimitActionOutputReference | RateLimitAction): any;
export declare function rateLimitActionToHclTerraform(struct?: RateLimitActionOutputReference | RateLimitAction): any;
export declare class RateLimitActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RateLimitAction | undefined;
    set internalValue(value: RateLimitAction | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _response;
    get response(): RateLimitActionResponseOutputReference;
    putResponse(value: RateLimitActionResponse): void;
    resetResponse(): void;
    get responseInput(): RateLimitActionResponse | undefined;
}
export interface RateLimitCorrelate {
    /**
    * If set to 'nat', NAT support will be enabled for rate limiting. Available values: `nat`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#by RateLimit#by}
    */
    readonly by?: string;
}
export declare function rateLimitCorrelateToTerraform(struct?: RateLimitCorrelateOutputReference | RateLimitCorrelate): any;
export declare function rateLimitCorrelateToHclTerraform(struct?: RateLimitCorrelateOutputReference | RateLimitCorrelate): any;
export declare class RateLimitCorrelateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RateLimitCorrelate | undefined;
    set internalValue(value: RateLimitCorrelate | undefined);
    private _by?;
    get by(): string;
    set by(value: string);
    resetBy(): void;
    get byInput(): string | undefined;
}
export interface RateLimitMatchRequest {
    /**
    * HTTP Methods to match traffic on. Available values: `GET`, `POST`, `PUT`, `DELETE`, `PATCH`, `HEAD`, `_ALL_`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#methods RateLimit#methods}
    */
    readonly methods?: string[];
    /**
    * HTTP schemes to match traffic on. Available values: `HTTP`, `HTTPS`, `_ALL_`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#schemes RateLimit#schemes}
    */
    readonly schemes?: string[];
    /**
    * The URL pattern to match comprised of the host and path, i.e. example.org/path. Wildcard are expanded to match applicable traffic, query strings are not matched. Use _ for all traffic to your zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#url_pattern RateLimit#url_pattern}
    */
    readonly urlPattern?: string;
}
export declare function rateLimitMatchRequestToTerraform(struct?: RateLimitMatchRequestOutputReference | RateLimitMatchRequest): any;
export declare function rateLimitMatchRequestToHclTerraform(struct?: RateLimitMatchRequestOutputReference | RateLimitMatchRequest): any;
export declare class RateLimitMatchRequestOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RateLimitMatchRequest | undefined;
    set internalValue(value: RateLimitMatchRequest | undefined);
    private _methods?;
    get methods(): string[];
    set methods(value: string[]);
    resetMethods(): void;
    get methodsInput(): string[] | undefined;
    private _schemes?;
    get schemes(): string[];
    set schemes(value: string[]);
    resetSchemes(): void;
    get schemesInput(): string[] | undefined;
    private _urlPattern?;
    get urlPattern(): string;
    set urlPattern(value: string);
    resetUrlPattern(): void;
    get urlPatternInput(): string | undefined;
}
export interface RateLimitMatchResponse {
    /**
    * List of HTTP headers maps to match the origin response on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#headers RateLimit#headers}
    */
    readonly headers?: {
        [key: string]: string;
    }[] | cdktf.IResolvable;
    /**
    * Only count traffic that has come from your origin servers. If true, cached items that Cloudflare serve will not count towards rate limiting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#origin_traffic RateLimit#origin_traffic}
    */
    readonly originTraffic?: boolean | cdktf.IResolvable;
    /**
    * HTTP Status codes, can be one, many or indicate all by not providing this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#statuses RateLimit#statuses}
    */
    readonly statuses?: number[];
}
export declare function rateLimitMatchResponseToTerraform(struct?: RateLimitMatchResponseOutputReference | RateLimitMatchResponse): any;
export declare function rateLimitMatchResponseToHclTerraform(struct?: RateLimitMatchResponseOutputReference | RateLimitMatchResponse): any;
export declare class RateLimitMatchResponseOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RateLimitMatchResponse | undefined;
    set internalValue(value: RateLimitMatchResponse | undefined);
    private _headers?;
    get headers(): {
        [key: string]: string;
    }[] | cdktf.IResolvable;
    set headers(value: {
        [key: string]: string;
    }[] | cdktf.IResolvable);
    resetHeaders(): void;
    get headersInput(): cdktf.IResolvable | {
        [key: string]: string;
    }[] | undefined;
    private _originTraffic?;
    get originTraffic(): boolean | cdktf.IResolvable;
    set originTraffic(value: boolean | cdktf.IResolvable);
    resetOriginTraffic(): void;
    get originTrafficInput(): boolean | cdktf.IResolvable | undefined;
    private _statuses?;
    get statuses(): number[];
    set statuses(value: number[]);
    resetStatuses(): void;
    get statusesInput(): number[] | undefined;
}
export interface RateLimitMatch {
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#request RateLimit#request}
    */
    readonly request?: RateLimitMatchRequest;
    /**
    * response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#response RateLimit#response}
    */
    readonly response?: RateLimitMatchResponse;
}
export declare function rateLimitMatchToTerraform(struct?: RateLimitMatchOutputReference | RateLimitMatch): any;
export declare function rateLimitMatchToHclTerraform(struct?: RateLimitMatchOutputReference | RateLimitMatch): any;
export declare class RateLimitMatchOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RateLimitMatch | undefined;
    set internalValue(value: RateLimitMatch | undefined);
    private _request;
    get request(): RateLimitMatchRequestOutputReference;
    putRequest(value: RateLimitMatchRequest): void;
    resetRequest(): void;
    get requestInput(): RateLimitMatchRequest | undefined;
    private _response;
    get response(): RateLimitMatchResponseOutputReference;
    putResponse(value: RateLimitMatchResponse): void;
    resetResponse(): void;
    get responseInput(): RateLimitMatchResponse | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit cloudflare_rate_limit}
*/
export declare class RateLimit extends cdktf.TerraformResource {
    static readonly tfResourceType = "cloudflare_rate_limit";
    /**
    * Generates CDKTF code for importing a RateLimit resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RateLimit to import
    * @param importFromId The id of the existing RateLimit that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RateLimit to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/rate_limit cloudflare_rate_limit} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RateLimitConfig
    */
    constructor(scope: Construct, id: string, config: RateLimitConfig);
    private _bypassUrlPatterns?;
    get bypassUrlPatterns(): string[];
    set bypassUrlPatterns(value: string[]);
    resetBypassUrlPatterns(): void;
    get bypassUrlPatternsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktf.IResolvable;
    set disabled(value: boolean | cdktf.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    get periodInput(): number | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _action;
    get action(): RateLimitActionOutputReference;
    putAction(value: RateLimitAction): void;
    get actionInput(): RateLimitAction | undefined;
    private _correlate;
    get correlate(): RateLimitCorrelateOutputReference;
    putCorrelate(value: RateLimitCorrelate): void;
    resetCorrelate(): void;
    get correlateInput(): RateLimitCorrelate | undefined;
    private _match;
    get match(): RateLimitMatchOutputReference;
    putMatch(value: RateLimitMatch): void;
    resetMatch(): void;
    get matchInput(): RateLimitMatch | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
