import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LoadBalancerMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#account_id LoadBalancerMonitor#account_id}
    */
    readonly accountId: string;
    /**
    * Do not validate the certificate when monitor use HTTPS.  Only valid if `type` is "http" or "https".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#allow_insecure LoadBalancerMonitor#allow_insecure}
    */
    readonly allowInsecure?: boolean | cdktn.IResolvable;
    /**
    * Free text description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#description LoadBalancerMonitor#description}
    */
    readonly description?: string;
    /**
    * A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. Only valid if `type` is "http" or "https".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#expected_body LoadBalancerMonitor#expected_body}
    */
    readonly expectedBody?: string;
    /**
    * The expected HTTP response code or code range of the health check. Eg `2xx`. Only valid and required if `type` is "http" or "https".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#expected_codes LoadBalancerMonitor#expected_codes}
    */
    readonly expectedCodes?: string;
    /**
    * Follow redirects if returned by the origin. Only valid if `type` is "http" or "https".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#follow_redirects LoadBalancerMonitor#follow_redirects}
    */
    readonly followRedirects?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#id LoadBalancerMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The interval between each health check. Shorter intervals may improve failover time, but will increase load on the origins as we check from multiple locations. Defaults to `60`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#interval LoadBalancerMonitor#interval}
    */
    readonly interval?: number;
    /**
    * The method to use for the health check.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#method LoadBalancerMonitor#method}
    */
    readonly method?: string;
    /**
    * The endpoint path to health check against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#path LoadBalancerMonitor#path}
    */
    readonly path?: string;
    /**
    * The port number to use for the healthcheck, required when creating a TCP monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#port LoadBalancerMonitor#port}
    */
    readonly port?: number;
    /**
    * Assign this monitor to emulate the specified zone while probing. Only valid if `type` is "http" or "https".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#probe_zone LoadBalancerMonitor#probe_zone}
    */
    readonly probeZone?: string;
    /**
    * The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. Defaults to `2`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#retries LoadBalancerMonitor#retries}
    */
    readonly retries?: number;
    /**
    * The timeout (in seconds) before marking the health check as failed. Defaults to `5`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#timeout LoadBalancerMonitor#timeout}
    */
    readonly timeout?: number;
    /**
    * The protocol to use for the healthcheck. Available values: `http`, `https`, `tcp`, `udp_icmp`, `icmp_ping`, `smtp`. Defaults to `http`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#type LoadBalancerMonitor#type}
    */
    readonly type?: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#header LoadBalancerMonitor#header}
    */
    readonly header?: LoadBalancerMonitorHeader[] | cdktn.IResolvable;
}
export interface LoadBalancerMonitorHeader {
    /**
    * The header name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#header LoadBalancerMonitor#header}
    */
    readonly header: string;
    /**
    * A list of values for the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#values LoadBalancerMonitor#values}
    */
    readonly values: string[];
}
export declare function loadBalancerMonitorHeaderToTerraform(struct?: LoadBalancerMonitorHeader | cdktn.IResolvable): any;
export declare function loadBalancerMonitorHeaderToHclTerraform(struct?: LoadBalancerMonitorHeader | cdktn.IResolvable): any;
export declare class LoadBalancerMonitorHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerMonitorHeader | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerMonitorHeader | cdktn.IResolvable | undefined);
    private _header?;
    get header(): string;
    set header(value: string);
    get headerInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class LoadBalancerMonitorHeaderList extends cdktn.ComplexList {
    internalValue?: LoadBalancerMonitorHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerMonitorHeaderOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor cloudflare_load_balancer_monitor}
*/
export declare class LoadBalancerMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_load_balancer_monitor";
    /**
    * Generates CDKTN code for importing a LoadBalancerMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LoadBalancerMonitor to import
    * @param importFromId The id of the existing LoadBalancerMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LoadBalancerMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_monitor cloudflare_load_balancer_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoadBalancerMonitorConfig
    */
    constructor(scope: Construct, id: string, config: LoadBalancerMonitorConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _allowInsecure?;
    get allowInsecure(): boolean | cdktn.IResolvable;
    set allowInsecure(value: boolean | cdktn.IResolvable);
    resetAllowInsecure(): void;
    get allowInsecureInput(): boolean | cdktn.IResolvable | undefined;
    get createdOn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expectedBody?;
    get expectedBody(): string;
    set expectedBody(value: string);
    resetExpectedBody(): void;
    get expectedBodyInput(): string | undefined;
    private _expectedCodes?;
    get expectedCodes(): string;
    set expectedCodes(value: string);
    resetExpectedCodes(): void;
    get expectedCodesInput(): string | undefined;
    private _followRedirects?;
    get followRedirects(): boolean | cdktn.IResolvable;
    set followRedirects(value: boolean | cdktn.IResolvable);
    resetFollowRedirects(): void;
    get followRedirectsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    get modifiedOn(): string;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _probeZone?;
    get probeZone(): string;
    set probeZone(value: string);
    resetProbeZone(): void;
    get probeZoneInput(): string | undefined;
    private _retries?;
    get retries(): number;
    set retries(value: number);
    resetRetries(): void;
    get retriesInput(): number | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _header;
    get header(): LoadBalancerMonitorHeaderList;
    putHeader(value: LoadBalancerMonitorHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | LoadBalancerMonitorHeader[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
