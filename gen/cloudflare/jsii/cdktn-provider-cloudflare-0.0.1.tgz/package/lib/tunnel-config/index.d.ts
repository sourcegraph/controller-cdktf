import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TunnelConfigAConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#account_id TunnelConfigA#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#id TunnelConfigA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Identifier of the Tunnel to target for this configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#tunnel_id TunnelConfigA#tunnel_id}
    */
    readonly tunnelId: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#config TunnelConfigA#config}
    */
    readonly config: TunnelConfigConfig;
}
export interface TunnelConfigConfigIngressRule {
    /**
    * Hostname to match the incoming request with. If the hostname matches, the request will be sent to the service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#hostname TunnelConfigA#hostname}
    */
    readonly hostname?: string;
    /**
    * Path of the incoming request. If the path matches, the request will be sent to the local service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#path TunnelConfigA#path}
    */
    readonly path?: string;
    /**
    * Name of the service to which the request will be sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#service TunnelConfigA#service}
    */
    readonly service: string;
}
export declare function tunnelConfigConfigIngressRuleToTerraform(struct?: TunnelConfigConfigIngressRule | cdktn.IResolvable): any;
export declare function tunnelConfigConfigIngressRuleToHclTerraform(struct?: TunnelConfigConfigIngressRule | cdktn.IResolvable): any;
export declare class TunnelConfigConfigIngressRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TunnelConfigConfigIngressRule | cdktn.IResolvable | undefined;
    set internalValue(value: TunnelConfigConfigIngressRule | cdktn.IResolvable | undefined);
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export declare class TunnelConfigConfigIngressRuleList extends cdktn.ComplexList {
    internalValue?: TunnelConfigConfigIngressRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TunnelConfigConfigIngressRuleOutputReference;
}
export interface TunnelConfigConfigOriginRequestIpRules {
    /**
    * Whether to allow the IP prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#allow TunnelConfigA#allow}
    */
    readonly allow?: boolean | cdktn.IResolvable;
    /**
    * Ports to use within the IP rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#ports TunnelConfigA#ports}
    */
    readonly ports?: number[];
    /**
    * IP rule prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#prefix TunnelConfigA#prefix}
    */
    readonly prefix?: string;
}
export declare function tunnelConfigConfigOriginRequestIpRulesToTerraform(struct?: TunnelConfigConfigOriginRequestIpRules | cdktn.IResolvable): any;
export declare function tunnelConfigConfigOriginRequestIpRulesToHclTerraform(struct?: TunnelConfigConfigOriginRequestIpRules | cdktn.IResolvable): any;
export declare class TunnelConfigConfigOriginRequestIpRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TunnelConfigConfigOriginRequestIpRules | cdktn.IResolvable | undefined;
    set internalValue(value: TunnelConfigConfigOriginRequestIpRules | cdktn.IResolvable | undefined);
    private _allow?;
    get allow(): boolean | cdktn.IResolvable;
    set allow(value: boolean | cdktn.IResolvable);
    resetAllow(): void;
    get allowInput(): boolean | cdktn.IResolvable | undefined;
    private _ports?;
    get ports(): number[];
    set ports(value: number[]);
    resetPorts(): void;
    get portsInput(): number[] | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
}
export declare class TunnelConfigConfigOriginRequestIpRulesList extends cdktn.ComplexList {
    internalValue?: TunnelConfigConfigOriginRequestIpRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TunnelConfigConfigOriginRequestIpRulesOutputReference;
}
export interface TunnelConfigConfigOriginRequest {
    /**
    * Runs as jump host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#bastion_mode TunnelConfigA#bastion_mode}
    */
    readonly bastionMode?: boolean | cdktn.IResolvable;
    /**
    * Path to the certificate authority (CA) for the certificate of your origin. This option should be used only if your certificate is not signed by Cloudflare. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#ca_pool TunnelConfigA#ca_pool}
    */
    readonly caPool?: string;
    /**
    * Timeout for establishing a new TCP connection to your origin server. This excludes the time taken to establish TLS, which is controlled by `tlsTimeout`. Defaults to `30s`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#connect_timeout TunnelConfigA#connect_timeout}
    */
    readonly connectTimeout?: string;
    /**
    * Disables chunked transfer encoding. Useful if you are running a Web Server Gateway Interface (WSGI) server. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#disable_chunked_encoding TunnelConfigA#disable_chunked_encoding}
    */
    readonly disableChunkedEncoding?: boolean | cdktn.IResolvable;
    /**
    * Sets the HTTP Host header on requests sent to the local service. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#http_host_header TunnelConfigA#http_host_header}
    */
    readonly httpHostHeader?: string;
    /**
    * Maximum number of idle keepalive connections between Tunnel and your origin. This does not restrict the total number of concurrent connections. Defaults to `100`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#keep_alive_connections TunnelConfigA#keep_alive_connections}
    */
    readonly keepAliveConnections?: number;
    /**
    * Timeout after which an idle keepalive connection can be discarded. Defaults to `1m30s`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#keep_alive_timeout TunnelConfigA#keep_alive_timeout}
    */
    readonly keepAliveTimeout?: string;
    /**
    * Disable the “happy eyeballs” algorithm for IPv4/IPv6 fallback if your local network has misconfigured one of the protocols. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#no_happy_eyeballs TunnelConfigA#no_happy_eyeballs}
    */
    readonly noHappyEyeballs?: boolean | cdktn.IResolvable;
    /**
    * Disables TLS verification of the certificate presented by your origin. Will allow any certificate from the origin to be accepted. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#no_tls_verify TunnelConfigA#no_tls_verify}
    */
    readonly noTlsVerify?: boolean | cdktn.IResolvable;
    /**
    * Hostname that cloudflared should expect from your origin server certificate. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#origin_server_name TunnelConfigA#origin_server_name}
    */
    readonly originServerName?: string;
    /**
    * cloudflared starts a proxy server to translate HTTP traffic into TCP when proxying, for example, SSH or RDP. This configures the listen address for that proxy. Defaults to `127.0.0.1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#proxy_address TunnelConfigA#proxy_address}
    */
    readonly proxyAddress?: string;
    /**
    * cloudflared starts a proxy server to translate HTTP traffic into TCP when proxying, for example, SSH or RDP. This configures the listen port for that proxy. If set to zero, an unused port will randomly be chosen. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#proxy_port TunnelConfigA#proxy_port}
    */
    readonly proxyPort?: number;
    /**
    * cloudflared starts a proxy server to translate HTTP traffic into TCP when proxying, for example, SSH or RDP. This configures what type of proxy will be started. Available values: `""`, `socks`. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#proxy_type TunnelConfigA#proxy_type}
    */
    readonly proxyType?: string;
    /**
    * The timeout after which a TCP keepalive packet is sent on a connection between Tunnel and the origin server. Defaults to `30s`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#tcp_keep_alive TunnelConfigA#tcp_keep_alive}
    */
    readonly tcpKeepAlive?: string;
    /**
    * Timeout for completing a TLS handshake to your origin server, if you have chosen to connect Tunnel to an HTTPS server. Defaults to `10s`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#tls_timeout TunnelConfigA#tls_timeout}
    */
    readonly tlsTimeout?: string;
    /**
    * ip_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#ip_rules TunnelConfigA#ip_rules}
    */
    readonly ipRules?: TunnelConfigConfigOriginRequestIpRules[] | cdktn.IResolvable;
}
export declare function tunnelConfigConfigOriginRequestToTerraform(struct?: TunnelConfigConfigOriginRequestOutputReference | TunnelConfigConfigOriginRequest): any;
export declare function tunnelConfigConfigOriginRequestToHclTerraform(struct?: TunnelConfigConfigOriginRequestOutputReference | TunnelConfigConfigOriginRequest): any;
export declare class TunnelConfigConfigOriginRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TunnelConfigConfigOriginRequest | undefined;
    set internalValue(value: TunnelConfigConfigOriginRequest | undefined);
    private _bastionMode?;
    get bastionMode(): boolean | cdktn.IResolvable;
    set bastionMode(value: boolean | cdktn.IResolvable);
    resetBastionMode(): void;
    get bastionModeInput(): boolean | cdktn.IResolvable | undefined;
    private _caPool?;
    get caPool(): string;
    set caPool(value: string);
    resetCaPool(): void;
    get caPoolInput(): string | undefined;
    private _connectTimeout?;
    get connectTimeout(): string;
    set connectTimeout(value: string);
    resetConnectTimeout(): void;
    get connectTimeoutInput(): string | undefined;
    private _disableChunkedEncoding?;
    get disableChunkedEncoding(): boolean | cdktn.IResolvable;
    set disableChunkedEncoding(value: boolean | cdktn.IResolvable);
    resetDisableChunkedEncoding(): void;
    get disableChunkedEncodingInput(): boolean | cdktn.IResolvable | undefined;
    private _httpHostHeader?;
    get httpHostHeader(): string;
    set httpHostHeader(value: string);
    resetHttpHostHeader(): void;
    get httpHostHeaderInput(): string | undefined;
    private _keepAliveConnections?;
    get keepAliveConnections(): number;
    set keepAliveConnections(value: number);
    resetKeepAliveConnections(): void;
    get keepAliveConnectionsInput(): number | undefined;
    private _keepAliveTimeout?;
    get keepAliveTimeout(): string;
    set keepAliveTimeout(value: string);
    resetKeepAliveTimeout(): void;
    get keepAliveTimeoutInput(): string | undefined;
    private _noHappyEyeballs?;
    get noHappyEyeballs(): boolean | cdktn.IResolvable;
    set noHappyEyeballs(value: boolean | cdktn.IResolvable);
    resetNoHappyEyeballs(): void;
    get noHappyEyeballsInput(): boolean | cdktn.IResolvable | undefined;
    private _noTlsVerify?;
    get noTlsVerify(): boolean | cdktn.IResolvable;
    set noTlsVerify(value: boolean | cdktn.IResolvable);
    resetNoTlsVerify(): void;
    get noTlsVerifyInput(): boolean | cdktn.IResolvable | undefined;
    private _originServerName?;
    get originServerName(): string;
    set originServerName(value: string);
    resetOriginServerName(): void;
    get originServerNameInput(): string | undefined;
    private _proxyAddress?;
    get proxyAddress(): string;
    set proxyAddress(value: string);
    resetProxyAddress(): void;
    get proxyAddressInput(): string | undefined;
    private _proxyPort?;
    get proxyPort(): number;
    set proxyPort(value: number);
    resetProxyPort(): void;
    get proxyPortInput(): number | undefined;
    private _proxyType?;
    get proxyType(): string;
    set proxyType(value: string);
    resetProxyType(): void;
    get proxyTypeInput(): string | undefined;
    private _tcpKeepAlive?;
    get tcpKeepAlive(): string;
    set tcpKeepAlive(value: string);
    resetTcpKeepAlive(): void;
    get tcpKeepAliveInput(): string | undefined;
    private _tlsTimeout?;
    get tlsTimeout(): string;
    set tlsTimeout(value: string);
    resetTlsTimeout(): void;
    get tlsTimeoutInput(): string | undefined;
    private _ipRules;
    get ipRules(): TunnelConfigConfigOriginRequestIpRulesList;
    putIpRules(value: TunnelConfigConfigOriginRequestIpRules[] | cdktn.IResolvable): void;
    resetIpRules(): void;
    get ipRulesInput(): cdktn.IResolvable | TunnelConfigConfigOriginRequestIpRules[] | undefined;
}
export interface TunnelConfigConfigWarpRouting {
    /**
    * Whether WARP routing is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#enabled TunnelConfigA#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function tunnelConfigConfigWarpRoutingToTerraform(struct?: TunnelConfigConfigWarpRoutingOutputReference | TunnelConfigConfigWarpRouting): any;
export declare function tunnelConfigConfigWarpRoutingToHclTerraform(struct?: TunnelConfigConfigWarpRoutingOutputReference | TunnelConfigConfigWarpRouting): any;
export declare class TunnelConfigConfigWarpRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TunnelConfigConfigWarpRouting | undefined;
    set internalValue(value: TunnelConfigConfigWarpRouting | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface TunnelConfigConfig {
    /**
    * ingress_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#ingress_rule TunnelConfigA#ingress_rule}
    */
    readonly ingressRule: TunnelConfigConfigIngressRule[] | cdktn.IResolvable;
    /**
    * origin_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#origin_request TunnelConfigA#origin_request}
    */
    readonly originRequest?: TunnelConfigConfigOriginRequest;
    /**
    * warp_routing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#warp_routing TunnelConfigA#warp_routing}
    */
    readonly warpRouting?: TunnelConfigConfigWarpRouting;
}
export declare function tunnelConfigConfigToTerraform(struct?: TunnelConfigConfigOutputReference | TunnelConfigConfig): any;
export declare function tunnelConfigConfigToHclTerraform(struct?: TunnelConfigConfigOutputReference | TunnelConfigConfig): any;
export declare class TunnelConfigConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TunnelConfigConfig | undefined;
    set internalValue(value: TunnelConfigConfig | undefined);
    private _ingressRule;
    get ingressRule(): TunnelConfigConfigIngressRuleList;
    putIngressRule(value: TunnelConfigConfigIngressRule[] | cdktn.IResolvable): void;
    get ingressRuleInput(): cdktn.IResolvable | TunnelConfigConfigIngressRule[] | undefined;
    private _originRequest;
    get originRequest(): TunnelConfigConfigOriginRequestOutputReference;
    putOriginRequest(value: TunnelConfigConfigOriginRequest): void;
    resetOriginRequest(): void;
    get originRequestInput(): TunnelConfigConfigOriginRequest | undefined;
    private _warpRouting;
    get warpRouting(): TunnelConfigConfigWarpRoutingOutputReference;
    putWarpRouting(value: TunnelConfigConfigWarpRouting): void;
    resetWarpRouting(): void;
    get warpRoutingInput(): TunnelConfigConfigWarpRouting | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config cloudflare_tunnel_config}
*/
export declare class TunnelConfigA extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_tunnel_config";
    /**
    * Generates CDKTN code for importing a TunnelConfigA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TunnelConfigA to import
    * @param importFromId The id of the existing TunnelConfigA that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TunnelConfigA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/tunnel_config cloudflare_tunnel_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TunnelConfigAConfig
    */
    constructor(scope: Construct, id: string, config: TunnelConfigAConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _tunnelId?;
    get tunnelId(): string;
    set tunnelId(value: string);
    get tunnelIdInput(): string | undefined;
    private _config;
    get config(): TunnelConfigConfigOutputReference;
    putConfig(value: TunnelConfigConfig): void;
    get configInput(): TunnelConfigConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
