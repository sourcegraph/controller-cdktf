import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DlpProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#account_id DlpProfile#account_id}
    */
    readonly accountId: string;
    /**
    * Related DLP policies will trigger when the match count exceeds the number set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#allowed_match_count DlpProfile#allowed_match_count}
    */
    readonly allowedMatchCount: number;
    /**
    * Brief summary of the profile and its intended use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#description DlpProfile#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#id DlpProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the profile. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#name DlpProfile#name}
    */
    readonly name: string;
    /**
    * The type of the profile. Available values: `custom`, `predefined`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#type DlpProfile#type}
    */
    readonly type: string;
    /**
    * entry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#entry DlpProfile#entry}
    */
    readonly entry: DlpProfileEntry[] | cdktn.IResolvable;
}
export interface DlpProfileEntryPattern {
    /**
    * The regex that defines the pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#regex DlpProfile#regex}
    */
    readonly regex: string;
    /**
    * The validation algorithm to apply with this pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#validation DlpProfile#validation}
    */
    readonly validation?: string;
}
export declare function dlpProfileEntryPatternToTerraform(struct?: DlpProfileEntryPatternOutputReference | DlpProfileEntryPattern): any;
export declare function dlpProfileEntryPatternToHclTerraform(struct?: DlpProfileEntryPatternOutputReference | DlpProfileEntryPattern): any;
export declare class DlpProfileEntryPatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DlpProfileEntryPattern | undefined;
    set internalValue(value: DlpProfileEntryPattern | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    get regexInput(): string | undefined;
    private _validation?;
    get validation(): string;
    set validation(value: string);
    resetValidation(): void;
    get validationInput(): string | undefined;
}
export interface DlpProfileEntry {
    /**
    * Whether the entry is active. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#enabled DlpProfile#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Unique entry identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#id DlpProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the entry to deploy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#name DlpProfile#name}
    */
    readonly name: string;
    /**
    * pattern block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#pattern DlpProfile#pattern}
    */
    readonly pattern?: DlpProfileEntryPattern;
}
export declare function dlpProfileEntryToTerraform(struct?: DlpProfileEntry | cdktn.IResolvable): any;
export declare function dlpProfileEntryToHclTerraform(struct?: DlpProfileEntry | cdktn.IResolvable): any;
export declare class DlpProfileEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DlpProfileEntry | cdktn.IResolvable | undefined;
    set internalValue(value: DlpProfileEntry | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pattern;
    get pattern(): DlpProfileEntryPatternOutputReference;
    putPattern(value: DlpProfileEntryPattern): void;
    resetPattern(): void;
    get patternInput(): DlpProfileEntryPattern | undefined;
}
export declare class DlpProfileEntryList extends cdktn.ComplexList {
    internalValue?: DlpProfileEntry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DlpProfileEntryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile cloudflare_dlp_profile}
*/
export declare class DlpProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_dlp_profile";
    /**
    * Generates CDKTN code for importing a DlpProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DlpProfile to import
    * @param importFromId The id of the existing DlpProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DlpProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/dlp_profile cloudflare_dlp_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DlpProfileConfig
    */
    constructor(scope: Construct, id: string, config: DlpProfileConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _allowedMatchCount?;
    get allowedMatchCount(): number;
    set allowedMatchCount(value: number);
    get allowedMatchCountInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _entry;
    get entry(): DlpProfileEntryList;
    putEntry(value: DlpProfileEntry[] | cdktn.IResolvable): void;
    get entryInput(): cdktn.IResolvable | DlpProfileEntry[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
