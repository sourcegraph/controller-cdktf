import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DeviceManagedNetworksConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_managed_networks#account_id DeviceManagedNetworks#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_managed_networks#id DeviceManagedNetworks#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Device Managed Network. Must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_managed_networks#name DeviceManagedNetworks#name}
    */
    readonly name: string;
    /**
    * The type of Device Managed Network. Available values: `tls`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_managed_networks#type DeviceManagedNetworks#type}
    */
    readonly type: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_managed_networks#config DeviceManagedNetworks#config}
    */
    readonly config: DeviceManagedNetworksConfigA;
}
export interface DeviceManagedNetworksConfigA {
    /**
    * The SHA-256 hash of the TLS certificate presented by the host found at tls_sockaddr. If absent, regular certificate verification (trusted roots, valid timestamp, etc) will be used to validate the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_managed_networks#sha256 DeviceManagedNetworks#sha256}
    */
    readonly sha256: string;
    /**
    * A network address of the form "host:port" that the WARP client will use to detect the presence of a TLS host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_managed_networks#tls_sockaddr DeviceManagedNetworks#tls_sockaddr}
    */
    readonly tlsSockaddr: string;
}
export declare function deviceManagedNetworksConfigAToTerraform(struct?: DeviceManagedNetworksConfigAOutputReference | DeviceManagedNetworksConfigA): any;
export declare function deviceManagedNetworksConfigAToHclTerraform(struct?: DeviceManagedNetworksConfigAOutputReference | DeviceManagedNetworksConfigA): any;
export declare class DeviceManagedNetworksConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DeviceManagedNetworksConfigA | undefined;
    set internalValue(value: DeviceManagedNetworksConfigA | undefined);
    private _sha256?;
    get sha256(): string;
    set sha256(value: string);
    get sha256Input(): string | undefined;
    private _tlsSockaddr?;
    get tlsSockaddr(): string;
    set tlsSockaddr(value: string);
    get tlsSockaddrInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_managed_networks cloudflare_device_managed_networks}
*/
export declare class DeviceManagedNetworks extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_device_managed_networks";
    /**
    * Generates CDKTN code for importing a DeviceManagedNetworks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DeviceManagedNetworks to import
    * @param importFromId The id of the existing DeviceManagedNetworks that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_managed_networks#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DeviceManagedNetworks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_managed_networks cloudflare_device_managed_networks} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DeviceManagedNetworksConfig
    */
    constructor(scope: Construct, id: string, config: DeviceManagedNetworksConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _config;
    get config(): DeviceManagedNetworksConfigAOutputReference;
    putConfig(value: DeviceManagedNetworksConfigA): void;
    get configInput(): DeviceManagedNetworksConfigA | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
