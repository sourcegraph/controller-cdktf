import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TeamsLocationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_location#account_id TeamsLocation#account_id}
    */
    readonly accountId: string;
    /**
    * Indicator that this is the default location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_location#client_default TeamsLocation#client_default}
    */
    readonly clientDefault?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_location#id TeamsLocation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the teams location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_location#name TeamsLocation#name}
    */
    readonly name: string;
    /**
    * networks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_location#networks TeamsLocation#networks}
    */
    readonly networks?: TeamsLocationNetworks[] | cdktn.IResolvable;
}
export interface TeamsLocationNetworks {
    /**
    * CIDR notation representation of the network IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_location#network TeamsLocation#network}
    */
    readonly network: string;
}
export declare function teamsLocationNetworksToTerraform(struct?: TeamsLocationNetworks | cdktn.IResolvable): any;
export declare function teamsLocationNetworksToHclTerraform(struct?: TeamsLocationNetworks | cdktn.IResolvable): any;
export declare class TeamsLocationNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TeamsLocationNetworks | cdktn.IResolvable | undefined;
    set internalValue(value: TeamsLocationNetworks | cdktn.IResolvable | undefined);
    get id(): string;
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
}
export declare class TeamsLocationNetworksList extends cdktn.ComplexList {
    internalValue?: TeamsLocationNetworks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TeamsLocationNetworksOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_location cloudflare_teams_location}
*/
export declare class TeamsLocation extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_teams_location";
    /**
    * Generates CDKTN code for importing a TeamsLocation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamsLocation to import
    * @param importFromId The id of the existing TeamsLocation that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_location#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamsLocation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/teams_location cloudflare_teams_location} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamsLocationConfig
    */
    constructor(scope: Construct, id: string, config: TeamsLocationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get anonymizedLogsEnabled(): cdktn.IResolvable;
    private _clientDefault?;
    get clientDefault(): boolean | cdktn.IResolvable;
    set clientDefault(value: boolean | cdktn.IResolvable);
    resetClientDefault(): void;
    get clientDefaultInput(): boolean | cdktn.IResolvable | undefined;
    get dohSubdomain(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ip(): string;
    get ipv4Destination(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyIds(): string[];
    private _networks;
    get networks(): TeamsLocationNetworksList;
    putNetworks(value: TeamsLocationNetworks[] | cdktn.IResolvable): void;
    resetNetworks(): void;
    get networksInput(): cdktn.IResolvable | TeamsLocationNetworks[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
