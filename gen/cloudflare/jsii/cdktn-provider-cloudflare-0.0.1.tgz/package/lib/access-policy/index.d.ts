import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. Conflicts with `zone_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#account_id AccessPolicy#account_id}
    */
    readonly accountId?: string;
    /**
    * The ID of the application the policy is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#application_id AccessPolicy#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#approval_required AccessPolicy#approval_required}
    */
    readonly approvalRequired?: boolean | cdktn.IResolvable;
    /**
    * Defines the action Access will take if the policy matches the user. Available values: `allow`, `deny`, `non_identity`, `bypass`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#decision AccessPolicy#decision}
    */
    readonly decision: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#id AccessPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Friendly name of the Access Policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name: string;
    /**
    * The unique precedence for policies on a single application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#precedence AccessPolicy#precedence}
    */
    readonly precedence: number;
    /**
    * The prompt to display to the user for a justification for accessing the resource. Required when using `purpose_justification_required`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#purpose_justification_prompt AccessPolicy#purpose_justification_prompt}
    */
    readonly purposeJustificationPrompt?: string;
    /**
    * Whether to prompt the user for a justification for accessing the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#purpose_justification_required AccessPolicy#purpose_justification_required}
    */
    readonly purposeJustificationRequired?: boolean | cdktn.IResolvable;
    /**
    * The zone identifier to target for the resource. Conflicts with `account_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#zone_id AccessPolicy#zone_id}
    */
    readonly zoneId?: string;
    /**
    * approval_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#approval_group AccessPolicy#approval_group}
    */
    readonly approvalGroup?: AccessPolicyApprovalGroup[] | cdktn.IResolvable;
    /**
    * exclude block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#exclude AccessPolicy#exclude}
    */
    readonly exclude?: AccessPolicyExclude[] | cdktn.IResolvable;
    /**
    * include block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#include AccessPolicy#include}
    */
    readonly include: AccessPolicyInclude[] | cdktn.IResolvable;
    /**
    * require block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#require AccessPolicy#require}
    */
    readonly require?: AccessPolicyRequire[] | cdktn.IResolvable;
}
export interface AccessPolicyApprovalGroup {
    /**
    * Number of approvals needed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#approvals_needed AccessPolicy#approvals_needed}
    */
    readonly approvalsNeeded: number;
    /**
    * List of emails to request approval from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email_addresses AccessPolicy#email_addresses}
    */
    readonly emailAddresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email_list_uuid AccessPolicy#email_list_uuid}
    */
    readonly emailListUuid?: string;
}
export declare function accessPolicyApprovalGroupToTerraform(struct?: AccessPolicyApprovalGroup | cdktn.IResolvable): any;
export declare function accessPolicyApprovalGroupToHclTerraform(struct?: AccessPolicyApprovalGroup | cdktn.IResolvable): any;
export declare class AccessPolicyApprovalGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyApprovalGroup | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyApprovalGroup | cdktn.IResolvable | undefined);
    private _approvalsNeeded?;
    get approvalsNeeded(): number;
    set approvalsNeeded(value: number);
    get approvalsNeededInput(): number | undefined;
    private _emailAddresses?;
    get emailAddresses(): string[];
    set emailAddresses(value: string[]);
    resetEmailAddresses(): void;
    get emailAddressesInput(): string[] | undefined;
    private _emailListUuid?;
    get emailListUuid(): string;
    set emailListUuid(value: string);
    resetEmailListUuid(): void;
    get emailListUuidInput(): string | undefined;
}
export declare class AccessPolicyApprovalGroupList extends cdktn.ComplexList {
    internalValue?: AccessPolicyApprovalGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyApprovalGroupOutputReference;
}
export interface AccessPolicyExcludeAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#id AccessPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyExcludeAzureToTerraform(struct?: AccessPolicyExcludeAzure | cdktn.IResolvable): any;
export declare function accessPolicyExcludeAzureToHclTerraform(struct?: AccessPolicyExcludeAzure | cdktn.IResolvable): any;
export declare class AccessPolicyExcludeAzureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExcludeAzure | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyExcludeAzure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyExcludeAzureList extends cdktn.ComplexList {
    internalValue?: AccessPolicyExcludeAzure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeAzureOutputReference;
}
export interface AccessPolicyExcludeExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#evaluate_url AccessPolicy#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#keys_url AccessPolicy#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessPolicyExcludeExternalEvaluationToTerraform(struct?: AccessPolicyExcludeExternalEvaluationOutputReference | AccessPolicyExcludeExternalEvaluation): any;
export declare function accessPolicyExcludeExternalEvaluationToHclTerraform(struct?: AccessPolicyExcludeExternalEvaluationOutputReference | AccessPolicyExcludeExternalEvaluation): any;
export declare class AccessPolicyExcludeExternalEvaluationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPolicyExcludeExternalEvaluation | undefined;
    set internalValue(value: AccessPolicyExcludeExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessPolicyExcludeGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#teams AccessPolicy#teams}
    */
    readonly teams?: string[];
}
export declare function accessPolicyExcludeGithubToTerraform(struct?: AccessPolicyExcludeGithub | cdktn.IResolvable): any;
export declare function accessPolicyExcludeGithubToHclTerraform(struct?: AccessPolicyExcludeGithub | cdktn.IResolvable): any;
export declare class AccessPolicyExcludeGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExcludeGithub | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyExcludeGithub | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessPolicyExcludeGithubList extends cdktn.ComplexList {
    internalValue?: AccessPolicyExcludeGithub[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeGithubOutputReference;
}
export interface AccessPolicyExcludeGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyExcludeGsuiteToTerraform(struct?: AccessPolicyExcludeGsuite | cdktn.IResolvable): any;
export declare function accessPolicyExcludeGsuiteToHclTerraform(struct?: AccessPolicyExcludeGsuite | cdktn.IResolvable): any;
export declare class AccessPolicyExcludeGsuiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExcludeGsuite | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyExcludeGsuite | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyExcludeGsuiteList extends cdktn.ComplexList {
    internalValue?: AccessPolicyExcludeGsuite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeGsuiteOutputReference;
}
export interface AccessPolicyExcludeOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string[];
}
export declare function accessPolicyExcludeOktaToTerraform(struct?: AccessPolicyExcludeOkta | cdktn.IResolvable): any;
export declare function accessPolicyExcludeOktaToHclTerraform(struct?: AccessPolicyExcludeOkta | cdktn.IResolvable): any;
export declare class AccessPolicyExcludeOktaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExcludeOkta | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyExcludeOkta | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessPolicyExcludeOktaList extends cdktn.ComplexList {
    internalValue?: AccessPolicyExcludeOkta[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeOktaOutputReference;
}
export interface AccessPolicyExcludeSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_name AccessPolicy#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_value AccessPolicy#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyExcludeSamlToTerraform(struct?: AccessPolicyExcludeSaml | cdktn.IResolvable): any;
export declare function accessPolicyExcludeSamlToHclTerraform(struct?: AccessPolicyExcludeSaml | cdktn.IResolvable): any;
export declare class AccessPolicyExcludeSamlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExcludeSaml | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyExcludeSaml | cdktn.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyExcludeSamlList extends cdktn.ComplexList {
    internalValue?: AccessPolicyExcludeSaml[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeSamlOutputReference;
}
export interface AccessPolicyExclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#any_valid_service_token AccessPolicy#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#auth_method AccessPolicy#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#certificate AccessPolicy#certificate}
    */
    readonly certificate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#common_name AccessPolicy#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#device_posture AccessPolicy#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email_domain AccessPolicy#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#everyone AccessPolicy#everyone}
    */
    readonly everyone?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#geo AccessPolicy#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#group AccessPolicy#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip AccessPolicy#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip_list AccessPolicy#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#login_method AccessPolicy#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#service_token AccessPolicy#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#azure AccessPolicy#azure}
    */
    readonly azure?: AccessPolicyExcludeAzure[] | cdktn.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#external_evaluation AccessPolicy#external_evaluation}
    */
    readonly externalEvaluation?: AccessPolicyExcludeExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#github AccessPolicy#github}
    */
    readonly github?: AccessPolicyExcludeGithub[] | cdktn.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#gsuite AccessPolicy#gsuite}
    */
    readonly gsuite?: AccessPolicyExcludeGsuite[] | cdktn.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#okta AccessPolicy#okta}
    */
    readonly okta?: AccessPolicyExcludeOkta[] | cdktn.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#saml AccessPolicy#saml}
    */
    readonly saml?: AccessPolicyExcludeSaml[] | cdktn.IResolvable;
}
export declare function accessPolicyExcludeToTerraform(struct?: AccessPolicyExclude | cdktn.IResolvable): any;
export declare function accessPolicyExcludeToHclTerraform(struct?: AccessPolicyExclude | cdktn.IResolvable): any;
export declare class AccessPolicyExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyExclude | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyExclude | cdktn.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktn.IResolvable;
    set anyValidServiceToken(value: boolean | cdktn.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktn.IResolvable;
    set certificate(value: boolean | cdktn.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktn.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktn.IResolvable;
    set everyone(value: boolean | cdktn.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktn.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessPolicyExcludeAzureList;
    putAzure(value: AccessPolicyExcludeAzure[] | cdktn.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktn.IResolvable | AccessPolicyExcludeAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessPolicyExcludeExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessPolicyExcludeExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessPolicyExcludeExternalEvaluation | undefined;
    private _github;
    get github(): AccessPolicyExcludeGithubList;
    putGithub(value: AccessPolicyExcludeGithub[] | cdktn.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktn.IResolvable | AccessPolicyExcludeGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessPolicyExcludeGsuiteList;
    putGsuite(value: AccessPolicyExcludeGsuite[] | cdktn.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktn.IResolvable | AccessPolicyExcludeGsuite[] | undefined;
    private _okta;
    get okta(): AccessPolicyExcludeOktaList;
    putOkta(value: AccessPolicyExcludeOkta[] | cdktn.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktn.IResolvable | AccessPolicyExcludeOkta[] | undefined;
    private _saml;
    get saml(): AccessPolicyExcludeSamlList;
    putSaml(value: AccessPolicyExcludeSaml[] | cdktn.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktn.IResolvable | AccessPolicyExcludeSaml[] | undefined;
}
export declare class AccessPolicyExcludeList extends cdktn.ComplexList {
    internalValue?: AccessPolicyExclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyExcludeOutputReference;
}
export interface AccessPolicyIncludeAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#id AccessPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyIncludeAzureToTerraform(struct?: AccessPolicyIncludeAzure | cdktn.IResolvable): any;
export declare function accessPolicyIncludeAzureToHclTerraform(struct?: AccessPolicyIncludeAzure | cdktn.IResolvable): any;
export declare class AccessPolicyIncludeAzureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyIncludeAzure | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyIncludeAzure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyIncludeAzureList extends cdktn.ComplexList {
    internalValue?: AccessPolicyIncludeAzure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeAzureOutputReference;
}
export interface AccessPolicyIncludeExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#evaluate_url AccessPolicy#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#keys_url AccessPolicy#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessPolicyIncludeExternalEvaluationToTerraform(struct?: AccessPolicyIncludeExternalEvaluationOutputReference | AccessPolicyIncludeExternalEvaluation): any;
export declare function accessPolicyIncludeExternalEvaluationToHclTerraform(struct?: AccessPolicyIncludeExternalEvaluationOutputReference | AccessPolicyIncludeExternalEvaluation): any;
export declare class AccessPolicyIncludeExternalEvaluationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPolicyIncludeExternalEvaluation | undefined;
    set internalValue(value: AccessPolicyIncludeExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessPolicyIncludeGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#teams AccessPolicy#teams}
    */
    readonly teams?: string[];
}
export declare function accessPolicyIncludeGithubToTerraform(struct?: AccessPolicyIncludeGithub | cdktn.IResolvable): any;
export declare function accessPolicyIncludeGithubToHclTerraform(struct?: AccessPolicyIncludeGithub | cdktn.IResolvable): any;
export declare class AccessPolicyIncludeGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyIncludeGithub | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyIncludeGithub | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessPolicyIncludeGithubList extends cdktn.ComplexList {
    internalValue?: AccessPolicyIncludeGithub[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeGithubOutputReference;
}
export interface AccessPolicyIncludeGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyIncludeGsuiteToTerraform(struct?: AccessPolicyIncludeGsuite | cdktn.IResolvable): any;
export declare function accessPolicyIncludeGsuiteToHclTerraform(struct?: AccessPolicyIncludeGsuite | cdktn.IResolvable): any;
export declare class AccessPolicyIncludeGsuiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyIncludeGsuite | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyIncludeGsuite | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyIncludeGsuiteList extends cdktn.ComplexList {
    internalValue?: AccessPolicyIncludeGsuite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeGsuiteOutputReference;
}
export interface AccessPolicyIncludeOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string[];
}
export declare function accessPolicyIncludeOktaToTerraform(struct?: AccessPolicyIncludeOkta | cdktn.IResolvable): any;
export declare function accessPolicyIncludeOktaToHclTerraform(struct?: AccessPolicyIncludeOkta | cdktn.IResolvable): any;
export declare class AccessPolicyIncludeOktaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyIncludeOkta | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyIncludeOkta | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessPolicyIncludeOktaList extends cdktn.ComplexList {
    internalValue?: AccessPolicyIncludeOkta[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeOktaOutputReference;
}
export interface AccessPolicyIncludeSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_name AccessPolicy#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_value AccessPolicy#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyIncludeSamlToTerraform(struct?: AccessPolicyIncludeSaml | cdktn.IResolvable): any;
export declare function accessPolicyIncludeSamlToHclTerraform(struct?: AccessPolicyIncludeSaml | cdktn.IResolvable): any;
export declare class AccessPolicyIncludeSamlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyIncludeSaml | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyIncludeSaml | cdktn.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyIncludeSamlList extends cdktn.ComplexList {
    internalValue?: AccessPolicyIncludeSaml[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeSamlOutputReference;
}
export interface AccessPolicyInclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#any_valid_service_token AccessPolicy#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#auth_method AccessPolicy#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#certificate AccessPolicy#certificate}
    */
    readonly certificate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#common_name AccessPolicy#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#device_posture AccessPolicy#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email_domain AccessPolicy#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#everyone AccessPolicy#everyone}
    */
    readonly everyone?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#geo AccessPolicy#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#group AccessPolicy#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip AccessPolicy#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip_list AccessPolicy#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#login_method AccessPolicy#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#service_token AccessPolicy#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#azure AccessPolicy#azure}
    */
    readonly azure?: AccessPolicyIncludeAzure[] | cdktn.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#external_evaluation AccessPolicy#external_evaluation}
    */
    readonly externalEvaluation?: AccessPolicyIncludeExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#github AccessPolicy#github}
    */
    readonly github?: AccessPolicyIncludeGithub[] | cdktn.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#gsuite AccessPolicy#gsuite}
    */
    readonly gsuite?: AccessPolicyIncludeGsuite[] | cdktn.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#okta AccessPolicy#okta}
    */
    readonly okta?: AccessPolicyIncludeOkta[] | cdktn.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#saml AccessPolicy#saml}
    */
    readonly saml?: AccessPolicyIncludeSaml[] | cdktn.IResolvable;
}
export declare function accessPolicyIncludeToTerraform(struct?: AccessPolicyInclude | cdktn.IResolvable): any;
export declare function accessPolicyIncludeToHclTerraform(struct?: AccessPolicyInclude | cdktn.IResolvable): any;
export declare class AccessPolicyIncludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyInclude | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyInclude | cdktn.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktn.IResolvable;
    set anyValidServiceToken(value: boolean | cdktn.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktn.IResolvable;
    set certificate(value: boolean | cdktn.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktn.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktn.IResolvable;
    set everyone(value: boolean | cdktn.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktn.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessPolicyIncludeAzureList;
    putAzure(value: AccessPolicyIncludeAzure[] | cdktn.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktn.IResolvable | AccessPolicyIncludeAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessPolicyIncludeExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessPolicyIncludeExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessPolicyIncludeExternalEvaluation | undefined;
    private _github;
    get github(): AccessPolicyIncludeGithubList;
    putGithub(value: AccessPolicyIncludeGithub[] | cdktn.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktn.IResolvable | AccessPolicyIncludeGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessPolicyIncludeGsuiteList;
    putGsuite(value: AccessPolicyIncludeGsuite[] | cdktn.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktn.IResolvable | AccessPolicyIncludeGsuite[] | undefined;
    private _okta;
    get okta(): AccessPolicyIncludeOktaList;
    putOkta(value: AccessPolicyIncludeOkta[] | cdktn.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktn.IResolvable | AccessPolicyIncludeOkta[] | undefined;
    private _saml;
    get saml(): AccessPolicyIncludeSamlList;
    putSaml(value: AccessPolicyIncludeSaml[] | cdktn.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktn.IResolvable | AccessPolicyIncludeSaml[] | undefined;
}
export declare class AccessPolicyIncludeList extends cdktn.ComplexList {
    internalValue?: AccessPolicyInclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyIncludeOutputReference;
}
export interface AccessPolicyRequireAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#id AccessPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyRequireAzureToTerraform(struct?: AccessPolicyRequireAzure | cdktn.IResolvable): any;
export declare function accessPolicyRequireAzureToHclTerraform(struct?: AccessPolicyRequireAzure | cdktn.IResolvable): any;
export declare class AccessPolicyRequireAzureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequireAzure | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequireAzure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyRequireAzureList extends cdktn.ComplexList {
    internalValue?: AccessPolicyRequireAzure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireAzureOutputReference;
}
export interface AccessPolicyRequireExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#evaluate_url AccessPolicy#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#keys_url AccessPolicy#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessPolicyRequireExternalEvaluationToTerraform(struct?: AccessPolicyRequireExternalEvaluationOutputReference | AccessPolicyRequireExternalEvaluation): any;
export declare function accessPolicyRequireExternalEvaluationToHclTerraform(struct?: AccessPolicyRequireExternalEvaluationOutputReference | AccessPolicyRequireExternalEvaluation): any;
export declare class AccessPolicyRequireExternalEvaluationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPolicyRequireExternalEvaluation | undefined;
    set internalValue(value: AccessPolicyRequireExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessPolicyRequireGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#teams AccessPolicy#teams}
    */
    readonly teams?: string[];
}
export declare function accessPolicyRequireGithubToTerraform(struct?: AccessPolicyRequireGithub | cdktn.IResolvable): any;
export declare function accessPolicyRequireGithubToHclTerraform(struct?: AccessPolicyRequireGithub | cdktn.IResolvable): any;
export declare class AccessPolicyRequireGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequireGithub | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequireGithub | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessPolicyRequireGithubList extends cdktn.ComplexList {
    internalValue?: AccessPolicyRequireGithub[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireGithubOutputReference;
}
export interface AccessPolicyRequireGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyRequireGsuiteToTerraform(struct?: AccessPolicyRequireGsuite | cdktn.IResolvable): any;
export declare function accessPolicyRequireGsuiteToHclTerraform(struct?: AccessPolicyRequireGsuite | cdktn.IResolvable): any;
export declare class AccessPolicyRequireGsuiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequireGsuite | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequireGsuite | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyRequireGsuiteList extends cdktn.ComplexList {
    internalValue?: AccessPolicyRequireGsuite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireGsuiteOutputReference;
}
export interface AccessPolicyRequireOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#name AccessPolicy#name}
    */
    readonly name?: string[];
}
export declare function accessPolicyRequireOktaToTerraform(struct?: AccessPolicyRequireOkta | cdktn.IResolvable): any;
export declare function accessPolicyRequireOktaToHclTerraform(struct?: AccessPolicyRequireOkta | cdktn.IResolvable): any;
export declare class AccessPolicyRequireOktaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequireOkta | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequireOkta | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessPolicyRequireOktaList extends cdktn.ComplexList {
    internalValue?: AccessPolicyRequireOkta[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireOktaOutputReference;
}
export interface AccessPolicyRequireSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_name AccessPolicy#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#attribute_value AccessPolicy#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#identity_provider_id AccessPolicy#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessPolicyRequireSamlToTerraform(struct?: AccessPolicyRequireSaml | cdktn.IResolvable): any;
export declare function accessPolicyRequireSamlToHclTerraform(struct?: AccessPolicyRequireSaml | cdktn.IResolvable): any;
export declare class AccessPolicyRequireSamlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequireSaml | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequireSaml | cdktn.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessPolicyRequireSamlList extends cdktn.ComplexList {
    internalValue?: AccessPolicyRequireSaml[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireSamlOutputReference;
}
export interface AccessPolicyRequire {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#any_valid_service_token AccessPolicy#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#auth_method AccessPolicy#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#certificate AccessPolicy#certificate}
    */
    readonly certificate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#common_name AccessPolicy#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#device_posture AccessPolicy#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email AccessPolicy#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#email_domain AccessPolicy#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#everyone AccessPolicy#everyone}
    */
    readonly everyone?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#geo AccessPolicy#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#group AccessPolicy#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip AccessPolicy#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#ip_list AccessPolicy#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#login_method AccessPolicy#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#service_token AccessPolicy#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#azure AccessPolicy#azure}
    */
    readonly azure?: AccessPolicyRequireAzure[] | cdktn.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#external_evaluation AccessPolicy#external_evaluation}
    */
    readonly externalEvaluation?: AccessPolicyRequireExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#github AccessPolicy#github}
    */
    readonly github?: AccessPolicyRequireGithub[] | cdktn.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#gsuite AccessPolicy#gsuite}
    */
    readonly gsuite?: AccessPolicyRequireGsuite[] | cdktn.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#okta AccessPolicy#okta}
    */
    readonly okta?: AccessPolicyRequireOkta[] | cdktn.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#saml AccessPolicy#saml}
    */
    readonly saml?: AccessPolicyRequireSaml[] | cdktn.IResolvable;
}
export declare function accessPolicyRequireToTerraform(struct?: AccessPolicyRequire | cdktn.IResolvable): any;
export declare function accessPolicyRequireToHclTerraform(struct?: AccessPolicyRequire | cdktn.IResolvable): any;
export declare class AccessPolicyRequireOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPolicyRequire | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPolicyRequire | cdktn.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktn.IResolvable;
    set anyValidServiceToken(value: boolean | cdktn.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktn.IResolvable;
    set certificate(value: boolean | cdktn.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktn.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktn.IResolvable;
    set everyone(value: boolean | cdktn.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktn.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessPolicyRequireAzureList;
    putAzure(value: AccessPolicyRequireAzure[] | cdktn.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktn.IResolvable | AccessPolicyRequireAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessPolicyRequireExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessPolicyRequireExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessPolicyRequireExternalEvaluation | undefined;
    private _github;
    get github(): AccessPolicyRequireGithubList;
    putGithub(value: AccessPolicyRequireGithub[] | cdktn.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktn.IResolvable | AccessPolicyRequireGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessPolicyRequireGsuiteList;
    putGsuite(value: AccessPolicyRequireGsuite[] | cdktn.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktn.IResolvable | AccessPolicyRequireGsuite[] | undefined;
    private _okta;
    get okta(): AccessPolicyRequireOktaList;
    putOkta(value: AccessPolicyRequireOkta[] | cdktn.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktn.IResolvable | AccessPolicyRequireOkta[] | undefined;
    private _saml;
    get saml(): AccessPolicyRequireSamlList;
    putSaml(value: AccessPolicyRequireSaml[] | cdktn.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktn.IResolvable | AccessPolicyRequireSaml[] | undefined;
}
export declare class AccessPolicyRequireList extends cdktn.ComplexList {
    internalValue?: AccessPolicyRequire[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPolicyRequireOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy cloudflare_access_policy}
*/
export declare class AccessPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_access_policy";
    /**
    * Generates CDKTN code for importing a AccessPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessPolicy to import
    * @param importFromId The id of the existing AccessPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_policy cloudflare_access_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AccessPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _approvalRequired?;
    get approvalRequired(): boolean | cdktn.IResolvable;
    set approvalRequired(value: boolean | cdktn.IResolvable);
    resetApprovalRequired(): void;
    get approvalRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _decision?;
    get decision(): string;
    set decision(value: string);
    get decisionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precedence?;
    get precedence(): number;
    set precedence(value: number);
    get precedenceInput(): number | undefined;
    private _purposeJustificationPrompt?;
    get purposeJustificationPrompt(): string;
    set purposeJustificationPrompt(value: string);
    resetPurposeJustificationPrompt(): void;
    get purposeJustificationPromptInput(): string | undefined;
    private _purposeJustificationRequired?;
    get purposeJustificationRequired(): boolean | cdktn.IResolvable;
    set purposeJustificationRequired(value: boolean | cdktn.IResolvable);
    resetPurposeJustificationRequired(): void;
    get purposeJustificationRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _approvalGroup;
    get approvalGroup(): AccessPolicyApprovalGroupList;
    putApprovalGroup(value: AccessPolicyApprovalGroup[] | cdktn.IResolvable): void;
    resetApprovalGroup(): void;
    get approvalGroupInput(): cdktn.IResolvable | AccessPolicyApprovalGroup[] | undefined;
    private _exclude;
    get exclude(): AccessPolicyExcludeList;
    putExclude(value: AccessPolicyExclude[] | cdktn.IResolvable): void;
    resetExclude(): void;
    get excludeInput(): cdktn.IResolvable | AccessPolicyExclude[] | undefined;
    private _include;
    get include(): AccessPolicyIncludeList;
    putInclude(value: AccessPolicyInclude[] | cdktn.IResolvable): void;
    get includeInput(): cdktn.IResolvable | AccessPolicyInclude[] | undefined;
    private _require;
    get require(): AccessPolicyRequireList;
    putRequire(value: AccessPolicyRequire[] | cdktn.IResolvable): void;
    resetRequire(): void;
    get requireInput(): cdktn.IResolvable | AccessPolicyRequire[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
