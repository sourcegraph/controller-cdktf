import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareLoadBalancerPoolsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the datasource lookups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/load_balancer_pools#account_id DataCloudflareLoadBalancerPools#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/load_balancer_pools#id DataCloudflareLoadBalancerPools#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/load_balancer_pools#filter DataCloudflareLoadBalancerPools#filter}
    */
    readonly filter?: DataCloudflareLoadBalancerPoolsFilter;
    /**
    * pools block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/load_balancer_pools#pools DataCloudflareLoadBalancerPools#pools}
    */
    readonly pools?: DataCloudflareLoadBalancerPoolsPools[] | cdktn.IResolvable;
}
export interface DataCloudflareLoadBalancerPoolsFilter {
    /**
    * A regular expression matching the name of the Load Balancer pool to lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/load_balancer_pools#name DataCloudflareLoadBalancerPools#name}
    */
    readonly name?: string;
}
export declare function dataCloudflareLoadBalancerPoolsFilterToTerraform(struct?: DataCloudflareLoadBalancerPoolsFilterOutputReference | DataCloudflareLoadBalancerPoolsFilter): any;
export declare function dataCloudflareLoadBalancerPoolsFilterToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsFilterOutputReference | DataCloudflareLoadBalancerPoolsFilter): any;
export declare class DataCloudflareLoadBalancerPoolsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerPoolsFilter | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsFilter | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface DataCloudflareLoadBalancerPoolsPoolsLoadShedding {
}
export declare function dataCloudflareLoadBalancerPoolsPoolsLoadSheddingToTerraform(struct?: DataCloudflareLoadBalancerPoolsPoolsLoadShedding): any;
export declare function dataCloudflareLoadBalancerPoolsPoolsLoadSheddingToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsPoolsLoadShedding): any;
export declare class DataCloudflareLoadBalancerPoolsPoolsLoadSheddingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerPoolsPoolsLoadShedding | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsPoolsLoadShedding | undefined);
    get defaultPercent(): number;
    get defaultPolicy(): string;
    get sessionPercent(): number;
    get sessionPolicy(): string;
}
export declare class DataCloudflareLoadBalancerPoolsPoolsLoadSheddingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerPoolsPoolsLoadSheddingOutputReference;
}
export interface DataCloudflareLoadBalancerPoolsPoolsOriginsHeader {
}
export declare function dataCloudflareLoadBalancerPoolsPoolsOriginsHeaderToTerraform(struct?: DataCloudflareLoadBalancerPoolsPoolsOriginsHeader): any;
export declare function dataCloudflareLoadBalancerPoolsPoolsOriginsHeaderToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsPoolsOriginsHeader): any;
export declare class DataCloudflareLoadBalancerPoolsPoolsOriginsHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerPoolsPoolsOriginsHeader | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsPoolsOriginsHeader | undefined);
    get header(): string;
    get values(): string[];
}
export declare class DataCloudflareLoadBalancerPoolsPoolsOriginsHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerPoolsPoolsOriginsHeaderOutputReference;
}
export interface DataCloudflareLoadBalancerPoolsPoolsOrigins {
}
export declare function dataCloudflareLoadBalancerPoolsPoolsOriginsToTerraform(struct?: DataCloudflareLoadBalancerPoolsPoolsOrigins): any;
export declare function dataCloudflareLoadBalancerPoolsPoolsOriginsToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsPoolsOrigins): any;
export declare class DataCloudflareLoadBalancerPoolsPoolsOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerPoolsPoolsOrigins | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsPoolsOrigins | undefined);
    get address(): string;
    get enabled(): cdktn.IResolvable;
    private _header;
    get header(): DataCloudflareLoadBalancerPoolsPoolsOriginsHeaderList;
    get name(): string;
    get weight(): number;
}
export declare class DataCloudflareLoadBalancerPoolsPoolsOriginsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerPoolsPoolsOriginsOutputReference;
}
export interface DataCloudflareLoadBalancerPoolsPools {
}
export declare function dataCloudflareLoadBalancerPoolsPoolsToTerraform(struct?: DataCloudflareLoadBalancerPoolsPools | cdktn.IResolvable): any;
export declare function dataCloudflareLoadBalancerPoolsPoolsToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsPools | cdktn.IResolvable): any;
export declare class DataCloudflareLoadBalancerPoolsPoolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerPoolsPools | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsPools | cdktn.IResolvable | undefined);
    get checkRegions(): string[];
    get createdOn(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get latitude(): number;
    private _loadShedding;
    get loadShedding(): DataCloudflareLoadBalancerPoolsPoolsLoadSheddingList;
    get longitude(): number;
    get minimumOrigins(): number;
    get modifiedOn(): string;
    get monitor(): string;
    get name(): string;
    get notificationEmail(): string;
    private _origins;
    get origins(): DataCloudflareLoadBalancerPoolsPoolsOriginsList;
}
export declare class DataCloudflareLoadBalancerPoolsPoolsList extends cdktn.ComplexList {
    internalValue?: DataCloudflareLoadBalancerPoolsPools[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerPoolsPoolsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/load_balancer_pools cloudflare_load_balancer_pools}
*/
export declare class DataCloudflareLoadBalancerPools extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_load_balancer_pools";
    /**
    * Generates CDKTN code for importing a DataCloudflareLoadBalancerPools resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareLoadBalancerPools to import
    * @param importFromId The id of the existing DataCloudflareLoadBalancerPools that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/load_balancer_pools#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareLoadBalancerPools to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/data-sources/load_balancer_pools cloudflare_load_balancer_pools} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareLoadBalancerPoolsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareLoadBalancerPoolsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _filter;
    get filter(): DataCloudflareLoadBalancerPoolsFilterOutputReference;
    putFilter(value: DataCloudflareLoadBalancerPoolsFilter): void;
    resetFilter(): void;
    get filterInput(): DataCloudflareLoadBalancerPoolsFilter | undefined;
    private _pools;
    get pools(): DataCloudflareLoadBalancerPoolsPoolsList;
    putPools(value: DataCloudflareLoadBalancerPoolsPools[] | cdktn.IResolvable): void;
    resetPools(): void;
    get poolsInput(): cdktn.IResolvable | DataCloudflareLoadBalancerPoolsPools[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
