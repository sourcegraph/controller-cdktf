import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessIdentityProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. Conflicts with `zone_id`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#account_id AccessIdentityProvider#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#id AccessIdentityProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Friendly name of the Access Identity Provider configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#name AccessIdentityProvider#name}
    */
    readonly name: string;
    /**
    * The provider type to use. Available values: `centrify`, `facebook`, `google-apps`, `oidc`, `github`, `google`, `saml`, `linkedin`, `azureAD`, `okta`, `onetimepin`, `onelogin`, `yandex`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#type AccessIdentityProvider#type}
    */
    readonly type: string;
    /**
    * The zone identifier to target for the resource. Conflicts with `account_id`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#zone_id AccessIdentityProvider#zone_id}
    */
    readonly zoneId?: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#config AccessIdentityProvider#config}
    */
    readonly config?: AccessIdentityProviderConfigA[] | cdktn.IResolvable;
    /**
    * scim_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#scim_config AccessIdentityProvider#scim_config}
    */
    readonly scimConfig?: AccessIdentityProviderScimConfig[] | cdktn.IResolvable;
}
export interface AccessIdentityProviderConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#api_token AccessIdentityProvider#api_token}
    */
    readonly apiToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#apps_domain AccessIdentityProvider#apps_domain}
    */
    readonly appsDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#attributes AccessIdentityProvider#attributes}
    */
    readonly attributes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#auth_url AccessIdentityProvider#auth_url}
    */
    readonly authUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#centrify_account AccessIdentityProvider#centrify_account}
    */
    readonly centrifyAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#centrify_app_id AccessIdentityProvider#centrify_app_id}
    */
    readonly centrifyAppId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#certs_url AccessIdentityProvider#certs_url}
    */
    readonly certsUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#claims AccessIdentityProvider#claims}
    */
    readonly claims?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#client_id AccessIdentityProvider#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#client_secret AccessIdentityProvider#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#directory_id AccessIdentityProvider#directory_id}
    */
    readonly directoryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#email_attribute_name AccessIdentityProvider#email_attribute_name}
    */
    readonly emailAttributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#idp_public_cert AccessIdentityProvider#idp_public_cert}
    */
    readonly idpPublicCert?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#issuer_url AccessIdentityProvider#issuer_url}
    */
    readonly issuerUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#okta_account AccessIdentityProvider#okta_account}
    */
    readonly oktaAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#onelogin_account AccessIdentityProvider#onelogin_account}
    */
    readonly oneloginAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#pkce_enabled AccessIdentityProvider#pkce_enabled}
    */
    readonly pkceEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#redirect_url AccessIdentityProvider#redirect_url}
    */
    readonly redirectUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#scopes AccessIdentityProvider#scopes}
    */
    readonly scopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#sign_request AccessIdentityProvider#sign_request}
    */
    readonly signRequest?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#sso_target_url AccessIdentityProvider#sso_target_url}
    */
    readonly ssoTargetUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#support_groups AccessIdentityProvider#support_groups}
    */
    readonly supportGroups?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#token_url AccessIdentityProvider#token_url}
    */
    readonly tokenUrl?: string;
}
export declare function accessIdentityProviderConfigAToTerraform(struct?: AccessIdentityProviderConfigA | cdktn.IResolvable): any;
export declare function accessIdentityProviderConfigAToHclTerraform(struct?: AccessIdentityProviderConfigA | cdktn.IResolvable): any;
export declare class AccessIdentityProviderConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessIdentityProviderConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: AccessIdentityProviderConfigA | cdktn.IResolvable | undefined);
    private _apiToken?;
    get apiToken(): string;
    set apiToken(value: string);
    resetApiToken(): void;
    get apiTokenInput(): string | undefined;
    private _appsDomain?;
    get appsDomain(): string;
    set appsDomain(value: string);
    resetAppsDomain(): void;
    get appsDomainInput(): string | undefined;
    private _attributes?;
    get attributes(): string[];
    set attributes(value: string[]);
    resetAttributes(): void;
    get attributesInput(): string[] | undefined;
    private _authUrl?;
    get authUrl(): string;
    set authUrl(value: string);
    resetAuthUrl(): void;
    get authUrlInput(): string | undefined;
    private _centrifyAccount?;
    get centrifyAccount(): string;
    set centrifyAccount(value: string);
    resetCentrifyAccount(): void;
    get centrifyAccountInput(): string | undefined;
    private _centrifyAppId?;
    get centrifyAppId(): string;
    set centrifyAppId(value: string);
    resetCentrifyAppId(): void;
    get centrifyAppIdInput(): string | undefined;
    private _certsUrl?;
    get certsUrl(): string;
    set certsUrl(value: string);
    resetCertsUrl(): void;
    get certsUrlInput(): string | undefined;
    private _claims?;
    get claims(): string[];
    set claims(value: string[]);
    resetClaims(): void;
    get claimsInput(): string[] | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    resetDirectoryId(): void;
    get directoryIdInput(): string | undefined;
    private _emailAttributeName?;
    get emailAttributeName(): string;
    set emailAttributeName(value: string);
    resetEmailAttributeName(): void;
    get emailAttributeNameInput(): string | undefined;
    private _idpPublicCert?;
    get idpPublicCert(): string;
    set idpPublicCert(value: string);
    resetIdpPublicCert(): void;
    get idpPublicCertInput(): string | undefined;
    private _issuerUrl?;
    get issuerUrl(): string;
    set issuerUrl(value: string);
    resetIssuerUrl(): void;
    get issuerUrlInput(): string | undefined;
    private _oktaAccount?;
    get oktaAccount(): string;
    set oktaAccount(value: string);
    resetOktaAccount(): void;
    get oktaAccountInput(): string | undefined;
    private _oneloginAccount?;
    get oneloginAccount(): string;
    set oneloginAccount(value: string);
    resetOneloginAccount(): void;
    get oneloginAccountInput(): string | undefined;
    private _pkceEnabled?;
    get pkceEnabled(): boolean | cdktn.IResolvable;
    set pkceEnabled(value: boolean | cdktn.IResolvable);
    resetPkceEnabled(): void;
    get pkceEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _redirectUrl?;
    get redirectUrl(): string;
    set redirectUrl(value: string);
    resetRedirectUrl(): void;
    get redirectUrlInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _signRequest?;
    get signRequest(): boolean | cdktn.IResolvable;
    set signRequest(value: boolean | cdktn.IResolvable);
    resetSignRequest(): void;
    get signRequestInput(): boolean | cdktn.IResolvable | undefined;
    private _ssoTargetUrl?;
    get ssoTargetUrl(): string;
    set ssoTargetUrl(value: string);
    resetSsoTargetUrl(): void;
    get ssoTargetUrlInput(): string | undefined;
    private _supportGroups?;
    get supportGroups(): boolean | cdktn.IResolvable;
    set supportGroups(value: boolean | cdktn.IResolvable);
    resetSupportGroups(): void;
    get supportGroupsInput(): boolean | cdktn.IResolvable | undefined;
    private _tokenUrl?;
    get tokenUrl(): string;
    set tokenUrl(value: string);
    resetTokenUrl(): void;
    get tokenUrlInput(): string | undefined;
}
export declare class AccessIdentityProviderConfigAList extends cdktn.ComplexList {
    internalValue?: AccessIdentityProviderConfigA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessIdentityProviderConfigAOutputReference;
}
export interface AccessIdentityProviderScimConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#enabled AccessIdentityProvider#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#group_member_deprovision AccessIdentityProvider#group_member_deprovision}
    */
    readonly groupMemberDeprovision?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#seat_deprovision AccessIdentityProvider#seat_deprovision}
    */
    readonly seatDeprovision?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#secret AccessIdentityProvider#secret}
    */
    readonly secret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#user_deprovision AccessIdentityProvider#user_deprovision}
    */
    readonly userDeprovision?: boolean | cdktn.IResolvable;
}
export declare function accessIdentityProviderScimConfigToTerraform(struct?: AccessIdentityProviderScimConfig | cdktn.IResolvable): any;
export declare function accessIdentityProviderScimConfigToHclTerraform(struct?: AccessIdentityProviderScimConfig | cdktn.IResolvable): any;
export declare class AccessIdentityProviderScimConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessIdentityProviderScimConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AccessIdentityProviderScimConfig | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _groupMemberDeprovision?;
    get groupMemberDeprovision(): boolean | cdktn.IResolvable;
    set groupMemberDeprovision(value: boolean | cdktn.IResolvable);
    resetGroupMemberDeprovision(): void;
    get groupMemberDeprovisionInput(): boolean | cdktn.IResolvable | undefined;
    private _seatDeprovision?;
    get seatDeprovision(): boolean | cdktn.IResolvable;
    set seatDeprovision(value: boolean | cdktn.IResolvable);
    resetSeatDeprovision(): void;
    get seatDeprovisionInput(): boolean | cdktn.IResolvable | undefined;
    private _secret?;
    get secret(): string;
    set secret(value: string);
    resetSecret(): void;
    get secretInput(): string | undefined;
    private _userDeprovision?;
    get userDeprovision(): boolean | cdktn.IResolvable;
    set userDeprovision(value: boolean | cdktn.IResolvable);
    resetUserDeprovision(): void;
    get userDeprovisionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class AccessIdentityProviderScimConfigList extends cdktn.ComplexList {
    internalValue?: AccessIdentityProviderScimConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessIdentityProviderScimConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider cloudflare_access_identity_provider}
*/
export declare class AccessIdentityProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_access_identity_provider";
    /**
    * Generates CDKTN code for importing a AccessIdentityProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessIdentityProvider to import
    * @param importFromId The id of the existing AccessIdentityProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessIdentityProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_identity_provider cloudflare_access_identity_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessIdentityProviderConfig
    */
    constructor(scope: Construct, id: string, config: AccessIdentityProviderConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _config;
    get config(): AccessIdentityProviderConfigAList;
    putConfig(value: AccessIdentityProviderConfigA[] | cdktn.IResolvable): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | AccessIdentityProviderConfigA[] | undefined;
    private _scimConfig;
    get scimConfig(): AccessIdentityProviderScimConfigList;
    putScimConfig(value: AccessIdentityProviderScimConfig[] | cdktn.IResolvable): void;
    resetScimConfig(): void;
    get scimConfigInput(): cdktn.IResolvable | AccessIdentityProviderScimConfig[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
