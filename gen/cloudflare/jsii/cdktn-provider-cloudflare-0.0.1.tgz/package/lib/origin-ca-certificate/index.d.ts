import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OriginCaCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Certificate Signing Request. Must be newline-encoded. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/origin_ca_certificate#csr OriginCaCertificate#csr}
    */
    readonly csr?: string;
    /**
    * A list of hostnames or wildcard names bound to the certificate. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/origin_ca_certificate#hostnames OriginCaCertificate#hostnames}
    */
    readonly hostnames: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/origin_ca_certificate#id OriginCaCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Number of days prior to the expiry to trigger a renewal of the certificate if a Terraform operation is run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/origin_ca_certificate#min_days_for_renewal OriginCaCertificate#min_days_for_renewal}
    */
    readonly minDaysForRenewal?: number;
    /**
    * The signature type desired on the certificate. Available values: `origin-rsa`, `origin-ecc`, `keyless-certificate`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/origin_ca_certificate#request_type OriginCaCertificate#request_type}
    */
    readonly requestType: string;
    /**
    * The number of days for which the certificate should be valid. Available values: `7`, `30`, `90`, `365`, `730`, `1095`, `5475`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/origin_ca_certificate#requested_validity OriginCaCertificate#requested_validity}
    */
    readonly requestedValidity?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/origin_ca_certificate cloudflare_origin_ca_certificate}
*/
export declare class OriginCaCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_origin_ca_certificate";
    /**
    * Generates CDKTN code for importing a OriginCaCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OriginCaCertificate to import
    * @param importFromId The id of the existing OriginCaCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/origin_ca_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OriginCaCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/origin_ca_certificate cloudflare_origin_ca_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OriginCaCertificateConfig
    */
    constructor(scope: Construct, id: string, config: OriginCaCertificateConfig);
    get certificate(): string;
    private _csr?;
    get csr(): string;
    set csr(value: string);
    resetCsr(): void;
    get csrInput(): string | undefined;
    get expiresOn(): string;
    private _hostnames?;
    get hostnames(): string[];
    set hostnames(value: string[]);
    get hostnamesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _minDaysForRenewal?;
    get minDaysForRenewal(): number;
    set minDaysForRenewal(value: number);
    resetMinDaysForRenewal(): void;
    get minDaysForRenewalInput(): number | undefined;
    private _requestType?;
    get requestType(): string;
    set requestType(value: string);
    get requestTypeInput(): string | undefined;
    private _requestedValidity?;
    get requestedValidity(): number;
    set requestedValidity(value: number);
    resetRequestedValidity(): void;
    get requestedValidityInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
