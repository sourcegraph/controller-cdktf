import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PagesProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#account_id PagesProject#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#id PagesProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the project. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#name PagesProject#name}
    */
    readonly name: string;
    /**
    * The name of the branch that is used for the production environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#production_branch PagesProject#production_branch}
    */
    readonly productionBranch: string;
    /**
    * build_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#build_config PagesProject#build_config}
    */
    readonly buildConfig?: PagesProjectBuildConfig;
    /**
    * deployment_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#deployment_configs PagesProject#deployment_configs}
    */
    readonly deploymentConfigs?: PagesProjectDeploymentConfigs;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#source PagesProject#source}
    */
    readonly source?: PagesProjectSource;
}
export interface PagesProjectBuildConfig {
    /**
    * Command used to build project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#build_command PagesProject#build_command}
    */
    readonly buildCommand?: string;
    /**
    * Output directory of the build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#destination_dir PagesProject#destination_dir}
    */
    readonly destinationDir?: string;
    /**
    * Directory to run the command.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#root_dir PagesProject#root_dir}
    */
    readonly rootDir?: string;
    /**
    * The classifying tag for analytics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#web_analytics_tag PagesProject#web_analytics_tag}
    */
    readonly webAnalyticsTag?: string;
    /**
    * The auth token for analytics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#web_analytics_token PagesProject#web_analytics_token}
    */
    readonly webAnalyticsToken?: string;
}
export declare function pagesProjectBuildConfigToTerraform(struct?: PagesProjectBuildConfigOutputReference | PagesProjectBuildConfig): any;
export declare function pagesProjectBuildConfigToHclTerraform(struct?: PagesProjectBuildConfigOutputReference | PagesProjectBuildConfig): any;
export declare class PagesProjectBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectBuildConfig | undefined;
    set internalValue(value: PagesProjectBuildConfig | undefined);
    private _buildCommand?;
    get buildCommand(): string;
    set buildCommand(value: string);
    resetBuildCommand(): void;
    get buildCommandInput(): string | undefined;
    private _destinationDir?;
    get destinationDir(): string;
    set destinationDir(value: string);
    resetDestinationDir(): void;
    get destinationDirInput(): string | undefined;
    private _rootDir?;
    get rootDir(): string;
    set rootDir(value: string);
    resetRootDir(): void;
    get rootDirInput(): string | undefined;
    private _webAnalyticsTag?;
    get webAnalyticsTag(): string;
    set webAnalyticsTag(value: string);
    resetWebAnalyticsTag(): void;
    get webAnalyticsTagInput(): string | undefined;
    private _webAnalyticsToken?;
    get webAnalyticsToken(): string;
    set webAnalyticsToken(value: string);
    resetWebAnalyticsToken(): void;
    get webAnalyticsTokenInput(): string | undefined;
}
export interface PagesProjectDeploymentConfigsPreviewServiceBinding {
    /**
    * The name of the Worker environment to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#environment PagesProject#environment}
    */
    readonly environment?: string;
    /**
    * The global variable for the binding in your Worker code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#name PagesProject#name}
    */
    readonly name: string;
    /**
    * The name of the Worker to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#service PagesProject#service}
    */
    readonly service: string;
}
export declare function pagesProjectDeploymentConfigsPreviewServiceBindingToTerraform(struct?: PagesProjectDeploymentConfigsPreviewServiceBinding | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewServiceBindingToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewServiceBinding | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewServiceBindingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PagesProjectDeploymentConfigsPreviewServiceBinding | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewServiceBinding | cdktn.IResolvable | undefined);
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewServiceBindingList extends cdktn.ComplexList {
    internalValue?: PagesProjectDeploymentConfigsPreviewServiceBinding[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PagesProjectDeploymentConfigsPreviewServiceBindingOutputReference;
}
export interface PagesProjectDeploymentConfigsPreview {
    /**
    * Use latest compatibility date for Pages Functions. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#always_use_latest_compatibility_date PagesProject#always_use_latest_compatibility_date}
    */
    readonly alwaysUseLatestCompatibilityDate?: boolean | cdktn.IResolvable;
    /**
    * Compatibility date used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#compatibility_date PagesProject#compatibility_date}
    */
    readonly compatibilityDate?: string;
    /**
    * Compatibility flags used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#compatibility_flags PagesProject#compatibility_flags}
    */
    readonly compatibilityFlags?: string[];
    /**
    * D1 Databases used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#d1_databases PagesProject#d1_databases}
    */
    readonly d1Databases?: {
        [key: string]: string;
    };
    /**
    * Durable Object namespaces used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#durable_object_namespaces PagesProject#durable_object_namespaces}
    */
    readonly durableObjectNamespaces?: {
        [key: string]: string;
    };
    /**
    * Environment variables for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#environment_variables PagesProject#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Fail open used for Pages Functions. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#fail_open PagesProject#fail_open}
    */
    readonly failOpen?: boolean | cdktn.IResolvable;
    /**
    * KV namespaces used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#kv_namespaces PagesProject#kv_namespaces}
    */
    readonly kvNamespaces?: {
        [key: string]: string;
    };
    /**
    * R2 Buckets used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#r2_buckets PagesProject#r2_buckets}
    */
    readonly r2Buckets?: {
        [key: string]: string;
    };
    /**
    * Usage model used for Pages Functions. Defaults to `bundled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#usage_model PagesProject#usage_model}
    */
    readonly usageModel?: string;
    /**
    * service_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#service_binding PagesProject#service_binding}
    */
    readonly serviceBinding?: PagesProjectDeploymentConfigsPreviewServiceBinding[] | cdktn.IResolvable;
}
export declare function pagesProjectDeploymentConfigsPreviewToTerraform(struct?: PagesProjectDeploymentConfigsPreviewOutputReference | PagesProjectDeploymentConfigsPreview): any;
export declare function pagesProjectDeploymentConfigsPreviewToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewOutputReference | PagesProjectDeploymentConfigsPreview): any;
export declare class PagesProjectDeploymentConfigsPreviewOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectDeploymentConfigsPreview | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreview | undefined);
    private _alwaysUseLatestCompatibilityDate?;
    get alwaysUseLatestCompatibilityDate(): boolean | cdktn.IResolvable;
    set alwaysUseLatestCompatibilityDate(value: boolean | cdktn.IResolvable);
    resetAlwaysUseLatestCompatibilityDate(): void;
    get alwaysUseLatestCompatibilityDateInput(): boolean | cdktn.IResolvable | undefined;
    private _compatibilityDate?;
    get compatibilityDate(): string;
    set compatibilityDate(value: string);
    resetCompatibilityDate(): void;
    get compatibilityDateInput(): string | undefined;
    private _compatibilityFlags?;
    get compatibilityFlags(): string[];
    set compatibilityFlags(value: string[]);
    resetCompatibilityFlags(): void;
    get compatibilityFlagsInput(): string[] | undefined;
    private _d1Databases?;
    get d1Databases(): {
        [key: string]: string;
    };
    set d1Databases(value: {
        [key: string]: string;
    });
    resetD1Databases(): void;
    get d1DatabasesInput(): {
        [key: string]: string;
    } | undefined;
    private _durableObjectNamespaces?;
    get durableObjectNamespaces(): {
        [key: string]: string;
    };
    set durableObjectNamespaces(value: {
        [key: string]: string;
    });
    resetDurableObjectNamespaces(): void;
    get durableObjectNamespacesInput(): {
        [key: string]: string;
    } | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _failOpen?;
    get failOpen(): boolean | cdktn.IResolvable;
    set failOpen(value: boolean | cdktn.IResolvable);
    resetFailOpen(): void;
    get failOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _kvNamespaces?;
    get kvNamespaces(): {
        [key: string]: string;
    };
    set kvNamespaces(value: {
        [key: string]: string;
    });
    resetKvNamespaces(): void;
    get kvNamespacesInput(): {
        [key: string]: string;
    } | undefined;
    private _r2Buckets?;
    get r2Buckets(): {
        [key: string]: string;
    };
    set r2Buckets(value: {
        [key: string]: string;
    });
    resetR2Buckets(): void;
    get r2BucketsInput(): {
        [key: string]: string;
    } | undefined;
    private _usageModel?;
    get usageModel(): string;
    set usageModel(value: string);
    resetUsageModel(): void;
    get usageModelInput(): string | undefined;
    private _serviceBinding;
    get serviceBinding(): PagesProjectDeploymentConfigsPreviewServiceBindingList;
    putServiceBinding(value: PagesProjectDeploymentConfigsPreviewServiceBinding[] | cdktn.IResolvable): void;
    resetServiceBinding(): void;
    get serviceBindingInput(): cdktn.IResolvable | PagesProjectDeploymentConfigsPreviewServiceBinding[] | undefined;
}
export interface PagesProjectDeploymentConfigsProductionServiceBinding {
    /**
    * The name of the Worker environment to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#environment PagesProject#environment}
    */
    readonly environment?: string;
    /**
    * The global variable for the binding in your Worker code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#name PagesProject#name}
    */
    readonly name: string;
    /**
    * The name of the Worker to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#service PagesProject#service}
    */
    readonly service: string;
}
export declare function pagesProjectDeploymentConfigsProductionServiceBindingToTerraform(struct?: PagesProjectDeploymentConfigsProductionServiceBinding | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionServiceBindingToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionServiceBinding | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionServiceBindingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PagesProjectDeploymentConfigsProductionServiceBinding | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionServiceBinding | cdktn.IResolvable | undefined);
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionServiceBindingList extends cdktn.ComplexList {
    internalValue?: PagesProjectDeploymentConfigsProductionServiceBinding[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PagesProjectDeploymentConfigsProductionServiceBindingOutputReference;
}
export interface PagesProjectDeploymentConfigsProduction {
    /**
    * Use latest compatibility date for Pages Functions. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#always_use_latest_compatibility_date PagesProject#always_use_latest_compatibility_date}
    */
    readonly alwaysUseLatestCompatibilityDate?: boolean | cdktn.IResolvable;
    /**
    * Compatibility date used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#compatibility_date PagesProject#compatibility_date}
    */
    readonly compatibilityDate?: string;
    /**
    * Compatibility flags used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#compatibility_flags PagesProject#compatibility_flags}
    */
    readonly compatibilityFlags?: string[];
    /**
    * D1 Databases used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#d1_databases PagesProject#d1_databases}
    */
    readonly d1Databases?: {
        [key: string]: string;
    };
    /**
    * Durable Object namespaces used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#durable_object_namespaces PagesProject#durable_object_namespaces}
    */
    readonly durableObjectNamespaces?: {
        [key: string]: string;
    };
    /**
    * Environment variables for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#environment_variables PagesProject#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Fail open used for Pages Functions. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#fail_open PagesProject#fail_open}
    */
    readonly failOpen?: boolean | cdktn.IResolvable;
    /**
    * KV namespaces used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#kv_namespaces PagesProject#kv_namespaces}
    */
    readonly kvNamespaces?: {
        [key: string]: string;
    };
    /**
    * R2 Buckets used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#r2_buckets PagesProject#r2_buckets}
    */
    readonly r2Buckets?: {
        [key: string]: string;
    };
    /**
    * Usage model used for Pages Functions. Defaults to `bundled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#usage_model PagesProject#usage_model}
    */
    readonly usageModel?: string;
    /**
    * service_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#service_binding PagesProject#service_binding}
    */
    readonly serviceBinding?: PagesProjectDeploymentConfigsProductionServiceBinding[] | cdktn.IResolvable;
}
export declare function pagesProjectDeploymentConfigsProductionToTerraform(struct?: PagesProjectDeploymentConfigsProductionOutputReference | PagesProjectDeploymentConfigsProduction): any;
export declare function pagesProjectDeploymentConfigsProductionToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionOutputReference | PagesProjectDeploymentConfigsProduction): any;
export declare class PagesProjectDeploymentConfigsProductionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectDeploymentConfigsProduction | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProduction | undefined);
    private _alwaysUseLatestCompatibilityDate?;
    get alwaysUseLatestCompatibilityDate(): boolean | cdktn.IResolvable;
    set alwaysUseLatestCompatibilityDate(value: boolean | cdktn.IResolvable);
    resetAlwaysUseLatestCompatibilityDate(): void;
    get alwaysUseLatestCompatibilityDateInput(): boolean | cdktn.IResolvable | undefined;
    private _compatibilityDate?;
    get compatibilityDate(): string;
    set compatibilityDate(value: string);
    resetCompatibilityDate(): void;
    get compatibilityDateInput(): string | undefined;
    private _compatibilityFlags?;
    get compatibilityFlags(): string[];
    set compatibilityFlags(value: string[]);
    resetCompatibilityFlags(): void;
    get compatibilityFlagsInput(): string[] | undefined;
    private _d1Databases?;
    get d1Databases(): {
        [key: string]: string;
    };
    set d1Databases(value: {
        [key: string]: string;
    });
    resetD1Databases(): void;
    get d1DatabasesInput(): {
        [key: string]: string;
    } | undefined;
    private _durableObjectNamespaces?;
    get durableObjectNamespaces(): {
        [key: string]: string;
    };
    set durableObjectNamespaces(value: {
        [key: string]: string;
    });
    resetDurableObjectNamespaces(): void;
    get durableObjectNamespacesInput(): {
        [key: string]: string;
    } | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _failOpen?;
    get failOpen(): boolean | cdktn.IResolvable;
    set failOpen(value: boolean | cdktn.IResolvable);
    resetFailOpen(): void;
    get failOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _kvNamespaces?;
    get kvNamespaces(): {
        [key: string]: string;
    };
    set kvNamespaces(value: {
        [key: string]: string;
    });
    resetKvNamespaces(): void;
    get kvNamespacesInput(): {
        [key: string]: string;
    } | undefined;
    private _r2Buckets?;
    get r2Buckets(): {
        [key: string]: string;
    };
    set r2Buckets(value: {
        [key: string]: string;
    });
    resetR2Buckets(): void;
    get r2BucketsInput(): {
        [key: string]: string;
    } | undefined;
    private _usageModel?;
    get usageModel(): string;
    set usageModel(value: string);
    resetUsageModel(): void;
    get usageModelInput(): string | undefined;
    private _serviceBinding;
    get serviceBinding(): PagesProjectDeploymentConfigsProductionServiceBindingList;
    putServiceBinding(value: PagesProjectDeploymentConfigsProductionServiceBinding[] | cdktn.IResolvable): void;
    resetServiceBinding(): void;
    get serviceBindingInput(): cdktn.IResolvable | PagesProjectDeploymentConfigsProductionServiceBinding[] | undefined;
}
export interface PagesProjectDeploymentConfigs {
    /**
    * preview block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#preview PagesProject#preview}
    */
    readonly preview: PagesProjectDeploymentConfigsPreview;
    /**
    * production block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#production PagesProject#production}
    */
    readonly production: PagesProjectDeploymentConfigsProduction;
}
export declare function pagesProjectDeploymentConfigsToTerraform(struct?: PagesProjectDeploymentConfigsOutputReference | PagesProjectDeploymentConfigs): any;
export declare function pagesProjectDeploymentConfigsToHclTerraform(struct?: PagesProjectDeploymentConfigsOutputReference | PagesProjectDeploymentConfigs): any;
export declare class PagesProjectDeploymentConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectDeploymentConfigs | undefined;
    set internalValue(value: PagesProjectDeploymentConfigs | undefined);
    private _preview;
    get preview(): PagesProjectDeploymentConfigsPreviewOutputReference;
    putPreview(value: PagesProjectDeploymentConfigsPreview): void;
    get previewInput(): PagesProjectDeploymentConfigsPreview | undefined;
    private _production;
    get production(): PagesProjectDeploymentConfigsProductionOutputReference;
    putProduction(value: PagesProjectDeploymentConfigsProduction): void;
    get productionInput(): PagesProjectDeploymentConfigsProduction | undefined;
}
export interface PagesProjectSourceConfig {
    /**
    * Toggle deployments on this repo. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#deployments_enabled PagesProject#deployments_enabled}
    */
    readonly deploymentsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Project owner username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#owner PagesProject#owner}
    */
    readonly owner?: string;
    /**
    * Enable Pages to comment on Pull Requests. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#pr_comments_enabled PagesProject#pr_comments_enabled}
    */
    readonly prCommentsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Branches will be excluded from automatic deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#preview_branch_excludes PagesProject#preview_branch_excludes}
    */
    readonly previewBranchExcludes?: string[];
    /**
    * Branches will be included for automatic deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#preview_branch_includes PagesProject#preview_branch_includes}
    */
    readonly previewBranchIncludes?: string[];
    /**
    * Preview Deployment Setting. Defaults to `all`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#preview_deployment_setting PagesProject#preview_deployment_setting}
    */
    readonly previewDeploymentSetting?: string;
    /**
    * Project production branch name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#production_branch PagesProject#production_branch}
    */
    readonly productionBranch: string;
    /**
    * Enable production deployments. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#production_deployment_enabled PagesProject#production_deployment_enabled}
    */
    readonly productionDeploymentEnabled?: boolean | cdktn.IResolvable;
    /**
    * Project repository name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#repo_name PagesProject#repo_name}
    */
    readonly repoName?: string;
}
export declare function pagesProjectSourceConfigToTerraform(struct?: PagesProjectSourceConfigOutputReference | PagesProjectSourceConfig): any;
export declare function pagesProjectSourceConfigToHclTerraform(struct?: PagesProjectSourceConfigOutputReference | PagesProjectSourceConfig): any;
export declare class PagesProjectSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectSourceConfig | undefined;
    set internalValue(value: PagesProjectSourceConfig | undefined);
    private _deploymentsEnabled?;
    get deploymentsEnabled(): boolean | cdktn.IResolvable;
    set deploymentsEnabled(value: boolean | cdktn.IResolvable);
    resetDeploymentsEnabled(): void;
    get deploymentsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _prCommentsEnabled?;
    get prCommentsEnabled(): boolean | cdktn.IResolvable;
    set prCommentsEnabled(value: boolean | cdktn.IResolvable);
    resetPrCommentsEnabled(): void;
    get prCommentsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _previewBranchExcludes?;
    get previewBranchExcludes(): string[];
    set previewBranchExcludes(value: string[]);
    resetPreviewBranchExcludes(): void;
    get previewBranchExcludesInput(): string[] | undefined;
    private _previewBranchIncludes?;
    get previewBranchIncludes(): string[];
    set previewBranchIncludes(value: string[]);
    resetPreviewBranchIncludes(): void;
    get previewBranchIncludesInput(): string[] | undefined;
    private _previewDeploymentSetting?;
    get previewDeploymentSetting(): string;
    set previewDeploymentSetting(value: string);
    resetPreviewDeploymentSetting(): void;
    get previewDeploymentSettingInput(): string | undefined;
    private _productionBranch?;
    get productionBranch(): string;
    set productionBranch(value: string);
    get productionBranchInput(): string | undefined;
    private _productionDeploymentEnabled?;
    get productionDeploymentEnabled(): boolean | cdktn.IResolvable;
    set productionDeploymentEnabled(value: boolean | cdktn.IResolvable);
    resetProductionDeploymentEnabled(): void;
    get productionDeploymentEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _repoName?;
    get repoName(): string;
    set repoName(value: string);
    resetRepoName(): void;
    get repoNameInput(): string | undefined;
}
export interface PagesProjectSource {
    /**
    * Project host type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#type PagesProject#type}
    */
    readonly type?: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#config PagesProject#config}
    */
    readonly config?: PagesProjectSourceConfig;
}
export declare function pagesProjectSourceToTerraform(struct?: PagesProjectSourceOutputReference | PagesProjectSource): any;
export declare function pagesProjectSourceToHclTerraform(struct?: PagesProjectSourceOutputReference | PagesProjectSource): any;
export declare class PagesProjectSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectSource | undefined;
    set internalValue(value: PagesProjectSource | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _config;
    get config(): PagesProjectSourceConfigOutputReference;
    putConfig(value: PagesProjectSourceConfig): void;
    resetConfig(): void;
    get configInput(): PagesProjectSourceConfig | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project cloudflare_pages_project}
*/
export declare class PagesProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_pages_project";
    /**
    * Generates CDKTN code for importing a PagesProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PagesProject to import
    * @param importFromId The id of the existing PagesProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PagesProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/pages_project cloudflare_pages_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PagesProjectConfig
    */
    constructor(scope: Construct, id: string, config: PagesProjectConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdOn(): string;
    get domains(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _productionBranch?;
    get productionBranch(): string;
    set productionBranch(value: string);
    get productionBranchInput(): string | undefined;
    get subdomain(): string;
    private _buildConfig;
    get buildConfig(): PagesProjectBuildConfigOutputReference;
    putBuildConfig(value: PagesProjectBuildConfig): void;
    resetBuildConfig(): void;
    get buildConfigInput(): PagesProjectBuildConfig | undefined;
    private _deploymentConfigs;
    get deploymentConfigs(): PagesProjectDeploymentConfigsOutputReference;
    putDeploymentConfigs(value: PagesProjectDeploymentConfigs): void;
    resetDeploymentConfigs(): void;
    get deploymentConfigsInput(): PagesProjectDeploymentConfigs | undefined;
    private _source;
    get source(): PagesProjectSourceOutputReference;
    putSource(value: PagesProjectSource): void;
    resetSource(): void;
    get sourceInput(): PagesProjectSource | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
