import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ManagedHeadersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers#id ManagedHeaders#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The zone identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers#zone_id ManagedHeaders#zone_id}
    */
    readonly zoneId: string;
    /**
    * managed_request_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers#managed_request_headers ManagedHeaders#managed_request_headers}
    */
    readonly managedRequestHeaders?: ManagedHeadersManagedRequestHeaders[] | cdktn.IResolvable;
    /**
    * managed_response_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers#managed_response_headers ManagedHeaders#managed_response_headers}
    */
    readonly managedResponseHeaders?: ManagedHeadersManagedResponseHeaders[] | cdktn.IResolvable;
}
export interface ManagedHeadersManagedRequestHeaders {
    /**
    * Whether the headers rule is active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers#enabled ManagedHeaders#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Unique headers rule identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers#id ManagedHeaders#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function managedHeadersManagedRequestHeadersToTerraform(struct?: ManagedHeadersManagedRequestHeaders | cdktn.IResolvable): any;
export declare function managedHeadersManagedRequestHeadersToHclTerraform(struct?: ManagedHeadersManagedRequestHeaders | cdktn.IResolvable): any;
export declare class ManagedHeadersManagedRequestHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ManagedHeadersManagedRequestHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ManagedHeadersManagedRequestHeaders | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class ManagedHeadersManagedRequestHeadersList extends cdktn.ComplexList {
    internalValue?: ManagedHeadersManagedRequestHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ManagedHeadersManagedRequestHeadersOutputReference;
}
export interface ManagedHeadersManagedResponseHeaders {
    /**
    * Whether the headers rule is active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers#enabled ManagedHeaders#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Unique headers rule identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers#id ManagedHeaders#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function managedHeadersManagedResponseHeadersToTerraform(struct?: ManagedHeadersManagedResponseHeaders | cdktn.IResolvable): any;
export declare function managedHeadersManagedResponseHeadersToHclTerraform(struct?: ManagedHeadersManagedResponseHeaders | cdktn.IResolvable): any;
export declare class ManagedHeadersManagedResponseHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ManagedHeadersManagedResponseHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ManagedHeadersManagedResponseHeaders | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class ManagedHeadersManagedResponseHeadersList extends cdktn.ComplexList {
    internalValue?: ManagedHeadersManagedResponseHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ManagedHeadersManagedResponseHeadersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers cloudflare_managed_headers}
*/
export declare class ManagedHeaders extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_managed_headers";
    /**
    * Generates CDKTN code for importing a ManagedHeaders resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ManagedHeaders to import
    * @param importFromId The id of the existing ManagedHeaders that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ManagedHeaders to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/managed_headers cloudflare_managed_headers} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ManagedHeadersConfig
    */
    constructor(scope: Construct, id: string, config: ManagedHeadersConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _managedRequestHeaders;
    get managedRequestHeaders(): ManagedHeadersManagedRequestHeadersList;
    putManagedRequestHeaders(value: ManagedHeadersManagedRequestHeaders[] | cdktn.IResolvable): void;
    resetManagedRequestHeaders(): void;
    get managedRequestHeadersInput(): cdktn.IResolvable | ManagedHeadersManagedRequestHeaders[] | undefined;
    private _managedResponseHeaders;
    get managedResponseHeaders(): ManagedHeadersManagedResponseHeadersList;
    putManagedResponseHeaders(value: ManagedHeadersManagedResponseHeaders[] | cdktn.IResolvable): void;
    resetManagedResponseHeaders(): void;
    get managedResponseHeadersInput(): cdktn.IResolvable | ManagedHeadersManagedResponseHeaders[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
