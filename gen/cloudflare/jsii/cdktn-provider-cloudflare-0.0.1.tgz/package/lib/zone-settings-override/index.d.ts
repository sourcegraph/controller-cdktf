import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ZoneSettingsOverrideConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#id ZoneSettingsOverride#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#zone_id ZoneSettingsOverride#zone_id}
    */
    readonly zoneId: string;
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#settings ZoneSettingsOverride#settings}
    */
    readonly settings?: ZoneSettingsOverrideSettings;
}
export interface ZoneSettingsOverrideInitialSettingsMinify {
}
export declare function zoneSettingsOverrideInitialSettingsMinifyToTerraform(struct?: ZoneSettingsOverrideInitialSettingsMinify): any;
export declare function zoneSettingsOverrideInitialSettingsMinifyToHclTerraform(struct?: ZoneSettingsOverrideInitialSettingsMinify): any;
export declare class ZoneSettingsOverrideInitialSettingsMinifyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ZoneSettingsOverrideInitialSettingsMinify | undefined;
    set internalValue(value: ZoneSettingsOverrideInitialSettingsMinify | undefined);
    get css(): string;
    get html(): string;
    get js(): string;
}
export declare class ZoneSettingsOverrideInitialSettingsMinifyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ZoneSettingsOverrideInitialSettingsMinifyOutputReference;
}
export interface ZoneSettingsOverrideInitialSettingsMobileRedirect {
}
export declare function zoneSettingsOverrideInitialSettingsMobileRedirectToTerraform(struct?: ZoneSettingsOverrideInitialSettingsMobileRedirect): any;
export declare function zoneSettingsOverrideInitialSettingsMobileRedirectToHclTerraform(struct?: ZoneSettingsOverrideInitialSettingsMobileRedirect): any;
export declare class ZoneSettingsOverrideInitialSettingsMobileRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ZoneSettingsOverrideInitialSettingsMobileRedirect | undefined;
    set internalValue(value: ZoneSettingsOverrideInitialSettingsMobileRedirect | undefined);
    get mobileSubdomain(): string;
    get status(): string;
    get stripUri(): cdktn.IResolvable;
}
export declare class ZoneSettingsOverrideInitialSettingsMobileRedirectList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ZoneSettingsOverrideInitialSettingsMobileRedirectOutputReference;
}
export interface ZoneSettingsOverrideInitialSettingsSecurityHeader {
}
export declare function zoneSettingsOverrideInitialSettingsSecurityHeaderToTerraform(struct?: ZoneSettingsOverrideInitialSettingsSecurityHeader): any;
export declare function zoneSettingsOverrideInitialSettingsSecurityHeaderToHclTerraform(struct?: ZoneSettingsOverrideInitialSettingsSecurityHeader): any;
export declare class ZoneSettingsOverrideInitialSettingsSecurityHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ZoneSettingsOverrideInitialSettingsSecurityHeader | undefined;
    set internalValue(value: ZoneSettingsOverrideInitialSettingsSecurityHeader | undefined);
    get enabled(): cdktn.IResolvable;
    get includeSubdomains(): cdktn.IResolvable;
    get maxAge(): number;
    get nosniff(): cdktn.IResolvable;
    get preload(): cdktn.IResolvable;
}
export declare class ZoneSettingsOverrideInitialSettingsSecurityHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ZoneSettingsOverrideInitialSettingsSecurityHeaderOutputReference;
}
export interface ZoneSettingsOverrideInitialSettings {
}
export declare function zoneSettingsOverrideInitialSettingsToTerraform(struct?: ZoneSettingsOverrideInitialSettings): any;
export declare function zoneSettingsOverrideInitialSettingsToHclTerraform(struct?: ZoneSettingsOverrideInitialSettings): any;
export declare class ZoneSettingsOverrideInitialSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ZoneSettingsOverrideInitialSettings | undefined;
    set internalValue(value: ZoneSettingsOverrideInitialSettings | undefined);
    get alwaysOnline(): string;
    get alwaysUseHttps(): string;
    get automaticHttpsRewrites(): string;
    get binaryAst(): string;
    get brotli(): string;
    get browserCacheTtl(): number;
    get browserCheck(): string;
    get cacheLevel(): string;
    get challengeTtl(): number;
    get ciphers(): string[];
    get cnameFlattening(): string;
    get developmentMode(): string;
    get earlyHints(): string;
    get emailObfuscation(): string;
    get filterLogsToCloudflare(): string;
    get h2Prioritization(): string;
    get hotlinkProtection(): string;
    get http2(): string;
    get http3(): string;
    get imageResizing(): string;
    get ipGeolocation(): string;
    get ipv6(): string;
    get logToCloudflare(): string;
    get maxUpload(): number;
    get minTlsVersion(): string;
    private _minify;
    get minify(): ZoneSettingsOverrideInitialSettingsMinifyList;
    get mirage(): string;
    private _mobileRedirect;
    get mobileRedirect(): ZoneSettingsOverrideInitialSettingsMobileRedirectList;
    get opportunisticEncryption(): string;
    get opportunisticOnion(): string;
    get orangeToOrange(): string;
    get originErrorPagePassThru(): string;
    get originMaxHttpVersion(): string;
    get polish(): string;
    get prefetchPreload(): string;
    get privacyPass(): string;
    get proxyReadTimeout(): string;
    get pseudoIpv4(): string;
    get responseBuffering(): string;
    get rocketLoader(): string;
    private _securityHeader;
    get securityHeader(): ZoneSettingsOverrideInitialSettingsSecurityHeaderList;
    get securityLevel(): string;
    get serverSideExclude(): string;
    get sortQueryStringForCache(): string;
    get ssl(): string;
    get tls12Only(): string;
    get tls13(): string;
    get tlsClientAuth(): string;
    get trueClientIpHeader(): string;
    get universalSsl(): string;
    get visitorIp(): string;
    get waf(): string;
    get webp(): string;
    get websockets(): string;
    get zeroRtt(): string;
}
export declare class ZoneSettingsOverrideInitialSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ZoneSettingsOverrideInitialSettingsOutputReference;
}
export interface ZoneSettingsOverrideSettingsMinify {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#css ZoneSettingsOverride#css}
    */
    readonly css: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#html ZoneSettingsOverride#html}
    */
    readonly html: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#js ZoneSettingsOverride#js}
    */
    readonly js: string;
}
export declare function zoneSettingsOverrideSettingsMinifyToTerraform(struct?: ZoneSettingsOverrideSettingsMinifyOutputReference | ZoneSettingsOverrideSettingsMinify): any;
export declare function zoneSettingsOverrideSettingsMinifyToHclTerraform(struct?: ZoneSettingsOverrideSettingsMinifyOutputReference | ZoneSettingsOverrideSettingsMinify): any;
export declare class ZoneSettingsOverrideSettingsMinifyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ZoneSettingsOverrideSettingsMinify | undefined;
    set internalValue(value: ZoneSettingsOverrideSettingsMinify | undefined);
    private _css?;
    get css(): string;
    set css(value: string);
    get cssInput(): string | undefined;
    private _html?;
    get html(): string;
    set html(value: string);
    get htmlInput(): string | undefined;
    private _js?;
    get js(): string;
    set js(value: string);
    get jsInput(): string | undefined;
}
export interface ZoneSettingsOverrideSettingsMobileRedirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#mobile_subdomain ZoneSettingsOverride#mobile_subdomain}
    */
    readonly mobileSubdomain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#status ZoneSettingsOverride#status}
    */
    readonly status: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#strip_uri ZoneSettingsOverride#strip_uri}
    */
    readonly stripUri: boolean | cdktn.IResolvable;
}
export declare function zoneSettingsOverrideSettingsMobileRedirectToTerraform(struct?: ZoneSettingsOverrideSettingsMobileRedirectOutputReference | ZoneSettingsOverrideSettingsMobileRedirect): any;
export declare function zoneSettingsOverrideSettingsMobileRedirectToHclTerraform(struct?: ZoneSettingsOverrideSettingsMobileRedirectOutputReference | ZoneSettingsOverrideSettingsMobileRedirect): any;
export declare class ZoneSettingsOverrideSettingsMobileRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ZoneSettingsOverrideSettingsMobileRedirect | undefined;
    set internalValue(value: ZoneSettingsOverrideSettingsMobileRedirect | undefined);
    private _mobileSubdomain?;
    get mobileSubdomain(): string;
    set mobileSubdomain(value: string);
    get mobileSubdomainInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _stripUri?;
    get stripUri(): boolean | cdktn.IResolvable;
    set stripUri(value: boolean | cdktn.IResolvable);
    get stripUriInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ZoneSettingsOverrideSettingsSecurityHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#enabled ZoneSettingsOverride#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#include_subdomains ZoneSettingsOverride#include_subdomains}
    */
    readonly includeSubdomains?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#max_age ZoneSettingsOverride#max_age}
    */
    readonly maxAge?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#nosniff ZoneSettingsOverride#nosniff}
    */
    readonly nosniff?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#preload ZoneSettingsOverride#preload}
    */
    readonly preload?: boolean | cdktn.IResolvable;
}
export declare function zoneSettingsOverrideSettingsSecurityHeaderToTerraform(struct?: ZoneSettingsOverrideSettingsSecurityHeaderOutputReference | ZoneSettingsOverrideSettingsSecurityHeader): any;
export declare function zoneSettingsOverrideSettingsSecurityHeaderToHclTerraform(struct?: ZoneSettingsOverrideSettingsSecurityHeaderOutputReference | ZoneSettingsOverrideSettingsSecurityHeader): any;
export declare class ZoneSettingsOverrideSettingsSecurityHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ZoneSettingsOverrideSettingsSecurityHeader | undefined;
    set internalValue(value: ZoneSettingsOverrideSettingsSecurityHeader | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSubdomains?;
    get includeSubdomains(): boolean | cdktn.IResolvable;
    set includeSubdomains(value: boolean | cdktn.IResolvable);
    resetIncludeSubdomains(): void;
    get includeSubdomainsInput(): boolean | cdktn.IResolvable | undefined;
    private _maxAge?;
    get maxAge(): number;
    set maxAge(value: number);
    resetMaxAge(): void;
    get maxAgeInput(): number | undefined;
    private _nosniff?;
    get nosniff(): boolean | cdktn.IResolvable;
    set nosniff(value: boolean | cdktn.IResolvable);
    resetNosniff(): void;
    get nosniffInput(): boolean | cdktn.IResolvable | undefined;
    private _preload?;
    get preload(): boolean | cdktn.IResolvable;
    set preload(value: boolean | cdktn.IResolvable);
    resetPreload(): void;
    get preloadInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ZoneSettingsOverrideSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#always_online ZoneSettingsOverride#always_online}
    */
    readonly alwaysOnline?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#always_use_https ZoneSettingsOverride#always_use_https}
    */
    readonly alwaysUseHttps?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#automatic_https_rewrites ZoneSettingsOverride#automatic_https_rewrites}
    */
    readonly automaticHttpsRewrites?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#binary_ast ZoneSettingsOverride#binary_ast}
    */
    readonly binaryAst?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#brotli ZoneSettingsOverride#brotli}
    */
    readonly brotli?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#browser_cache_ttl ZoneSettingsOverride#browser_cache_ttl}
    */
    readonly browserCacheTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#browser_check ZoneSettingsOverride#browser_check}
    */
    readonly browserCheck?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#cache_level ZoneSettingsOverride#cache_level}
    */
    readonly cacheLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#challenge_ttl ZoneSettingsOverride#challenge_ttl}
    */
    readonly challengeTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#ciphers ZoneSettingsOverride#ciphers}
    */
    readonly ciphers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#cname_flattening ZoneSettingsOverride#cname_flattening}
    */
    readonly cnameFlattening?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#development_mode ZoneSettingsOverride#development_mode}
    */
    readonly developmentMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#early_hints ZoneSettingsOverride#early_hints}
    */
    readonly earlyHints?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#email_obfuscation ZoneSettingsOverride#email_obfuscation}
    */
    readonly emailObfuscation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#filter_logs_to_cloudflare ZoneSettingsOverride#filter_logs_to_cloudflare}
    */
    readonly filterLogsToCloudflare?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#h2_prioritization ZoneSettingsOverride#h2_prioritization}
    */
    readonly h2Prioritization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#hotlink_protection ZoneSettingsOverride#hotlink_protection}
    */
    readonly hotlinkProtection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#http2 ZoneSettingsOverride#http2}
    */
    readonly http2?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#http3 ZoneSettingsOverride#http3}
    */
    readonly http3?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#image_resizing ZoneSettingsOverride#image_resizing}
    */
    readonly imageResizing?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#ip_geolocation ZoneSettingsOverride#ip_geolocation}
    */
    readonly ipGeolocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#ipv6 ZoneSettingsOverride#ipv6}
    */
    readonly ipv6?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#log_to_cloudflare ZoneSettingsOverride#log_to_cloudflare}
    */
    readonly logToCloudflare?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#max_upload ZoneSettingsOverride#max_upload}
    */
    readonly maxUpload?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#min_tls_version ZoneSettingsOverride#min_tls_version}
    */
    readonly minTlsVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#mirage ZoneSettingsOverride#mirage}
    */
    readonly mirage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#opportunistic_encryption ZoneSettingsOverride#opportunistic_encryption}
    */
    readonly opportunisticEncryption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#opportunistic_onion ZoneSettingsOverride#opportunistic_onion}
    */
    readonly opportunisticOnion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#orange_to_orange ZoneSettingsOverride#orange_to_orange}
    */
    readonly orangeToOrange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#origin_error_page_pass_thru ZoneSettingsOverride#origin_error_page_pass_thru}
    */
    readonly originErrorPagePassThru?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#origin_max_http_version ZoneSettingsOverride#origin_max_http_version}
    */
    readonly originMaxHttpVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#polish ZoneSettingsOverride#polish}
    */
    readonly polish?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#prefetch_preload ZoneSettingsOverride#prefetch_preload}
    */
    readonly prefetchPreload?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#privacy_pass ZoneSettingsOverride#privacy_pass}
    */
    readonly privacyPass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#proxy_read_timeout ZoneSettingsOverride#proxy_read_timeout}
    */
    readonly proxyReadTimeout?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#pseudo_ipv4 ZoneSettingsOverride#pseudo_ipv4}
    */
    readonly pseudoIpv4?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#response_buffering ZoneSettingsOverride#response_buffering}
    */
    readonly responseBuffering?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#rocket_loader ZoneSettingsOverride#rocket_loader}
    */
    readonly rocketLoader?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#security_level ZoneSettingsOverride#security_level}
    */
    readonly securityLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#server_side_exclude ZoneSettingsOverride#server_side_exclude}
    */
    readonly serverSideExclude?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#sort_query_string_for_cache ZoneSettingsOverride#sort_query_string_for_cache}
    */
    readonly sortQueryStringForCache?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#ssl ZoneSettingsOverride#ssl}
    */
    readonly ssl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#tls_1_2_only ZoneSettingsOverride#tls_1_2_only}
    */
    readonly tls12Only?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#tls_1_3 ZoneSettingsOverride#tls_1_3}
    */
    readonly tls13?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#tls_client_auth ZoneSettingsOverride#tls_client_auth}
    */
    readonly tlsClientAuth?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#true_client_ip_header ZoneSettingsOverride#true_client_ip_header}
    */
    readonly trueClientIpHeader?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#universal_ssl ZoneSettingsOverride#universal_ssl}
    */
    readonly universalSsl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#visitor_ip ZoneSettingsOverride#visitor_ip}
    */
    readonly visitorIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#waf ZoneSettingsOverride#waf}
    */
    readonly waf?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#webp ZoneSettingsOverride#webp}
    */
    readonly webp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#websockets ZoneSettingsOverride#websockets}
    */
    readonly websockets?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#zero_rtt ZoneSettingsOverride#zero_rtt}
    */
    readonly zeroRtt?: string;
    /**
    * minify block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#minify ZoneSettingsOverride#minify}
    */
    readonly minify?: ZoneSettingsOverrideSettingsMinify;
    /**
    * mobile_redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#mobile_redirect ZoneSettingsOverride#mobile_redirect}
    */
    readonly mobileRedirect?: ZoneSettingsOverrideSettingsMobileRedirect;
    /**
    * security_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#security_header ZoneSettingsOverride#security_header}
    */
    readonly securityHeader?: ZoneSettingsOverrideSettingsSecurityHeader;
}
export declare function zoneSettingsOverrideSettingsToTerraform(struct?: ZoneSettingsOverrideSettingsOutputReference | ZoneSettingsOverrideSettings): any;
export declare function zoneSettingsOverrideSettingsToHclTerraform(struct?: ZoneSettingsOverrideSettingsOutputReference | ZoneSettingsOverrideSettings): any;
export declare class ZoneSettingsOverrideSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ZoneSettingsOverrideSettings | undefined;
    set internalValue(value: ZoneSettingsOverrideSettings | undefined);
    private _alwaysOnline?;
    get alwaysOnline(): string;
    set alwaysOnline(value: string);
    resetAlwaysOnline(): void;
    get alwaysOnlineInput(): string | undefined;
    private _alwaysUseHttps?;
    get alwaysUseHttps(): string;
    set alwaysUseHttps(value: string);
    resetAlwaysUseHttps(): void;
    get alwaysUseHttpsInput(): string | undefined;
    private _automaticHttpsRewrites?;
    get automaticHttpsRewrites(): string;
    set automaticHttpsRewrites(value: string);
    resetAutomaticHttpsRewrites(): void;
    get automaticHttpsRewritesInput(): string | undefined;
    private _binaryAst?;
    get binaryAst(): string;
    set binaryAst(value: string);
    resetBinaryAst(): void;
    get binaryAstInput(): string | undefined;
    private _brotli?;
    get brotli(): string;
    set brotli(value: string);
    resetBrotli(): void;
    get brotliInput(): string | undefined;
    private _browserCacheTtl?;
    get browserCacheTtl(): number;
    set browserCacheTtl(value: number);
    resetBrowserCacheTtl(): void;
    get browserCacheTtlInput(): number | undefined;
    private _browserCheck?;
    get browserCheck(): string;
    set browserCheck(value: string);
    resetBrowserCheck(): void;
    get browserCheckInput(): string | undefined;
    private _cacheLevel?;
    get cacheLevel(): string;
    set cacheLevel(value: string);
    resetCacheLevel(): void;
    get cacheLevelInput(): string | undefined;
    private _challengeTtl?;
    get challengeTtl(): number;
    set challengeTtl(value: number);
    resetChallengeTtl(): void;
    get challengeTtlInput(): number | undefined;
    private _ciphers?;
    get ciphers(): string[];
    set ciphers(value: string[]);
    resetCiphers(): void;
    get ciphersInput(): string[] | undefined;
    private _cnameFlattening?;
    get cnameFlattening(): string;
    set cnameFlattening(value: string);
    resetCnameFlattening(): void;
    get cnameFlatteningInput(): string | undefined;
    private _developmentMode?;
    get developmentMode(): string;
    set developmentMode(value: string);
    resetDevelopmentMode(): void;
    get developmentModeInput(): string | undefined;
    private _earlyHints?;
    get earlyHints(): string;
    set earlyHints(value: string);
    resetEarlyHints(): void;
    get earlyHintsInput(): string | undefined;
    private _emailObfuscation?;
    get emailObfuscation(): string;
    set emailObfuscation(value: string);
    resetEmailObfuscation(): void;
    get emailObfuscationInput(): string | undefined;
    private _filterLogsToCloudflare?;
    get filterLogsToCloudflare(): string;
    set filterLogsToCloudflare(value: string);
    resetFilterLogsToCloudflare(): void;
    get filterLogsToCloudflareInput(): string | undefined;
    private _h2Prioritization?;
    get h2Prioritization(): string;
    set h2Prioritization(value: string);
    resetH2Prioritization(): void;
    get h2PrioritizationInput(): string | undefined;
    private _hotlinkProtection?;
    get hotlinkProtection(): string;
    set hotlinkProtection(value: string);
    resetHotlinkProtection(): void;
    get hotlinkProtectionInput(): string | undefined;
    private _http2?;
    get http2(): string;
    set http2(value: string);
    resetHttp2(): void;
    get http2Input(): string | undefined;
    private _http3?;
    get http3(): string;
    set http3(value: string);
    resetHttp3(): void;
    get http3Input(): string | undefined;
    private _imageResizing?;
    get imageResizing(): string;
    set imageResizing(value: string);
    resetImageResizing(): void;
    get imageResizingInput(): string | undefined;
    private _ipGeolocation?;
    get ipGeolocation(): string;
    set ipGeolocation(value: string);
    resetIpGeolocation(): void;
    get ipGeolocationInput(): string | undefined;
    private _ipv6?;
    get ipv6(): string;
    set ipv6(value: string);
    resetIpv6(): void;
    get ipv6Input(): string | undefined;
    private _logToCloudflare?;
    get logToCloudflare(): string;
    set logToCloudflare(value: string);
    resetLogToCloudflare(): void;
    get logToCloudflareInput(): string | undefined;
    private _maxUpload?;
    get maxUpload(): number;
    set maxUpload(value: number);
    resetMaxUpload(): void;
    get maxUploadInput(): number | undefined;
    private _minTlsVersion?;
    get minTlsVersion(): string;
    set minTlsVersion(value: string);
    resetMinTlsVersion(): void;
    get minTlsVersionInput(): string | undefined;
    private _mirage?;
    get mirage(): string;
    set mirage(value: string);
    resetMirage(): void;
    get mirageInput(): string | undefined;
    private _opportunisticEncryption?;
    get opportunisticEncryption(): string;
    set opportunisticEncryption(value: string);
    resetOpportunisticEncryption(): void;
    get opportunisticEncryptionInput(): string | undefined;
    private _opportunisticOnion?;
    get opportunisticOnion(): string;
    set opportunisticOnion(value: string);
    resetOpportunisticOnion(): void;
    get opportunisticOnionInput(): string | undefined;
    private _orangeToOrange?;
    get orangeToOrange(): string;
    set orangeToOrange(value: string);
    resetOrangeToOrange(): void;
    get orangeToOrangeInput(): string | undefined;
    private _originErrorPagePassThru?;
    get originErrorPagePassThru(): string;
    set originErrorPagePassThru(value: string);
    resetOriginErrorPagePassThru(): void;
    get originErrorPagePassThruInput(): string | undefined;
    private _originMaxHttpVersion?;
    get originMaxHttpVersion(): string;
    set originMaxHttpVersion(value: string);
    resetOriginMaxHttpVersion(): void;
    get originMaxHttpVersionInput(): string | undefined;
    private _polish?;
    get polish(): string;
    set polish(value: string);
    resetPolish(): void;
    get polishInput(): string | undefined;
    private _prefetchPreload?;
    get prefetchPreload(): string;
    set prefetchPreload(value: string);
    resetPrefetchPreload(): void;
    get prefetchPreloadInput(): string | undefined;
    private _privacyPass?;
    get privacyPass(): string;
    set privacyPass(value: string);
    resetPrivacyPass(): void;
    get privacyPassInput(): string | undefined;
    private _proxyReadTimeout?;
    get proxyReadTimeout(): string;
    set proxyReadTimeout(value: string);
    resetProxyReadTimeout(): void;
    get proxyReadTimeoutInput(): string | undefined;
    private _pseudoIpv4?;
    get pseudoIpv4(): string;
    set pseudoIpv4(value: string);
    resetPseudoIpv4(): void;
    get pseudoIpv4Input(): string | undefined;
    private _responseBuffering?;
    get responseBuffering(): string;
    set responseBuffering(value: string);
    resetResponseBuffering(): void;
    get responseBufferingInput(): string | undefined;
    private _rocketLoader?;
    get rocketLoader(): string;
    set rocketLoader(value: string);
    resetRocketLoader(): void;
    get rocketLoaderInput(): string | undefined;
    private _securityLevel?;
    get securityLevel(): string;
    set securityLevel(value: string);
    resetSecurityLevel(): void;
    get securityLevelInput(): string | undefined;
    private _serverSideExclude?;
    get serverSideExclude(): string;
    set serverSideExclude(value: string);
    resetServerSideExclude(): void;
    get serverSideExcludeInput(): string | undefined;
    private _sortQueryStringForCache?;
    get sortQueryStringForCache(): string;
    set sortQueryStringForCache(value: string);
    resetSortQueryStringForCache(): void;
    get sortQueryStringForCacheInput(): string | undefined;
    private _ssl?;
    get ssl(): string;
    set ssl(value: string);
    resetSsl(): void;
    get sslInput(): string | undefined;
    private _tls12Only?;
    get tls12Only(): string;
    set tls12Only(value: string);
    resetTls12Only(): void;
    get tls12OnlyInput(): string | undefined;
    private _tls13?;
    get tls13(): string;
    set tls13(value: string);
    resetTls13(): void;
    get tls13Input(): string | undefined;
    private _tlsClientAuth?;
    get tlsClientAuth(): string;
    set tlsClientAuth(value: string);
    resetTlsClientAuth(): void;
    get tlsClientAuthInput(): string | undefined;
    private _trueClientIpHeader?;
    get trueClientIpHeader(): string;
    set trueClientIpHeader(value: string);
    resetTrueClientIpHeader(): void;
    get trueClientIpHeaderInput(): string | undefined;
    private _universalSsl?;
    get universalSsl(): string;
    set universalSsl(value: string);
    resetUniversalSsl(): void;
    get universalSslInput(): string | undefined;
    private _visitorIp?;
    get visitorIp(): string;
    set visitorIp(value: string);
    resetVisitorIp(): void;
    get visitorIpInput(): string | undefined;
    private _waf?;
    get waf(): string;
    set waf(value: string);
    resetWaf(): void;
    get wafInput(): string | undefined;
    private _webp?;
    get webp(): string;
    set webp(value: string);
    resetWebp(): void;
    get webpInput(): string | undefined;
    private _websockets?;
    get websockets(): string;
    set websockets(value: string);
    resetWebsockets(): void;
    get websocketsInput(): string | undefined;
    private _zeroRtt?;
    get zeroRtt(): string;
    set zeroRtt(value: string);
    resetZeroRtt(): void;
    get zeroRttInput(): string | undefined;
    private _minify;
    get minify(): ZoneSettingsOverrideSettingsMinifyOutputReference;
    putMinify(value: ZoneSettingsOverrideSettingsMinify): void;
    resetMinify(): void;
    get minifyInput(): ZoneSettingsOverrideSettingsMinify | undefined;
    private _mobileRedirect;
    get mobileRedirect(): ZoneSettingsOverrideSettingsMobileRedirectOutputReference;
    putMobileRedirect(value: ZoneSettingsOverrideSettingsMobileRedirect): void;
    resetMobileRedirect(): void;
    get mobileRedirectInput(): ZoneSettingsOverrideSettingsMobileRedirect | undefined;
    private _securityHeader;
    get securityHeader(): ZoneSettingsOverrideSettingsSecurityHeaderOutputReference;
    putSecurityHeader(value: ZoneSettingsOverrideSettingsSecurityHeader): void;
    resetSecurityHeader(): void;
    get securityHeaderInput(): ZoneSettingsOverrideSettingsSecurityHeader | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override cloudflare_zone_settings_override}
*/
export declare class ZoneSettingsOverride extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_zone_settings_override";
    /**
    * Generates CDKTN code for importing a ZoneSettingsOverride resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ZoneSettingsOverride to import
    * @param importFromId The id of the existing ZoneSettingsOverride that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ZoneSettingsOverride to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_settings_override cloudflare_zone_settings_override} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ZoneSettingsOverrideConfig
    */
    constructor(scope: Construct, id: string, config: ZoneSettingsOverrideConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initialSettings;
    get initialSettings(): ZoneSettingsOverrideInitialSettingsList;
    get initialSettingsReadAt(): string;
    get readonlySettings(): string[];
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    get zoneStatus(): string;
    get zoneType(): string;
    private _settings;
    get settings(): ZoneSettingsOverrideSettingsOutputReference;
    putSettings(value: ZoneSettingsOverrideSettings): void;
    resetSettings(): void;
    get settingsInput(): ZoneSettingsOverrideSettings | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
