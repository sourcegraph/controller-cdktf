import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SpectrumApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Enables Argo Smart Routing. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#argo_smart_routing SpectrumApplication#argo_smart_routing}
    */
    readonly argoSmartRouting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#id SpectrumApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Enables the IP Firewall for this application. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#ip_firewall SpectrumApplication#ip_firewall}
    */
    readonly ipFirewall?: boolean | cdktn.IResolvable;
    /**
    * A list of destination addresses to the origin. e.g. `tcp://192.0.2.1:22`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#origin_direct SpectrumApplication#origin_direct}
    */
    readonly originDirect?: string[];
    /**
    * Origin port to proxy traffice to. Conflicts with `origin_port_range`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#origin_port SpectrumApplication#origin_port}
    */
    readonly originPort?: number;
    /**
    * The port configuration at Cloudflare's edge. e.g. `tcp/22`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#protocol SpectrumApplication#protocol}
    */
    readonly protocol: string;
    /**
    * Enables a proxy protocol to the origin. Available values: `off`, `v1`, `v2`, `simple`. Defaults to `off`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#proxy_protocol SpectrumApplication#proxy_protocol}
    */
    readonly proxyProtocol?: string;
    /**
    * TLS configuration option for Cloudflare to connect to your origin. Available values: `off`, `flexible`, `full`, `strict`. Defaults to `off`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#tls SpectrumApplication#tls}
    */
    readonly tls?: string;
    /**
    * Sets application type. Available values: `direct`, `http`, `https`. Defaults to `direct`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#traffic_type SpectrumApplication#traffic_type}
    */
    readonly trafficType?: string;
    /**
    * The zone identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#zone_id SpectrumApplication#zone_id}
    */
    readonly zoneId: string;
    /**
    * dns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#dns SpectrumApplication#dns}
    */
    readonly dns: SpectrumApplicationDns;
    /**
    * edge_ips block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#edge_ips SpectrumApplication#edge_ips}
    */
    readonly edgeIps?: SpectrumApplicationEdgeIps;
    /**
    * origin_dns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#origin_dns SpectrumApplication#origin_dns}
    */
    readonly originDns?: SpectrumApplicationOriginDns;
    /**
    * origin_port_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#origin_port_range SpectrumApplication#origin_port_range}
    */
    readonly originPortRange?: SpectrumApplicationOriginPortRange;
}
export interface SpectrumApplicationDns {
    /**
    * The name of the DNS record associated with the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#name SpectrumApplication#name}
    */
    readonly name: string;
    /**
    * The type of DNS record associated with the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#type SpectrumApplication#type}
    */
    readonly type: string;
}
export declare function spectrumApplicationDnsToTerraform(struct?: SpectrumApplicationDnsOutputReference | SpectrumApplicationDns): any;
export declare function spectrumApplicationDnsToHclTerraform(struct?: SpectrumApplicationDnsOutputReference | SpectrumApplicationDns): any;
export declare class SpectrumApplicationDnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SpectrumApplicationDns | undefined;
    set internalValue(value: SpectrumApplicationDns | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface SpectrumApplicationEdgeIps {
    /**
    * The IP versions supported for inbound connections on Spectrum anycast IPs. Required when `type` is not `static`. Available values: `all`, `ipv4`, `ipv6`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#connectivity SpectrumApplication#connectivity}
    */
    readonly connectivity?: string;
    /**
    * The collection of customer owned IPs to broadcast via anycast for this hostname and application. Requires [Bring Your Own IP](https://developers.cloudflare.com/spectrum/getting-started/byoip/) provisioned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#ips SpectrumApplication#ips}
    */
    readonly ips?: string[];
    /**
    * The type of edge IP configuration specified. Available values: `dynamic`, `static`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#type SpectrumApplication#type}
    */
    readonly type: string;
}
export declare function spectrumApplicationEdgeIpsToTerraform(struct?: SpectrumApplicationEdgeIpsOutputReference | SpectrumApplicationEdgeIps): any;
export declare function spectrumApplicationEdgeIpsToHclTerraform(struct?: SpectrumApplicationEdgeIpsOutputReference | SpectrumApplicationEdgeIps): any;
export declare class SpectrumApplicationEdgeIpsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SpectrumApplicationEdgeIps | undefined;
    set internalValue(value: SpectrumApplicationEdgeIps | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    resetConnectivity(): void;
    get connectivityInput(): string | undefined;
    private _ips?;
    get ips(): string[];
    set ips(value: string[]);
    resetIps(): void;
    get ipsInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface SpectrumApplicationOriginDns {
    /**
    * Fully qualified domain name of the origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#name SpectrumApplication#name}
    */
    readonly name: string;
}
export declare function spectrumApplicationOriginDnsToTerraform(struct?: SpectrumApplicationOriginDnsOutputReference | SpectrumApplicationOriginDns): any;
export declare function spectrumApplicationOriginDnsToHclTerraform(struct?: SpectrumApplicationOriginDnsOutputReference | SpectrumApplicationOriginDns): any;
export declare class SpectrumApplicationOriginDnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SpectrumApplicationOriginDns | undefined;
    set internalValue(value: SpectrumApplicationOriginDns | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface SpectrumApplicationOriginPortRange {
    /**
    * Upper bound of the origin port range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#end SpectrumApplication#end}
    */
    readonly end: number;
    /**
    * Lower bound of the origin port range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#start SpectrumApplication#start}
    */
    readonly start: number;
}
export declare function spectrumApplicationOriginPortRangeToTerraform(struct?: SpectrumApplicationOriginPortRangeOutputReference | SpectrumApplicationOriginPortRange): any;
export declare function spectrumApplicationOriginPortRangeToHclTerraform(struct?: SpectrumApplicationOriginPortRangeOutputReference | SpectrumApplicationOriginPortRange): any;
export declare class SpectrumApplicationOriginPortRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SpectrumApplicationOriginPortRange | undefined;
    set internalValue(value: SpectrumApplicationOriginPortRange | undefined);
    private _end?;
    get end(): number;
    set end(value: number);
    get endInput(): number | undefined;
    private _start?;
    get start(): number;
    set start(value: number);
    get startInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application cloudflare_spectrum_application}
*/
export declare class SpectrumApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_spectrum_application";
    /**
    * Generates CDKTN code for importing a SpectrumApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SpectrumApplication to import
    * @param importFromId The id of the existing SpectrumApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SpectrumApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/spectrum_application cloudflare_spectrum_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SpectrumApplicationConfig
    */
    constructor(scope: Construct, id: string, config: SpectrumApplicationConfig);
    private _argoSmartRouting?;
    get argoSmartRouting(): boolean | cdktn.IResolvable;
    set argoSmartRouting(value: boolean | cdktn.IResolvable);
    resetArgoSmartRouting(): void;
    get argoSmartRoutingInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipFirewall?;
    get ipFirewall(): boolean | cdktn.IResolvable;
    set ipFirewall(value: boolean | cdktn.IResolvable);
    resetIpFirewall(): void;
    get ipFirewallInput(): boolean | cdktn.IResolvable | undefined;
    private _originDirect?;
    get originDirect(): string[];
    set originDirect(value: string[]);
    resetOriginDirect(): void;
    get originDirectInput(): string[] | undefined;
    private _originPort?;
    get originPort(): number;
    set originPort(value: number);
    resetOriginPort(): void;
    get originPortInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _proxyProtocol?;
    get proxyProtocol(): string;
    set proxyProtocol(value: string);
    resetProxyProtocol(): void;
    get proxyProtocolInput(): string | undefined;
    private _tls?;
    get tls(): string;
    set tls(value: string);
    resetTls(): void;
    get tlsInput(): string | undefined;
    private _trafficType?;
    get trafficType(): string;
    set trafficType(value: string);
    resetTrafficType(): void;
    get trafficTypeInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _dns;
    get dns(): SpectrumApplicationDnsOutputReference;
    putDns(value: SpectrumApplicationDns): void;
    get dnsInput(): SpectrumApplicationDns | undefined;
    private _edgeIps;
    get edgeIps(): SpectrumApplicationEdgeIpsOutputReference;
    putEdgeIps(value: SpectrumApplicationEdgeIps): void;
    resetEdgeIps(): void;
    get edgeIpsInput(): SpectrumApplicationEdgeIps | undefined;
    private _originDns;
    get originDns(): SpectrumApplicationOriginDnsOutputReference;
    putOriginDns(value: SpectrumApplicationOriginDns): void;
    resetOriginDns(): void;
    get originDnsInput(): SpectrumApplicationOriginDns | undefined;
    private _originPortRange;
    get originPortRange(): SpectrumApplicationOriginPortRangeOutputReference;
    putOriginPortRange(value: SpectrumApplicationOriginPortRange): void;
    resetOriginPortRange(): void;
    get originPortRangeInput(): SpectrumApplicationOriginPortRange | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
