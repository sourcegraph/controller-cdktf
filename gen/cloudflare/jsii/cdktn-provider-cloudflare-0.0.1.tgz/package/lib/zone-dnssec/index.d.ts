import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ZoneDnssecConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_dnssec#id ZoneDnssec#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Zone DNSSEC updated time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_dnssec#modified_on ZoneDnssec#modified_on}
    */
    readonly modifiedOn?: string;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_dnssec#zone_id ZoneDnssec#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_dnssec cloudflare_zone_dnssec}
*/
export declare class ZoneDnssec extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_zone_dnssec";
    /**
    * Generates CDKTN code for importing a ZoneDnssec resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ZoneDnssec to import
    * @param importFromId The id of the existing ZoneDnssec that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_dnssec#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ZoneDnssec to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_dnssec cloudflare_zone_dnssec} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ZoneDnssecConfig
    */
    constructor(scope: Construct, id: string, config: ZoneDnssecConfig);
    get algorithm(): string;
    get digest(): string;
    get digestAlgorithm(): string;
    get digestType(): string;
    get ds(): string;
    get flags(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get keyTag(): number;
    get keyType(): string;
    private _modifiedOn?;
    get modifiedOn(): string;
    set modifiedOn(value: string);
    resetModifiedOn(): void;
    get modifiedOnInput(): string | undefined;
    get publicKey(): string;
    get status(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
