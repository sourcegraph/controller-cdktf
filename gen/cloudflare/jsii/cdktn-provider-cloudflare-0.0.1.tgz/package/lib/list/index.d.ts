import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ListConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#account_id List#account_id}
    */
    readonly accountId: string;
    /**
    * An optional description of the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#description List#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#id List#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The type of items the list will contain. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#kind List#kind}
    */
    readonly kind: string;
    /**
    * The name of the list. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#name List#name}
    */
    readonly name: string;
    /**
    * item block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#item List#item}
    */
    readonly item?: ListItem[] | cdktn.IResolvable;
}
export interface ListItemValueRedirect {
    /**
    * Whether the redirect also matches subdomains of the source url. Available values: `disabled`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#include_subdomains List#include_subdomains}
    */
    readonly includeSubdomains?: string;
    /**
    * Whether to preserve the path suffix when doing subpath matching. Available values: `disabled`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#preserve_path_suffix List#preserve_path_suffix}
    */
    readonly preservePathSuffix?: string;
    /**
    * Whether the redirect target url should keep the query string of the request's url. Available values: `disabled`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#preserve_query_string List#preserve_query_string}
    */
    readonly preserveQueryString?: string;
    /**
    * The source url of the redirect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#source_url List#source_url}
    */
    readonly sourceUrl: string;
    /**
    * The status code to be used when redirecting a request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#status_code List#status_code}
    */
    readonly statusCode?: number;
    /**
    * Whether the redirect also matches subpaths of the source url. Available values: `disabled`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#subpath_matching List#subpath_matching}
    */
    readonly subpathMatching?: string;
    /**
    * The target url of the redirect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#target_url List#target_url}
    */
    readonly targetUrl: string;
}
export declare function listItemValueRedirectToTerraform(struct?: ListItemValueRedirect | cdktn.IResolvable): any;
export declare function listItemValueRedirectToHclTerraform(struct?: ListItemValueRedirect | cdktn.IResolvable): any;
export declare class ListItemValueRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ListItemValueRedirect | cdktn.IResolvable | undefined;
    set internalValue(value: ListItemValueRedirect | cdktn.IResolvable | undefined);
    private _includeSubdomains?;
    get includeSubdomains(): string;
    set includeSubdomains(value: string);
    resetIncludeSubdomains(): void;
    get includeSubdomainsInput(): string | undefined;
    private _preservePathSuffix?;
    get preservePathSuffix(): string;
    set preservePathSuffix(value: string);
    resetPreservePathSuffix(): void;
    get preservePathSuffixInput(): string | undefined;
    private _preserveQueryString?;
    get preserveQueryString(): string;
    set preserveQueryString(value: string);
    resetPreserveQueryString(): void;
    get preserveQueryStringInput(): string | undefined;
    private _sourceUrl?;
    get sourceUrl(): string;
    set sourceUrl(value: string);
    get sourceUrlInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _subpathMatching?;
    get subpathMatching(): string;
    set subpathMatching(value: string);
    resetSubpathMatching(): void;
    get subpathMatchingInput(): string | undefined;
    private _targetUrl?;
    get targetUrl(): string;
    set targetUrl(value: string);
    get targetUrlInput(): string | undefined;
}
export declare class ListItemValueRedirectList extends cdktn.ComplexList {
    internalValue?: ListItemValueRedirect[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ListItemValueRedirectOutputReference;
}
export interface ListItemValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#ip List#ip}
    */
    readonly ip?: string;
    /**
    * redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#redirect List#redirect}
    */
    readonly redirect?: ListItemValueRedirect[] | cdktn.IResolvable;
}
export declare function listItemValueToTerraform(struct?: ListItemValueOutputReference | ListItemValue): any;
export declare function listItemValueToHclTerraform(struct?: ListItemValueOutputReference | ListItemValue): any;
export declare class ListItemValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ListItemValue | undefined;
    set internalValue(value: ListItemValue | undefined);
    private _ip?;
    get ip(): string;
    set ip(value: string);
    resetIp(): void;
    get ipInput(): string | undefined;
    private _redirect;
    get redirect(): ListItemValueRedirectList;
    putRedirect(value: ListItemValueRedirect[] | cdktn.IResolvable): void;
    resetRedirect(): void;
    get redirectInput(): cdktn.IResolvable | ListItemValueRedirect[] | undefined;
}
export interface ListItem {
    /**
    * An optional comment for the item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#comment List#comment}
    */
    readonly comment?: string;
    /**
    * value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#value List#value}
    */
    readonly value: ListItemValue;
}
export declare function listItemToTerraform(struct?: ListItem | cdktn.IResolvable): any;
export declare function listItemToHclTerraform(struct?: ListItem | cdktn.IResolvable): any;
export declare class ListItemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ListItem | cdktn.IResolvable | undefined;
    set internalValue(value: ListItem | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _value;
    get value(): ListItemValueOutputReference;
    putValue(value: ListItemValue): void;
    get valueInput(): ListItemValue | undefined;
}
export declare class ListItemList extends cdktn.ComplexList {
    internalValue?: ListItem[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ListItemOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list cloudflare_list}
*/
export declare class List extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_list";
    /**
    * Generates CDKTN code for importing a List resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the List to import
    * @param importFromId The id of the existing List that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the List to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list cloudflare_list} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ListConfig
    */
    constructor(scope: Construct, id: string, config: ListConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _item;
    get item(): ListItemList;
    putItem(value: ListItem[] | cdktn.IResolvable): void;
    resetItem(): void;
    get itemInput(): cdktn.IResolvable | ListItem[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
