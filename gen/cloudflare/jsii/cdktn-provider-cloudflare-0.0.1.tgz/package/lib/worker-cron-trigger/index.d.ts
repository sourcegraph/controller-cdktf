import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkerCronTriggerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_cron_trigger#account_id WorkerCronTrigger#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_cron_trigger#id WorkerCronTrigger#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Cron expressions to execute the Worker script.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_cron_trigger#schedules WorkerCronTrigger#schedules}
    */
    readonly schedules: string[];
    /**
    * Worker script to target for the schedules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_cron_trigger#script_name WorkerCronTrigger#script_name}
    */
    readonly scriptName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_cron_trigger cloudflare_worker_cron_trigger}
*/
export declare class WorkerCronTrigger extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_worker_cron_trigger";
    /**
    * Generates CDKTN code for importing a WorkerCronTrigger resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkerCronTrigger to import
    * @param importFromId The id of the existing WorkerCronTrigger that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_cron_trigger#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkerCronTrigger to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/worker_cron_trigger cloudflare_worker_cron_trigger} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkerCronTriggerConfig
    */
    constructor(scope: Construct, id: string, config: WorkerCronTriggerConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _schedules?;
    get schedules(): string[];
    set schedules(value: string[]);
    get schedulesInput(): string[] | undefined;
    private _scriptName?;
    get scriptName(): string;
    set scriptName(value: string);
    get scriptNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
