import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ListItemAConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#account_id ListItemA#account_id}
    */
    readonly accountId: string;
    /**
    * An optional comment for the item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#comment ListItemA#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#id ListItemA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * IP address to include in the list. Must provide only one of `ip`, `redirect`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#ip ListItemA#ip}
    */
    readonly ip?: string;
    /**
    * The list identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#list_id ListItemA#list_id}
    */
    readonly listId: string;
    /**
    * redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#redirect ListItemA#redirect}
    */
    readonly redirect?: ListItemRedirect;
}
export interface ListItemRedirect {
    /**
    * Whether the redirect also matches subdomains of the source url. Available values: `disabled`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#include_subdomains ListItemA#include_subdomains}
    */
    readonly includeSubdomains?: string;
    /**
    * Whether to preserve the path suffix when doing subpath matching. Available values: `disabled`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#preserve_path_suffix ListItemA#preserve_path_suffix}
    */
    readonly preservePathSuffix?: string;
    /**
    * Whether the redirect target url should keep the query string of the request's url. Available values: `disabled`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#preserve_query_string ListItemA#preserve_query_string}
    */
    readonly preserveQueryString?: string;
    /**
    * The source url of the redirect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#source_url ListItemA#source_url}
    */
    readonly sourceUrl: string;
    /**
    * The status code to be used when redirecting a request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#status_code ListItemA#status_code}
    */
    readonly statusCode?: number;
    /**
    * Whether the redirect also matches subpaths of the source url. Available values: `disabled`, `enabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#subpath_matching ListItemA#subpath_matching}
    */
    readonly subpathMatching?: string;
    /**
    * The target url of the redirect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#target_url ListItemA#target_url}
    */
    readonly targetUrl: string;
}
export declare function listItemRedirectToTerraform(struct?: ListItemRedirectOutputReference | ListItemRedirect): any;
export declare function listItemRedirectToHclTerraform(struct?: ListItemRedirectOutputReference | ListItemRedirect): any;
export declare class ListItemRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ListItemRedirect | undefined;
    set internalValue(value: ListItemRedirect | undefined);
    private _includeSubdomains?;
    get includeSubdomains(): string;
    set includeSubdomains(value: string);
    resetIncludeSubdomains(): void;
    get includeSubdomainsInput(): string | undefined;
    private _preservePathSuffix?;
    get preservePathSuffix(): string;
    set preservePathSuffix(value: string);
    resetPreservePathSuffix(): void;
    get preservePathSuffixInput(): string | undefined;
    private _preserveQueryString?;
    get preserveQueryString(): string;
    set preserveQueryString(value: string);
    resetPreserveQueryString(): void;
    get preserveQueryStringInput(): string | undefined;
    private _sourceUrl?;
    get sourceUrl(): string;
    set sourceUrl(value: string);
    get sourceUrlInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _subpathMatching?;
    get subpathMatching(): string;
    set subpathMatching(value: string);
    resetSubpathMatching(): void;
    get subpathMatchingInput(): string | undefined;
    private _targetUrl?;
    get targetUrl(): string;
    set targetUrl(value: string);
    get targetUrlInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item cloudflare_list_item}
*/
export declare class ListItemA extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_list_item";
    /**
    * Generates CDKTN code for importing a ListItemA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ListItemA to import
    * @param importFromId The id of the existing ListItemA that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ListItemA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/list_item cloudflare_list_item} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ListItemAConfig
    */
    constructor(scope: Construct, id: string, config: ListItemAConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    resetIp(): void;
    get ipInput(): string | undefined;
    private _listId?;
    get listId(): string;
    set listId(value: string);
    get listIdInput(): string | undefined;
    private _redirect;
    get redirect(): ListItemRedirectOutputReference;
    putRedirect(value: ListItemRedirect): void;
    resetRedirect(): void;
    get redirectInput(): ListItemRedirect | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
