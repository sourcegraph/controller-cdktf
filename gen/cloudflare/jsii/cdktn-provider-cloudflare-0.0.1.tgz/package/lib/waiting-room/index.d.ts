import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WaitingRoomConfig extends cdktn.TerraformMetaArguments {
    /**
    * This is a templated html file that will be rendered at the edge.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#custom_page_html WaitingRoom#custom_page_html}
    */
    readonly customPageHtml?: string;
    /**
    * The language to use for the default waiting room page. Available values: `de-DE`, `es-ES`, `en-US`, `fr-FR`, `id-ID`, `it-IT`, `ja-JP`, `ko-KR`, `nl-NL`, `pl-PL`, `pt-BR`, `tr-TR`, `zh-CN`, `zh-TW`, `ru-RU`, `fa-IR`. Defaults to `en-US`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#default_template_language WaitingRoom#default_template_language}
    */
    readonly defaultTemplateLanguage?: string;
    /**
    * A description to add more details about the waiting room.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#description WaitingRoom#description}
    */
    readonly description?: string;
    /**
    * Disables automatic renewal of session cookies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#disable_session_renewal WaitingRoom#disable_session_renewal}
    */
    readonly disableSessionRenewal?: boolean | cdktn.IResolvable;
    /**
    * Host name for which the waiting room will be applied (no wildcards).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#host WaitingRoom#host}
    */
    readonly host: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#id WaitingRoom#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If true, requests to the waiting room with the header `Accept: application/json` will receive a JSON response object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#json_response_enabled WaitingRoom#json_response_enabled}
    */
    readonly jsonResponseEnabled?: boolean | cdktn.IResolvable;
    /**
    * A unique name to identify the waiting room. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#name WaitingRoom#name}
    */
    readonly name: string;
    /**
    * The number of new users that will be let into the route every minute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#new_users_per_minute WaitingRoom#new_users_per_minute}
    */
    readonly newUsersPerMinute: number;
    /**
    * The path within the host to enable the waiting room on. Defaults to `/`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#path WaitingRoom#path}
    */
    readonly path?: string;
    /**
    * If queue_all is true, then all traffic will be sent to the waiting room.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#queue_all WaitingRoom#queue_all}
    */
    readonly queueAll?: boolean | cdktn.IResolvable;
    /**
    * The queueing method used by the waiting room. Available values: `fifo`, `random`, `passthrough`, `reject`. Defaults to `fifo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#queueing_method WaitingRoom#queueing_method}
    */
    readonly queueingMethod?: string;
    /**
    * Lifetime of a cookie (in minutes) set by Cloudflare for users who get access to the origin. Defaults to `5`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#session_duration WaitingRoom#session_duration}
    */
    readonly sessionDuration?: number;
    /**
    * Suspends the waiting room.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#suspended WaitingRoom#suspended}
    */
    readonly suspended?: boolean | cdktn.IResolvable;
    /**
    * The total number of active user sessions on the route at a point in time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#total_active_users WaitingRoom#total_active_users}
    */
    readonly totalActiveUsers: number;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#zone_id WaitingRoom#zone_id}
    */
    readonly zoneId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#timeouts WaitingRoom#timeouts}
    */
    readonly timeouts?: WaitingRoomTimeouts;
}
export interface WaitingRoomTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#create WaitingRoom#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#update WaitingRoom#update}
    */
    readonly update?: string;
}
export declare function waitingRoomTimeoutsToTerraform(struct?: WaitingRoomTimeouts | cdktn.IResolvable): any;
export declare function waitingRoomTimeoutsToHclTerraform(struct?: WaitingRoomTimeouts | cdktn.IResolvable): any;
export declare class WaitingRoomTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WaitingRoomTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: WaitingRoomTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room cloudflare_waiting_room}
*/
export declare class WaitingRoom extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_waiting_room";
    /**
    * Generates CDKTN code for importing a WaitingRoom resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WaitingRoom to import
    * @param importFromId The id of the existing WaitingRoom that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WaitingRoom to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room cloudflare_waiting_room} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WaitingRoomConfig
    */
    constructor(scope: Construct, id: string, config: WaitingRoomConfig);
    private _customPageHtml?;
    get customPageHtml(): string;
    set customPageHtml(value: string);
    resetCustomPageHtml(): void;
    get customPageHtmlInput(): string | undefined;
    private _defaultTemplateLanguage?;
    get defaultTemplateLanguage(): string;
    set defaultTemplateLanguage(value: string);
    resetDefaultTemplateLanguage(): void;
    get defaultTemplateLanguageInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableSessionRenewal?;
    get disableSessionRenewal(): boolean | cdktn.IResolvable;
    set disableSessionRenewal(value: boolean | cdktn.IResolvable);
    resetDisableSessionRenewal(): void;
    get disableSessionRenewalInput(): boolean | cdktn.IResolvable | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jsonResponseEnabled?;
    get jsonResponseEnabled(): boolean | cdktn.IResolvable;
    set jsonResponseEnabled(value: boolean | cdktn.IResolvable);
    resetJsonResponseEnabled(): void;
    get jsonResponseEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _newUsersPerMinute?;
    get newUsersPerMinute(): number;
    set newUsersPerMinute(value: number);
    get newUsersPerMinuteInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _queueAll?;
    get queueAll(): boolean | cdktn.IResolvable;
    set queueAll(value: boolean | cdktn.IResolvable);
    resetQueueAll(): void;
    get queueAllInput(): boolean | cdktn.IResolvable | undefined;
    private _queueingMethod?;
    get queueingMethod(): string;
    set queueingMethod(value: string);
    resetQueueingMethod(): void;
    get queueingMethodInput(): string | undefined;
    private _sessionDuration?;
    get sessionDuration(): number;
    set sessionDuration(value: number);
    resetSessionDuration(): void;
    get sessionDurationInput(): number | undefined;
    private _suspended?;
    get suspended(): boolean | cdktn.IResolvable;
    set suspended(value: boolean | cdktn.IResolvable);
    resetSuspended(): void;
    get suspendedInput(): boolean | cdktn.IResolvable | undefined;
    private _totalActiveUsers?;
    get totalActiveUsers(): number;
    set totalActiveUsers(value: number);
    get totalActiveUsersInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): WaitingRoomTimeoutsOutputReference;
    putTimeouts(value: WaitingRoomTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | WaitingRoomTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
