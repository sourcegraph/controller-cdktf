import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DevicePostureRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#account_id DevicePostureRule#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#description DevicePostureRule#description}
    */
    readonly description?: string;
    /**
    * Expire posture results after the specified amount of time. Must be in the format `1h` or `30m`. Valid units are `h` and `m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#expiration DevicePostureRule#expiration}
    */
    readonly expiration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#id DevicePostureRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the device posture rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#name DevicePostureRule#name}
    */
    readonly name?: string;
    /**
    * Tells the client when to run the device posture check. Must be in the format `1h` or `30m`. Valid units are `h` and `m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#schedule DevicePostureRule#schedule}
    */
    readonly schedule?: string;
    /**
    * The device posture rule type. Available values: `serial_number`, `file`, `application`, `gateway`, `warp`, `domain_joined`, `os_version`, `disk_encryption`, `firewall`, `workspace_one`, `unique_client_id`, `crowdstrike_s2s`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#type DevicePostureRule#type}
    */
    readonly type: string;
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#input DevicePostureRule#input}
    */
    readonly input?: DevicePostureRuleInput[] | cdktn.IResolvable;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#match DevicePostureRule#match}
    */
    readonly match?: DevicePostureRuleMatch[] | cdktn.IResolvable;
}
export interface DevicePostureRuleInput {
    /**
    * Specific volume(s) to check for encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#check_disks DevicePostureRule#check_disks}
    */
    readonly checkDisks?: string[];
    /**
    * The workspace one device compliance status. Available values: `compliant`, `noncompliant`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#compliance_status DevicePostureRule#compliance_status}
    */
    readonly complianceStatus?: string;
    /**
    * The workspace one connection id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#connection_id DevicePostureRule#connection_id}
    */
    readonly connectionId?: string;
    /**
    * The domain that the client must join.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#domain DevicePostureRule#domain}
    */
    readonly domain?: string;
    /**
    * True if the firewall must be enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#enabled DevicePostureRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Checks if the file should exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#exists DevicePostureRule#exists}
    */
    readonly exists?: boolean | cdktn.IResolvable;
    /**
    * The Teams List id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#id DevicePostureRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The version comparison operator. Available values: `>`, `>=`, `<`, `<=`, `==`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#operator DevicePostureRule#operator}
    */
    readonly operator?: string;
    /**
    * OS signal score from Crowdstrike. Value must be between 1 and 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#os DevicePostureRule#os}
    */
    readonly os?: string;
    /**
    * The operating system excluding version information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#os_distro_name DevicePostureRule#os_distro_name}
    */
    readonly osDistroName?: string;
    /**
    * The operating system version excluding OS name information or release name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#os_distro_revision DevicePostureRule#os_distro_revision}
    */
    readonly osDistroRevision?: string;
    /**
    * Overall ZTA score from Crowdstrike. Value must be between 1 and 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#overall DevicePostureRule#overall}
    */
    readonly overall?: string;
    /**
    * The path to the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#path DevicePostureRule#path}
    */
    readonly path?: string;
    /**
    * True if all drives must be encrypted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#require_all DevicePostureRule#require_all}
    */
    readonly requireAll?: boolean | cdktn.IResolvable;
    /**
    * Checks if the application should be running.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#running DevicePostureRule#running}
    */
    readonly running?: boolean | cdktn.IResolvable;
    /**
    * Sensor signal score from Crowdstrike. Value must be between 1 and 100.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#sensor_config DevicePostureRule#sensor_config}
    */
    readonly sensorConfig?: string;
    /**
    * The sha256 hash of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#sha256 DevicePostureRule#sha256}
    */
    readonly sha256?: string;
    /**
    * The thumbprint of the file certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#thumbprint DevicePostureRule#thumbprint}
    */
    readonly thumbprint?: string;
    /**
    * The operating system semantic version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#version DevicePostureRule#version}
    */
    readonly version?: string;
    /**
    * The version comparison operator for crowdstrike. Available values: `>`, `>=`, `<`, `<=`, `==`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#version_operator DevicePostureRule#version_operator}
    */
    readonly versionOperator?: string;
}
export declare function devicePostureRuleInputToTerraform(struct?: DevicePostureRuleInput | cdktn.IResolvable): any;
export declare function devicePostureRuleInputToHclTerraform(struct?: DevicePostureRuleInput | cdktn.IResolvable): any;
export declare class DevicePostureRuleInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DevicePostureRuleInput | cdktn.IResolvable | undefined;
    set internalValue(value: DevicePostureRuleInput | cdktn.IResolvable | undefined);
    private _checkDisks?;
    get checkDisks(): string[];
    set checkDisks(value: string[]);
    resetCheckDisks(): void;
    get checkDisksInput(): string[] | undefined;
    private _complianceStatus?;
    get complianceStatus(): string;
    set complianceStatus(value: string);
    resetComplianceStatus(): void;
    get complianceStatusInput(): string | undefined;
    private _connectionId?;
    get connectionId(): string;
    set connectionId(value: string);
    resetConnectionId(): void;
    get connectionIdInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _exists?;
    get exists(): boolean | cdktn.IResolvable;
    set exists(value: boolean | cdktn.IResolvable);
    resetExists(): void;
    get existsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _os?;
    get os(): string;
    set os(value: string);
    resetOs(): void;
    get osInput(): string | undefined;
    private _osDistroName?;
    get osDistroName(): string;
    set osDistroName(value: string);
    resetOsDistroName(): void;
    get osDistroNameInput(): string | undefined;
    private _osDistroRevision?;
    get osDistroRevision(): string;
    set osDistroRevision(value: string);
    resetOsDistroRevision(): void;
    get osDistroRevisionInput(): string | undefined;
    private _overall?;
    get overall(): string;
    set overall(value: string);
    resetOverall(): void;
    get overallInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _requireAll?;
    get requireAll(): boolean | cdktn.IResolvable;
    set requireAll(value: boolean | cdktn.IResolvable);
    resetRequireAll(): void;
    get requireAllInput(): boolean | cdktn.IResolvable | undefined;
    private _running?;
    get running(): boolean | cdktn.IResolvable;
    set running(value: boolean | cdktn.IResolvable);
    resetRunning(): void;
    get runningInput(): boolean | cdktn.IResolvable | undefined;
    private _sensorConfig?;
    get sensorConfig(): string;
    set sensorConfig(value: string);
    resetSensorConfig(): void;
    get sensorConfigInput(): string | undefined;
    private _sha256?;
    get sha256(): string;
    set sha256(value: string);
    resetSha256(): void;
    get sha256Input(): string | undefined;
    private _thumbprint?;
    get thumbprint(): string;
    set thumbprint(value: string);
    resetThumbprint(): void;
    get thumbprintInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _versionOperator?;
    get versionOperator(): string;
    set versionOperator(value: string);
    resetVersionOperator(): void;
    get versionOperatorInput(): string | undefined;
}
export declare class DevicePostureRuleInputList extends cdktn.ComplexList {
    internalValue?: DevicePostureRuleInput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DevicePostureRuleInputOutputReference;
}
export interface DevicePostureRuleMatch {
    /**
    * The platform of the device. Available values: `windows`, `mac`, `linux`, `android`, `ios`, `chromeos`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#platform DevicePostureRule#platform}
    */
    readonly platform?: string;
}
export declare function devicePostureRuleMatchToTerraform(struct?: DevicePostureRuleMatch | cdktn.IResolvable): any;
export declare function devicePostureRuleMatchToHclTerraform(struct?: DevicePostureRuleMatch | cdktn.IResolvable): any;
export declare class DevicePostureRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DevicePostureRuleMatch | cdktn.IResolvable | undefined;
    set internalValue(value: DevicePostureRuleMatch | cdktn.IResolvable | undefined);
    private _platform?;
    get platform(): string;
    set platform(value: string);
    resetPlatform(): void;
    get platformInput(): string | undefined;
}
export declare class DevicePostureRuleMatchList extends cdktn.ComplexList {
    internalValue?: DevicePostureRuleMatch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DevicePostureRuleMatchOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule cloudflare_device_posture_rule}
*/
export declare class DevicePostureRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_device_posture_rule";
    /**
    * Generates CDKTN code for importing a DevicePostureRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DevicePostureRule to import
    * @param importFromId The id of the existing DevicePostureRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DevicePostureRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_rule cloudflare_device_posture_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DevicePostureRuleConfig
    */
    constructor(scope: Construct, id: string, config: DevicePostureRuleConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expiration?;
    get expiration(): string;
    set expiration(value: string);
    resetExpiration(): void;
    get expirationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    resetSchedule(): void;
    get scheduleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _input;
    get input(): DevicePostureRuleInputList;
    putInput(value: DevicePostureRuleInput[] | cdktn.IResolvable): void;
    resetInput(): void;
    get inputInput(): cdktn.IResolvable | DevicePostureRuleInput[] | undefined;
    private _match;
    get match(): DevicePostureRuleMatchList;
    putMatch(value: DevicePostureRuleMatch[] | cdktn.IResolvable): void;
    resetMatch(): void;
    get matchInput(): cdktn.IResolvable | DevicePostureRuleMatch[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
