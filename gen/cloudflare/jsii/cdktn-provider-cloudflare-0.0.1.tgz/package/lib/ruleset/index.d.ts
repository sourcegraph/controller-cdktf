import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RulesetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#account_id Ruleset#account_id}
    */
    readonly accountId?: string;
    /**
    * Brief summary of the ruleset and its intended use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#description Ruleset#description}
    */
    readonly description?: string;
    /**
    * Type of Ruleset to create. Available values: `custom`, `managed`, `root`, `schema`, `zone`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#kind Ruleset#kind}
    */
    readonly kind: string;
    /**
    * Name of the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name: string;
    /**
    * Point in the request/response lifecycle where the ruleset will be created. Available values: `ddos_l4`, `ddos_l7`, `http_custom_errors`, `http_log_custom_fields`, `http_request_cache_settings`, `http_request_firewall_custom`, `http_request_firewall_managed`, `http_request_late_transform`, `http_request_late_transform_managed`, `http_request_main`, `http_request_origin`, `http_request_dynamic_redirect`, `http_request_redirect`, `http_request_sanitize`, `http_request_transform`, `http_response_firewall_managed`, `http_response_headers_transform`, `http_response_headers_transform_managed`, `magic_transit`, `http_ratelimit`, `http_request_sbfm`, `http_config_settings`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#phase Ruleset#phase}
    */
    readonly phase: string;
    /**
    * Name of entitlement that is shareable between entities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#shareable_entitlement_name Ruleset#shareable_entitlement_name}
    */
    readonly shareableEntitlementName?: string;
    /**
    * The zone identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#zone_id Ruleset#zone_id}
    */
    readonly zoneId?: string;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#rules Ruleset#rules}
    */
    readonly rules?: RulesetRules[] | cdktn.IResolvable;
}
export interface RulesetRulesActionParametersAutominify {
    /**
    * CSS minification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#css Ruleset#css}
    */
    readonly css?: boolean | cdktn.IResolvable;
    /**
    * HTML minification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#html Ruleset#html}
    */
    readonly html?: boolean | cdktn.IResolvable;
    /**
    * JS minification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#js Ruleset#js}
    */
    readonly js?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersAutominifyToTerraform(struct?: RulesetRulesActionParametersAutominify | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersAutominifyToHclTerraform(struct?: RulesetRulesActionParametersAutominify | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersAutominifyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersAutominify | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersAutominify | cdktn.IResolvable | undefined);
    private _css?;
    get css(): boolean | cdktn.IResolvable;
    set css(value: boolean | cdktn.IResolvable);
    resetCss(): void;
    get cssInput(): boolean | cdktn.IResolvable | undefined;
    private _html?;
    get html(): boolean | cdktn.IResolvable;
    set html(value: boolean | cdktn.IResolvable);
    resetHtml(): void;
    get htmlInput(): boolean | cdktn.IResolvable | undefined;
    private _js?;
    get js(): boolean | cdktn.IResolvable;
    set js(value: boolean | cdktn.IResolvable);
    resetJs(): void;
    get jsInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersAutominifyList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersAutominify[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersAutominifyOutputReference;
}
export interface RulesetRulesActionParametersBrowserTtl {
    /**
    * Default browser TTL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#default Ruleset#default}
    */
    readonly default?: number;
    /**
    * Mode of the browser TTL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#mode Ruleset#mode}
    */
    readonly mode?: string;
}
export declare function rulesetRulesActionParametersBrowserTtlToTerraform(struct?: RulesetRulesActionParametersBrowserTtl | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersBrowserTtlToHclTerraform(struct?: RulesetRulesActionParametersBrowserTtl | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersBrowserTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersBrowserTtl | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersBrowserTtl | cdktn.IResolvable | undefined);
    private _default?;
    get default(): number;
    set default(value: number);
    resetDefault(): void;
    get defaultInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export declare class RulesetRulesActionParametersBrowserTtlList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersBrowserTtl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersBrowserTtlOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyCookie {
    /**
    * List of cookies to check for presence in the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#check_presence Ruleset#check_presence}
    */
    readonly checkPresence?: string[];
    /**
    * List of cookies to include in the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#include Ruleset#include}
    */
    readonly include?: string[];
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyCookieToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyCookieToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktn.IResolvable | undefined);
    private _checkPresence?;
    get checkPresence(): string[];
    set checkPresence(value: string[]);
    resetCheckPresence(): void;
    get checkPresenceInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyCookieList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKeyCookie[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyCookieOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyHeader {
    /**
    * List of headers to check for presence in the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#check_presence Ruleset#check_presence}
    */
    readonly checkPresence?: string[];
    /**
    * Exclude the origin header from the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#exclude_origin Ruleset#exclude_origin}
    */
    readonly excludeOrigin?: boolean | cdktn.IResolvable;
    /**
    * List of headers to include in the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#include Ruleset#include}
    */
    readonly include?: string[];
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHeaderToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHeaderToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktn.IResolvable | undefined);
    private _checkPresence?;
    get checkPresence(): string[];
    set checkPresence(value: string[]);
    resetCheckPresence(): void;
    get checkPresenceInput(): string[] | undefined;
    private _excludeOrigin?;
    get excludeOrigin(): boolean | cdktn.IResolvable;
    set excludeOrigin(value: boolean | cdktn.IResolvable);
    resetExcludeOrigin(): void;
    get excludeOriginInput(): boolean | cdktn.IResolvable | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyHeaderList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKeyHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyHeaderOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyHost {
    /**
    * Resolve hostname to IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#resolved Ruleset#resolved}
    */
    readonly resolved?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHostToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHostToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyHostOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktn.IResolvable | undefined);
    private _resolved?;
    get resolved(): boolean | cdktn.IResolvable;
    set resolved(value: boolean | cdktn.IResolvable);
    resetResolved(): void;
    get resolvedInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyHostList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKeyHost[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyHostOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyQueryString {
    /**
    * List of query string parameters to exclude from the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#exclude Ruleset#exclude}
    */
    readonly exclude?: string[];
    /**
    * List of query string parameters to include in the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#include Ruleset#include}
    */
    readonly include?: string[];
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyQueryStringToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyQueryStringToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyQueryStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktn.IResolvable | undefined);
    private _exclude?;
    get exclude(): string[];
    set exclude(value: string[]);
    resetExclude(): void;
    get excludeInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyQueryStringList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyQueryStringOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyUser {
    /**
    * Add device type to the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#device_type Ruleset#device_type}
    */
    readonly deviceType?: boolean | cdktn.IResolvable;
    /**
    * Add geo data to the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#geo Ruleset#geo}
    */
    readonly geo?: boolean | cdktn.IResolvable;
    /**
    * Add language data to the custom key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#lang Ruleset#lang}
    */
    readonly lang?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyUserToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyUserToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktn.IResolvable | undefined);
    private _deviceType?;
    get deviceType(): boolean | cdktn.IResolvable;
    set deviceType(value: boolean | cdktn.IResolvable);
    resetDeviceType(): void;
    get deviceTypeInput(): boolean | cdktn.IResolvable | undefined;
    private _geo?;
    get geo(): boolean | cdktn.IResolvable;
    set geo(value: boolean | cdktn.IResolvable);
    resetGeo(): void;
    get geoInput(): boolean | cdktn.IResolvable | undefined;
    private _lang?;
    get lang(): boolean | cdktn.IResolvable;
    set lang(value: boolean | cdktn.IResolvable);
    resetLang(): void;
    get langInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyUserList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKeyUser[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyUserOutputReference;
}
export interface RulesetRulesActionParametersCacheKeyCustomKey {
    /**
    * cookie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cookie Ruleset#cookie}
    */
    readonly cookie?: RulesetRulesActionParametersCacheKeyCustomKeyCookie[] | cdktn.IResolvable;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#header Ruleset#header}
    */
    readonly header?: RulesetRulesActionParametersCacheKeyCustomKeyHeader[] | cdktn.IResolvable;
    /**
    * host block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#host Ruleset#host}
    */
    readonly host?: RulesetRulesActionParametersCacheKeyCustomKeyHost[] | cdktn.IResolvable;
    /**
    * query_string block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#query_string Ruleset#query_string}
    */
    readonly queryString?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString[] | cdktn.IResolvable;
    /**
    * user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#user Ruleset#user}
    */
    readonly user?: RulesetRulesActionParametersCacheKeyCustomKeyUser[] | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKey | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKey | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKey | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKey | cdktn.IResolvable | undefined);
    private _cookie;
    get cookie(): RulesetRulesActionParametersCacheKeyCustomKeyCookieList;
    putCookie(value: RulesetRulesActionParametersCacheKeyCustomKeyCookie[] | cdktn.IResolvable): void;
    resetCookie(): void;
    get cookieInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyCookie[] | undefined;
    private _header;
    get header(): RulesetRulesActionParametersCacheKeyCustomKeyHeaderList;
    putHeader(value: RulesetRulesActionParametersCacheKeyCustomKeyHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyHeader[] | undefined;
    private _host;
    get host(): RulesetRulesActionParametersCacheKeyCustomKeyHostList;
    putHost(value: RulesetRulesActionParametersCacheKeyCustomKeyHost[] | cdktn.IResolvable): void;
    resetHost(): void;
    get hostInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyHost[] | undefined;
    private _queryString;
    get queryString(): RulesetRulesActionParametersCacheKeyCustomKeyQueryStringList;
    putQueryString(value: RulesetRulesActionParametersCacheKeyCustomKeyQueryString[] | cdktn.IResolvable): void;
    resetQueryString(): void;
    get queryStringInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyQueryString[] | undefined;
    private _user;
    get user(): RulesetRulesActionParametersCacheKeyCustomKeyUserList;
    putUser(value: RulesetRulesActionParametersCacheKeyCustomKeyUser[] | cdktn.IResolvable): void;
    resetUser(): void;
    get userInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyUser[] | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyCustomKeyList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersCacheKeyCustomKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyCustomKeyOutputReference;
}
export interface RulesetRulesActionParametersCacheKey {
    /**
    * Cache by device type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cache_by_device_type Ruleset#cache_by_device_type}
    */
    readonly cacheByDeviceType?: boolean | cdktn.IResolvable;
    /**
    * Cache deception armor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cache_deception_armor Ruleset#cache_deception_armor}
    */
    readonly cacheDeceptionArmor?: boolean | cdktn.IResolvable;
    /**
    * Ignore query strings order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#ignore_query_strings_order Ruleset#ignore_query_strings_order}
    */
    readonly ignoreQueryStringsOrder?: boolean | cdktn.IResolvable;
    /**
    * custom_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#custom_key Ruleset#custom_key}
    */
    readonly customKey?: RulesetRulesActionParametersCacheKeyCustomKey[] | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyToTerraform(struct?: RulesetRulesActionParametersCacheKey | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyToHclTerraform(struct?: RulesetRulesActionParametersCacheKey | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCacheKey | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKey | cdktn.IResolvable | undefined);
    private _cacheByDeviceType?;
    get cacheByDeviceType(): boolean | cdktn.IResolvable;
    set cacheByDeviceType(value: boolean | cdktn.IResolvable);
    resetCacheByDeviceType(): void;
    get cacheByDeviceTypeInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheDeceptionArmor?;
    get cacheDeceptionArmor(): boolean | cdktn.IResolvable;
    set cacheDeceptionArmor(value: boolean | cdktn.IResolvable);
    resetCacheDeceptionArmor(): void;
    get cacheDeceptionArmorInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreQueryStringsOrder?;
    get ignoreQueryStringsOrder(): boolean | cdktn.IResolvable;
    set ignoreQueryStringsOrder(value: boolean | cdktn.IResolvable);
    resetIgnoreQueryStringsOrder(): void;
    get ignoreQueryStringsOrderInput(): boolean | cdktn.IResolvable | undefined;
    private _customKey;
    get customKey(): RulesetRulesActionParametersCacheKeyCustomKeyList;
    putCustomKey(value: RulesetRulesActionParametersCacheKeyCustomKey[] | cdktn.IResolvable): void;
    resetCustomKey(): void;
    get customKeyInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKey[] | undefined;
}
export declare class RulesetRulesActionParametersCacheKeyList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersCacheKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCacheKeyOutputReference;
}
export interface RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange {
    /**
    * From status code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#from Ruleset#from}
    */
    readonly from?: number;
    /**
    * To status code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#to Ruleset#to}
    */
    readonly to?: number;
}
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeToTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeToHclTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktn.IResolvable | undefined);
    private _from?;
    get from(): number;
    set from(value: number);
    resetFrom(): void;
    get fromInput(): number | undefined;
    private _to?;
    get to(): number;
    set to(value: number);
    resetTo(): void;
    get toInput(): number | undefined;
}
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeOutputReference;
}
export interface RulesetRulesActionParametersEdgeTtlStatusCodeTtl {
    /**
    * Status code for which the edge TTL is applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
    /**
    * Status code edge TTL value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: number;
    /**
    * status_code_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code_range Ruleset#status_code_range}
    */
    readonly statusCodeRange?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange[] | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlToTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlToHclTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktn.IResolvable | undefined);
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
    private _statusCodeRange;
    get statusCodeRange(): RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeList;
    putStatusCodeRange(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange[] | cdktn.IResolvable): void;
    resetStatusCodeRange(): void;
    get statusCodeRangeInput(): cdktn.IResolvable | RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange[] | undefined;
}
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersEdgeTtlStatusCodeTtlOutputReference;
}
export interface RulesetRulesActionParametersEdgeTtl {
    /**
    * Default edge TTL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#default Ruleset#default}
    */
    readonly default?: number;
    /**
    * Mode of the edge TTL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#mode Ruleset#mode}
    */
    readonly mode?: string;
    /**
    * status_code_ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code_ttl Ruleset#status_code_ttl}
    */
    readonly statusCodeTtl?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersEdgeTtlToTerraform(struct?: RulesetRulesActionParametersEdgeTtl | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersEdgeTtlToHclTerraform(struct?: RulesetRulesActionParametersEdgeTtl | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersEdgeTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersEdgeTtl | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersEdgeTtl | cdktn.IResolvable | undefined);
    private _default?;
    get default(): number;
    set default(value: number);
    resetDefault(): void;
    get defaultInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _statusCodeTtl;
    get statusCodeTtl(): RulesetRulesActionParametersEdgeTtlStatusCodeTtlList;
    putStatusCodeTtl(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | cdktn.IResolvable): void;
    resetStatusCodeTtl(): void;
    get statusCodeTtlInput(): cdktn.IResolvable | RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | undefined;
}
export declare class RulesetRulesActionParametersEdgeTtlList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersEdgeTtl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersEdgeTtlOutputReference;
}
export interface RulesetRulesActionParametersFromListStruct {
    /**
    * Expression to use for the list lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#key Ruleset#key}
    */
    readonly key?: string;
    /**
    * Name of the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name?: string;
}
export declare function rulesetRulesActionParametersFromListStructToTerraform(struct?: RulesetRulesActionParametersFromListStruct | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersFromListStructToHclTerraform(struct?: RulesetRulesActionParametersFromListStruct | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersFromListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersFromListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersFromListStruct | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class RulesetRulesActionParametersFromListStructList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersFromListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersFromListStructOutputReference;
}
export interface RulesetRulesActionParametersFromValueTargetUrl {
    /**
    * Use a value dynamically determined by the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * Static value to provide as the HTTP request header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersFromValueTargetUrlToTerraform(struct?: RulesetRulesActionParametersFromValueTargetUrl | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersFromValueTargetUrlToHclTerraform(struct?: RulesetRulesActionParametersFromValueTargetUrl | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersFromValueTargetUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersFromValueTargetUrl | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersFromValueTargetUrl | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersFromValueTargetUrlList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersFromValueTargetUrl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersFromValueTargetUrlOutputReference;
}
export interface RulesetRulesActionParametersFromValue {
    /**
    * Preserve query string for redirect URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#preserve_query_string Ruleset#preserve_query_string}
    */
    readonly preserveQueryString?: boolean | cdktn.IResolvable;
    /**
    * Status code for redirect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
    /**
    * target_url block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#target_url Ruleset#target_url}
    */
    readonly targetUrl?: RulesetRulesActionParametersFromValueTargetUrl[] | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersFromValueToTerraform(struct?: RulesetRulesActionParametersFromValue | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersFromValueToHclTerraform(struct?: RulesetRulesActionParametersFromValue | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersFromValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersFromValue | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersFromValue | cdktn.IResolvable | undefined);
    private _preserveQueryString?;
    get preserveQueryString(): boolean | cdktn.IResolvable;
    set preserveQueryString(value: boolean | cdktn.IResolvable);
    resetPreserveQueryString(): void;
    get preserveQueryStringInput(): boolean | cdktn.IResolvable | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _targetUrl;
    get targetUrl(): RulesetRulesActionParametersFromValueTargetUrlList;
    putTargetUrl(value: RulesetRulesActionParametersFromValueTargetUrl[] | cdktn.IResolvable): void;
    resetTargetUrl(): void;
    get targetUrlInput(): cdktn.IResolvable | RulesetRulesActionParametersFromValueTargetUrl[] | undefined;
}
export declare class RulesetRulesActionParametersFromValueList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersFromValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersFromValueOutputReference;
}
export interface RulesetRulesActionParametersHeaders {
    /**
    * Use a value dynamically determined by the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * Name of the HTTP request header to target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name?: string;
    /**
    * Action to perform on the HTTP request header. Available values: `remove`, `set`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation?: string;
    /**
    * Static value to provide as the HTTP request header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersHeadersToTerraform(struct?: RulesetRulesActionParametersHeaders | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersHeadersToHclTerraform(struct?: RulesetRulesActionParametersHeaders | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersHeaders | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    resetOperation(): void;
    get operationInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersHeadersList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersHeadersOutputReference;
}
export interface RulesetRulesActionParametersMatchedData {
    /**
    * Public key to use within WAF Ruleset payload logging to view the HTTP request parameters. You can generate a public key [using the `matched-data-cli` command-line tool](https://developers.cloudflare.com/waf/managed-rulesets/payload-logging/command-line/generate-key-pair) or [in the Cloudflare dashboard](https://developers.cloudflare.com/waf/managed-rulesets/payload-logging/configure).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#public_key Ruleset#public_key}
    */
    readonly publicKey?: string;
}
export declare function rulesetRulesActionParametersMatchedDataToTerraform(struct?: RulesetRulesActionParametersMatchedData | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersMatchedDataToHclTerraform(struct?: RulesetRulesActionParametersMatchedData | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersMatchedDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersMatchedData | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersMatchedData | cdktn.IResolvable | undefined);
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    resetPublicKey(): void;
    get publicKeyInput(): string | undefined;
}
export declare class RulesetRulesActionParametersMatchedDataList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersMatchedData[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersMatchedDataOutputReference;
}
export interface RulesetRulesActionParametersOrigin {
    /**
    * Origin Hostname where request is sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#host Ruleset#host}
    */
    readonly host?: string;
    /**
    * Origin Port where request is sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#port Ruleset#port}
    */
    readonly port?: number;
}
export declare function rulesetRulesActionParametersOriginToTerraform(struct?: RulesetRulesActionParametersOrigin | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersOriginToHclTerraform(struct?: RulesetRulesActionParametersOrigin | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOrigin | cdktn.IResolvable | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export declare class RulesetRulesActionParametersOriginList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersOrigin[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOriginOutputReference;
}
export interface RulesetRulesActionParametersOverridesCategories {
    /**
    * Action to perform in the tag-level override. Available values: `allow`, `block`, `challenge`, `ddos_dynamic`, `execute`, `force_connection_close`, `js_challenge`, `log`, `log_custom_field`, `managed_challenge`, `redirect`, `rewrite`, `route`, `score`, `set_cache_settings`, `set_config`, `serve_error`, `skip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * Tag name to apply the ruleset rule override to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#category Ruleset#category}
    */
    readonly category?: string;
    /**
    * Defines if the current tag-level override enables or disables the ruleset rules with the specified tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersOverridesCategoriesToTerraform(struct?: RulesetRulesActionParametersOverridesCategories | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersOverridesCategoriesToHclTerraform(struct?: RulesetRulesActionParametersOverridesCategories | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersOverridesCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersOverridesCategories | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOverridesCategories | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersOverridesCategoriesList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersOverridesCategories[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOverridesCategoriesOutputReference;
}
export interface RulesetRulesActionParametersOverridesRules {
    /**
    * Action to perform in the rule-level override. Available values: `allow`, `block`, `challenge`, `ddos_dynamic`, `execute`, `force_connection_close`, `js_challenge`, `log`, `log_custom_field`, `managed_challenge`, `redirect`, `rewrite`, `route`, `score`, `set_cache_settings`, `set_config`, `serve_error`, `skip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * Defines if the current rule-level override enables or disables the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Rule ID to apply the override to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#id Ruleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Anomaly score threshold to apply in the ruleset rule override. Only applicable to modsecurity-based rulesets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#score_threshold Ruleset#score_threshold}
    */
    readonly scoreThreshold?: number;
    /**
    * Sensitivity level for a ruleset rule override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#sensitivity_level Ruleset#sensitivity_level}
    */
    readonly sensitivityLevel?: string;
}
export declare function rulesetRulesActionParametersOverridesRulesToTerraform(struct?: RulesetRulesActionParametersOverridesRules | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersOverridesRulesToHclTerraform(struct?: RulesetRulesActionParametersOverridesRules | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersOverridesRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersOverridesRules | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOverridesRules | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _scoreThreshold?;
    get scoreThreshold(): number;
    set scoreThreshold(value: number);
    resetScoreThreshold(): void;
    get scoreThresholdInput(): number | undefined;
    private _sensitivityLevel?;
    get sensitivityLevel(): string;
    set sensitivityLevel(value: string);
    resetSensitivityLevel(): void;
    get sensitivityLevelInput(): string | undefined;
}
export declare class RulesetRulesActionParametersOverridesRulesList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersOverridesRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOverridesRulesOutputReference;
}
export interface RulesetRulesActionParametersOverrides {
    /**
    * Action to perform in the rule-level override. Available values: `allow`, `block`, `challenge`, `ddos_dynamic`, `execute`, `force_connection_close`, `js_challenge`, `log`, `log_custom_field`, `managed_challenge`, `redirect`, `rewrite`, `route`, `score`, `set_cache_settings`, `set_config`, `serve_error`, `skip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * Defines if the current ruleset-level override enables or disables the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Sensitivity level to override for all ruleset rules. Available values: `default`, `medium`, `low`, `eoff`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#sensitivity_level Ruleset#sensitivity_level}
    */
    readonly sensitivityLevel?: string;
    /**
    * categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#categories Ruleset#categories}
    */
    readonly categories?: RulesetRulesActionParametersOverridesCategories[] | cdktn.IResolvable;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#rules Ruleset#rules}
    */
    readonly rules?: RulesetRulesActionParametersOverridesRules[] | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersOverridesToTerraform(struct?: RulesetRulesActionParametersOverrides | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersOverridesToHclTerraform(struct?: RulesetRulesActionParametersOverrides | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOverrides | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sensitivityLevel?;
    get sensitivityLevel(): string;
    set sensitivityLevel(value: string);
    resetSensitivityLevel(): void;
    get sensitivityLevelInput(): string | undefined;
    private _categories;
    get categories(): RulesetRulesActionParametersOverridesCategoriesList;
    putCategories(value: RulesetRulesActionParametersOverridesCategories[] | cdktn.IResolvable): void;
    resetCategories(): void;
    get categoriesInput(): cdktn.IResolvable | RulesetRulesActionParametersOverridesCategories[] | undefined;
    private _rules;
    get rules(): RulesetRulesActionParametersOverridesRulesList;
    putRules(value: RulesetRulesActionParametersOverridesRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | RulesetRulesActionParametersOverridesRules[] | undefined;
}
export declare class RulesetRulesActionParametersOverridesList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOverridesOutputReference;
}
export interface RulesetRulesActionParametersResponse {
    /**
    * Body content to include in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#content Ruleset#content}
    */
    readonly content?: string;
    /**
    * HTTP content type to send in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#content_type Ruleset#content_type}
    */
    readonly contentType?: string;
    /**
    * HTTP status code to send in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
}
export declare function rulesetRulesActionParametersResponseToTerraform(struct?: RulesetRulesActionParametersResponse | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersResponseToHclTerraform(struct?: RulesetRulesActionParametersResponse | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersResponse | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersResponse | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
}
export declare class RulesetRulesActionParametersResponseList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersResponse[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersResponseOutputReference;
}
export interface RulesetRulesActionParametersServeStale {
    /**
    * Disable stale while updating.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#disable_stale_while_updating Ruleset#disable_stale_while_updating}
    */
    readonly disableStaleWhileUpdating?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersServeStaleToTerraform(struct?: RulesetRulesActionParametersServeStale | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersServeStaleToHclTerraform(struct?: RulesetRulesActionParametersServeStale | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersServeStaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersServeStale | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersServeStale | cdktn.IResolvable | undefined);
    private _disableStaleWhileUpdating?;
    get disableStaleWhileUpdating(): boolean | cdktn.IResolvable;
    set disableStaleWhileUpdating(value: boolean | cdktn.IResolvable);
    resetDisableStaleWhileUpdating(): void;
    get disableStaleWhileUpdatingInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersServeStaleList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersServeStale[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersServeStaleOutputReference;
}
export interface RulesetRulesActionParametersSni {
    /**
    * Value to define for SNI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersSniToTerraform(struct?: RulesetRulesActionParametersSni | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersSniToHclTerraform(struct?: RulesetRulesActionParametersSni | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersSniOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersSni | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersSni | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersSniList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersSni[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersSniOutputReference;
}
export interface RulesetRulesActionParametersUriPath {
    /**
    * Expression that defines the updated (dynamic) value of the URI path or query string component. Uses the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * Static string value of the updated URI path or query string component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersUriPathToTerraform(struct?: RulesetRulesActionParametersUriPath | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersUriPathToHclTerraform(struct?: RulesetRulesActionParametersUriPath | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersUriPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersUriPath | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersUriPath | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersUriPathList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersUriPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersUriPathOutputReference;
}
export interface RulesetRulesActionParametersUriQuery {
    /**
    * Expression that defines the updated (dynamic) value of the URI path or query string component. Uses the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * Static string value of the updated URI path or query string component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersUriQueryToTerraform(struct?: RulesetRulesActionParametersUriQuery | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersUriQueryToHclTerraform(struct?: RulesetRulesActionParametersUriQuery | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersUriQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersUriQuery | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersUriQuery | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersUriQueryList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersUriQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersUriQueryOutputReference;
}
export interface RulesetRulesActionParametersUri {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#origin Ruleset#origin}
    */
    readonly origin?: boolean | cdktn.IResolvable;
    /**
    * path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#path Ruleset#path}
    */
    readonly path?: RulesetRulesActionParametersUriPath[] | cdktn.IResolvable;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#query Ruleset#query}
    */
    readonly query?: RulesetRulesActionParametersUriQuery[] | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersUriToTerraform(struct?: RulesetRulesActionParametersUri | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersUriToHclTerraform(struct?: RulesetRulesActionParametersUri | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersUriOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersUri | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersUri | cdktn.IResolvable | undefined);
    private _origin?;
    get origin(): boolean | cdktn.IResolvable;
    set origin(value: boolean | cdktn.IResolvable);
    resetOrigin(): void;
    get originInput(): boolean | cdktn.IResolvable | undefined;
    private _path;
    get path(): RulesetRulesActionParametersUriPathList;
    putPath(value: RulesetRulesActionParametersUriPath[] | cdktn.IResolvable): void;
    resetPath(): void;
    get pathInput(): cdktn.IResolvable | RulesetRulesActionParametersUriPath[] | undefined;
    private _query;
    get query(): RulesetRulesActionParametersUriQueryList;
    putQuery(value: RulesetRulesActionParametersUriQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | RulesetRulesActionParametersUriQuery[] | undefined;
}
export declare class RulesetRulesActionParametersUriList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParametersUri[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersUriOutputReference;
}
export interface RulesetRulesActionParameters {
    /**
    * Turn on or off Cloudflare Automatic HTTPS rewrites.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#automatic_https_rewrites Ruleset#automatic_https_rewrites}
    */
    readonly automaticHttpsRewrites?: boolean | cdktn.IResolvable;
    /**
    * Inspect the visitor's browser for headers commonly associated with spammers and certain bots.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#bic Ruleset#bic}
    */
    readonly bic?: boolean | cdktn.IResolvable;
    /**
    * Whether to cache if expression matches.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cache Ruleset#cache}
    */
    readonly cache?: boolean | cdktn.IResolvable;
    /**
    * Content of the custom error response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#content Ruleset#content}
    */
    readonly content?: string;
    /**
    * Content-Type of the custom error response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#content_type Ruleset#content_type}
    */
    readonly contentType?: string;
    /**
    * List of cookie values to include as part of custom fields logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cookie_fields Ruleset#cookie_fields}
    */
    readonly cookieFields?: string[];
    /**
    * Turn off all active Cloudflare Apps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#disable_apps Ruleset#disable_apps}
    */
    readonly disableApps?: boolean | cdktn.IResolvable;
    /**
    * Turn off railgun feature of the Cloudflare Speed app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#disable_railgun Ruleset#disable_railgun}
    */
    readonly disableRailgun?: boolean | cdktn.IResolvable;
    /**
    * Turn off zaraz feature.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#disable_zaraz Ruleset#disable_zaraz}
    */
    readonly disableZaraz?: boolean | cdktn.IResolvable;
    /**
    * Turn on or off the Cloudflare Email Obfuscation feature of the Cloudflare Scrape Shield app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#email_obfuscation Ruleset#email_obfuscation}
    */
    readonly emailObfuscation?: boolean | cdktn.IResolvable;
    /**
    * Host Header that request origin receives.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#host_header Ruleset#host_header}
    */
    readonly hostHeader?: string;
    /**
    * Turn on or off the hotlink protection feature.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#hotlink_protection Ruleset#hotlink_protection}
    */
    readonly hotlinkProtection?: boolean | cdktn.IResolvable;
    /**
    * Identifier of the action parameter to modify.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#id Ruleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#increment Ruleset#increment}
    */
    readonly increment?: number;
    /**
    * Turn on or off Cloudflare Mirage of the Cloudflare Speed app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#mirage Ruleset#mirage}
    */
    readonly mirage?: boolean | cdktn.IResolvable;
    /**
    * Turn on or off the Cloudflare Opportunistic Encryption feature of the Edge Certificates tab in the Cloudflare SSL/TLS app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#opportunistic_encryption Ruleset#opportunistic_encryption}
    */
    readonly opportunisticEncryption?: boolean | cdktn.IResolvable;
    /**
    * Pass-through error page for origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#origin_error_page_passthru Ruleset#origin_error_page_passthru}
    */
    readonly originErrorPagePassthru?: boolean | cdktn.IResolvable;
    /**
    * Point in the request/response lifecycle where the ruleset will be created. Available values: `ddos_l4`, `ddos_l7`, `http_custom_errors`, `http_log_custom_fields`, `http_request_cache_settings`, `http_request_firewall_custom`, `http_request_firewall_managed`, `http_request_late_transform`, `http_request_late_transform_managed`, `http_request_main`, `http_request_origin`, `http_request_dynamic_redirect`, `http_request_redirect`, `http_request_sanitize`, `http_request_transform`, `http_response_firewall_managed`, `http_response_headers_transform`, `http_response_headers_transform_managed`, `magic_transit`, `http_ratelimit`, `http_request_sbfm`, `http_config_settings`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#phases Ruleset#phases}
    */
    readonly phases?: string[];
    /**
    * Apply options from the Polish feature of the Cloudflare Speed app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#polish Ruleset#polish}
    */
    readonly polish?: string;
    /**
    * Products to target with the actions. Available values: `bic`, `hot`, `ratelimit`, `securityLevel`, `uablock`, `waf`, `zonelockdown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#products Ruleset#products}
    */
    readonly products?: string[];
    /**
    * List of request headers to include as part of custom fields logging, in lowercase.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#request_fields Ruleset#request_fields}
    */
    readonly requestFields?: string[];
    /**
    * Respect strong ETags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#respect_strong_etags Ruleset#respect_strong_etags}
    */
    readonly respectStrongEtags?: boolean | cdktn.IResolvable;
    /**
    * List of response headers to include as part of custom fields logging, in lowercase.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#response_fields Ruleset#response_fields}
    */
    readonly responseFields?: string[];
    /**
    * Turn on or off Cloudflare Rocket Loader in the Cloudflare Speed app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#rocket_loader Ruleset#rocket_loader}
    */
    readonly rocketLoader?: boolean | cdktn.IResolvable;
    /**
    * Map of managed WAF rule ID to comma-delimited string of ruleset rule IDs. Example: `rules = { "efb7b8c949ac4650a09736fc376e9aee" = "5de7edfa648c4d6891dc3e7f84534ffa,e3a567afc347477d9702d9047e97d760" }`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#rules Ruleset#rules}
    */
    readonly rules?: {
        [key: string]: string;
    };
    /**
    * Which ruleset ID to target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#ruleset Ruleset#ruleset}
    */
    readonly ruleset?: string;
    /**
    * List of managed WAF rule IDs to target. Only valid when the `"action"` is set to skip.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#rulesets Ruleset#rulesets}
    */
    readonly rulesets?: string[];
    /**
    * Control options for the Security Level feature from the Security app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#security_level Ruleset#security_level}
    */
    readonly securityLevel?: string;
    /**
    * Turn on or off the Server Side Excludes feature of the Cloudflare Scrape Shield app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#server_side_excludes Ruleset#server_side_excludes}
    */
    readonly serverSideExcludes?: boolean | cdktn.IResolvable;
    /**
    * Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#ssl Ruleset#ssl}
    */
    readonly ssl?: string;
    /**
    * HTTP status code of the custom error response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
    /**
    * Turn on or off the SXG feature.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#sxg Ruleset#sxg}
    */
    readonly sxg?: boolean | cdktn.IResolvable;
    /**
    * Version of the ruleset to deploy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#version Ruleset#version}
    */
    readonly version?: string;
    /**
    * autominify block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#autominify Ruleset#autominify}
    */
    readonly autominify?: RulesetRulesActionParametersAutominify[] | cdktn.IResolvable;
    /**
    * browser_ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#browser_ttl Ruleset#browser_ttl}
    */
    readonly browserTtl?: RulesetRulesActionParametersBrowserTtl[] | cdktn.IResolvable;
    /**
    * cache_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#cache_key Ruleset#cache_key}
    */
    readonly cacheKey?: RulesetRulesActionParametersCacheKey[] | cdktn.IResolvable;
    /**
    * edge_ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#edge_ttl Ruleset#edge_ttl}
    */
    readonly edgeTtl?: RulesetRulesActionParametersEdgeTtl[] | cdktn.IResolvable;
    /**
    * from_list block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#from_list Ruleset#from_list}
    */
    readonly fromList?: RulesetRulesActionParametersFromListStruct[] | cdktn.IResolvable;
    /**
    * from_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#from_value Ruleset#from_value}
    */
    readonly fromValue?: RulesetRulesActionParametersFromValue[] | cdktn.IResolvable;
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#headers Ruleset#headers}
    */
    readonly headers?: RulesetRulesActionParametersHeaders[] | cdktn.IResolvable;
    /**
    * matched_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#matched_data Ruleset#matched_data}
    */
    readonly matchedData?: RulesetRulesActionParametersMatchedData[] | cdktn.IResolvable;
    /**
    * origin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#origin Ruleset#origin}
    */
    readonly origin?: RulesetRulesActionParametersOrigin[] | cdktn.IResolvable;
    /**
    * overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#overrides Ruleset#overrides}
    */
    readonly overrides?: RulesetRulesActionParametersOverrides[] | cdktn.IResolvable;
    /**
    * response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#response Ruleset#response}
    */
    readonly response?: RulesetRulesActionParametersResponse[] | cdktn.IResolvable;
    /**
    * serve_stale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#serve_stale Ruleset#serve_stale}
    */
    readonly serveStale?: RulesetRulesActionParametersServeStale[] | cdktn.IResolvable;
    /**
    * sni block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#sni Ruleset#sni}
    */
    readonly sni?: RulesetRulesActionParametersSni[] | cdktn.IResolvable;
    /**
    * uri block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#uri Ruleset#uri}
    */
    readonly uri?: RulesetRulesActionParametersUri[] | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersToTerraform(struct?: RulesetRulesActionParameters | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersToHclTerraform(struct?: RulesetRulesActionParameters | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParameters | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParameters | cdktn.IResolvable | undefined);
    private _automaticHttpsRewrites?;
    get automaticHttpsRewrites(): boolean | cdktn.IResolvable;
    set automaticHttpsRewrites(value: boolean | cdktn.IResolvable);
    resetAutomaticHttpsRewrites(): void;
    get automaticHttpsRewritesInput(): boolean | cdktn.IResolvable | undefined;
    private _bic?;
    get bic(): boolean | cdktn.IResolvable;
    set bic(value: boolean | cdktn.IResolvable);
    resetBic(): void;
    get bicInput(): boolean | cdktn.IResolvable | undefined;
    private _cache?;
    get cache(): boolean | cdktn.IResolvable;
    set cache(value: boolean | cdktn.IResolvable);
    resetCache(): void;
    get cacheInput(): boolean | cdktn.IResolvable | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _cookieFields?;
    get cookieFields(): string[];
    set cookieFields(value: string[]);
    resetCookieFields(): void;
    get cookieFieldsInput(): string[] | undefined;
    private _disableApps?;
    get disableApps(): boolean | cdktn.IResolvable;
    set disableApps(value: boolean | cdktn.IResolvable);
    resetDisableApps(): void;
    get disableAppsInput(): boolean | cdktn.IResolvable | undefined;
    private _disableRailgun?;
    get disableRailgun(): boolean | cdktn.IResolvable;
    set disableRailgun(value: boolean | cdktn.IResolvable);
    resetDisableRailgun(): void;
    get disableRailgunInput(): boolean | cdktn.IResolvable | undefined;
    private _disableZaraz?;
    get disableZaraz(): boolean | cdktn.IResolvable;
    set disableZaraz(value: boolean | cdktn.IResolvable);
    resetDisableZaraz(): void;
    get disableZarazInput(): boolean | cdktn.IResolvable | undefined;
    private _emailObfuscation?;
    get emailObfuscation(): boolean | cdktn.IResolvable;
    set emailObfuscation(value: boolean | cdktn.IResolvable);
    resetEmailObfuscation(): void;
    get emailObfuscationInput(): boolean | cdktn.IResolvable | undefined;
    private _hostHeader?;
    get hostHeader(): string;
    set hostHeader(value: string);
    resetHostHeader(): void;
    get hostHeaderInput(): string | undefined;
    private _hotlinkProtection?;
    get hotlinkProtection(): boolean | cdktn.IResolvable;
    set hotlinkProtection(value: boolean | cdktn.IResolvable);
    resetHotlinkProtection(): void;
    get hotlinkProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _increment?;
    get increment(): number;
    set increment(value: number);
    resetIncrement(): void;
    get incrementInput(): number | undefined;
    private _mirage?;
    get mirage(): boolean | cdktn.IResolvable;
    set mirage(value: boolean | cdktn.IResolvable);
    resetMirage(): void;
    get mirageInput(): boolean | cdktn.IResolvable | undefined;
    private _opportunisticEncryption?;
    get opportunisticEncryption(): boolean | cdktn.IResolvable;
    set opportunisticEncryption(value: boolean | cdktn.IResolvable);
    resetOpportunisticEncryption(): void;
    get opportunisticEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _originErrorPagePassthru?;
    get originErrorPagePassthru(): boolean | cdktn.IResolvable;
    set originErrorPagePassthru(value: boolean | cdktn.IResolvable);
    resetOriginErrorPagePassthru(): void;
    get originErrorPagePassthruInput(): boolean | cdktn.IResolvable | undefined;
    private _phases?;
    get phases(): string[];
    set phases(value: string[]);
    resetPhases(): void;
    get phasesInput(): string[] | undefined;
    private _polish?;
    get polish(): string;
    set polish(value: string);
    resetPolish(): void;
    get polishInput(): string | undefined;
    private _products?;
    get products(): string[];
    set products(value: string[]);
    resetProducts(): void;
    get productsInput(): string[] | undefined;
    private _requestFields?;
    get requestFields(): string[];
    set requestFields(value: string[]);
    resetRequestFields(): void;
    get requestFieldsInput(): string[] | undefined;
    private _respectStrongEtags?;
    get respectStrongEtags(): boolean | cdktn.IResolvable;
    set respectStrongEtags(value: boolean | cdktn.IResolvable);
    resetRespectStrongEtags(): void;
    get respectStrongEtagsInput(): boolean | cdktn.IResolvable | undefined;
    private _responseFields?;
    get responseFields(): string[];
    set responseFields(value: string[]);
    resetResponseFields(): void;
    get responseFieldsInput(): string[] | undefined;
    private _rocketLoader?;
    get rocketLoader(): boolean | cdktn.IResolvable;
    set rocketLoader(value: boolean | cdktn.IResolvable);
    resetRocketLoader(): void;
    get rocketLoaderInput(): boolean | cdktn.IResolvable | undefined;
    private _rules?;
    get rules(): {
        [key: string]: string;
    };
    set rules(value: {
        [key: string]: string;
    });
    resetRules(): void;
    get rulesInput(): {
        [key: string]: string;
    } | undefined;
    private _ruleset?;
    get ruleset(): string;
    set ruleset(value: string);
    resetRuleset(): void;
    get rulesetInput(): string | undefined;
    private _rulesets?;
    get rulesets(): string[];
    set rulesets(value: string[]);
    resetRulesets(): void;
    get rulesetsInput(): string[] | undefined;
    private _securityLevel?;
    get securityLevel(): string;
    set securityLevel(value: string);
    resetSecurityLevel(): void;
    get securityLevelInput(): string | undefined;
    private _serverSideExcludes?;
    get serverSideExcludes(): boolean | cdktn.IResolvable;
    set serverSideExcludes(value: boolean | cdktn.IResolvable);
    resetServerSideExcludes(): void;
    get serverSideExcludesInput(): boolean | cdktn.IResolvable | undefined;
    private _ssl?;
    get ssl(): string;
    set ssl(value: string);
    resetSsl(): void;
    get sslInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _sxg?;
    get sxg(): boolean | cdktn.IResolvable;
    set sxg(value: boolean | cdktn.IResolvable);
    resetSxg(): void;
    get sxgInput(): boolean | cdktn.IResolvable | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _autominify;
    get autominify(): RulesetRulesActionParametersAutominifyList;
    putAutominify(value: RulesetRulesActionParametersAutominify[] | cdktn.IResolvable): void;
    resetAutominify(): void;
    get autominifyInput(): cdktn.IResolvable | RulesetRulesActionParametersAutominify[] | undefined;
    private _browserTtl;
    get browserTtl(): RulesetRulesActionParametersBrowserTtlList;
    putBrowserTtl(value: RulesetRulesActionParametersBrowserTtl[] | cdktn.IResolvable): void;
    resetBrowserTtl(): void;
    get browserTtlInput(): cdktn.IResolvable | RulesetRulesActionParametersBrowserTtl[] | undefined;
    private _cacheKey;
    get cacheKey(): RulesetRulesActionParametersCacheKeyList;
    putCacheKey(value: RulesetRulesActionParametersCacheKey[] | cdktn.IResolvable): void;
    resetCacheKey(): void;
    get cacheKeyInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKey[] | undefined;
    private _edgeTtl;
    get edgeTtl(): RulesetRulesActionParametersEdgeTtlList;
    putEdgeTtl(value: RulesetRulesActionParametersEdgeTtl[] | cdktn.IResolvable): void;
    resetEdgeTtl(): void;
    get edgeTtlInput(): cdktn.IResolvable | RulesetRulesActionParametersEdgeTtl[] | undefined;
    private _fromList;
    get fromList(): RulesetRulesActionParametersFromListStructList;
    putFromList(value: RulesetRulesActionParametersFromListStruct[] | cdktn.IResolvable): void;
    resetFromList(): void;
    get fromListInput(): cdktn.IResolvable | RulesetRulesActionParametersFromListStruct[] | undefined;
    private _fromValue;
    get fromValue(): RulesetRulesActionParametersFromValueList;
    putFromValue(value: RulesetRulesActionParametersFromValue[] | cdktn.IResolvable): void;
    resetFromValue(): void;
    get fromValueInput(): cdktn.IResolvable | RulesetRulesActionParametersFromValue[] | undefined;
    private _headers;
    get headers(): RulesetRulesActionParametersHeadersList;
    putHeaders(value: RulesetRulesActionParametersHeaders[] | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | RulesetRulesActionParametersHeaders[] | undefined;
    private _matchedData;
    get matchedData(): RulesetRulesActionParametersMatchedDataList;
    putMatchedData(value: RulesetRulesActionParametersMatchedData[] | cdktn.IResolvable): void;
    resetMatchedData(): void;
    get matchedDataInput(): cdktn.IResolvable | RulesetRulesActionParametersMatchedData[] | undefined;
    private _origin;
    get origin(): RulesetRulesActionParametersOriginList;
    putOrigin(value: RulesetRulesActionParametersOrigin[] | cdktn.IResolvable): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | RulesetRulesActionParametersOrigin[] | undefined;
    private _overrides;
    get overrides(): RulesetRulesActionParametersOverridesList;
    putOverrides(value: RulesetRulesActionParametersOverrides[] | cdktn.IResolvable): void;
    resetOverrides(): void;
    get overridesInput(): cdktn.IResolvable | RulesetRulesActionParametersOverrides[] | undefined;
    private _response;
    get response(): RulesetRulesActionParametersResponseList;
    putResponse(value: RulesetRulesActionParametersResponse[] | cdktn.IResolvable): void;
    resetResponse(): void;
    get responseInput(): cdktn.IResolvable | RulesetRulesActionParametersResponse[] | undefined;
    private _serveStale;
    get serveStale(): RulesetRulesActionParametersServeStaleList;
    putServeStale(value: RulesetRulesActionParametersServeStale[] | cdktn.IResolvable): void;
    resetServeStale(): void;
    get serveStaleInput(): cdktn.IResolvable | RulesetRulesActionParametersServeStale[] | undefined;
    private _sni;
    get sni(): RulesetRulesActionParametersSniList;
    putSni(value: RulesetRulesActionParametersSni[] | cdktn.IResolvable): void;
    resetSni(): void;
    get sniInput(): cdktn.IResolvable | RulesetRulesActionParametersSni[] | undefined;
    private _uri;
    get uri(): RulesetRulesActionParametersUriList;
    putUri(value: RulesetRulesActionParametersUri[] | cdktn.IResolvable): void;
    resetUri(): void;
    get uriInput(): cdktn.IResolvable | RulesetRulesActionParametersUri[] | undefined;
}
export declare class RulesetRulesActionParametersList extends cdktn.ComplexList {
    internalValue?: RulesetRulesActionParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOutputReference;
}
export interface RulesetRulesExposedCredentialCheck {
    /**
    * Firewall Rules expression language based on Wireshark display filters for where to check for the "password" value. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#password_expression Ruleset#password_expression}
    */
    readonly passwordExpression?: string;
    /**
    * Firewall Rules expression language based on Wireshark display filters for where to check for the "username" value. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#username_expression Ruleset#username_expression}
    */
    readonly usernameExpression?: string;
}
export declare function rulesetRulesExposedCredentialCheckToTerraform(struct?: RulesetRulesExposedCredentialCheck | cdktn.IResolvable): any;
export declare function rulesetRulesExposedCredentialCheckToHclTerraform(struct?: RulesetRulesExposedCredentialCheck | cdktn.IResolvable): any;
export declare class RulesetRulesExposedCredentialCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesExposedCredentialCheck | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesExposedCredentialCheck | cdktn.IResolvable | undefined);
    private _passwordExpression?;
    get passwordExpression(): string;
    set passwordExpression(value: string);
    resetPasswordExpression(): void;
    get passwordExpressionInput(): string | undefined;
    private _usernameExpression?;
    get usernameExpression(): string;
    set usernameExpression(value: string);
    resetUsernameExpression(): void;
    get usernameExpressionInput(): string | undefined;
}
export declare class RulesetRulesExposedCredentialCheckList extends cdktn.ComplexList {
    internalValue?: RulesetRulesExposedCredentialCheck[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesExposedCredentialCheckOutputReference;
}
export interface RulesetRulesLogging {
    /**
    * Override the default logging behavior when a rule is matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesLoggingToTerraform(struct?: RulesetRulesLogging | cdktn.IResolvable): any;
export declare function rulesetRulesLoggingToHclTerraform(struct?: RulesetRulesLogging | cdktn.IResolvable): any;
export declare class RulesetRulesLoggingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesLogging | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesLogging | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class RulesetRulesLoggingList extends cdktn.ComplexList {
    internalValue?: RulesetRulesLogging[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesLoggingOutputReference;
}
export interface RulesetRulesRatelimit {
    /**
    * List of parameters that define how Cloudflare tracks the request rate for this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#characteristics Ruleset#characteristics}
    */
    readonly characteristics?: string[];
    /**
    * Criteria for counting HTTP requests to trigger the Rate Limiting action. Uses the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#counting_expression Ruleset#counting_expression}
    */
    readonly countingExpression?: string;
    /**
    * Once the request rate is reached, the Rate Limiting rule blocks further requests for the period of time defined in this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#mitigation_timeout Ruleset#mitigation_timeout}
    */
    readonly mitigationTimeout?: number;
    /**
    * The period of time to consider (in seconds) when evaluating the request rate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#period Ruleset#period}
    */
    readonly period?: number;
    /**
    * The number of requests over the period of time that will trigger the Rate Limiting rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#requests_per_period Ruleset#requests_per_period}
    */
    readonly requestsPerPeriod?: number;
    /**
    * Whether to include requests to origin within the Rate Limiting count.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#requests_to_origin Ruleset#requests_to_origin}
    */
    readonly requestsToOrigin?: boolean | cdktn.IResolvable;
    /**
    * The maximum aggregate score over the period of time that will trigger Rate Limiting rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#score_per_period Ruleset#score_per_period}
    */
    readonly scorePerPeriod?: number;
    /**
    * Name of HTTP header in the response, set by the origin server, with the score for the current request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#score_response_header_name Ruleset#score_response_header_name}
    */
    readonly scoreResponseHeaderName?: string;
}
export declare function rulesetRulesRatelimitToTerraform(struct?: RulesetRulesRatelimit | cdktn.IResolvable): any;
export declare function rulesetRulesRatelimitToHclTerraform(struct?: RulesetRulesRatelimit | cdktn.IResolvable): any;
export declare class RulesetRulesRatelimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesRatelimit | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesRatelimit | cdktn.IResolvable | undefined);
    private _characteristics?;
    get characteristics(): string[];
    set characteristics(value: string[]);
    resetCharacteristics(): void;
    get characteristicsInput(): string[] | undefined;
    private _countingExpression?;
    get countingExpression(): string;
    set countingExpression(value: string);
    resetCountingExpression(): void;
    get countingExpressionInput(): string | undefined;
    private _mitigationTimeout?;
    get mitigationTimeout(): number;
    set mitigationTimeout(value: number);
    resetMitigationTimeout(): void;
    get mitigationTimeoutInput(): number | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _requestsPerPeriod?;
    get requestsPerPeriod(): number;
    set requestsPerPeriod(value: number);
    resetRequestsPerPeriod(): void;
    get requestsPerPeriodInput(): number | undefined;
    private _requestsToOrigin?;
    get requestsToOrigin(): boolean | cdktn.IResolvable;
    set requestsToOrigin(value: boolean | cdktn.IResolvable);
    resetRequestsToOrigin(): void;
    get requestsToOriginInput(): boolean | cdktn.IResolvable | undefined;
    private _scorePerPeriod?;
    get scorePerPeriod(): number;
    set scorePerPeriod(value: number);
    resetScorePerPeriod(): void;
    get scorePerPeriodInput(): number | undefined;
    private _scoreResponseHeaderName?;
    get scoreResponseHeaderName(): string;
    set scoreResponseHeaderName(value: string);
    resetScoreResponseHeaderName(): void;
    get scoreResponseHeaderNameInput(): string | undefined;
}
export declare class RulesetRulesRatelimitList extends cdktn.ComplexList {
    internalValue?: RulesetRulesRatelimit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesRatelimitOutputReference;
}
export interface RulesetRules {
    /**
    * Action to perform in the ruleset rule. Available values: `allow`, `block`, `challenge`, `ddos_dynamic`, `execute`, `force_connection_close`, `js_challenge`, `log`, `log_custom_field`, `managed_challenge`, `redirect`, `rewrite`, `route`, `score`, `set_cache_settings`, `set_config`, `serve_error`, `skip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * Brief summary of the ruleset rule and its intended use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#description Ruleset#description}
    */
    readonly description?: string;
    /**
    * Whether the rule is active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Criteria for an HTTP request to trigger the ruleset rule action. Uses the Firewall Rules expression language based on Wireshark display filters. Refer to the [Firewall Rules language](https://developers.cloudflare.com/firewall/cf-firewall-language) documentation for all available fields, operators, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression: string;
    /**
    * Unique rule identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#id Ruleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The most recent update to this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#last_updated Ruleset#last_updated}
    */
    readonly lastUpdated?: string;
    /**
    * Rule reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#ref Ruleset#ref}
    */
    readonly ref?: string;
    /**
    * Version of the ruleset to deploy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#version Ruleset#version}
    */
    readonly version?: string;
    /**
    * action_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#action_parameters Ruleset#action_parameters}
    */
    readonly actionParameters?: RulesetRulesActionParameters[] | cdktn.IResolvable;
    /**
    * exposed_credential_check block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#exposed_credential_check Ruleset#exposed_credential_check}
    */
    readonly exposedCredentialCheck?: RulesetRulesExposedCredentialCheck[] | cdktn.IResolvable;
    /**
    * logging block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#logging Ruleset#logging}
    */
    readonly logging?: RulesetRulesLogging[] | cdktn.IResolvable;
    /**
    * ratelimit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#ratelimit Ruleset#ratelimit}
    */
    readonly ratelimit?: RulesetRulesRatelimit[] | cdktn.IResolvable;
}
export declare function rulesetRulesToTerraform(struct?: RulesetRules | cdktn.IResolvable): any;
export declare function rulesetRulesToHclTerraform(struct?: RulesetRules | cdktn.IResolvable): any;
export declare class RulesetRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRules | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRules | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lastUpdated?;
    get lastUpdated(): string;
    set lastUpdated(value: string);
    resetLastUpdated(): void;
    get lastUpdatedInput(): string | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _actionParameters;
    get actionParameters(): RulesetRulesActionParametersList;
    putActionParameters(value: RulesetRulesActionParameters[] | cdktn.IResolvable): void;
    resetActionParameters(): void;
    get actionParametersInput(): cdktn.IResolvable | RulesetRulesActionParameters[] | undefined;
    private _exposedCredentialCheck;
    get exposedCredentialCheck(): RulesetRulesExposedCredentialCheckList;
    putExposedCredentialCheck(value: RulesetRulesExposedCredentialCheck[] | cdktn.IResolvable): void;
    resetExposedCredentialCheck(): void;
    get exposedCredentialCheckInput(): cdktn.IResolvable | RulesetRulesExposedCredentialCheck[] | undefined;
    private _logging;
    get logging(): RulesetRulesLoggingList;
    putLogging(value: RulesetRulesLogging[] | cdktn.IResolvable): void;
    resetLogging(): void;
    get loggingInput(): cdktn.IResolvable | RulesetRulesLogging[] | undefined;
    private _ratelimit;
    get ratelimit(): RulesetRulesRatelimitList;
    putRatelimit(value: RulesetRulesRatelimit[] | cdktn.IResolvable): void;
    resetRatelimit(): void;
    get ratelimitInput(): cdktn.IResolvable | RulesetRulesRatelimit[] | undefined;
}
export declare class RulesetRulesList extends cdktn.ComplexList {
    internalValue?: RulesetRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset cloudflare_ruleset}
*/
export declare class Ruleset extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_ruleset";
    /**
    * Generates CDKTN code for importing a Ruleset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Ruleset to import
    * @param importFromId The id of the existing Ruleset that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Ruleset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/ruleset cloudflare_ruleset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RulesetConfig
    */
    constructor(scope: Construct, id: string, config: RulesetConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    get phaseInput(): string | undefined;
    private _shareableEntitlementName?;
    get shareableEntitlementName(): string;
    set shareableEntitlementName(value: string);
    resetShareableEntitlementName(): void;
    get shareableEntitlementNameInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _rules;
    get rules(): RulesetRulesList;
    putRules(value: RulesetRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | RulesetRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
