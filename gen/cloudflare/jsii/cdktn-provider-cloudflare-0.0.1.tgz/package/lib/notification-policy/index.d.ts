import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NotificationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#account_id NotificationPolicy#account_id}
    */
    readonly accountId: string;
    /**
    * The event type that will trigger the dispatch of a notification. See the developer documentation for descriptions of [available alert types](https://developers.cloudflare.com/fundamentals/notifications/notification-available/). Available values: `access_custom_certificate_expiration_type`, `advanced_ddos_attack_l4_alert`, `advanced_ddos_attack_l7_alert`, `bgp_hijack_notification`, `billing_usage_alert`, `block_notification_block_removed`, `block_notification_new_block`, `block_notification_review_rejected`, `clickhouse_alert_fw_anomaly`, `clickhouse_alert_fw_ent_anomaly`, `custom_ssl_certificate_event_type`, `dedicated_ssl_certificate_event_type`, `dos_attack_l4`, `dos_attack_l7`, `expiring_service_token_alert`, `failing_logpush_job_disabled_alert`, `fbm_auto_advertisement`, `fbm_dosd_attack`, `fbm_volumetric_attack`, `health_check_status_notification`, `hostname_aop_custom_certificate_expiration_type`, `http_alert_edge_error`, `http_alert_origin_error`, `load_balancing_health_alert`, `load_balancing_pool_enablement_alert`, `real_origin_monitoring`, `scriptmonitor_alert_new_code_change_detections`, `scriptmonitor_alert_new_hosts`, `scriptmonitor_alert_new_malicious_hosts`, `scriptmonitor_alert_new_malicious_scripts`, `scriptmonitor_alert_new_malicious_url`, `scriptmonitor_alert_new_max_length_resource_url`, `scriptmonitor_alert_new_resources`, `secondary_dns_all_primaries_failing`, `secondary_dns_primaries_failing`, `secondary_dns_zone_successfully_updated`, `secondary_dns_zone_validation_warning`, `sentinel_alert`, `stream_live_notifications`, `tunnel_health_event`, `tunnel_update_event`, `universal_ssl_event_type`, `web_analytics_metrics_update`, `weekly_account_overview`, `workers_alert`, `zone_aop_custom_certificate_expiration_type`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#alert_type NotificationPolicy#alert_type}
    */
    readonly alertType: string;
    /**
    * Description of the notification policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#description NotificationPolicy#description}
    */
    readonly description?: string;
    /**
    * The status of the notification policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#enabled NotificationPolicy#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#id NotificationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the notification policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#name NotificationPolicy#name}
    */
    readonly name: string;
    /**
    * email_integration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#email_integration NotificationPolicy#email_integration}
    */
    readonly emailIntegration?: NotificationPolicyEmailIntegration[] | cdktn.IResolvable;
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#filters NotificationPolicy#filters}
    */
    readonly filters?: NotificationPolicyFilters;
    /**
    * pagerduty_integration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#pagerduty_integration NotificationPolicy#pagerduty_integration}
    */
    readonly pagerdutyIntegration?: NotificationPolicyPagerdutyIntegration[] | cdktn.IResolvable;
    /**
    * webhooks_integration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#webhooks_integration NotificationPolicy#webhooks_integration}
    */
    readonly webhooksIntegration?: NotificationPolicyWebhooksIntegration[] | cdktn.IResolvable;
}
export interface NotificationPolicyEmailIntegration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#id NotificationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#name NotificationPolicy#name}
    */
    readonly name?: string;
}
export declare function notificationPolicyEmailIntegrationToTerraform(struct?: NotificationPolicyEmailIntegration | cdktn.IResolvable): any;
export declare function notificationPolicyEmailIntegrationToHclTerraform(struct?: NotificationPolicyEmailIntegration | cdktn.IResolvable): any;
export declare class NotificationPolicyEmailIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationPolicyEmailIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationPolicyEmailIntegration | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class NotificationPolicyEmailIntegrationList extends cdktn.ComplexList {
    internalValue?: NotificationPolicyEmailIntegration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationPolicyEmailIntegrationOutputReference;
}
export interface NotificationPolicyFilters {
    /**
    * State of the pool to alert on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#enabled NotificationPolicy#enabled}
    */
    readonly enabled?: string[];
    /**
    * Source configuration to alert on for pool or origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#event_source NotificationPolicy#event_source}
    */
    readonly eventSource?: string[];
    /**
    * Stream event type to alert on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#event_type NotificationPolicy#event_type}
    */
    readonly eventType?: string[];
    /**
    * Identifier health check. Required when using `filters.0.status`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#health_check_id NotificationPolicy#health_check_id}
    */
    readonly healthCheckId?: string[];
    /**
    * Stream input id to alert on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#input_id NotificationPolicy#input_id}
    */
    readonly inputId?: string[];
    /**
    * A numerical limit. Example: `100`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#limit NotificationPolicy#limit}
    */
    readonly limit?: string[];
    /**
    * Health status to alert on for pool or origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#new_health NotificationPolicy#new_health}
    */
    readonly newHealth?: string[];
    /**
    * Packets per second threshold for dos alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#packets_per_second NotificationPolicy#packets_per_second}
    */
    readonly packetsPerSecond?: string[];
    /**
    * Load balancer pool identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#pool_id NotificationPolicy#pool_id}
    */
    readonly poolId?: string[];
    /**
    * Product name. Available values: `worker_requests`, `worker_durable_objects_requests`, `worker_durable_objects_duration`, `worker_durable_objects_data_transfer`, `worker_durable_objects_stored_data`, `worker_durable_objects_storage_deletes`, `worker_durable_objects_storage_writes`, `worker_durable_objects_storage_reads`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#product NotificationPolicy#product}
    */
    readonly product?: string[];
    /**
    * Protocol to alert on for dos.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#protocol NotificationPolicy#protocol}
    */
    readonly protocol?: string[];
    /**
    * Requests per second threshold for dos alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#requests_per_second NotificationPolicy#requests_per_second}
    */
    readonly requestsPerSecond?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#services NotificationPolicy#services}
    */
    readonly services?: string[];
    /**
    * A numerical limit. Example: `99.9`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#slo NotificationPolicy#slo}
    */
    readonly slo?: string[];
    /**
    * Status to alert on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#status NotificationPolicy#status}
    */
    readonly status?: string[];
    /**
    * Target host to alert on for dos.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#target_host NotificationPolicy#target_host}
    */
    readonly targetHost?: string[];
    /**
    * Target domain to alert on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#target_zone_name NotificationPolicy#target_zone_name}
    */
    readonly targetZoneName?: string[];
    /**
    * A list of zone identifiers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#zones NotificationPolicy#zones}
    */
    readonly zones?: string[];
}
export declare function notificationPolicyFiltersToTerraform(struct?: NotificationPolicyFiltersOutputReference | NotificationPolicyFilters): any;
export declare function notificationPolicyFiltersToHclTerraform(struct?: NotificationPolicyFiltersOutputReference | NotificationPolicyFilters): any;
export declare class NotificationPolicyFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationPolicyFilters | undefined;
    set internalValue(value: NotificationPolicyFilters | undefined);
    private _enabled?;
    get enabled(): string[];
    set enabled(value: string[]);
    resetEnabled(): void;
    get enabledInput(): string[] | undefined;
    private _eventSource?;
    get eventSource(): string[];
    set eventSource(value: string[]);
    resetEventSource(): void;
    get eventSourceInput(): string[] | undefined;
    private _eventType?;
    get eventType(): string[];
    set eventType(value: string[]);
    resetEventType(): void;
    get eventTypeInput(): string[] | undefined;
    private _healthCheckId?;
    get healthCheckId(): string[];
    set healthCheckId(value: string[]);
    resetHealthCheckId(): void;
    get healthCheckIdInput(): string[] | undefined;
    private _inputId?;
    get inputId(): string[];
    set inputId(value: string[]);
    resetInputId(): void;
    get inputIdInput(): string[] | undefined;
    private _limit?;
    get limit(): string[];
    set limit(value: string[]);
    resetLimit(): void;
    get limitInput(): string[] | undefined;
    private _newHealth?;
    get newHealth(): string[];
    set newHealth(value: string[]);
    resetNewHealth(): void;
    get newHealthInput(): string[] | undefined;
    private _packetsPerSecond?;
    get packetsPerSecond(): string[];
    set packetsPerSecond(value: string[]);
    resetPacketsPerSecond(): void;
    get packetsPerSecondInput(): string[] | undefined;
    private _poolId?;
    get poolId(): string[];
    set poolId(value: string[]);
    resetPoolId(): void;
    get poolIdInput(): string[] | undefined;
    private _product?;
    get product(): string[];
    set product(value: string[]);
    resetProduct(): void;
    get productInput(): string[] | undefined;
    private _protocol?;
    get protocol(): string[];
    set protocol(value: string[]);
    resetProtocol(): void;
    get protocolInput(): string[] | undefined;
    private _requestsPerSecond?;
    get requestsPerSecond(): string[];
    set requestsPerSecond(value: string[]);
    resetRequestsPerSecond(): void;
    get requestsPerSecondInput(): string[] | undefined;
    private _services?;
    get services(): string[];
    set services(value: string[]);
    resetServices(): void;
    get servicesInput(): string[] | undefined;
    private _slo?;
    get slo(): string[];
    set slo(value: string[]);
    resetSlo(): void;
    get sloInput(): string[] | undefined;
    private _status?;
    get status(): string[];
    set status(value: string[]);
    resetStatus(): void;
    get statusInput(): string[] | undefined;
    private _targetHost?;
    get targetHost(): string[];
    set targetHost(value: string[]);
    resetTargetHost(): void;
    get targetHostInput(): string[] | undefined;
    private _targetZoneName?;
    get targetZoneName(): string[];
    set targetZoneName(value: string[]);
    resetTargetZoneName(): void;
    get targetZoneNameInput(): string[] | undefined;
    private _zones?;
    get zones(): string[];
    set zones(value: string[]);
    resetZones(): void;
    get zonesInput(): string[] | undefined;
}
export interface NotificationPolicyPagerdutyIntegration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#id NotificationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#name NotificationPolicy#name}
    */
    readonly name?: string;
}
export declare function notificationPolicyPagerdutyIntegrationToTerraform(struct?: NotificationPolicyPagerdutyIntegration | cdktn.IResolvable): any;
export declare function notificationPolicyPagerdutyIntegrationToHclTerraform(struct?: NotificationPolicyPagerdutyIntegration | cdktn.IResolvable): any;
export declare class NotificationPolicyPagerdutyIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationPolicyPagerdutyIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationPolicyPagerdutyIntegration | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class NotificationPolicyPagerdutyIntegrationList extends cdktn.ComplexList {
    internalValue?: NotificationPolicyPagerdutyIntegration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationPolicyPagerdutyIntegrationOutputReference;
}
export interface NotificationPolicyWebhooksIntegration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#id NotificationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#name NotificationPolicy#name}
    */
    readonly name?: string;
}
export declare function notificationPolicyWebhooksIntegrationToTerraform(struct?: NotificationPolicyWebhooksIntegration | cdktn.IResolvable): any;
export declare function notificationPolicyWebhooksIntegrationToHclTerraform(struct?: NotificationPolicyWebhooksIntegration | cdktn.IResolvable): any;
export declare class NotificationPolicyWebhooksIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationPolicyWebhooksIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationPolicyWebhooksIntegration | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class NotificationPolicyWebhooksIntegrationList extends cdktn.ComplexList {
    internalValue?: NotificationPolicyWebhooksIntegration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationPolicyWebhooksIntegrationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy cloudflare_notification_policy}
*/
export declare class NotificationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_notification_policy";
    /**
    * Generates CDKTN code for importing a NotificationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NotificationPolicy to import
    * @param importFromId The id of the existing NotificationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NotificationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/notification_policy cloudflare_notification_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NotificationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: NotificationPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _alertType?;
    get alertType(): string;
    set alertType(value: string);
    get alertTypeInput(): string | undefined;
    get created(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get modified(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _emailIntegration;
    get emailIntegration(): NotificationPolicyEmailIntegrationList;
    putEmailIntegration(value: NotificationPolicyEmailIntegration[] | cdktn.IResolvable): void;
    resetEmailIntegration(): void;
    get emailIntegrationInput(): cdktn.IResolvable | NotificationPolicyEmailIntegration[] | undefined;
    private _filters;
    get filters(): NotificationPolicyFiltersOutputReference;
    putFilters(value: NotificationPolicyFilters): void;
    resetFilters(): void;
    get filtersInput(): NotificationPolicyFilters | undefined;
    private _pagerdutyIntegration;
    get pagerdutyIntegration(): NotificationPolicyPagerdutyIntegrationList;
    putPagerdutyIntegration(value: NotificationPolicyPagerdutyIntegration[] | cdktn.IResolvable): void;
    resetPagerdutyIntegration(): void;
    get pagerdutyIntegrationInput(): cdktn.IResolvable | NotificationPolicyPagerdutyIntegration[] | undefined;
    private _webhooksIntegration;
    get webhooksIntegration(): NotificationPolicyWebhooksIntegrationList;
    putWebhooksIntegration(value: NotificationPolicyWebhooksIntegration[] | cdktn.IResolvable): void;
    resetWebhooksIntegration(): void;
    get webhooksIntegrationInput(): cdktn.IResolvable | NotificationPolicyWebhooksIntegration[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
