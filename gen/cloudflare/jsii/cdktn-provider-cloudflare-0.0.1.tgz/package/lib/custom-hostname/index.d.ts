import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomHostnameConfig extends cdktn.TerraformMetaArguments {
    /**
    * Custom metadata associated with custom hostname. Only supports primitive string values, all other values are accessible via the API directly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#custom_metadata CustomHostname#custom_metadata}
    */
    readonly customMetadata?: {
        [key: string]: string;
    };
    /**
    * The custom origin server used for certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#custom_origin_server CustomHostname#custom_origin_server}
    */
    readonly customOriginServer?: string;
    /**
    * The [custom origin SNI](https://developers.cloudflare.com/ssl/ssl-for-saas/hostname-specific-behavior/custom-origin) used for certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#custom_origin_sni CustomHostname#custom_origin_sni}
    */
    readonly customOriginSni?: string;
    /**
    * Hostname you intend to request a certificate for. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#hostname CustomHostname#hostname}
    */
    readonly hostname: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#id CustomHostname#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to wait for a custom hostname SSL sub-object to reach status `pending_validation` during creation. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#wait_for_ssl_pending_validation CustomHostname#wait_for_ssl_pending_validation}
    */
    readonly waitForSslPendingValidation?: boolean | cdktn.IResolvable;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#zone_id CustomHostname#zone_id}
    */
    readonly zoneId: string;
    /**
    * ssl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#ssl CustomHostname#ssl}
    */
    readonly ssl?: CustomHostnameSsl[] | cdktn.IResolvable;
}
export interface CustomHostnameSslValidationErrors {
}
export declare function customHostnameSslValidationErrorsToTerraform(struct?: CustomHostnameSslValidationErrors): any;
export declare function customHostnameSslValidationErrorsToHclTerraform(struct?: CustomHostnameSslValidationErrors): any;
export declare class CustomHostnameSslValidationErrorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomHostnameSslValidationErrors | undefined;
    set internalValue(value: CustomHostnameSslValidationErrors | undefined);
    get message(): string;
}
export declare class CustomHostnameSslValidationErrorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomHostnameSslValidationErrorsOutputReference;
}
export interface CustomHostnameSslValidationRecords {
}
export declare function customHostnameSslValidationRecordsToTerraform(struct?: CustomHostnameSslValidationRecords): any;
export declare function customHostnameSslValidationRecordsToHclTerraform(struct?: CustomHostnameSslValidationRecords): any;
export declare class CustomHostnameSslValidationRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomHostnameSslValidationRecords | undefined;
    set internalValue(value: CustomHostnameSslValidationRecords | undefined);
    get cnameName(): string;
    get cnameTarget(): string;
    get emails(): string[];
    get httpBody(): string;
    get httpUrl(): string;
    get txtName(): string;
    get txtValue(): string;
}
export declare class CustomHostnameSslValidationRecordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomHostnameSslValidationRecordsOutputReference;
}
export interface CustomHostnameSslSettings {
    /**
    * List of SSL/TLS ciphers to associate with this certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#ciphers CustomHostname#ciphers}
    */
    readonly ciphers?: string[];
    /**
    * Whether early hints should be supported. Available values: `on`, `off`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#early_hints CustomHostname#early_hints}
    */
    readonly earlyHints?: string;
    /**
    * Whether HTTP2 should be supported. Available values: `on`, `off`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#http2 CustomHostname#http2}
    */
    readonly http2?: string;
    /**
    * Lowest version of TLS this certificate should support. Available values: `1.0`, `1.1`, `1.2`, `1.3`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#min_tls_version CustomHostname#min_tls_version}
    */
    readonly minTlsVersion?: string;
    /**
    * Whether TLSv1.3 should be supported. Available values: `on`, `off`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#tls13 CustomHostname#tls13}
    */
    readonly tls13?: string;
}
export declare function customHostnameSslSettingsToTerraform(struct?: CustomHostnameSslSettings | cdktn.IResolvable): any;
export declare function customHostnameSslSettingsToHclTerraform(struct?: CustomHostnameSslSettings | cdktn.IResolvable): any;
export declare class CustomHostnameSslSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomHostnameSslSettings | cdktn.IResolvable | undefined;
    set internalValue(value: CustomHostnameSslSettings | cdktn.IResolvable | undefined);
    private _ciphers?;
    get ciphers(): string[];
    set ciphers(value: string[]);
    resetCiphers(): void;
    get ciphersInput(): string[] | undefined;
    private _earlyHints?;
    get earlyHints(): string;
    set earlyHints(value: string);
    resetEarlyHints(): void;
    get earlyHintsInput(): string | undefined;
    private _http2?;
    get http2(): string;
    set http2(value: string);
    resetHttp2(): void;
    get http2Input(): string | undefined;
    private _minTlsVersion?;
    get minTlsVersion(): string;
    set minTlsVersion(value: string);
    resetMinTlsVersion(): void;
    get minTlsVersionInput(): string | undefined;
    private _tls13?;
    get tls13(): string;
    set tls13(value: string);
    resetTls13(): void;
    get tls13Input(): string | undefined;
}
export declare class CustomHostnameSslSettingsList extends cdktn.ComplexList {
    internalValue?: CustomHostnameSslSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomHostnameSslSettingsOutputReference;
}
export interface CustomHostnameSsl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#certificate_authority CustomHostname#certificate_authority}
    */
    readonly certificateAuthority?: string;
    /**
    * If a custom uploaded certificate is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#custom_certificate CustomHostname#custom_certificate}
    */
    readonly customCertificate?: string;
    /**
    * The key for a custom uploaded certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#custom_key CustomHostname#custom_key}
    */
    readonly customKey?: string;
    /**
    * Domain control validation (DCV) method used for this hostname. Available values: `http`, `txt`, `email`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#method CustomHostname#method}
    */
    readonly method?: string;
    /**
    * Level of validation to be used for this hostname. Available values: `dv`. Defaults to `dv`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#type CustomHostname#type}
    */
    readonly type?: string;
    /**
    * Indicates whether the certificate covers a wildcard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#wildcard CustomHostname#wildcard}
    */
    readonly wildcard?: boolean | cdktn.IResolvable;
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#settings CustomHostname#settings}
    */
    readonly settings?: CustomHostnameSslSettings[] | cdktn.IResolvable;
}
export declare function customHostnameSslToTerraform(struct?: CustomHostnameSsl | cdktn.IResolvable): any;
export declare function customHostnameSslToHclTerraform(struct?: CustomHostnameSsl | cdktn.IResolvable): any;
export declare class CustomHostnameSslOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomHostnameSsl | cdktn.IResolvable | undefined;
    set internalValue(value: CustomHostnameSsl | cdktn.IResolvable | undefined);
    private _certificateAuthority?;
    get certificateAuthority(): string;
    set certificateAuthority(value: string);
    resetCertificateAuthority(): void;
    get certificateAuthorityInput(): string | undefined;
    private _customCertificate?;
    get customCertificate(): string;
    set customCertificate(value: string);
    resetCustomCertificate(): void;
    get customCertificateInput(): string | undefined;
    private _customKey?;
    get customKey(): string;
    set customKey(value: string);
    resetCustomKey(): void;
    get customKeyInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    get status(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _validationErrors;
    get validationErrors(): CustomHostnameSslValidationErrorsList;
    private _validationRecords;
    get validationRecords(): CustomHostnameSslValidationRecordsList;
    private _wildcard?;
    get wildcard(): boolean | cdktn.IResolvable;
    set wildcard(value: boolean | cdktn.IResolvable);
    resetWildcard(): void;
    get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    private _settings;
    get settings(): CustomHostnameSslSettingsList;
    putSettings(value: CustomHostnameSslSettings[] | cdktn.IResolvable): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | CustomHostnameSslSettings[] | undefined;
}
export declare class CustomHostnameSslList extends cdktn.ComplexList {
    internalValue?: CustomHostnameSsl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomHostnameSslOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname cloudflare_custom_hostname}
*/
export declare class CustomHostname extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_custom_hostname";
    /**
    * Generates CDKTN code for importing a CustomHostname resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomHostname to import
    * @param importFromId The id of the existing CustomHostname that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomHostname to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/custom_hostname cloudflare_custom_hostname} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomHostnameConfig
    */
    constructor(scope: Construct, id: string, config: CustomHostnameConfig);
    private _customMetadata?;
    get customMetadata(): {
        [key: string]: string;
    };
    set customMetadata(value: {
        [key: string]: string;
    });
    resetCustomMetadata(): void;
    get customMetadataInput(): {
        [key: string]: string;
    } | undefined;
    private _customOriginServer?;
    get customOriginServer(): string;
    set customOriginServer(value: string);
    resetCustomOriginServer(): void;
    get customOriginServerInput(): string | undefined;
    private _customOriginSni?;
    get customOriginSni(): string;
    set customOriginSni(value: string);
    resetCustomOriginSni(): void;
    get customOriginSniInput(): string | undefined;
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    get hostnameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ownershipVerification;
    get ownershipVerification(): cdktn.StringMap;
    private _ownershipVerificationHttp;
    get ownershipVerificationHttp(): cdktn.StringMap;
    get status(): string;
    private _waitForSslPendingValidation?;
    get waitForSslPendingValidation(): boolean | cdktn.IResolvable;
    set waitForSslPendingValidation(value: boolean | cdktn.IResolvable);
    resetWaitForSslPendingValidation(): void;
    get waitForSslPendingValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _ssl;
    get ssl(): CustomHostnameSslList;
    putSsl(value: CustomHostnameSsl[] | cdktn.IResolvable): void;
    resetSsl(): void;
    get sslInput(): cdktn.IResolvable | CustomHostnameSsl[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
