import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface HealthcheckConfig extends cdktn.TerraformMetaArguments {
    /**
    * The hostname or IP address of the origin server to run health checks on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#address Healthcheck#address}
    */
    readonly address: string;
    /**
    * Do not validate the certificate when the health check uses HTTPS. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#allow_insecure Healthcheck#allow_insecure}
    */
    readonly allowInsecure?: boolean | cdktn.IResolvable;
    /**
    * A list of regions from which to run health checks. If not set, Cloudflare will pick a default region. Available values: `WNAM`, `ENAM`, `WEU`, `EEU`, `NSAM`, `SSAM`, `OC`, `ME`, `NAF`, `SAF`, `IN`, `SEAS`, `NEAS`, `ALL_REGIONS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#check_regions Healthcheck#check_regions}
    */
    readonly checkRegions?: string[];
    /**
    * The number of consecutive fails required from a health check before changing the health to unhealthy. Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#consecutive_fails Healthcheck#consecutive_fails}
    */
    readonly consecutiveFails?: number;
    /**
    * The number of consecutive successes required from a health check before changing the health to healthy. Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#consecutive_successes Healthcheck#consecutive_successes}
    */
    readonly consecutiveSuccesses?: number;
    /**
    * A human-readable description of the health check.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#description Healthcheck#description}
    */
    readonly description?: string;
    /**
    * A case-insensitive sub-string to look for in the response body. If this string is not found the origin will be marked as unhealthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#expected_body Healthcheck#expected_body}
    */
    readonly expectedBody?: string;
    /**
    * The expected HTTP response codes (e.g. '200') or code ranges (e.g. '2xx' for all codes starting with 2) of the health check.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#expected_codes Healthcheck#expected_codes}
    */
    readonly expectedCodes?: string[];
    /**
    * Follow redirects if the origin returns a 3xx status code. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#follow_redirects Healthcheck#follow_redirects}
    */
    readonly followRedirects?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#id Healthcheck#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase the load on the origin as we check from multiple locations. Defaults to `60`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#interval Healthcheck#interval}
    */
    readonly interval?: number;
    /**
    * The HTTP method to use for the health check. Available values: `connection_established`, `GET`, `HEAD`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#method Healthcheck#method}
    */
    readonly method?: string;
    /**
    * A short name to identify the health check. Only alphanumeric characters, hyphens, and underscores are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#name Healthcheck#name}
    */
    readonly name: string;
    /**
    * The endpoint path to health check against. Defaults to `/`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#path Healthcheck#path}
    */
    readonly path?: string;
    /**
    * Port number to connect to for the health check. Defaults to `80`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#port Healthcheck#port}
    */
    readonly port?: number;
    /**
    * The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. Defaults to `2`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#retries Healthcheck#retries}
    */
    readonly retries?: number;
    /**
    * If suspended, no health checks are sent to the origin. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#suspended Healthcheck#suspended}
    */
    readonly suspended?: boolean | cdktn.IResolvable;
    /**
    * The timeout (in seconds) before marking the health check as failed. Defaults to `5`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#timeout Healthcheck#timeout}
    */
    readonly timeout?: number;
    /**
    * The protocol to use for the health check. Available values: `TCP`, `HTTP`, `HTTPS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#type Healthcheck#type}
    */
    readonly type: string;
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#zone_id Healthcheck#zone_id}
    */
    readonly zoneId: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#header Healthcheck#header}
    */
    readonly header?: HealthcheckHeader[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#timeouts Healthcheck#timeouts}
    */
    readonly timeouts?: HealthcheckTimeouts;
}
export interface HealthcheckHeader {
    /**
    * The header name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#header Healthcheck#header}
    */
    readonly header: string;
    /**
    * A list of string values for the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#values Healthcheck#values}
    */
    readonly values: string[];
}
export declare function healthcheckHeaderToTerraform(struct?: HealthcheckHeader | cdktn.IResolvable): any;
export declare function healthcheckHeaderToHclTerraform(struct?: HealthcheckHeader | cdktn.IResolvable): any;
export declare class HealthcheckHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HealthcheckHeader | cdktn.IResolvable | undefined;
    set internalValue(value: HealthcheckHeader | cdktn.IResolvable | undefined);
    private _header?;
    get header(): string;
    set header(value: string);
    get headerInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class HealthcheckHeaderList extends cdktn.ComplexList {
    internalValue?: HealthcheckHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HealthcheckHeaderOutputReference;
}
export interface HealthcheckTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#create Healthcheck#create}
    */
    readonly create?: string;
}
export declare function healthcheckTimeoutsToTerraform(struct?: HealthcheckTimeouts | cdktn.IResolvable): any;
export declare function healthcheckTimeoutsToHclTerraform(struct?: HealthcheckTimeouts | cdktn.IResolvable): any;
export declare class HealthcheckTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HealthcheckTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: HealthcheckTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck cloudflare_healthcheck}
*/
export declare class Healthcheck extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_healthcheck";
    /**
    * Generates CDKTN code for importing a Healthcheck resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Healthcheck to import
    * @param importFromId The id of the existing Healthcheck that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Healthcheck to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/healthcheck cloudflare_healthcheck} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HealthcheckConfig
    */
    constructor(scope: Construct, id: string, config: HealthcheckConfig);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _allowInsecure?;
    get allowInsecure(): boolean | cdktn.IResolvable;
    set allowInsecure(value: boolean | cdktn.IResolvable);
    resetAllowInsecure(): void;
    get allowInsecureInput(): boolean | cdktn.IResolvable | undefined;
    private _checkRegions?;
    get checkRegions(): string[];
    set checkRegions(value: string[]);
    resetCheckRegions(): void;
    get checkRegionsInput(): string[] | undefined;
    private _consecutiveFails?;
    get consecutiveFails(): number;
    set consecutiveFails(value: number);
    resetConsecutiveFails(): void;
    get consecutiveFailsInput(): number | undefined;
    private _consecutiveSuccesses?;
    get consecutiveSuccesses(): number;
    set consecutiveSuccesses(value: number);
    resetConsecutiveSuccesses(): void;
    get consecutiveSuccessesInput(): number | undefined;
    get createdOn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expectedBody?;
    get expectedBody(): string;
    set expectedBody(value: string);
    resetExpectedBody(): void;
    get expectedBodyInput(): string | undefined;
    private _expectedCodes?;
    get expectedCodes(): string[];
    set expectedCodes(value: string[]);
    resetExpectedCodes(): void;
    get expectedCodesInput(): string[] | undefined;
    private _followRedirects?;
    get followRedirects(): boolean | cdktn.IResolvable;
    set followRedirects(value: boolean | cdktn.IResolvable);
    resetFollowRedirects(): void;
    get followRedirectsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    get modifiedOn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _retries?;
    get retries(): number;
    set retries(value: number);
    resetRetries(): void;
    get retriesInput(): number | undefined;
    private _suspended?;
    get suspended(): boolean | cdktn.IResolvable;
    set suspended(value: boolean | cdktn.IResolvable);
    resetSuspended(): void;
    get suspendedInput(): boolean | cdktn.IResolvable | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _header;
    get header(): HealthcheckHeaderList;
    putHeader(value: HealthcheckHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | HealthcheckHeader[] | undefined;
    private _timeouts;
    get timeouts(): HealthcheckTimeoutsOutputReference;
    putTimeouts(value: HealthcheckTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | HealthcheckTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
