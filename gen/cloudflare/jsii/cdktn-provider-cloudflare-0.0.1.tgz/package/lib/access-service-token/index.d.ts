import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessServiceTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. Conflicts with `zone_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_service_token#account_id AccessServiceToken#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_service_token#id AccessServiceToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Refresh the token if terraform is run within the specified amount of days before expiration. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_service_token#min_days_for_renewal AccessServiceToken#min_days_for_renewal}
    */
    readonly minDaysForRenewal?: number;
    /**
    * Friendly name of the token's intent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_service_token#name AccessServiceToken#name}
    */
    readonly name: string;
    /**
    * The zone identifier to target for the resource. Conflicts with `account_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_service_token#zone_id AccessServiceToken#zone_id}
    */
    readonly zoneId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_service_token cloudflare_access_service_token}
*/
export declare class AccessServiceToken extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_access_service_token";
    /**
    * Generates CDKTN code for importing a AccessServiceToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessServiceToken to import
    * @param importFromId The id of the existing AccessServiceToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_service_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessServiceToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_service_token cloudflare_access_service_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessServiceTokenConfig
    */
    constructor(scope: Construct, id: string, config: AccessServiceTokenConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get clientId(): string;
    get clientSecret(): string;
    get expiresAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _minDaysForRenewal?;
    get minDaysForRenewal(): number;
    set minDaysForRenewal(value: number);
    resetMinDaysForRenewal(): void;
    get minDaysForRenewalInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
