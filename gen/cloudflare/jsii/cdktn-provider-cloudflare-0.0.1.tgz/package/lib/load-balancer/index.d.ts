import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LoadBalancerConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of pool IDs ordered by their failover priority. Used whenever [`pop_pools`](#pop_pools)/[`country_pools`](#country_pools)/[`region_pools`](#region_pools) are not defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#default_pool_ids LoadBalancer#default_pool_ids}
    */
    readonly defaultPoolIds: string[];
    /**
    * Free text description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#description LoadBalancer#description}
    */
    readonly description?: string;
    /**
    * Enable or disable the load balancer. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#enabled LoadBalancer#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The pool ID to use when all other pools are detected as unhealthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#fallback_pool_id LoadBalancer#fallback_pool_id}
    */
    readonly fallbackPoolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#id LoadBalancer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The DNS hostname to associate with your load balancer. If this hostname already exists as a DNS record in Cloudflare's DNS, the load balancer will take precedence and the DNS record will not be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#name LoadBalancer#name}
    */
    readonly name: string;
    /**
    * Whether the hostname gets Cloudflare's origin protection. Defaults to `false`. Conflicts with `ttl`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#proxied LoadBalancer#proxied}
    */
    readonly proxied?: boolean | cdktn.IResolvable;
    /**
    * Specifies the type of session affinity the load balancer should use unless specified as `none` or `""` (default). With value `cookie`, on the first request to a proxied load balancer, a cookie is generated, encoding information of which origin the request will be forwarded to. Subsequent requests, by the same client to the same load balancer, will be sent to the origin server the cookie encodes, for the duration of the cookie and as long as the origin server remains healthy. If the cookie has expired or the origin server is unhealthy then a new origin server is calculated and used. Value `ip_cookie` behaves the same as `cookie` except the initial origin selection is stable and based on the client's IP address. Available values: `""`, `none`, `cookie`, `ip_cookie`. Defaults to `none`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#session_affinity LoadBalancer#session_affinity}
    */
    readonly sessionAffinity?: string;
    /**
    * Time, in seconds, until this load balancer's session affinity cookie expires after being created. This parameter is ignored unless a supported session affinity policy is set. The current default of `82800` (23 hours) will be used unless [`session_affinity_ttl`](#session_affinity_ttl) is explicitly set. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. Valid values are between `1800` and `604800`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#session_affinity_ttl LoadBalancer#session_affinity_ttl}
    */
    readonly sessionAffinityTtl?: number;
    /**
    * The method the load balancer uses to determine the route to your origin. Value `off` uses [`default_pool_ids`](#default_pool_ids). Value `geo` uses [`pop_pools`](#pop_pools)/[`country_pools`](#country_pools)/[`region_pools`](#region_pools). For non-proxied requests, the [`country`](#country) for [`country_pools`](#country_pools) is determined by [`location_strategy`](#location_strategy). Value `random` selects a pool randomly. Value `dynamic_latency` uses round trip time to select the closest pool in [`default_pool_ids`](#default_pool_ids) (requires pool health checks). Value `proximity` uses the pools' latitude and longitude to select the closest pool using the Cloudflare PoP location for proxied requests or the location determined by [`location_strategy`](#location_strategy) for non-proxied requests. Value `""` maps to `geo` if you use [`pop_pools`](#pop_pools)/[`country_pools`](#country_pools)/[`region_pools`](#region_pools) otherwise `off`. Available values: `off`, `geo`, `dynamic_latency`, `random`, `proximity`, `""` Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#steering_policy LoadBalancer#steering_policy}
    */
    readonly steeringPolicy?: string;
    /**
    * Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This cannot be set for proxied load balancers. Defaults to `30`. Conflicts with `proxied`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#ttl LoadBalancer#ttl}
    */
    readonly ttl?: number;
    /**
    * The zone ID to add the load balancer to. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#zone_id LoadBalancer#zone_id}
    */
    readonly zoneId: string;
    /**
    * adaptive_routing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#adaptive_routing LoadBalancer#adaptive_routing}
    */
    readonly adaptiveRouting?: LoadBalancerAdaptiveRouting[] | cdktn.IResolvable;
    /**
    * country_pools block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#country_pools LoadBalancer#country_pools}
    */
    readonly countryPools?: LoadBalancerCountryPools[] | cdktn.IResolvable;
    /**
    * location_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#location_strategy LoadBalancer#location_strategy}
    */
    readonly locationStrategy?: LoadBalancerLocationStrategy[] | cdktn.IResolvable;
    /**
    * pop_pools block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pop_pools LoadBalancer#pop_pools}
    */
    readonly popPools?: LoadBalancerPopPools[] | cdktn.IResolvable;
    /**
    * random_steering block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#random_steering LoadBalancer#random_steering}
    */
    readonly randomSteering?: LoadBalancerRandomSteering[] | cdktn.IResolvable;
    /**
    * region_pools block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#region_pools LoadBalancer#region_pools}
    */
    readonly regionPools?: LoadBalancerRegionPools[] | cdktn.IResolvable;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#rules LoadBalancer#rules}
    */
    readonly rules?: LoadBalancerRules[] | cdktn.IResolvable;
    /**
    * session_affinity_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#session_affinity_attributes LoadBalancer#session_affinity_attributes}
    */
    readonly sessionAffinityAttributes?: LoadBalancerSessionAffinityAttributes[] | cdktn.IResolvable;
}
export interface LoadBalancerAdaptiveRouting {
    /**
    * Extends zero-downtime failover of requests to healthy origins from alternate pools, when no healthy alternate exists in the same pool, according to the failover order defined by traffic and origin steering. When set `false`, zero-downtime failover will only occur between origins within the same pool. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#failover_across_pools LoadBalancer#failover_across_pools}
    */
    readonly failoverAcrossPools?: boolean | cdktn.IResolvable;
}
export declare function loadBalancerAdaptiveRoutingToTerraform(struct?: LoadBalancerAdaptiveRouting | cdktn.IResolvable): any;
export declare function loadBalancerAdaptiveRoutingToHclTerraform(struct?: LoadBalancerAdaptiveRouting | cdktn.IResolvable): any;
export declare class LoadBalancerAdaptiveRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerAdaptiveRouting | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerAdaptiveRouting | cdktn.IResolvable | undefined);
    private _failoverAcrossPools?;
    get failoverAcrossPools(): boolean | cdktn.IResolvable;
    set failoverAcrossPools(value: boolean | cdktn.IResolvable);
    resetFailoverAcrossPools(): void;
    get failoverAcrossPoolsInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class LoadBalancerAdaptiveRoutingList extends cdktn.ComplexList {
    internalValue?: LoadBalancerAdaptiveRouting[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerAdaptiveRoutingOutputReference;
}
export interface LoadBalancerCountryPools {
    /**
    * A country code which can be determined with the Load Balancing Regions API described [here](https://developers.cloudflare.com/load-balancing/reference/region-mapping-api/). Multiple entries should not be specified with the same country.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#country LoadBalancer#country}
    */
    readonly country: string;
    /**
    * A list of pool IDs in failover priority to use in the given country.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pool_ids LoadBalancer#pool_ids}
    */
    readonly poolIds: string[];
}
export declare function loadBalancerCountryPoolsToTerraform(struct?: LoadBalancerCountryPools | cdktn.IResolvable): any;
export declare function loadBalancerCountryPoolsToHclTerraform(struct?: LoadBalancerCountryPools | cdktn.IResolvable): any;
export declare class LoadBalancerCountryPoolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerCountryPools | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerCountryPools | cdktn.IResolvable | undefined);
    private _country?;
    get country(): string;
    set country(value: string);
    get countryInput(): string | undefined;
    private _poolIds?;
    get poolIds(): string[];
    set poolIds(value: string[]);
    get poolIdsInput(): string[] | undefined;
}
export declare class LoadBalancerCountryPoolsList extends cdktn.ComplexList {
    internalValue?: LoadBalancerCountryPools[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerCountryPoolsOutputReference;
}
export interface LoadBalancerLocationStrategy {
    /**
    * Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. Value `pop` will use the Cloudflare PoP location. Value `resolver_ip` will use the DNS resolver GeoIP location. If the GeoIP lookup is unsuccessful, it will use the Cloudflare PoP location. Available values: `pop`, `resolver_ip`. Defaults to `pop`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#mode LoadBalancer#mode}
    */
    readonly mode?: string;
    /**
    * Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. Value `always` will always prefer ECS, `never` will never prefer ECS, `proximity` will prefer ECS only when [`steering_policy="proximity"`](#steering_policy), and `geo` will prefer ECS only when [`steering_policy="geo"`](#steering_policy). Available values: `always`, `never`, `proximity`, `geo`. Defaults to `proximity`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#prefer_ecs LoadBalancer#prefer_ecs}
    */
    readonly preferEcs?: string;
}
export declare function loadBalancerLocationStrategyToTerraform(struct?: LoadBalancerLocationStrategy | cdktn.IResolvable): any;
export declare function loadBalancerLocationStrategyToHclTerraform(struct?: LoadBalancerLocationStrategy | cdktn.IResolvable): any;
export declare class LoadBalancerLocationStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerLocationStrategy | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerLocationStrategy | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _preferEcs?;
    get preferEcs(): string;
    set preferEcs(value: string);
    resetPreferEcs(): void;
    get preferEcsInput(): string | undefined;
}
export declare class LoadBalancerLocationStrategyList extends cdktn.ComplexList {
    internalValue?: LoadBalancerLocationStrategy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerLocationStrategyOutputReference;
}
export interface LoadBalancerPopPools {
    /**
    * A list of pool IDs in failover priority to use for traffic reaching the given PoP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pool_ids LoadBalancer#pool_ids}
    */
    readonly poolIds: string[];
    /**
    * A 3-letter code for the Point-of-Presence. Allowed values can be found in the list of datacenters on the [status page](https://www.cloudflarestatus.com/). Multiple entries should not be specified with the same PoP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pop LoadBalancer#pop}
    */
    readonly pop: string;
}
export declare function loadBalancerPopPoolsToTerraform(struct?: LoadBalancerPopPools | cdktn.IResolvable): any;
export declare function loadBalancerPopPoolsToHclTerraform(struct?: LoadBalancerPopPools | cdktn.IResolvable): any;
export declare class LoadBalancerPopPoolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerPopPools | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerPopPools | cdktn.IResolvable | undefined);
    private _poolIds?;
    get poolIds(): string[];
    set poolIds(value: string[]);
    get poolIdsInput(): string[] | undefined;
    private _pop?;
    get pop(): string;
    set pop(value: string);
    get popInput(): string | undefined;
}
export declare class LoadBalancerPopPoolsList extends cdktn.ComplexList {
    internalValue?: LoadBalancerPopPools[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerPopPoolsOutputReference;
}
export interface LoadBalancerRandomSteering {
    /**
    * The default weight for pools in the load balancer that are not specified in the [`pool_weights`](#pool_weights) map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#default_weight LoadBalancer#default_weight}
    */
    readonly defaultWeight?: number;
    /**
    * A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pool_weights LoadBalancer#pool_weights}
    */
    readonly poolWeights?: {
        [key: string]: number;
    };
}
export declare function loadBalancerRandomSteeringToTerraform(struct?: LoadBalancerRandomSteering | cdktn.IResolvable): any;
export declare function loadBalancerRandomSteeringToHclTerraform(struct?: LoadBalancerRandomSteering | cdktn.IResolvable): any;
export declare class LoadBalancerRandomSteeringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRandomSteering | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRandomSteering | cdktn.IResolvable | undefined);
    private _defaultWeight?;
    get defaultWeight(): number;
    set defaultWeight(value: number);
    resetDefaultWeight(): void;
    get defaultWeightInput(): number | undefined;
    private _poolWeights?;
    get poolWeights(): {
        [key: string]: number;
    };
    set poolWeights(value: {
        [key: string]: number;
    });
    resetPoolWeights(): void;
    get poolWeightsInput(): {
        [key: string]: number;
    } | undefined;
}
export declare class LoadBalancerRandomSteeringList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRandomSteering[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRandomSteeringOutputReference;
}
export interface LoadBalancerRegionPools {
    /**
    * A list of pool IDs in failover priority to use in the given region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pool_ids LoadBalancer#pool_ids}
    */
    readonly poolIds: string[];
    /**
    * A region code which must be in the list defined [here](https://developers.cloudflare.com/load-balancing/reference/region-mapping-api/#list-of-load-balancer-regions). Multiple entries should not be specified with the same region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#region LoadBalancer#region}
    */
    readonly region: string;
}
export declare function loadBalancerRegionPoolsToTerraform(struct?: LoadBalancerRegionPools | cdktn.IResolvable): any;
export declare function loadBalancerRegionPoolsToHclTerraform(struct?: LoadBalancerRegionPools | cdktn.IResolvable): any;
export declare class LoadBalancerRegionPoolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRegionPools | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRegionPools | cdktn.IResolvable | undefined);
    private _poolIds?;
    get poolIds(): string[];
    set poolIds(value: string[]);
    get poolIdsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class LoadBalancerRegionPoolsList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRegionPools[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRegionPoolsOutputReference;
}
export interface LoadBalancerRulesFixedResponse {
    /**
    * The value of the HTTP context-type header for this fixed response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#content_type LoadBalancer#content_type}
    */
    readonly contentType?: string;
    /**
    * The value of the HTTP location header for this fixed response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#location LoadBalancer#location}
    */
    readonly location?: string;
    /**
    * The text used as the html body for this fixed response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#message_body LoadBalancer#message_body}
    */
    readonly messageBody?: string;
    /**
    * The HTTP status code used for this fixed response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#status_code LoadBalancer#status_code}
    */
    readonly statusCode?: number;
}
export declare function loadBalancerRulesFixedResponseToTerraform(struct?: LoadBalancerRulesFixedResponseOutputReference | LoadBalancerRulesFixedResponse): any;
export declare function loadBalancerRulesFixedResponseToHclTerraform(struct?: LoadBalancerRulesFixedResponseOutputReference | LoadBalancerRulesFixedResponse): any;
export declare class LoadBalancerRulesFixedResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadBalancerRulesFixedResponse | undefined;
    set internalValue(value: LoadBalancerRulesFixedResponse | undefined);
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _messageBody?;
    get messageBody(): string;
    set messageBody(value: string);
    resetMessageBody(): void;
    get messageBodyInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
}
export interface LoadBalancerRulesOverridesAdaptiveRouting {
    /**
    * Extends zero-downtime failover of requests to healthy origins from alternate pools, when no healthy alternate exists in the same pool, according to the failover order defined by traffic and origin steering. When set `false`, zero-downtime failover will only occur between origins within the same pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#failover_across_pools LoadBalancer#failover_across_pools}
    */
    readonly failoverAcrossPools?: boolean | cdktn.IResolvable;
}
export declare function loadBalancerRulesOverridesAdaptiveRoutingToTerraform(struct?: LoadBalancerRulesOverridesAdaptiveRouting | cdktn.IResolvable): any;
export declare function loadBalancerRulesOverridesAdaptiveRoutingToHclTerraform(struct?: LoadBalancerRulesOverridesAdaptiveRouting | cdktn.IResolvable): any;
export declare class LoadBalancerRulesOverridesAdaptiveRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRulesOverridesAdaptiveRouting | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRulesOverridesAdaptiveRouting | cdktn.IResolvable | undefined);
    private _failoverAcrossPools?;
    get failoverAcrossPools(): boolean | cdktn.IResolvable;
    set failoverAcrossPools(value: boolean | cdktn.IResolvable);
    resetFailoverAcrossPools(): void;
    get failoverAcrossPoolsInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class LoadBalancerRulesOverridesAdaptiveRoutingList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRulesOverridesAdaptiveRouting[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRulesOverridesAdaptiveRoutingOutputReference;
}
export interface LoadBalancerRulesOverridesCountryPools {
    /**
    * A country code which can be determined with the Load Balancing Regions API described [here](https://developers.cloudflare.com/load-balancing/reference/region-mapping-api/). Multiple entries should not be specified with the same country.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#country LoadBalancer#country}
    */
    readonly country: string;
    /**
    * A list of pool IDs in failover priority to use in the given country.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pool_ids LoadBalancer#pool_ids}
    */
    readonly poolIds: string[];
}
export declare function loadBalancerRulesOverridesCountryPoolsToTerraform(struct?: LoadBalancerRulesOverridesCountryPools | cdktn.IResolvable): any;
export declare function loadBalancerRulesOverridesCountryPoolsToHclTerraform(struct?: LoadBalancerRulesOverridesCountryPools | cdktn.IResolvable): any;
export declare class LoadBalancerRulesOverridesCountryPoolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRulesOverridesCountryPools | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRulesOverridesCountryPools | cdktn.IResolvable | undefined);
    private _country?;
    get country(): string;
    set country(value: string);
    get countryInput(): string | undefined;
    private _poolIds?;
    get poolIds(): string[];
    set poolIds(value: string[]);
    get poolIdsInput(): string[] | undefined;
}
export declare class LoadBalancerRulesOverridesCountryPoolsList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRulesOverridesCountryPools[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRulesOverridesCountryPoolsOutputReference;
}
export interface LoadBalancerRulesOverridesLocationStrategy {
    /**
    * Determines the authoritative location when ECS is not preferred, does not exist in the request, or its GeoIP lookup is unsuccessful. Value `pop` will use the Cloudflare PoP location. Value `resolver_ip` will use the DNS resolver GeoIP location. If the GeoIP lookup is unsuccessful, it will use the Cloudflare PoP location. Available values: `pop`, `resolver_ip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#mode LoadBalancer#mode}
    */
    readonly mode?: string;
    /**
    * Whether the EDNS Client Subnet (ECS) GeoIP should be preferred as the authoritative location. Value `always` will always prefer ECS, `never` will never prefer ECS, `proximity` will prefer ECS only when [`steering_policy="proximity"`](#steering_policy), and `geo` will prefer ECS only when [`steering_policy="geo"`](#steering_policy). Available values: `always`, `never`, `proximity`, `geo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#prefer_ecs LoadBalancer#prefer_ecs}
    */
    readonly preferEcs?: string;
}
export declare function loadBalancerRulesOverridesLocationStrategyToTerraform(struct?: LoadBalancerRulesOverridesLocationStrategy | cdktn.IResolvable): any;
export declare function loadBalancerRulesOverridesLocationStrategyToHclTerraform(struct?: LoadBalancerRulesOverridesLocationStrategy | cdktn.IResolvable): any;
export declare class LoadBalancerRulesOverridesLocationStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRulesOverridesLocationStrategy | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRulesOverridesLocationStrategy | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _preferEcs?;
    get preferEcs(): string;
    set preferEcs(value: string);
    resetPreferEcs(): void;
    get preferEcsInput(): string | undefined;
}
export declare class LoadBalancerRulesOverridesLocationStrategyList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRulesOverridesLocationStrategy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRulesOverridesLocationStrategyOutputReference;
}
export interface LoadBalancerRulesOverridesPopPools {
    /**
    * A list of pool IDs in failover priority to use for traffic reaching the given PoP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pool_ids LoadBalancer#pool_ids}
    */
    readonly poolIds: string[];
    /**
    * A 3-letter code for the Point-of-Presence. Allowed values can be found in the list of datacenters on the [status page](https://www.cloudflarestatus.com/). Multiple entries should not be specified with the same PoP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pop LoadBalancer#pop}
    */
    readonly pop: string;
}
export declare function loadBalancerRulesOverridesPopPoolsToTerraform(struct?: LoadBalancerRulesOverridesPopPools | cdktn.IResolvable): any;
export declare function loadBalancerRulesOverridesPopPoolsToHclTerraform(struct?: LoadBalancerRulesOverridesPopPools | cdktn.IResolvable): any;
export declare class LoadBalancerRulesOverridesPopPoolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRulesOverridesPopPools | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRulesOverridesPopPools | cdktn.IResolvable | undefined);
    private _poolIds?;
    get poolIds(): string[];
    set poolIds(value: string[]);
    get poolIdsInput(): string[] | undefined;
    private _pop?;
    get pop(): string;
    set pop(value: string);
    get popInput(): string | undefined;
}
export declare class LoadBalancerRulesOverridesPopPoolsList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRulesOverridesPopPools[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRulesOverridesPopPoolsOutputReference;
}
export interface LoadBalancerRulesOverridesRandomSteering {
    /**
    * The default weight for pools in the load balancer that are not specified in the [`pool_weights`](#pool_weights) map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#default_weight LoadBalancer#default_weight}
    */
    readonly defaultWeight?: number;
    /**
    * A mapping of pool IDs to custom weights. The weight is relative to other pools in the load balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pool_weights LoadBalancer#pool_weights}
    */
    readonly poolWeights?: {
        [key: string]: number;
    };
}
export declare function loadBalancerRulesOverridesRandomSteeringToTerraform(struct?: LoadBalancerRulesOverridesRandomSteering | cdktn.IResolvable): any;
export declare function loadBalancerRulesOverridesRandomSteeringToHclTerraform(struct?: LoadBalancerRulesOverridesRandomSteering | cdktn.IResolvable): any;
export declare class LoadBalancerRulesOverridesRandomSteeringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRulesOverridesRandomSteering | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRulesOverridesRandomSteering | cdktn.IResolvable | undefined);
    private _defaultWeight?;
    get defaultWeight(): number;
    set defaultWeight(value: number);
    resetDefaultWeight(): void;
    get defaultWeightInput(): number | undefined;
    private _poolWeights?;
    get poolWeights(): {
        [key: string]: number;
    };
    set poolWeights(value: {
        [key: string]: number;
    });
    resetPoolWeights(): void;
    get poolWeightsInput(): {
        [key: string]: number;
    } | undefined;
}
export declare class LoadBalancerRulesOverridesRandomSteeringList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRulesOverridesRandomSteering[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRulesOverridesRandomSteeringOutputReference;
}
export interface LoadBalancerRulesOverridesRegionPools {
    /**
    * A list of pool IDs in failover priority to use in the given region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pool_ids LoadBalancer#pool_ids}
    */
    readonly poolIds: string[];
    /**
    * A region code which must be in the list defined [here](https://developers.cloudflare.com/load-balancing/reference/region-mapping-api/#list-of-load-balancer-regions). Multiple entries should not be specified with the same region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#region LoadBalancer#region}
    */
    readonly region: string;
}
export declare function loadBalancerRulesOverridesRegionPoolsToTerraform(struct?: LoadBalancerRulesOverridesRegionPools | cdktn.IResolvable): any;
export declare function loadBalancerRulesOverridesRegionPoolsToHclTerraform(struct?: LoadBalancerRulesOverridesRegionPools | cdktn.IResolvable): any;
export declare class LoadBalancerRulesOverridesRegionPoolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRulesOverridesRegionPools | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRulesOverridesRegionPools | cdktn.IResolvable | undefined);
    private _poolIds?;
    get poolIds(): string[];
    set poolIds(value: string[]);
    get poolIdsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class LoadBalancerRulesOverridesRegionPoolsList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRulesOverridesRegionPools[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRulesOverridesRegionPoolsOutputReference;
}
export interface LoadBalancerRulesOverridesSessionAffinityAttributes {
    /**
    * Configures the SameSite attribute on session affinity cookie. Value `Auto` will be translated to `Lax` or `None` depending if Always Use HTTPS is enabled. Note: when using value `None`, then you can not set [`secure="Never"`](#secure). Available values: `Auto`, `Lax`, `None`, `Strict`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#samesite LoadBalancer#samesite}
    */
    readonly samesite?: string;
    /**
    * Configures the Secure attribute on session affinity cookie. Value `Always` indicates the Secure attribute will be set in the Set-Cookie header, `Never` indicates the Secure attribute will not be set, and `Auto` will set the Secure attribute depending if Always Use HTTPS is enabled. Available values: `Auto`, `Always`, `Never`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#secure LoadBalancer#secure}
    */
    readonly secure?: string;
    /**
    * Configures the zero-downtime failover between origins within a pool when session affinity is enabled. Value `none` means no failover takes place for sessions pinned to the origin. Value `temporary` means traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. Value `sticky` means the session affinity cookie is updated and subsequent requests are sent to the new origin. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. Available values: `none`, `temporary`, `sticky`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#zero_downtime_failover LoadBalancer#zero_downtime_failover}
    */
    readonly zeroDowntimeFailover?: string;
}
export declare function loadBalancerRulesOverridesSessionAffinityAttributesToTerraform(struct?: LoadBalancerRulesOverridesSessionAffinityAttributes | cdktn.IResolvable): any;
export declare function loadBalancerRulesOverridesSessionAffinityAttributesToHclTerraform(struct?: LoadBalancerRulesOverridesSessionAffinityAttributes | cdktn.IResolvable): any;
export declare class LoadBalancerRulesOverridesSessionAffinityAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRulesOverridesSessionAffinityAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRulesOverridesSessionAffinityAttributes | cdktn.IResolvable | undefined);
    private _samesite?;
    get samesite(): string;
    set samesite(value: string);
    resetSamesite(): void;
    get samesiteInput(): string | undefined;
    private _secure?;
    get secure(): string;
    set secure(value: string);
    resetSecure(): void;
    get secureInput(): string | undefined;
    private _zeroDowntimeFailover?;
    get zeroDowntimeFailover(): string;
    set zeroDowntimeFailover(value: string);
    resetZeroDowntimeFailover(): void;
    get zeroDowntimeFailoverInput(): string | undefined;
}
export declare class LoadBalancerRulesOverridesSessionAffinityAttributesList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRulesOverridesSessionAffinityAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRulesOverridesSessionAffinityAttributesOutputReference;
}
export interface LoadBalancerRulesOverrides {
    /**
    * A list of pool IDs ordered by their failover priority. Used whenever [`pop_pools`](#pop_pools)/[`country_pools`](#country_pools)/[`region_pools`](#region_pools) are not defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#default_pools LoadBalancer#default_pools}
    */
    readonly defaultPools?: string[];
    /**
    * The pool ID to use when all other pools are detected as unhealthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#fallback_pool LoadBalancer#fallback_pool}
    */
    readonly fallbackPool?: string;
    /**
    * Configure cookie attributes for session affinity cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#session_affinity LoadBalancer#session_affinity}
    */
    readonly sessionAffinity?: string;
    /**
    * Time, in seconds, until this load balancer's session affinity cookie expires after being created. This parameter is ignored unless a supported session affinity policy is set. The current default of `82800` (23 hours) will be used unless [`session_affinity_ttl`](#session_affinity_ttl) is explicitly set. Once the expiry time has been reached, subsequent requests may get sent to a different origin server. Valid values are between `1800` and `604800`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#session_affinity_ttl LoadBalancer#session_affinity_ttl}
    */
    readonly sessionAffinityTtl?: number;
    /**
    * The method the load balancer uses to determine the route to your origin. Value `off` uses [`default_pool_ids`](#default_pool_ids). Value `geo` uses [`pop_pools`](#pop_pools)/[`country_pools`](#country_pools)/[`region_pools`](#region_pools). For non-proxied requests, the [`country`](#country) for [`country_pools`](#country_pools) is determined by [`location_strategy`](#location_strategy). Value `random` selects a pool randomly. Value `dynamic_latency` uses round trip time to select the closest pool in [`default_pool_ids`](#default_pool_ids) (requires pool health checks). Value `proximity` uses the pools' latitude and longitude to select the closest pool using the Cloudflare PoP location for proxied requests or the location determined by [`location_strategy`](#location_strategy) for non-proxied requests. Value `""` maps to `geo` if you use [`pop_pools`](#pop_pools)/[`country_pools`](#country_pools)/[`region_pools`](#region_pools) otherwise `off`. Available values: `off`, `geo`, `dynamic_latency`, `random`, `proximity`, `""` Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#steering_policy LoadBalancer#steering_policy}
    */
    readonly steeringPolicy?: string;
    /**
    * Time to live (TTL) of the DNS entry for the IP address returned by this load balancer. This cannot be set for proxied load balancers. Defaults to `30`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#ttl LoadBalancer#ttl}
    */
    readonly ttl?: number;
    /**
    * adaptive_routing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#adaptive_routing LoadBalancer#adaptive_routing}
    */
    readonly adaptiveRouting?: LoadBalancerRulesOverridesAdaptiveRouting[] | cdktn.IResolvable;
    /**
    * country_pools block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#country_pools LoadBalancer#country_pools}
    */
    readonly countryPools?: LoadBalancerRulesOverridesCountryPools[] | cdktn.IResolvable;
    /**
    * location_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#location_strategy LoadBalancer#location_strategy}
    */
    readonly locationStrategy?: LoadBalancerRulesOverridesLocationStrategy[] | cdktn.IResolvable;
    /**
    * pop_pools block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#pop_pools LoadBalancer#pop_pools}
    */
    readonly popPools?: LoadBalancerRulesOverridesPopPools[] | cdktn.IResolvable;
    /**
    * random_steering block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#random_steering LoadBalancer#random_steering}
    */
    readonly randomSteering?: LoadBalancerRulesOverridesRandomSteering[] | cdktn.IResolvable;
    /**
    * region_pools block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#region_pools LoadBalancer#region_pools}
    */
    readonly regionPools?: LoadBalancerRulesOverridesRegionPools[] | cdktn.IResolvable;
    /**
    * session_affinity_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#session_affinity_attributes LoadBalancer#session_affinity_attributes}
    */
    readonly sessionAffinityAttributes?: LoadBalancerRulesOverridesSessionAffinityAttributes[] | cdktn.IResolvable;
}
export declare function loadBalancerRulesOverridesToTerraform(struct?: LoadBalancerRulesOverrides | cdktn.IResolvable): any;
export declare function loadBalancerRulesOverridesToHclTerraform(struct?: LoadBalancerRulesOverrides | cdktn.IResolvable): any;
export declare class LoadBalancerRulesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRulesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRulesOverrides | cdktn.IResolvable | undefined);
    private _defaultPools?;
    get defaultPools(): string[];
    set defaultPools(value: string[]);
    resetDefaultPools(): void;
    get defaultPoolsInput(): string[] | undefined;
    private _fallbackPool?;
    get fallbackPool(): string;
    set fallbackPool(value: string);
    resetFallbackPool(): void;
    get fallbackPoolInput(): string | undefined;
    private _sessionAffinity?;
    get sessionAffinity(): string;
    set sessionAffinity(value: string);
    resetSessionAffinity(): void;
    get sessionAffinityInput(): string | undefined;
    private _sessionAffinityTtl?;
    get sessionAffinityTtl(): number;
    set sessionAffinityTtl(value: number);
    resetSessionAffinityTtl(): void;
    get sessionAffinityTtlInput(): number | undefined;
    private _steeringPolicy?;
    get steeringPolicy(): string;
    set steeringPolicy(value: string);
    resetSteeringPolicy(): void;
    get steeringPolicyInput(): string | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    private _adaptiveRouting;
    get adaptiveRouting(): LoadBalancerRulesOverridesAdaptiveRoutingList;
    putAdaptiveRouting(value: LoadBalancerRulesOverridesAdaptiveRouting[] | cdktn.IResolvable): void;
    resetAdaptiveRouting(): void;
    get adaptiveRoutingInput(): cdktn.IResolvable | LoadBalancerRulesOverridesAdaptiveRouting[] | undefined;
    private _countryPools;
    get countryPools(): LoadBalancerRulesOverridesCountryPoolsList;
    putCountryPools(value: LoadBalancerRulesOverridesCountryPools[] | cdktn.IResolvable): void;
    resetCountryPools(): void;
    get countryPoolsInput(): cdktn.IResolvable | LoadBalancerRulesOverridesCountryPools[] | undefined;
    private _locationStrategy;
    get locationStrategy(): LoadBalancerRulesOverridesLocationStrategyList;
    putLocationStrategy(value: LoadBalancerRulesOverridesLocationStrategy[] | cdktn.IResolvable): void;
    resetLocationStrategy(): void;
    get locationStrategyInput(): cdktn.IResolvable | LoadBalancerRulesOverridesLocationStrategy[] | undefined;
    private _popPools;
    get popPools(): LoadBalancerRulesOverridesPopPoolsList;
    putPopPools(value: LoadBalancerRulesOverridesPopPools[] | cdktn.IResolvable): void;
    resetPopPools(): void;
    get popPoolsInput(): cdktn.IResolvable | LoadBalancerRulesOverridesPopPools[] | undefined;
    private _randomSteering;
    get randomSteering(): LoadBalancerRulesOverridesRandomSteeringList;
    putRandomSteering(value: LoadBalancerRulesOverridesRandomSteering[] | cdktn.IResolvable): void;
    resetRandomSteering(): void;
    get randomSteeringInput(): cdktn.IResolvable | LoadBalancerRulesOverridesRandomSteering[] | undefined;
    private _regionPools;
    get regionPools(): LoadBalancerRulesOverridesRegionPoolsList;
    putRegionPools(value: LoadBalancerRulesOverridesRegionPools[] | cdktn.IResolvable): void;
    resetRegionPools(): void;
    get regionPoolsInput(): cdktn.IResolvable | LoadBalancerRulesOverridesRegionPools[] | undefined;
    private _sessionAffinityAttributes;
    get sessionAffinityAttributes(): LoadBalancerRulesOverridesSessionAffinityAttributesList;
    putSessionAffinityAttributes(value: LoadBalancerRulesOverridesSessionAffinityAttributes[] | cdktn.IResolvable): void;
    resetSessionAffinityAttributes(): void;
    get sessionAffinityAttributesInput(): cdktn.IResolvable | LoadBalancerRulesOverridesSessionAffinityAttributes[] | undefined;
}
export declare class LoadBalancerRulesOverridesList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRulesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRulesOverridesOutputReference;
}
export interface LoadBalancerRules {
    /**
    * The statement to evaluate to determine if this rule's effects should be applied. An empty condition is always true. See [load balancing rules](https://developers.cloudflare.com/load-balancing/understand-basics/load-balancing-rules).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#condition LoadBalancer#condition}
    */
    readonly condition?: string;
    /**
    * A disabled rule will not be executed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#disabled LoadBalancer#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Human readable name for this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#name LoadBalancer#name}
    */
    readonly name: string;
    /**
    * Priority used when determining the order of rule execution. Lower values are executed first. If not provided, the list order will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#priority LoadBalancer#priority}
    */
    readonly priority?: number;
    /**
    * Terminates indicates that if this rule is true no further rules should be executed. Note: setting a [`fixed_response`](#fixed_response) forces this field to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#terminates LoadBalancer#terminates}
    */
    readonly terminates?: boolean | cdktn.IResolvable;
    /**
    * fixed_response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#fixed_response LoadBalancer#fixed_response}
    */
    readonly fixedResponse?: LoadBalancerRulesFixedResponse;
    /**
    * overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#overrides LoadBalancer#overrides}
    */
    readonly overrides?: LoadBalancerRulesOverrides[] | cdktn.IResolvable;
}
export declare function loadBalancerRulesToTerraform(struct?: LoadBalancerRules | cdktn.IResolvable): any;
export declare function loadBalancerRulesToHclTerraform(struct?: LoadBalancerRules | cdktn.IResolvable): any;
export declare class LoadBalancerRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerRules | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerRules | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _terminates?;
    get terminates(): boolean | cdktn.IResolvable;
    set terminates(value: boolean | cdktn.IResolvable);
    resetTerminates(): void;
    get terminatesInput(): boolean | cdktn.IResolvable | undefined;
    private _fixedResponse;
    get fixedResponse(): LoadBalancerRulesFixedResponseOutputReference;
    putFixedResponse(value: LoadBalancerRulesFixedResponse): void;
    resetFixedResponse(): void;
    get fixedResponseInput(): LoadBalancerRulesFixedResponse | undefined;
    private _overrides;
    get overrides(): LoadBalancerRulesOverridesList;
    putOverrides(value: LoadBalancerRulesOverrides[] | cdktn.IResolvable): void;
    resetOverrides(): void;
    get overridesInput(): cdktn.IResolvable | LoadBalancerRulesOverrides[] | undefined;
}
export declare class LoadBalancerRulesList extends cdktn.ComplexList {
    internalValue?: LoadBalancerRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerRulesOutputReference;
}
export interface LoadBalancerSessionAffinityAttributes {
    /**
    * Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#drain_duration LoadBalancer#drain_duration}
    */
    readonly drainDuration?: number;
    /**
    * Configures the SameSite attribute on session affinity cookie. Value `Auto` will be translated to `Lax` or `None` depending if Always Use HTTPS is enabled. Note: when using value `None`, then you can not set [`secure="Never"`](#secure). Available values: `Auto`, `Lax`, `None`, `Strict`. Defaults to `Auto`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#samesite LoadBalancer#samesite}
    */
    readonly samesite?: string;
    /**
    * Configures the Secure attribute on session affinity cookie. Value `Always` indicates the Secure attribute will be set in the Set-Cookie header, `Never` indicates the Secure attribute will not be set, and `Auto` will set the Secure attribute depending if Always Use HTTPS is enabled. Available values: `Auto`, `Always`, `Never`. Defaults to `Auto`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#secure LoadBalancer#secure}
    */
    readonly secure?: string;
    /**
    * Configures the zero-downtime failover between origins within a pool when session affinity is enabled. Value `none` means no failover takes place for sessions pinned to the origin. Value `temporary` means traffic will be sent to another other healthy origin until the originally pinned origin is available; note that this can potentially result in heavy origin flapping. Value `sticky` means the session affinity cookie is updated and subsequent requests are sent to the new origin. This feature is currently incompatible with Argo, Tiered Cache, and Bandwidth Alliance. Available values: `none`, `temporary`, `sticky`. Defaults to `none`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#zero_downtime_failover LoadBalancer#zero_downtime_failover}
    */
    readonly zeroDowntimeFailover?: string;
}
export declare function loadBalancerSessionAffinityAttributesToTerraform(struct?: LoadBalancerSessionAffinityAttributes | cdktn.IResolvable): any;
export declare function loadBalancerSessionAffinityAttributesToHclTerraform(struct?: LoadBalancerSessionAffinityAttributes | cdktn.IResolvable): any;
export declare class LoadBalancerSessionAffinityAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerSessionAffinityAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerSessionAffinityAttributes | cdktn.IResolvable | undefined);
    private _drainDuration?;
    get drainDuration(): number;
    set drainDuration(value: number);
    resetDrainDuration(): void;
    get drainDurationInput(): number | undefined;
    private _samesite?;
    get samesite(): string;
    set samesite(value: string);
    resetSamesite(): void;
    get samesiteInput(): string | undefined;
    private _secure?;
    get secure(): string;
    set secure(value: string);
    resetSecure(): void;
    get secureInput(): string | undefined;
    private _zeroDowntimeFailover?;
    get zeroDowntimeFailover(): string;
    set zeroDowntimeFailover(value: string);
    resetZeroDowntimeFailover(): void;
    get zeroDowntimeFailoverInput(): string | undefined;
}
export declare class LoadBalancerSessionAffinityAttributesList extends cdktn.ComplexList {
    internalValue?: LoadBalancerSessionAffinityAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerSessionAffinityAttributesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer cloudflare_load_balancer}
*/
export declare class LoadBalancer extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_load_balancer";
    /**
    * Generates CDKTN code for importing a LoadBalancer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LoadBalancer to import
    * @param importFromId The id of the existing LoadBalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LoadBalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer cloudflare_load_balancer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoadBalancerConfig
    */
    constructor(scope: Construct, id: string, config: LoadBalancerConfig);
    get createdOn(): string;
    private _defaultPoolIds?;
    get defaultPoolIds(): string[];
    set defaultPoolIds(value: string[]);
    get defaultPoolIdsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _fallbackPoolId?;
    get fallbackPoolId(): string;
    set fallbackPoolId(value: string);
    get fallbackPoolIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get modifiedOn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _proxied?;
    get proxied(): boolean | cdktn.IResolvable;
    set proxied(value: boolean | cdktn.IResolvable);
    resetProxied(): void;
    get proxiedInput(): boolean | cdktn.IResolvable | undefined;
    private _sessionAffinity?;
    get sessionAffinity(): string;
    set sessionAffinity(value: string);
    resetSessionAffinity(): void;
    get sessionAffinityInput(): string | undefined;
    private _sessionAffinityTtl?;
    get sessionAffinityTtl(): number;
    set sessionAffinityTtl(value: number);
    resetSessionAffinityTtl(): void;
    get sessionAffinityTtlInput(): number | undefined;
    private _steeringPolicy?;
    get steeringPolicy(): string;
    set steeringPolicy(value: string);
    resetSteeringPolicy(): void;
    get steeringPolicyInput(): string | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _adaptiveRouting;
    get adaptiveRouting(): LoadBalancerAdaptiveRoutingList;
    putAdaptiveRouting(value: LoadBalancerAdaptiveRouting[] | cdktn.IResolvable): void;
    resetAdaptiveRouting(): void;
    get adaptiveRoutingInput(): cdktn.IResolvable | LoadBalancerAdaptiveRouting[] | undefined;
    private _countryPools;
    get countryPools(): LoadBalancerCountryPoolsList;
    putCountryPools(value: LoadBalancerCountryPools[] | cdktn.IResolvable): void;
    resetCountryPools(): void;
    get countryPoolsInput(): cdktn.IResolvable | LoadBalancerCountryPools[] | undefined;
    private _locationStrategy;
    get locationStrategy(): LoadBalancerLocationStrategyList;
    putLocationStrategy(value: LoadBalancerLocationStrategy[] | cdktn.IResolvable): void;
    resetLocationStrategy(): void;
    get locationStrategyInput(): cdktn.IResolvable | LoadBalancerLocationStrategy[] | undefined;
    private _popPools;
    get popPools(): LoadBalancerPopPoolsList;
    putPopPools(value: LoadBalancerPopPools[] | cdktn.IResolvable): void;
    resetPopPools(): void;
    get popPoolsInput(): cdktn.IResolvable | LoadBalancerPopPools[] | undefined;
    private _randomSteering;
    get randomSteering(): LoadBalancerRandomSteeringList;
    putRandomSteering(value: LoadBalancerRandomSteering[] | cdktn.IResolvable): void;
    resetRandomSteering(): void;
    get randomSteeringInput(): cdktn.IResolvable | LoadBalancerRandomSteering[] | undefined;
    private _regionPools;
    get regionPools(): LoadBalancerRegionPoolsList;
    putRegionPools(value: LoadBalancerRegionPools[] | cdktn.IResolvable): void;
    resetRegionPools(): void;
    get regionPoolsInput(): cdktn.IResolvable | LoadBalancerRegionPools[] | undefined;
    private _rules;
    get rules(): LoadBalancerRulesList;
    putRules(value: LoadBalancerRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | LoadBalancerRules[] | undefined;
    private _sessionAffinityAttributes;
    get sessionAffinityAttributes(): LoadBalancerSessionAffinityAttributesList;
    putSessionAffinityAttributes(value: LoadBalancerSessionAffinityAttributes[] | cdktn.IResolvable): void;
    resetSessionAffinityAttributes(): void;
    get sessionAffinityAttributesInput(): cdktn.IResolvable | LoadBalancerSessionAffinityAttributes[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
