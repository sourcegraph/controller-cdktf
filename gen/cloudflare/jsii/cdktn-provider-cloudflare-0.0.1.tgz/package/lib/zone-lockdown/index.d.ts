import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ZoneLockdownConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description about the lockdown entry. Typically used as a reminder or explanation for the lockdown.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown#description ZoneLockdown#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown#id ZoneLockdown#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Boolean of whether this zone lockdown is currently paused. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown#paused ZoneLockdown#paused}
    */
    readonly paused?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown#priority ZoneLockdown#priority}
    */
    readonly priority?: number;
    /**
    * A list of simple wildcard patterns to match requests against. The order of the urls is unimportant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown#urls ZoneLockdown#urls}
    */
    readonly urls: string[];
    /**
    * The zone identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown#zone_id ZoneLockdown#zone_id}
    */
    readonly zoneId: string;
    /**
    * configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown#configurations ZoneLockdown#configurations}
    */
    readonly configurations: ZoneLockdownConfigurations[] | cdktn.IResolvable;
}
export interface ZoneLockdownConfigurations {
    /**
    * The request property to target. Available values: `ip`, `ip_range`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown#target ZoneLockdown#target}
    */
    readonly target: string;
    /**
    * The value to target. Depends on target's type. IP addresses should just be standard IPv4/IPv6 notation i.e. `192.0.2.1` or `2001:db8::/32` and IP ranges in CIDR format i.e. `192.0.2.0/24`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown#value ZoneLockdown#value}
    */
    readonly value: string;
}
export declare function zoneLockdownConfigurationsToTerraform(struct?: ZoneLockdownConfigurations | cdktn.IResolvable): any;
export declare function zoneLockdownConfigurationsToHclTerraform(struct?: ZoneLockdownConfigurations | cdktn.IResolvable): any;
export declare class ZoneLockdownConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ZoneLockdownConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: ZoneLockdownConfigurations | cdktn.IResolvable | undefined);
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ZoneLockdownConfigurationsList extends cdktn.ComplexList {
    internalValue?: ZoneLockdownConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ZoneLockdownConfigurationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown cloudflare_zone_lockdown}
*/
export declare class ZoneLockdown extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_zone_lockdown";
    /**
    * Generates CDKTN code for importing a ZoneLockdown resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ZoneLockdown to import
    * @param importFromId The id of the existing ZoneLockdown that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ZoneLockdown to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/zone_lockdown cloudflare_zone_lockdown} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ZoneLockdownConfig
    */
    constructor(scope: Construct, id: string, config: ZoneLockdownConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _paused?;
    get paused(): boolean | cdktn.IResolvable;
    set paused(value: boolean | cdktn.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktn.IResolvable | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _urls?;
    get urls(): string[];
    set urls(value: string[]);
    get urlsInput(): string[] | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _configurations;
    get configurations(): ZoneLockdownConfigurationsList;
    putConfigurations(value: ZoneLockdownConfigurations[] | cdktn.IResolvable): void;
    get configurationsInput(): cdktn.IResolvable | ZoneLockdownConfigurations[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
