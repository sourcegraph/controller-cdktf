import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AddressMapConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#account_id AddressMap#account_id}
    */
    readonly accountId: string;
    /**
    * If you have legacy TLS clients which do not send the TLS server name indicator, then you can specify one default SNI on the map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#default_sni AddressMap#default_sni}
    */
    readonly defaultSni?: string;
    /**
    * Description of the address map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#description AddressMap#description}
    */
    readonly description?: string;
    /**
    * Whether the Address Map is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#enabled AddressMap#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#id AddressMap#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ips block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#ips AddressMap#ips}
    */
    readonly ips?: AddressMapIps[] | cdktn.IResolvable;
    /**
    * memberships block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#memberships AddressMap#memberships}
    */
    readonly memberships?: AddressMapMemberships[] | cdktn.IResolvable;
}
export interface AddressMapIps {
    /**
    * An IPv4 or IPv6 address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#ip AddressMap#ip}
    */
    readonly ip: string;
}
export declare function addressMapIpsToTerraform(struct?: AddressMapIps | cdktn.IResolvable): any;
export declare function addressMapIpsToHclTerraform(struct?: AddressMapIps | cdktn.IResolvable): any;
export declare class AddressMapIpsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AddressMapIps | cdktn.IResolvable | undefined;
    set internalValue(value: AddressMapIps | cdktn.IResolvable | undefined);
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
}
export declare class AddressMapIpsList extends cdktn.ComplexList {
    internalValue?: AddressMapIps[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AddressMapIpsOutputReference;
}
export interface AddressMapMemberships {
    /**
    * Identifier of the account or zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#identifier AddressMap#identifier}
    */
    readonly identifier: string;
    /**
    * The type of the membership.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#kind AddressMap#kind}
    */
    readonly kind: string;
}
export declare function addressMapMembershipsToTerraform(struct?: AddressMapMemberships | cdktn.IResolvable): any;
export declare function addressMapMembershipsToHclTerraform(struct?: AddressMapMemberships | cdktn.IResolvable): any;
export declare class AddressMapMembershipsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AddressMapMemberships | cdktn.IResolvable | undefined;
    set internalValue(value: AddressMapMemberships | cdktn.IResolvable | undefined);
    get canDelete(): cdktn.IResolvable;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
}
export declare class AddressMapMembershipsList extends cdktn.ComplexList {
    internalValue?: AddressMapMemberships[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AddressMapMembershipsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map cloudflare_address_map}
*/
export declare class AddressMap extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_address_map";
    /**
    * Generates CDKTN code for importing a AddressMap resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AddressMap to import
    * @param importFromId The id of the existing AddressMap that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AddressMap to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/address_map cloudflare_address_map} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AddressMapConfig
    */
    constructor(scope: Construct, id: string, config: AddressMapConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get canDelete(): cdktn.IResolvable;
    get canModifyIps(): cdktn.IResolvable;
    private _defaultSni?;
    get defaultSni(): string;
    set defaultSni(value: string);
    resetDefaultSni(): void;
    get defaultSniInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ips;
    get ips(): AddressMapIpsList;
    putIps(value: AddressMapIps[] | cdktn.IResolvable): void;
    resetIps(): void;
    get ipsInput(): cdktn.IResolvable | AddressMapIps[] | undefined;
    private _memberships;
    get memberships(): AddressMapMembershipsList;
    putMemberships(value: AddressMapMemberships[] | cdktn.IResolvable): void;
    resetMemberships(): void;
    get membershipsInput(): cdktn.IResolvable | AddressMapMemberships[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
