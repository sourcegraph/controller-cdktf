import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. Conflicts with `zone_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#account_id AccessApplication#account_id}
    */
    readonly accountId?: string;
    /**
    * The identity providers selected for the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#allowed_idps AccessApplication#allowed_idps}
    */
    readonly allowedIdps?: string[];
    /**
    * Option to show/hide applications in App Launcher. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#app_launcher_visible AccessApplication#app_launcher_visible}
    */
    readonly appLauncherVisible?: boolean | cdktn.IResolvable;
    /**
    * Option to skip identity provider selection if only one is configured in `allowed_idps`. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#auto_redirect_to_identity AccessApplication#auto_redirect_to_identity}
    */
    readonly autoRedirectToIdentity?: boolean | cdktn.IResolvable;
    /**
    * Option that returns a custom error message when a user is denied access to the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#custom_deny_message AccessApplication#custom_deny_message}
    */
    readonly customDenyMessage?: string;
    /**
    * Option that redirects to a custom URL when a user is denied access to the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#custom_deny_url AccessApplication#custom_deny_url}
    */
    readonly customDenyUrl?: string;
    /**
    * The complete URL of the asset you wish to put Cloudflare Access in front of. Can include subdomains or paths. Or both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#domain AccessApplication#domain}
    */
    readonly domain?: string;
    /**
    * Option to provide increased security against compromised authorization tokens and CSRF attacks by requiring an additional "binding" cookie on requests. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#enable_binding_cookie AccessApplication#enable_binding_cookie}
    */
    readonly enableBindingCookie?: boolean | cdktn.IResolvable;
    /**
    * Option to add the `HttpOnly` cookie flag to access tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#http_only_cookie_attribute AccessApplication#http_only_cookie_attribute}
    */
    readonly httpOnlyCookieAttribute?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#id AccessApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Image URL for the logo shown in the app launcher dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#logo_url AccessApplication#logo_url}
    */
    readonly logoUrl?: string;
    /**
    * Friendly name of the Access Application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#name AccessApplication#name}
    */
    readonly name: string;
    /**
    * Defines the same-site cookie setting for access tokens. Available values: `none`, `lax`, `strict`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#same_site_cookie_attribute AccessApplication#same_site_cookie_attribute}
    */
    readonly sameSiteCookieAttribute?: string;
    /**
    * Option to return a 401 status code in service authentication rules on failed requests. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#service_auth_401_redirect AccessApplication#service_auth_401_redirect}
    */
    readonly serviceAuth401Redirect?: boolean | cdktn.IResolvable;
    /**
    * How often a user will be forced to re-authorise. Must be in the format `48h` or `2h45m`. Defaults to `24h`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#session_duration AccessApplication#session_duration}
    */
    readonly sessionDuration?: string;
    /**
    * Option to skip the authorization interstitial when using the CLI. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#skip_interstitial AccessApplication#skip_interstitial}
    */
    readonly skipInterstitial?: boolean | cdktn.IResolvable;
    /**
    * The application type. Available values: `app_launcher`, `bookmark`, `biso`, `dash_sso`, `saas`, `self_hosted`, `ssh`, `vnc`, `warp`. Defaults to `self_hosted`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#type AccessApplication#type}
    */
    readonly type?: string;
    /**
    * The zone identifier to target for the resource. Conflicts with `account_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#zone_id AccessApplication#zone_id}
    */
    readonly zoneId?: string;
    /**
    * cors_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#cors_headers AccessApplication#cors_headers}
    */
    readonly corsHeaders?: AccessApplicationCorsHeaders[] | cdktn.IResolvable;
    /**
    * saas_app block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#saas_app AccessApplication#saas_app}
    */
    readonly saasApp?: AccessApplicationSaasApp;
}
export interface AccessApplicationCorsHeaders {
    /**
    * Value to determine whether all HTTP headers are exposed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#allow_all_headers AccessApplication#allow_all_headers}
    */
    readonly allowAllHeaders?: boolean | cdktn.IResolvable;
    /**
    * Value to determine whether all methods are exposed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#allow_all_methods AccessApplication#allow_all_methods}
    */
    readonly allowAllMethods?: boolean | cdktn.IResolvable;
    /**
    * Value to determine whether all origins are permitted to make CORS requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#allow_all_origins AccessApplication#allow_all_origins}
    */
    readonly allowAllOrigins?: boolean | cdktn.IResolvable;
    /**
    * Value to determine if credentials (cookies, authorization headers, or TLS client certificates) are included with requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#allow_credentials AccessApplication#allow_credentials}
    */
    readonly allowCredentials?: boolean | cdktn.IResolvable;
    /**
    * List of HTTP headers to expose via CORS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#allowed_headers AccessApplication#allowed_headers}
    */
    readonly allowedHeaders?: string[];
    /**
    * List of methods to expose via CORS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#allowed_methods AccessApplication#allowed_methods}
    */
    readonly allowedMethods?: string[];
    /**
    * List of origins permitted to make CORS requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#allowed_origins AccessApplication#allowed_origins}
    */
    readonly allowedOrigins?: string[];
    /**
    * The maximum time a preflight request will be cached.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#max_age AccessApplication#max_age}
    */
    readonly maxAge?: number;
}
export declare function accessApplicationCorsHeadersToTerraform(struct?: AccessApplicationCorsHeaders | cdktn.IResolvable): any;
export declare function accessApplicationCorsHeadersToHclTerraform(struct?: AccessApplicationCorsHeaders | cdktn.IResolvable): any;
export declare class AccessApplicationCorsHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessApplicationCorsHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: AccessApplicationCorsHeaders | cdktn.IResolvable | undefined);
    private _allowAllHeaders?;
    get allowAllHeaders(): boolean | cdktn.IResolvable;
    set allowAllHeaders(value: boolean | cdktn.IResolvable);
    resetAllowAllHeaders(): void;
    get allowAllHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _allowAllMethods?;
    get allowAllMethods(): boolean | cdktn.IResolvable;
    set allowAllMethods(value: boolean | cdktn.IResolvable);
    resetAllowAllMethods(): void;
    get allowAllMethodsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowAllOrigins?;
    get allowAllOrigins(): boolean | cdktn.IResolvable;
    set allowAllOrigins(value: boolean | cdktn.IResolvable);
    resetAllowAllOrigins(): void;
    get allowAllOriginsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowCredentials?;
    get allowCredentials(): boolean | cdktn.IResolvable;
    set allowCredentials(value: boolean | cdktn.IResolvable);
    resetAllowCredentials(): void;
    get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedHeaders?;
    get allowedHeaders(): string[];
    set allowedHeaders(value: string[]);
    resetAllowedHeaders(): void;
    get allowedHeadersInput(): string[] | undefined;
    private _allowedMethods?;
    get allowedMethods(): string[];
    set allowedMethods(value: string[]);
    resetAllowedMethods(): void;
    get allowedMethodsInput(): string[] | undefined;
    private _allowedOrigins?;
    get allowedOrigins(): string[];
    set allowedOrigins(value: string[]);
    resetAllowedOrigins(): void;
    get allowedOriginsInput(): string[] | undefined;
    private _maxAge?;
    get maxAge(): number;
    set maxAge(value: number);
    resetMaxAge(): void;
    get maxAgeInput(): number | undefined;
}
export declare class AccessApplicationCorsHeadersList extends cdktn.ComplexList {
    internalValue?: AccessApplicationCorsHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessApplicationCorsHeadersOutputReference;
}
export interface AccessApplicationSaasApp {
    /**
    * The service provider's endpoint that is responsible for receiving and parsing a SAML assertion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#consumer_service_url AccessApplication#consumer_service_url}
    */
    readonly consumerServiceUrl: string;
    /**
    * The format of the name identifier sent to the SaaS application. Defaults to `email`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#name_id_format AccessApplication#name_id_format}
    */
    readonly nameIdFormat?: string;
    /**
    * A globally unique name for an identity or service provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#sp_entity_id AccessApplication#sp_entity_id}
    */
    readonly spEntityId: string;
}
export declare function accessApplicationSaasAppToTerraform(struct?: AccessApplicationSaasAppOutputReference | AccessApplicationSaasApp): any;
export declare function accessApplicationSaasAppToHclTerraform(struct?: AccessApplicationSaasAppOutputReference | AccessApplicationSaasApp): any;
export declare class AccessApplicationSaasAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessApplicationSaasApp | undefined;
    set internalValue(value: AccessApplicationSaasApp | undefined);
    private _consumerServiceUrl?;
    get consumerServiceUrl(): string;
    set consumerServiceUrl(value: string);
    get consumerServiceUrlInput(): string | undefined;
    private _nameIdFormat?;
    get nameIdFormat(): string;
    set nameIdFormat(value: string);
    resetNameIdFormat(): void;
    get nameIdFormatInput(): string | undefined;
    private _spEntityId?;
    get spEntityId(): string;
    set spEntityId(value: string);
    get spEntityIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application cloudflare_access_application}
*/
export declare class AccessApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_access_application";
    /**
    * Generates CDKTN code for importing a AccessApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessApplication to import
    * @param importFromId The id of the existing AccessApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_application cloudflare_access_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AccessApplicationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _allowedIdps?;
    get allowedIdps(): string[];
    set allowedIdps(value: string[]);
    resetAllowedIdps(): void;
    get allowedIdpsInput(): string[] | undefined;
    private _appLauncherVisible?;
    get appLauncherVisible(): boolean | cdktn.IResolvable;
    set appLauncherVisible(value: boolean | cdktn.IResolvable);
    resetAppLauncherVisible(): void;
    get appLauncherVisibleInput(): boolean | cdktn.IResolvable | undefined;
    get aud(): string;
    private _autoRedirectToIdentity?;
    get autoRedirectToIdentity(): boolean | cdktn.IResolvable;
    set autoRedirectToIdentity(value: boolean | cdktn.IResolvable);
    resetAutoRedirectToIdentity(): void;
    get autoRedirectToIdentityInput(): boolean | cdktn.IResolvable | undefined;
    private _customDenyMessage?;
    get customDenyMessage(): string;
    set customDenyMessage(value: string);
    resetCustomDenyMessage(): void;
    get customDenyMessageInput(): string | undefined;
    private _customDenyUrl?;
    get customDenyUrl(): string;
    set customDenyUrl(value: string);
    resetCustomDenyUrl(): void;
    get customDenyUrlInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _enableBindingCookie?;
    get enableBindingCookie(): boolean | cdktn.IResolvable;
    set enableBindingCookie(value: boolean | cdktn.IResolvable);
    resetEnableBindingCookie(): void;
    get enableBindingCookieInput(): boolean | cdktn.IResolvable | undefined;
    private _httpOnlyCookieAttribute?;
    get httpOnlyCookieAttribute(): boolean | cdktn.IResolvable;
    set httpOnlyCookieAttribute(value: boolean | cdktn.IResolvable);
    resetHttpOnlyCookieAttribute(): void;
    get httpOnlyCookieAttributeInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logoUrl?;
    get logoUrl(): string;
    set logoUrl(value: string);
    resetLogoUrl(): void;
    get logoUrlInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sameSiteCookieAttribute?;
    get sameSiteCookieAttribute(): string;
    set sameSiteCookieAttribute(value: string);
    resetSameSiteCookieAttribute(): void;
    get sameSiteCookieAttributeInput(): string | undefined;
    private _serviceAuth401Redirect?;
    get serviceAuth401Redirect(): boolean | cdktn.IResolvable;
    set serviceAuth401Redirect(value: boolean | cdktn.IResolvable);
    resetServiceAuth401Redirect(): void;
    get serviceAuth401RedirectInput(): boolean | cdktn.IResolvable | undefined;
    private _sessionDuration?;
    get sessionDuration(): string;
    set sessionDuration(value: string);
    resetSessionDuration(): void;
    get sessionDurationInput(): string | undefined;
    private _skipInterstitial?;
    get skipInterstitial(): boolean | cdktn.IResolvable;
    set skipInterstitial(value: boolean | cdktn.IResolvable);
    resetSkipInterstitial(): void;
    get skipInterstitialInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _corsHeaders;
    get corsHeaders(): AccessApplicationCorsHeadersList;
    putCorsHeaders(value: AccessApplicationCorsHeaders[] | cdktn.IResolvable): void;
    resetCorsHeaders(): void;
    get corsHeadersInput(): cdktn.IResolvable | AccessApplicationCorsHeaders[] | undefined;
    private _saasApp;
    get saasApp(): AccessApplicationSaasAppOutputReference;
    putSaasApp(value: AccessApplicationSaasApp): void;
    resetSaasApp(): void;
    get saasAppInput(): AccessApplicationSaasApp | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
