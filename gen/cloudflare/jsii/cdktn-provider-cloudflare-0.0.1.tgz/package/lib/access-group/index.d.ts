import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. Conflicts with `zone_id`. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#account_id AccessGroup#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#id AccessGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name: string;
    /**
    * The zone identifier to target for the resource. Conflicts with `account_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#zone_id AccessGroup#zone_id}
    */
    readonly zoneId?: string;
    /**
    * exclude block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#exclude AccessGroup#exclude}
    */
    readonly exclude?: AccessGroupExclude[] | cdktn.IResolvable;
    /**
    * include block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#include AccessGroup#include}
    */
    readonly include: AccessGroupInclude[] | cdktn.IResolvable;
    /**
    * require block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#require AccessGroup#require}
    */
    readonly require?: AccessGroupRequire[] | cdktn.IResolvable;
}
export interface AccessGroupExcludeAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#id AccessGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupExcludeAzureToTerraform(struct?: AccessGroupExcludeAzure | cdktn.IResolvable): any;
export declare function accessGroupExcludeAzureToHclTerraform(struct?: AccessGroupExcludeAzure | cdktn.IResolvable): any;
export declare class AccessGroupExcludeAzureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExcludeAzure | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupExcludeAzure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupExcludeAzureList extends cdktn.ComplexList {
    internalValue?: AccessGroupExcludeAzure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeAzureOutputReference;
}
export interface AccessGroupExcludeExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#evaluate_url AccessGroup#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#keys_url AccessGroup#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessGroupExcludeExternalEvaluationToTerraform(struct?: AccessGroupExcludeExternalEvaluationOutputReference | AccessGroupExcludeExternalEvaluation): any;
export declare function accessGroupExcludeExternalEvaluationToHclTerraform(struct?: AccessGroupExcludeExternalEvaluationOutputReference | AccessGroupExcludeExternalEvaluation): any;
export declare class AccessGroupExcludeExternalEvaluationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessGroupExcludeExternalEvaluation | undefined;
    set internalValue(value: AccessGroupExcludeExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessGroupExcludeGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#teams AccessGroup#teams}
    */
    readonly teams?: string[];
}
export declare function accessGroupExcludeGithubToTerraform(struct?: AccessGroupExcludeGithub | cdktn.IResolvable): any;
export declare function accessGroupExcludeGithubToHclTerraform(struct?: AccessGroupExcludeGithub | cdktn.IResolvable): any;
export declare class AccessGroupExcludeGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExcludeGithub | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupExcludeGithub | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessGroupExcludeGithubList extends cdktn.ComplexList {
    internalValue?: AccessGroupExcludeGithub[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeGithubOutputReference;
}
export interface AccessGroupExcludeGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupExcludeGsuiteToTerraform(struct?: AccessGroupExcludeGsuite | cdktn.IResolvable): any;
export declare function accessGroupExcludeGsuiteToHclTerraform(struct?: AccessGroupExcludeGsuite | cdktn.IResolvable): any;
export declare class AccessGroupExcludeGsuiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExcludeGsuite | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupExcludeGsuite | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupExcludeGsuiteList extends cdktn.ComplexList {
    internalValue?: AccessGroupExcludeGsuite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeGsuiteOutputReference;
}
export interface AccessGroupExcludeOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string[];
}
export declare function accessGroupExcludeOktaToTerraform(struct?: AccessGroupExcludeOkta | cdktn.IResolvable): any;
export declare function accessGroupExcludeOktaToHclTerraform(struct?: AccessGroupExcludeOkta | cdktn.IResolvable): any;
export declare class AccessGroupExcludeOktaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExcludeOkta | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupExcludeOkta | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessGroupExcludeOktaList extends cdktn.ComplexList {
    internalValue?: AccessGroupExcludeOkta[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeOktaOutputReference;
}
export interface AccessGroupExcludeSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_name AccessGroup#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_value AccessGroup#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupExcludeSamlToTerraform(struct?: AccessGroupExcludeSaml | cdktn.IResolvable): any;
export declare function accessGroupExcludeSamlToHclTerraform(struct?: AccessGroupExcludeSaml | cdktn.IResolvable): any;
export declare class AccessGroupExcludeSamlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExcludeSaml | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupExcludeSaml | cdktn.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupExcludeSamlList extends cdktn.ComplexList {
    internalValue?: AccessGroupExcludeSaml[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeSamlOutputReference;
}
export interface AccessGroupExclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#any_valid_service_token AccessGroup#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#auth_method AccessGroup#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#certificate AccessGroup#certificate}
    */
    readonly certificate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#common_name AccessGroup#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#device_posture AccessGroup#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email_domain AccessGroup#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#everyone AccessGroup#everyone}
    */
    readonly everyone?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#geo AccessGroup#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#group AccessGroup#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip AccessGroup#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip_list AccessGroup#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#login_method AccessGroup#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#service_token AccessGroup#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#azure AccessGroup#azure}
    */
    readonly azure?: AccessGroupExcludeAzure[] | cdktn.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#external_evaluation AccessGroup#external_evaluation}
    */
    readonly externalEvaluation?: AccessGroupExcludeExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#github AccessGroup#github}
    */
    readonly github?: AccessGroupExcludeGithub[] | cdktn.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#gsuite AccessGroup#gsuite}
    */
    readonly gsuite?: AccessGroupExcludeGsuite[] | cdktn.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#okta AccessGroup#okta}
    */
    readonly okta?: AccessGroupExcludeOkta[] | cdktn.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#saml AccessGroup#saml}
    */
    readonly saml?: AccessGroupExcludeSaml[] | cdktn.IResolvable;
}
export declare function accessGroupExcludeToTerraform(struct?: AccessGroupExclude | cdktn.IResolvable): any;
export declare function accessGroupExcludeToHclTerraform(struct?: AccessGroupExclude | cdktn.IResolvable): any;
export declare class AccessGroupExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupExclude | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupExclude | cdktn.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktn.IResolvable;
    set anyValidServiceToken(value: boolean | cdktn.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktn.IResolvable;
    set certificate(value: boolean | cdktn.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktn.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktn.IResolvable;
    set everyone(value: boolean | cdktn.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktn.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessGroupExcludeAzureList;
    putAzure(value: AccessGroupExcludeAzure[] | cdktn.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktn.IResolvable | AccessGroupExcludeAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessGroupExcludeExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessGroupExcludeExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessGroupExcludeExternalEvaluation | undefined;
    private _github;
    get github(): AccessGroupExcludeGithubList;
    putGithub(value: AccessGroupExcludeGithub[] | cdktn.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktn.IResolvable | AccessGroupExcludeGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessGroupExcludeGsuiteList;
    putGsuite(value: AccessGroupExcludeGsuite[] | cdktn.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktn.IResolvable | AccessGroupExcludeGsuite[] | undefined;
    private _okta;
    get okta(): AccessGroupExcludeOktaList;
    putOkta(value: AccessGroupExcludeOkta[] | cdktn.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktn.IResolvable | AccessGroupExcludeOkta[] | undefined;
    private _saml;
    get saml(): AccessGroupExcludeSamlList;
    putSaml(value: AccessGroupExcludeSaml[] | cdktn.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktn.IResolvable | AccessGroupExcludeSaml[] | undefined;
}
export declare class AccessGroupExcludeList extends cdktn.ComplexList {
    internalValue?: AccessGroupExclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupExcludeOutputReference;
}
export interface AccessGroupIncludeAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#id AccessGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupIncludeAzureToTerraform(struct?: AccessGroupIncludeAzure | cdktn.IResolvable): any;
export declare function accessGroupIncludeAzureToHclTerraform(struct?: AccessGroupIncludeAzure | cdktn.IResolvable): any;
export declare class AccessGroupIncludeAzureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupIncludeAzure | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupIncludeAzure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupIncludeAzureList extends cdktn.ComplexList {
    internalValue?: AccessGroupIncludeAzure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeAzureOutputReference;
}
export interface AccessGroupIncludeExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#evaluate_url AccessGroup#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#keys_url AccessGroup#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessGroupIncludeExternalEvaluationToTerraform(struct?: AccessGroupIncludeExternalEvaluationOutputReference | AccessGroupIncludeExternalEvaluation): any;
export declare function accessGroupIncludeExternalEvaluationToHclTerraform(struct?: AccessGroupIncludeExternalEvaluationOutputReference | AccessGroupIncludeExternalEvaluation): any;
export declare class AccessGroupIncludeExternalEvaluationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessGroupIncludeExternalEvaluation | undefined;
    set internalValue(value: AccessGroupIncludeExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessGroupIncludeGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#teams AccessGroup#teams}
    */
    readonly teams?: string[];
}
export declare function accessGroupIncludeGithubToTerraform(struct?: AccessGroupIncludeGithub | cdktn.IResolvable): any;
export declare function accessGroupIncludeGithubToHclTerraform(struct?: AccessGroupIncludeGithub | cdktn.IResolvable): any;
export declare class AccessGroupIncludeGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupIncludeGithub | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupIncludeGithub | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessGroupIncludeGithubList extends cdktn.ComplexList {
    internalValue?: AccessGroupIncludeGithub[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeGithubOutputReference;
}
export interface AccessGroupIncludeGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupIncludeGsuiteToTerraform(struct?: AccessGroupIncludeGsuite | cdktn.IResolvable): any;
export declare function accessGroupIncludeGsuiteToHclTerraform(struct?: AccessGroupIncludeGsuite | cdktn.IResolvable): any;
export declare class AccessGroupIncludeGsuiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupIncludeGsuite | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupIncludeGsuite | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupIncludeGsuiteList extends cdktn.ComplexList {
    internalValue?: AccessGroupIncludeGsuite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeGsuiteOutputReference;
}
export interface AccessGroupIncludeOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string[];
}
export declare function accessGroupIncludeOktaToTerraform(struct?: AccessGroupIncludeOkta | cdktn.IResolvable): any;
export declare function accessGroupIncludeOktaToHclTerraform(struct?: AccessGroupIncludeOkta | cdktn.IResolvable): any;
export declare class AccessGroupIncludeOktaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupIncludeOkta | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupIncludeOkta | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessGroupIncludeOktaList extends cdktn.ComplexList {
    internalValue?: AccessGroupIncludeOkta[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeOktaOutputReference;
}
export interface AccessGroupIncludeSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_name AccessGroup#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_value AccessGroup#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupIncludeSamlToTerraform(struct?: AccessGroupIncludeSaml | cdktn.IResolvable): any;
export declare function accessGroupIncludeSamlToHclTerraform(struct?: AccessGroupIncludeSaml | cdktn.IResolvable): any;
export declare class AccessGroupIncludeSamlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupIncludeSaml | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupIncludeSaml | cdktn.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupIncludeSamlList extends cdktn.ComplexList {
    internalValue?: AccessGroupIncludeSaml[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeSamlOutputReference;
}
export interface AccessGroupInclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#any_valid_service_token AccessGroup#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#auth_method AccessGroup#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#certificate AccessGroup#certificate}
    */
    readonly certificate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#common_name AccessGroup#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#device_posture AccessGroup#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email_domain AccessGroup#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#everyone AccessGroup#everyone}
    */
    readonly everyone?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#geo AccessGroup#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#group AccessGroup#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip AccessGroup#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip_list AccessGroup#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#login_method AccessGroup#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#service_token AccessGroup#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#azure AccessGroup#azure}
    */
    readonly azure?: AccessGroupIncludeAzure[] | cdktn.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#external_evaluation AccessGroup#external_evaluation}
    */
    readonly externalEvaluation?: AccessGroupIncludeExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#github AccessGroup#github}
    */
    readonly github?: AccessGroupIncludeGithub[] | cdktn.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#gsuite AccessGroup#gsuite}
    */
    readonly gsuite?: AccessGroupIncludeGsuite[] | cdktn.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#okta AccessGroup#okta}
    */
    readonly okta?: AccessGroupIncludeOkta[] | cdktn.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#saml AccessGroup#saml}
    */
    readonly saml?: AccessGroupIncludeSaml[] | cdktn.IResolvable;
}
export declare function accessGroupIncludeToTerraform(struct?: AccessGroupInclude | cdktn.IResolvable): any;
export declare function accessGroupIncludeToHclTerraform(struct?: AccessGroupInclude | cdktn.IResolvable): any;
export declare class AccessGroupIncludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupInclude | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupInclude | cdktn.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktn.IResolvable;
    set anyValidServiceToken(value: boolean | cdktn.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktn.IResolvable;
    set certificate(value: boolean | cdktn.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktn.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktn.IResolvable;
    set everyone(value: boolean | cdktn.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktn.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessGroupIncludeAzureList;
    putAzure(value: AccessGroupIncludeAzure[] | cdktn.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktn.IResolvable | AccessGroupIncludeAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessGroupIncludeExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessGroupIncludeExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessGroupIncludeExternalEvaluation | undefined;
    private _github;
    get github(): AccessGroupIncludeGithubList;
    putGithub(value: AccessGroupIncludeGithub[] | cdktn.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktn.IResolvable | AccessGroupIncludeGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessGroupIncludeGsuiteList;
    putGsuite(value: AccessGroupIncludeGsuite[] | cdktn.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktn.IResolvable | AccessGroupIncludeGsuite[] | undefined;
    private _okta;
    get okta(): AccessGroupIncludeOktaList;
    putOkta(value: AccessGroupIncludeOkta[] | cdktn.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktn.IResolvable | AccessGroupIncludeOkta[] | undefined;
    private _saml;
    get saml(): AccessGroupIncludeSamlList;
    putSaml(value: AccessGroupIncludeSaml[] | cdktn.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktn.IResolvable | AccessGroupIncludeSaml[] | undefined;
}
export declare class AccessGroupIncludeList extends cdktn.ComplexList {
    internalValue?: AccessGroupInclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupIncludeOutputReference;
}
export interface AccessGroupRequireAzure {
    /**
    * The ID of the Azure group or user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#id AccessGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string[];
    /**
    * The ID of the Azure Identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupRequireAzureToTerraform(struct?: AccessGroupRequireAzure | cdktn.IResolvable): any;
export declare function accessGroupRequireAzureToHclTerraform(struct?: AccessGroupRequireAzure | cdktn.IResolvable): any;
export declare class AccessGroupRequireAzureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequireAzure | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupRequireAzure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string[];
    set id(value: string[]);
    resetId(): void;
    get idInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupRequireAzureList extends cdktn.ComplexList {
    internalValue?: AccessGroupRequireAzure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireAzureOutputReference;
}
export interface AccessGroupRequireExternalEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#evaluate_url AccessGroup#evaluate_url}
    */
    readonly evaluateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#keys_url AccessGroup#keys_url}
    */
    readonly keysUrl?: string;
}
export declare function accessGroupRequireExternalEvaluationToTerraform(struct?: AccessGroupRequireExternalEvaluationOutputReference | AccessGroupRequireExternalEvaluation): any;
export declare function accessGroupRequireExternalEvaluationToHclTerraform(struct?: AccessGroupRequireExternalEvaluationOutputReference | AccessGroupRequireExternalEvaluation): any;
export declare class AccessGroupRequireExternalEvaluationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessGroupRequireExternalEvaluation | undefined;
    set internalValue(value: AccessGroupRequireExternalEvaluation | undefined);
    private _evaluateUrl?;
    get evaluateUrl(): string;
    set evaluateUrl(value: string);
    resetEvaluateUrl(): void;
    get evaluateUrlInput(): string | undefined;
    private _keysUrl?;
    get keysUrl(): string;
    set keysUrl(value: string);
    resetKeysUrl(): void;
    get keysUrlInput(): string | undefined;
}
export interface AccessGroupRequireGithub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#teams AccessGroup#teams}
    */
    readonly teams?: string[];
}
export declare function accessGroupRequireGithubToTerraform(struct?: AccessGroupRequireGithub | cdktn.IResolvable): any;
export declare function accessGroupRequireGithubToHclTerraform(struct?: AccessGroupRequireGithub | cdktn.IResolvable): any;
export declare class AccessGroupRequireGithubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequireGithub | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupRequireGithub | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
}
export declare class AccessGroupRequireGithubList extends cdktn.ComplexList {
    internalValue?: AccessGroupRequireGithub[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireGithubOutputReference;
}
export interface AccessGroupRequireGsuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupRequireGsuiteToTerraform(struct?: AccessGroupRequireGsuite | cdktn.IResolvable): any;
export declare function accessGroupRequireGsuiteToHclTerraform(struct?: AccessGroupRequireGsuite | cdktn.IResolvable): any;
export declare class AccessGroupRequireGsuiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequireGsuite | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupRequireGsuite | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupRequireGsuiteList extends cdktn.ComplexList {
    internalValue?: AccessGroupRequireGsuite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireGsuiteOutputReference;
}
export interface AccessGroupRequireOkta {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#name AccessGroup#name}
    */
    readonly name?: string[];
}
export declare function accessGroupRequireOktaToTerraform(struct?: AccessGroupRequireOkta | cdktn.IResolvable): any;
export declare function accessGroupRequireOktaToHclTerraform(struct?: AccessGroupRequireOkta | cdktn.IResolvable): any;
export declare class AccessGroupRequireOktaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequireOkta | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupRequireOkta | cdktn.IResolvable | undefined);
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    private _name?;
    get name(): string[];
    set name(value: string[]);
    resetName(): void;
    get nameInput(): string[] | undefined;
}
export declare class AccessGroupRequireOktaList extends cdktn.ComplexList {
    internalValue?: AccessGroupRequireOkta[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireOktaOutputReference;
}
export interface AccessGroupRequireSaml {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_name AccessGroup#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#attribute_value AccessGroup#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#identity_provider_id AccessGroup#identity_provider_id}
    */
    readonly identityProviderId?: string;
}
export declare function accessGroupRequireSamlToTerraform(struct?: AccessGroupRequireSaml | cdktn.IResolvable): any;
export declare function accessGroupRequireSamlToHclTerraform(struct?: AccessGroupRequireSaml | cdktn.IResolvable): any;
export declare class AccessGroupRequireSamlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequireSaml | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupRequireSaml | cdktn.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
}
export declare class AccessGroupRequireSamlList extends cdktn.ComplexList {
    internalValue?: AccessGroupRequireSaml[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireSamlOutputReference;
}
export interface AccessGroupRequire {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#any_valid_service_token AccessGroup#any_valid_service_token}
    */
    readonly anyValidServiceToken?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#auth_method AccessGroup#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#certificate AccessGroup#certificate}
    */
    readonly certificate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#common_name AccessGroup#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#device_posture AccessGroup#device_posture}
    */
    readonly devicePosture?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email AccessGroup#email}
    */
    readonly email?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#email_domain AccessGroup#email_domain}
    */
    readonly emailDomain?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#everyone AccessGroup#everyone}
    */
    readonly everyone?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#geo AccessGroup#geo}
    */
    readonly geo?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#group AccessGroup#group}
    */
    readonly group?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip AccessGroup#ip}
    */
    readonly ip?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#ip_list AccessGroup#ip_list}
    */
    readonly ipList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#login_method AccessGroup#login_method}
    */
    readonly loginMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#service_token AccessGroup#service_token}
    */
    readonly serviceToken?: string[];
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#azure AccessGroup#azure}
    */
    readonly azure?: AccessGroupRequireAzure[] | cdktn.IResolvable;
    /**
    * external_evaluation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#external_evaluation AccessGroup#external_evaluation}
    */
    readonly externalEvaluation?: AccessGroupRequireExternalEvaluation;
    /**
    * github block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#github AccessGroup#github}
    */
    readonly github?: AccessGroupRequireGithub[] | cdktn.IResolvable;
    /**
    * gsuite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#gsuite AccessGroup#gsuite}
    */
    readonly gsuite?: AccessGroupRequireGsuite[] | cdktn.IResolvable;
    /**
    * okta block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#okta AccessGroup#okta}
    */
    readonly okta?: AccessGroupRequireOkta[] | cdktn.IResolvable;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#saml AccessGroup#saml}
    */
    readonly saml?: AccessGroupRequireSaml[] | cdktn.IResolvable;
}
export declare function accessGroupRequireToTerraform(struct?: AccessGroupRequire | cdktn.IResolvable): any;
export declare function accessGroupRequireToHclTerraform(struct?: AccessGroupRequire | cdktn.IResolvable): any;
export declare class AccessGroupRequireOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessGroupRequire | cdktn.IResolvable | undefined;
    set internalValue(value: AccessGroupRequire | cdktn.IResolvable | undefined);
    private _anyValidServiceToken?;
    get anyValidServiceToken(): boolean | cdktn.IResolvable;
    set anyValidServiceToken(value: boolean | cdktn.IResolvable);
    resetAnyValidServiceToken(): void;
    get anyValidServiceTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _certificate?;
    get certificate(): boolean | cdktn.IResolvable;
    set certificate(value: boolean | cdktn.IResolvable);
    resetCertificate(): void;
    get certificateInput(): boolean | cdktn.IResolvable | undefined;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _devicePosture?;
    get devicePosture(): string[];
    set devicePosture(value: string[]);
    resetDevicePosture(): void;
    get devicePostureInput(): string[] | undefined;
    private _email?;
    get email(): string[];
    set email(value: string[]);
    resetEmail(): void;
    get emailInput(): string[] | undefined;
    private _emailDomain?;
    get emailDomain(): string[];
    set emailDomain(value: string[]);
    resetEmailDomain(): void;
    get emailDomainInput(): string[] | undefined;
    private _everyone?;
    get everyone(): boolean | cdktn.IResolvable;
    set everyone(value: boolean | cdktn.IResolvable);
    resetEveryone(): void;
    get everyoneInput(): boolean | cdktn.IResolvable | undefined;
    private _geo?;
    get geo(): string[];
    set geo(value: string[]);
    resetGeo(): void;
    get geoInput(): string[] | undefined;
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _ip?;
    get ip(): string[];
    set ip(value: string[]);
    resetIp(): void;
    get ipInput(): string[] | undefined;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _loginMethod?;
    get loginMethod(): string[];
    set loginMethod(value: string[]);
    resetLoginMethod(): void;
    get loginMethodInput(): string[] | undefined;
    private _serviceToken?;
    get serviceToken(): string[];
    set serviceToken(value: string[]);
    resetServiceToken(): void;
    get serviceTokenInput(): string[] | undefined;
    private _azure;
    get azure(): AccessGroupRequireAzureList;
    putAzure(value: AccessGroupRequireAzure[] | cdktn.IResolvable): void;
    resetAzure(): void;
    get azureInput(): cdktn.IResolvable | AccessGroupRequireAzure[] | undefined;
    private _externalEvaluation;
    get externalEvaluation(): AccessGroupRequireExternalEvaluationOutputReference;
    putExternalEvaluation(value: AccessGroupRequireExternalEvaluation): void;
    resetExternalEvaluation(): void;
    get externalEvaluationInput(): AccessGroupRequireExternalEvaluation | undefined;
    private _github;
    get github(): AccessGroupRequireGithubList;
    putGithub(value: AccessGroupRequireGithub[] | cdktn.IResolvable): void;
    resetGithub(): void;
    get githubInput(): cdktn.IResolvable | AccessGroupRequireGithub[] | undefined;
    private _gsuite;
    get gsuite(): AccessGroupRequireGsuiteList;
    putGsuite(value: AccessGroupRequireGsuite[] | cdktn.IResolvable): void;
    resetGsuite(): void;
    get gsuiteInput(): cdktn.IResolvable | AccessGroupRequireGsuite[] | undefined;
    private _okta;
    get okta(): AccessGroupRequireOktaList;
    putOkta(value: AccessGroupRequireOkta[] | cdktn.IResolvable): void;
    resetOkta(): void;
    get oktaInput(): cdktn.IResolvable | AccessGroupRequireOkta[] | undefined;
    private _saml;
    get saml(): AccessGroupRequireSamlList;
    putSaml(value: AccessGroupRequireSaml[] | cdktn.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktn.IResolvable | AccessGroupRequireSaml[] | undefined;
}
export declare class AccessGroupRequireList extends cdktn.ComplexList {
    internalValue?: AccessGroupRequire[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessGroupRequireOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group cloudflare_access_group}
*/
export declare class AccessGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_access_group";
    /**
    * Generates CDKTN code for importing a AccessGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessGroup to import
    * @param importFromId The id of the existing AccessGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/access_group cloudflare_access_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessGroupConfig
    */
    constructor(scope: Construct, id: string, config: AccessGroupConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _exclude;
    get exclude(): AccessGroupExcludeList;
    putExclude(value: AccessGroupExclude[] | cdktn.IResolvable): void;
    resetExclude(): void;
    get excludeInput(): cdktn.IResolvable | AccessGroupExclude[] | undefined;
    private _include;
    get include(): AccessGroupIncludeList;
    putInclude(value: AccessGroupInclude[] | cdktn.IResolvable): void;
    get includeInput(): cdktn.IResolvable | AccessGroupInclude[] | undefined;
    private _require;
    get require(): AccessGroupRequireList;
    putRequire(value: AccessGroupRequire[] | cdktn.IResolvable): void;
    resetRequire(): void;
    get requireInput(): cdktn.IResolvable | AccessGroupRequire[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
