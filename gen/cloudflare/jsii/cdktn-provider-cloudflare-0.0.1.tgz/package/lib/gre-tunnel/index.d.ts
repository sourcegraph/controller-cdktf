import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GreTunnelConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#account_id GreTunnel#account_id}
    */
    readonly accountId?: string;
    /**
    * The IP address assigned to the Cloudflare side of the GRE tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#cloudflare_gre_endpoint GreTunnel#cloudflare_gre_endpoint}
    */
    readonly cloudflareGreEndpoint: string;
    /**
    * The IP address assigned to the customer side of the GRE tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#customer_gre_endpoint GreTunnel#customer_gre_endpoint}
    */
    readonly customerGreEndpoint: string;
    /**
    * Description of the GRE tunnel intent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#description GreTunnel#description}
    */
    readonly description?: string;
    /**
    * Specifies if ICMP tunnel health checks are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#health_check_enabled GreTunnel#health_check_enabled}
    */
    readonly healthCheckEnabled?: boolean | cdktn.IResolvable;
    /**
    * The IP address of the customer endpoint that will receive tunnel health checks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#health_check_target GreTunnel#health_check_target}
    */
    readonly healthCheckTarget?: string;
    /**
    * Specifies the ICMP echo type for the health check. Available values: `request`, `reply`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#health_check_type GreTunnel#health_check_type}
    */
    readonly healthCheckType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#id GreTunnel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * 31-bit prefix (/31 in CIDR notation) supporting 2 hosts, one for each side of the tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#interface_address GreTunnel#interface_address}
    */
    readonly interfaceAddress: string;
    /**
    * Maximum Transmission Unit (MTU) in bytes for the GRE tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#mtu GreTunnel#mtu}
    */
    readonly mtu?: number;
    /**
    * Name of the GRE tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#name GreTunnel#name}
    */
    readonly name: string;
    /**
    * Time To Live (TTL) in number of hops of the GRE tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#ttl GreTunnel#ttl}
    */
    readonly ttl?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel cloudflare_gre_tunnel}
*/
export declare class GreTunnel extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_gre_tunnel";
    /**
    * Generates CDKTN code for importing a GreTunnel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GreTunnel to import
    * @param importFromId The id of the existing GreTunnel that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GreTunnel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/gre_tunnel cloudflare_gre_tunnel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GreTunnelConfig
    */
    constructor(scope: Construct, id: string, config: GreTunnelConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _cloudflareGreEndpoint?;
    get cloudflareGreEndpoint(): string;
    set cloudflareGreEndpoint(value: string);
    get cloudflareGreEndpointInput(): string | undefined;
    private _customerGreEndpoint?;
    get customerGreEndpoint(): string;
    set customerGreEndpoint(value: string);
    get customerGreEndpointInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _healthCheckEnabled?;
    get healthCheckEnabled(): boolean | cdktn.IResolvable;
    set healthCheckEnabled(value: boolean | cdktn.IResolvable);
    resetHealthCheckEnabled(): void;
    get healthCheckEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _healthCheckTarget?;
    get healthCheckTarget(): string;
    set healthCheckTarget(value: string);
    resetHealthCheckTarget(): void;
    get healthCheckTargetInput(): string | undefined;
    private _healthCheckType?;
    get healthCheckType(): string;
    set healthCheckType(value: string);
    resetHealthCheckType(): void;
    get healthCheckTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interfaceAddress?;
    get interfaceAddress(): string;
    set interfaceAddress(value: string);
    get interfaceAddressInput(): string | undefined;
    private _mtu?;
    get mtu(): number;
    set mtu(value: number);
    resetMtu(): void;
    get mtuInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
