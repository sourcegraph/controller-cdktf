import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DeviceDexTestConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource. **Modifying this attribute will force creation of a new resource.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#account_id DeviceDexTest#account_id}
    */
    readonly accountId: string;
    /**
    * Additional details about the test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#description DeviceDexTest#description}
    */
    readonly description: string;
    /**
    * Determines whether or not the test is active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#enabled DeviceDexTest#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#id DeviceDexTest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * How often the test will run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#interval DeviceDexTest#interval}
    */
    readonly interval: string;
    /**
    * The name of the Device Dex Test. Must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#name DeviceDexTest#name}
    */
    readonly name: string;
    /**
    * data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#data DeviceDexTest#data}
    */
    readonly data: DeviceDexTestData;
}
export interface DeviceDexTestData {
    /**
    * The host URL for `http` test `kind`. For `traceroute`, it must be a valid hostname or IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#host DeviceDexTest#host}
    */
    readonly host: string;
    /**
    * The type of Device Dex Test. Available values: `http`, `traceroute`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#kind DeviceDexTest#kind}
    */
    readonly kind: string;
    /**
    * The http request method. Available values: `GET`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#method DeviceDexTest#method}
    */
    readonly method?: string;
}
export declare function deviceDexTestDataToTerraform(struct?: DeviceDexTestDataOutputReference | DeviceDexTestData): any;
export declare function deviceDexTestDataToHclTerraform(struct?: DeviceDexTestDataOutputReference | DeviceDexTestData): any;
export declare class DeviceDexTestDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DeviceDexTestData | undefined;
    set internalValue(value: DeviceDexTestData | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test cloudflare_device_dex_test}
*/
export declare class DeviceDexTest extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_device_dex_test";
    /**
    * Generates CDKTN code for importing a DeviceDexTest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DeviceDexTest to import
    * @param importFromId The id of the existing DeviceDexTest that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DeviceDexTest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_dex_test cloudflare_device_dex_test} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DeviceDexTestConfig
    */
    constructor(scope: Construct, id: string, config: DeviceDexTestConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get created(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    get intervalInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get updated(): string;
    private _data;
    get data(): DeviceDexTestDataOutputReference;
    putData(value: DeviceDexTestData): void;
    get dataInput(): DeviceDexTestData | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
