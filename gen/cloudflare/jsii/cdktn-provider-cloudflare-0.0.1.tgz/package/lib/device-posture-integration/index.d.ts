import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DevicePostureIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#account_id DevicePostureIntegration#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#id DevicePostureIntegration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#identifier DevicePostureIntegration#identifier}
    */
    readonly identifier?: string;
    /**
    * Indicates the frequency with which to poll the third-party API. Must be in the format `1h` or `30m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#interval DevicePostureIntegration#interval}
    */
    readonly interval?: string;
    /**
    * Name of the device posture integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#name DevicePostureIntegration#name}
    */
    readonly name: string;
    /**
    * The device posture integration type. Available values: `workspace_one`, `uptycs`, `crowdstrike_s2s`, `intune`, `kolide`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#type DevicePostureIntegration#type}
    */
    readonly type: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#config DevicePostureIntegration#config}
    */
    readonly config?: DevicePostureIntegrationConfigA[] | cdktn.IResolvable;
}
export interface DevicePostureIntegrationConfigA {
    /**
    * The third-party API's URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#api_url DevicePostureIntegration#api_url}
    */
    readonly apiUrl?: string;
    /**
    * The third-party authorization API URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#auth_url DevicePostureIntegration#auth_url}
    */
    readonly authUrl?: string;
    /**
    * The client identifier for authenticating API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#client_id DevicePostureIntegration#client_id}
    */
    readonly clientId?: string;
    /**
    * The client key for authenticating API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#client_key DevicePostureIntegration#client_key}
    */
    readonly clientKey?: string;
    /**
    * The client secret for authenticating API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#client_secret DevicePostureIntegration#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * The customer identifier for authenticating API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#customer_id DevicePostureIntegration#customer_id}
    */
    readonly customerId?: string;
}
export declare function devicePostureIntegrationConfigAToTerraform(struct?: DevicePostureIntegrationConfigA | cdktn.IResolvable): any;
export declare function devicePostureIntegrationConfigAToHclTerraform(struct?: DevicePostureIntegrationConfigA | cdktn.IResolvable): any;
export declare class DevicePostureIntegrationConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DevicePostureIntegrationConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: DevicePostureIntegrationConfigA | cdktn.IResolvable | undefined);
    private _apiUrl?;
    get apiUrl(): string;
    set apiUrl(value: string);
    resetApiUrl(): void;
    get apiUrlInput(): string | undefined;
    private _authUrl?;
    get authUrl(): string;
    set authUrl(value: string);
    resetAuthUrl(): void;
    get authUrlInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientKey?;
    get clientKey(): string;
    set clientKey(value: string);
    resetClientKey(): void;
    get clientKeyInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _customerId?;
    get customerId(): string;
    set customerId(value: string);
    resetCustomerId(): void;
    get customerIdInput(): string | undefined;
}
export declare class DevicePostureIntegrationConfigAList extends cdktn.ComplexList {
    internalValue?: DevicePostureIntegrationConfigA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DevicePostureIntegrationConfigAOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration cloudflare_device_posture_integration}
*/
export declare class DevicePostureIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_device_posture_integration";
    /**
    * Generates CDKTN code for importing a DevicePostureIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DevicePostureIntegration to import
    * @param importFromId The id of the existing DevicePostureIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DevicePostureIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/device_posture_integration cloudflare_device_posture_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DevicePostureIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: DevicePostureIntegrationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    resetIdentifier(): void;
    get identifierInput(): string | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _config;
    get config(): DevicePostureIntegrationConfigAList;
    putConfig(value: DevicePostureIntegrationConfigA[] | cdktn.IResolvable): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | DevicePostureIntegrationConfigA[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
