import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LoadBalancerPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier to target for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#account_id LoadBalancerPool#account_id}
    */
    readonly accountId: string;
    /**
    * A list of regions (specified by region code) from which to run health checks. Empty means every Cloudflare data center (the default), but requires an Enterprise plan. Region codes can be found [here](https://developers.cloudflare.com/load-balancing/reference/region-mapping-api).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#check_regions LoadBalancerPool#check_regions}
    */
    readonly checkRegions?: string[];
    /**
    * Free text description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#description LoadBalancerPool#description}
    */
    readonly description?: string;
    /**
    * Whether to enable (the default) this pool. Disabled pools will not receive traffic and are excluded from health checks. Disabling a pool will cause any load balancers using it to failover to the next pool (if any). Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#enabled LoadBalancerPool#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#id LoadBalancerPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The latitude this pool is physically located at; used for proximity steering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#latitude LoadBalancerPool#latitude}
    */
    readonly latitude?: number;
    /**
    * The longitude this pool is physically located at; used for proximity steering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#longitude LoadBalancerPool#longitude}
    */
    readonly longitude?: number;
    /**
    * The minimum number of origins that must be healthy for this pool to serve traffic. If the number of healthy origins falls below this number, the pool will be marked unhealthy and we will failover to the next available pool. Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#minimum_origins LoadBalancerPool#minimum_origins}
    */
    readonly minimumOrigins?: number;
    /**
    * The ID of the Monitor to use for health checking origins within this pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#monitor LoadBalancerPool#monitor}
    */
    readonly monitor?: string;
    /**
    * A short name (tag) for the pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#name LoadBalancerPool#name}
    */
    readonly name: string;
    /**
    * The email address to send health status notifications to. This can be an individual mailbox or a mailing list. Multiple emails can be supplied as a comma delimited list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#notification_email LoadBalancerPool#notification_email}
    */
    readonly notificationEmail?: string;
    /**
    * load_shedding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#load_shedding LoadBalancerPool#load_shedding}
    */
    readonly loadShedding?: LoadBalancerPoolLoadShedding[] | cdktn.IResolvable;
    /**
    * origin_steering block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#origin_steering LoadBalancerPool#origin_steering}
    */
    readonly originSteering?: LoadBalancerPoolOriginSteering[] | cdktn.IResolvable;
    /**
    * origins block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#origins LoadBalancerPool#origins}
    */
    readonly origins: LoadBalancerPoolOrigins[] | cdktn.IResolvable;
}
export interface LoadBalancerPoolLoadShedding {
    /**
    * Percent of traffic to shed 0 - 100. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#default_percent LoadBalancerPool#default_percent}
    */
    readonly defaultPercent?: number;
    /**
    * Method of shedding traffic. Available values: `""`, `hash`, `random`. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#default_policy LoadBalancerPool#default_policy}
    */
    readonly defaultPolicy?: string;
    /**
    * Percent of session traffic to shed 0 - 100. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#session_percent LoadBalancerPool#session_percent}
    */
    readonly sessionPercent?: number;
    /**
    * Method of shedding traffic. Available values: `""`, `hash`. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#session_policy LoadBalancerPool#session_policy}
    */
    readonly sessionPolicy?: string;
}
export declare function loadBalancerPoolLoadSheddingToTerraform(struct?: LoadBalancerPoolLoadShedding | cdktn.IResolvable): any;
export declare function loadBalancerPoolLoadSheddingToHclTerraform(struct?: LoadBalancerPoolLoadShedding | cdktn.IResolvable): any;
export declare class LoadBalancerPoolLoadSheddingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerPoolLoadShedding | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerPoolLoadShedding | cdktn.IResolvable | undefined);
    private _defaultPercent?;
    get defaultPercent(): number;
    set defaultPercent(value: number);
    resetDefaultPercent(): void;
    get defaultPercentInput(): number | undefined;
    private _defaultPolicy?;
    get defaultPolicy(): string;
    set defaultPolicy(value: string);
    resetDefaultPolicy(): void;
    get defaultPolicyInput(): string | undefined;
    private _sessionPercent?;
    get sessionPercent(): number;
    set sessionPercent(value: number);
    resetSessionPercent(): void;
    get sessionPercentInput(): number | undefined;
    private _sessionPolicy?;
    get sessionPolicy(): string;
    set sessionPolicy(value: string);
    resetSessionPolicy(): void;
    get sessionPolicyInput(): string | undefined;
}
export declare class LoadBalancerPoolLoadSheddingList extends cdktn.ComplexList {
    internalValue?: LoadBalancerPoolLoadShedding[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerPoolLoadSheddingOutputReference;
}
export interface LoadBalancerPoolOriginSteering {
    /**
    * Origin steering policy to be used. Available values: `""`, `hash`, `random`. Defaults to `random`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#policy LoadBalancerPool#policy}
    */
    readonly policy?: string;
}
export declare function loadBalancerPoolOriginSteeringToTerraform(struct?: LoadBalancerPoolOriginSteering | cdktn.IResolvable): any;
export declare function loadBalancerPoolOriginSteeringToHclTerraform(struct?: LoadBalancerPoolOriginSteering | cdktn.IResolvable): any;
export declare class LoadBalancerPoolOriginSteeringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerPoolOriginSteering | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerPoolOriginSteering | cdktn.IResolvable | undefined);
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
}
export declare class LoadBalancerPoolOriginSteeringList extends cdktn.ComplexList {
    internalValue?: LoadBalancerPoolOriginSteering[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerPoolOriginSteeringOutputReference;
}
export interface LoadBalancerPoolOriginsHeader {
    /**
    * HTTP Header name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#header LoadBalancerPool#header}
    */
    readonly header: string;
    /**
    * Values for the HTTP headers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#values LoadBalancerPool#values}
    */
    readonly values: string[];
}
export declare function loadBalancerPoolOriginsHeaderToTerraform(struct?: LoadBalancerPoolOriginsHeader | cdktn.IResolvable): any;
export declare function loadBalancerPoolOriginsHeaderToHclTerraform(struct?: LoadBalancerPoolOriginsHeader | cdktn.IResolvable): any;
export declare class LoadBalancerPoolOriginsHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerPoolOriginsHeader | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerPoolOriginsHeader | cdktn.IResolvable | undefined);
    private _header?;
    get header(): string;
    set header(value: string);
    get headerInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class LoadBalancerPoolOriginsHeaderList extends cdktn.ComplexList {
    internalValue?: LoadBalancerPoolOriginsHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerPoolOriginsHeaderOutputReference;
}
export interface LoadBalancerPoolOrigins {
    /**
    * The IP address (IPv4 or IPv6) of the origin, or the publicly addressable hostname.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#address LoadBalancerPool#address}
    */
    readonly address: string;
    /**
    * Whether this origin is enabled. Disabled origins will not receive traffic and are excluded from health checks. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#enabled LoadBalancerPool#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * A human-identifiable name for the origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#name LoadBalancerPool#name}
    */
    readonly name: string;
    /**
    * The weight (0.01 - 1.00) of this origin, relative to other origins in the pool. Equal values mean equal weighting. A weight of 0 means traffic will not be sent to this origin, but health is still checked. Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#weight LoadBalancerPool#weight}
    */
    readonly weight?: number;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#header LoadBalancerPool#header}
    */
    readonly header?: LoadBalancerPoolOriginsHeader[] | cdktn.IResolvable;
}
export declare function loadBalancerPoolOriginsToTerraform(struct?: LoadBalancerPoolOrigins | cdktn.IResolvable): any;
export declare function loadBalancerPoolOriginsToHclTerraform(struct?: LoadBalancerPoolOrigins | cdktn.IResolvable): any;
export declare class LoadBalancerPoolOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadBalancerPoolOrigins | cdktn.IResolvable | undefined;
    set internalValue(value: LoadBalancerPoolOrigins | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
    private _header;
    get header(): LoadBalancerPoolOriginsHeaderList;
    putHeader(value: LoadBalancerPoolOriginsHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | LoadBalancerPoolOriginsHeader[] | undefined;
}
export declare class LoadBalancerPoolOriginsList extends cdktn.ComplexList {
    internalValue?: LoadBalancerPoolOrigins[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadBalancerPoolOriginsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool cloudflare_load_balancer_pool}
*/
export declare class LoadBalancerPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_load_balancer_pool";
    /**
    * Generates CDKTN code for importing a LoadBalancerPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LoadBalancerPool to import
    * @param importFromId The id of the existing LoadBalancerPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LoadBalancerPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/load_balancer_pool cloudflare_load_balancer_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoadBalancerPoolConfig
    */
    constructor(scope: Construct, id: string, config: LoadBalancerPoolConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _checkRegions?;
    get checkRegions(): string[];
    set checkRegions(value: string[]);
    resetCheckRegions(): void;
    get checkRegionsInput(): string[] | undefined;
    get createdOn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _latitude?;
    get latitude(): number;
    set latitude(value: number);
    resetLatitude(): void;
    get latitudeInput(): number | undefined;
    private _longitude?;
    get longitude(): number;
    set longitude(value: number);
    resetLongitude(): void;
    get longitudeInput(): number | undefined;
    private _minimumOrigins?;
    get minimumOrigins(): number;
    set minimumOrigins(value: number);
    resetMinimumOrigins(): void;
    get minimumOriginsInput(): number | undefined;
    get modifiedOn(): string;
    private _monitor?;
    get monitor(): string;
    set monitor(value: string);
    resetMonitor(): void;
    get monitorInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notificationEmail?;
    get notificationEmail(): string;
    set notificationEmail(value: string);
    resetNotificationEmail(): void;
    get notificationEmailInput(): string | undefined;
    private _loadShedding;
    get loadShedding(): LoadBalancerPoolLoadSheddingList;
    putLoadShedding(value: LoadBalancerPoolLoadShedding[] | cdktn.IResolvable): void;
    resetLoadShedding(): void;
    get loadSheddingInput(): cdktn.IResolvable | LoadBalancerPoolLoadShedding[] | undefined;
    private _originSteering;
    get originSteering(): LoadBalancerPoolOriginSteeringList;
    putOriginSteering(value: LoadBalancerPoolOriginSteering[] | cdktn.IResolvable): void;
    resetOriginSteering(): void;
    get originSteeringInput(): cdktn.IResolvable | LoadBalancerPoolOriginSteering[] | undefined;
    private _origins;
    get origins(): LoadBalancerPoolOriginsList;
    putOrigins(value: LoadBalancerPoolOrigins[] | cdktn.IResolvable): void;
    get originsInput(): cdktn.IResolvable | LoadBalancerPoolOrigins[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
