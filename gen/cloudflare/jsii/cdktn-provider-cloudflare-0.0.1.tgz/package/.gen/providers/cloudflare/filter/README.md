# `cloudflare_filter`

Refer to the Terraform Registry for docs: [`cloudflare_filter`](https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/filter).
