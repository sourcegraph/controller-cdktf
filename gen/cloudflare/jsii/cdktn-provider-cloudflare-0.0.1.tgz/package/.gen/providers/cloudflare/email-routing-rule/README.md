# `cloudflare_email_routing_rule`

Refer to the Terraform Registry for docs: [`cloudflare_email_routing_rule`](https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/email_routing_rule).
