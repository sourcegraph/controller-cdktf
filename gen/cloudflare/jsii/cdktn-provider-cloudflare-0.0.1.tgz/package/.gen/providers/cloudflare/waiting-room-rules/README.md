# `cloudflare_waiting_room_rules`

Refer to the Terraform Registry for docs: [`cloudflare_waiting_room_rules`](https://registry.terraform.io/providers/cloudflare/cloudflare/4.3.0/docs/resources/waiting_room_rules).
