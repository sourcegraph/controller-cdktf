import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GroupRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * When this setting is enabled, the admins won't receive any of the default Okta administrator emails. These admins also won't have access to contact Okta Support and open support cases on behalf of your org.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role#disable_notifications GroupRole#disable_notifications}
    */
    readonly disableNotifications?: boolean | cdktn.IResolvable;
    /**
    * ID of group to attach admin roles to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role#group_id GroupRole#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role#id GroupRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource Set ID. Required for role_type = `CUSTOM`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role#resource_set_id GroupRole#resource_set_id}
    */
    readonly resourceSetId?: string;
    /**
    * Role ID. Required for role_type = `CUSTOM`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role#role_id GroupRole#role_id}
    */
    readonly roleId?: string;
    /**
    * Admin role assigned to the group. It can be any one of the following values:
    * 	"API_ADMIN",
    * 	"APP_ADMIN",
    * 	"CUSTOM",
    * 	"GROUP_MEMBERSHIP_ADMIN",
    * 	"HELP_DESK_ADMIN",
    * 	"MOBILE_ADMIN",
    * 	"ORG_ADMIN",
    * 	"READ_ONLY_ADMIN",
    * 	"REPORT_ADMIN",
    * 	"SUPER_ADMIN",
    * 	"USER_ADMIN"
    * 	. See [API Docs](https://developer.okta.com/docs/reference/api/roles/#role-types).
    * 	- "USER_ADMIN" is the Group Administrator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role#role_type GroupRole#role_type}
    */
    readonly roleType: string;
    /**
    * A list of app names (name represents set of app instances, like 'salesforce' or 'facebook'), or a combination of app name and app instance ID (like 'facebook.0oapsqQ6dv19pqyEo0g3') you would like as the targets of the admin role. - Only supported when used with the role type `APP_ADMIN`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role#target_app_list GroupRole#target_app_list}
    */
    readonly targetAppList?: string[];
    /**
    * A list of group IDs you would like as the targets of the admin role. - Only supported when used with the role types: `GROUP_MEMBERSHIP_ADMIN`, `HELP_DESK_ADMIN`, or `USER_ADMIN`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role#target_group_list GroupRole#target_group_list}
    */
    readonly targetGroupList?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role okta_group_role}
*/
export declare class GroupRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_group_role";
    /**
    * Generates CDKTN code for importing a GroupRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupRole to import
    * @param importFromId The id of the existing GroupRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_role okta_group_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupRoleConfig
    */
    constructor(scope: Construct, id: string, config: GroupRoleConfig);
    private _disableNotifications?;
    get disableNotifications(): boolean | cdktn.IResolvable;
    set disableNotifications(value: boolean | cdktn.IResolvable);
    resetDisableNotifications(): void;
    get disableNotificationsInput(): boolean | cdktn.IResolvable | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _resourceSetId?;
    get resourceSetId(): string;
    set resourceSetId(value: string);
    resetResourceSetId(): void;
    get resourceSetIdInput(): string | undefined;
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    resetRoleId(): void;
    get roleIdInput(): string | undefined;
    private _roleType?;
    get roleType(): string;
    set roleType(value: string);
    get roleTypeInput(): string | undefined;
    private _targetAppList?;
    get targetAppList(): string[];
    set targetAppList(value: string[]);
    resetTargetAppList(): void;
    get targetAppListInput(): string[] | undefined;
    private _targetGroupList?;
    get targetGroupList(): string[];
    set targetGroupList(value: string[]);
    resetTargetGroupList(): void;
    get targetGroupListInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
