import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaBrandsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/brands#id DataOktaBrands#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOktaBrandsBrands {
}
export declare function dataOktaBrandsBrandsToTerraform(struct?: DataOktaBrandsBrands): any;
export declare function dataOktaBrandsBrandsToHclTerraform(struct?: DataOktaBrandsBrands): any;
export declare class DataOktaBrandsBrandsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOktaBrandsBrands | undefined;
    set internalValue(value: DataOktaBrandsBrands | undefined);
    get customPrivacyPolicyUrl(): string;
    get id(): string;
    get links(): string;
    get name(): string;
    get removePoweredByOkta(): cdktn.IResolvable;
}
export declare class DataOktaBrandsBrandsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOktaBrandsBrandsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/brands okta_brands}
*/
export declare class DataOktaBrands extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_brands";
    /**
    * Generates CDKTN code for importing a DataOktaBrands resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaBrands to import
    * @param importFromId The id of the existing DataOktaBrands that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/brands#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaBrands to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/brands okta_brands} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaBrandsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaBrandsConfig);
    private _brands;
    get brands(): DataOktaBrandsBrandsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
