import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaLogStreamConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the log stream to retrieve, conflicts with `name`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/log_stream#id DataOktaLogStream#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name for the Log Stream object, conflicts with `id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/log_stream#name DataOktaLogStream#name}
    */
    readonly name?: string;
}
export interface DataOktaLogStreamSettings {
}
export declare function dataOktaLogStreamSettingsToTerraform(struct?: DataOktaLogStreamSettings | cdktn.IResolvable): any;
export declare function dataOktaLogStreamSettingsToHclTerraform(struct?: DataOktaLogStreamSettings | cdktn.IResolvable): any;
export declare class DataOktaLogStreamSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaLogStreamSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataOktaLogStreamSettings | cdktn.IResolvable | undefined);
    get accountId(): string;
    get edition(): string;
    get eventSourceName(): string;
    get host(): string;
    get region(): string;
    get token(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/log_stream okta_log_stream}
*/
export declare class DataOktaLogStream extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_log_stream";
    /**
    * Generates CDKTN code for importing a DataOktaLogStream resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaLogStream to import
    * @param importFromId The id of the existing DataOktaLogStream that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/log_stream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaLogStream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/log_stream okta_log_stream} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaLogStreamConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaLogStreamConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get status(): string;
    get type(): string;
    private _settings;
    get settings(): DataOktaLogStreamSettingsOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
