import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaOrgMetadataConfig extends cdktn.TerraformMetaArguments {
}
export interface DataOktaOrgMetadataDomains {
}
export declare function dataOktaOrgMetadataDomainsToTerraform(struct?: DataOktaOrgMetadataDomains | cdktn.IResolvable): any;
export declare function dataOktaOrgMetadataDomainsToHclTerraform(struct?: DataOktaOrgMetadataDomains | cdktn.IResolvable): any;
export declare class DataOktaOrgMetadataDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaOrgMetadataDomains | cdktn.IResolvable | undefined;
    set internalValue(value: DataOktaOrgMetadataDomains | cdktn.IResolvable | undefined);
    get alternate(): string;
    get organization(): string;
}
export interface DataOktaOrgMetadataSettings {
}
export declare function dataOktaOrgMetadataSettingsToTerraform(struct?: DataOktaOrgMetadataSettings | cdktn.IResolvable): any;
export declare function dataOktaOrgMetadataSettingsToHclTerraform(struct?: DataOktaOrgMetadataSettings | cdktn.IResolvable): any;
export declare class DataOktaOrgMetadataSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaOrgMetadataSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataOktaOrgMetadataSettings | cdktn.IResolvable | undefined);
    get analyticsCollectionEnabled(): cdktn.IResolvable;
    get bugReportingEnabled(): cdktn.IResolvable;
    get omEnabled(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/org_metadata okta_org_metadata}
*/
export declare class DataOktaOrgMetadata extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_org_metadata";
    /**
    * Generates CDKTN code for importing a DataOktaOrgMetadata resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaOrgMetadata to import
    * @param importFromId The id of the existing DataOktaOrgMetadata that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/org_metadata#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaOrgMetadata to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/org_metadata okta_org_metadata} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaOrgMetadataConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaOrgMetadataConfig);
    get id(): string;
    get pipeline(): string;
    private _domains;
    get domains(): DataOktaOrgMetadataDomainsOutputReference;
    private _settings;
    get settings(): DataOktaOrgMetadataSettingsOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
