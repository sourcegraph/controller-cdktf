import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaNetworkZoneConfig extends cdktn.TerraformMetaArguments {
    /**
    * Array of locations ISO-3166-1(2) excluded. Format code: countryCode OR countryCode-regionCode. Use with type `DYNAMIC_V2`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/network_zone#dynamic_locations_exclude DataOktaNetworkZone#dynamic_locations_exclude}
    */
    readonly dynamicLocationsExclude?: string[];
    /**
    * ID of the network zone to retrieve, conflicts with `name`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/network_zone#id DataOktaNetworkZone#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * List of ip service excluded. Use with type `DYNAMIC_V2`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/network_zone#ip_service_categories_exclude DataOktaNetworkZone#ip_service_categories_exclude}
    */
    readonly ipServiceCategoriesExclude?: string[];
    /**
    * List of ip service included. Use with type `DYNAMIC_V2`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/network_zone#ip_service_categories_include DataOktaNetworkZone#ip_service_categories_include}
    */
    readonly ipServiceCategoriesInclude?: string[];
    /**
    * Name of the network zone to retrieve, conflicts with `id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/network_zone#name DataOktaNetworkZone#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/network_zone okta_network_zone}
*/
export declare class DataOktaNetworkZone extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_network_zone";
    /**
    * Generates CDKTN code for importing a DataOktaNetworkZone resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaNetworkZone to import
    * @param importFromId The id of the existing DataOktaNetworkZone that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/network_zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaNetworkZone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/network_zone okta_network_zone} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaNetworkZoneConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaNetworkZoneConfig);
    get asns(): string[];
    get dynamicLocations(): string[];
    private _dynamicLocationsExclude?;
    get dynamicLocationsExclude(): string[];
    set dynamicLocationsExclude(value: string[]);
    resetDynamicLocationsExclude(): void;
    get dynamicLocationsExcludeInput(): string[] | undefined;
    get dynamicProxyType(): string;
    get gateways(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipServiceCategoriesExclude?;
    get ipServiceCategoriesExclude(): string[];
    set ipServiceCategoriesExclude(value: string[]);
    resetIpServiceCategoriesExclude(): void;
    get ipServiceCategoriesExcludeInput(): string[] | undefined;
    private _ipServiceCategoriesInclude?;
    get ipServiceCategoriesInclude(): string[];
    set ipServiceCategoriesInclude(value: string[]);
    resetIpServiceCategoriesInclude(): void;
    get ipServiceCategoriesIncludeInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get proxies(): string[];
    get status(): string;
    get type(): string;
    get usage(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
