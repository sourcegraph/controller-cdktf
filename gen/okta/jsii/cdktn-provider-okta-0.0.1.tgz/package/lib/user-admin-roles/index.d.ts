import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UserAdminRolesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The list of Okta user admin roles, e.g. `['APP_ADMIN', 'USER_ADMIN']` See [API Docs](https://developer.okta.com/docs/reference/api/roles/#role-types).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_admin_roles#admin_roles UserAdminRoles#admin_roles}
    */
    readonly adminRoles: string[];
    /**
    * When this setting is enabled, the admins won't receive any of the default Okta administrator emails. These admins also won't have access to contact Okta Support and open support cases on behalf of your org.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_admin_roles#disable_notifications UserAdminRoles#disable_notifications}
    */
    readonly disableNotifications?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_admin_roles#id UserAdminRoles#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ID of a Okta User
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_admin_roles#user_id UserAdminRoles#user_id}
    */
    readonly userId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_admin_roles okta_user_admin_roles}
*/
export declare class UserAdminRoles extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_user_admin_roles";
    /**
    * Generates CDKTN code for importing a UserAdminRoles resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserAdminRoles to import
    * @param importFromId The id of the existing UserAdminRoles that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_admin_roles#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserAdminRoles to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_admin_roles okta_user_admin_roles} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserAdminRolesConfig
    */
    constructor(scope: Construct, id: string, config: UserAdminRolesConfig);
    private _adminRoles?;
    get adminRoles(): string[];
    set adminRoles(value: string[]);
    get adminRolesInput(): string[] | undefined;
    private _disableNotifications?;
    get disableNotifications(): boolean | cdktn.IResolvable;
    set disableNotifications(value: boolean | cdktn.IResolvable);
    resetDisableNotifications(): void;
    get disableNotificationsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
