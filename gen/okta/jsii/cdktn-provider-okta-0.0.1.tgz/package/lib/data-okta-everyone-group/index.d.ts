import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaEveryoneGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/everyone_group#id DataOktaEveryoneGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Fetch group users, having default off cuts down on API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/everyone_group#include_users DataOktaEveryoneGroup#include_users}
    */
    readonly includeUsers?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/everyone_group okta_everyone_group}
*/
export declare class DataOktaEveryoneGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_everyone_group";
    /**
    * Generates CDKTN code for importing a DataOktaEveryoneGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaEveryoneGroup to import
    * @param importFromId The id of the existing DataOktaEveryoneGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/everyone_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaEveryoneGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/everyone_group okta_everyone_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaEveryoneGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaEveryoneGroupConfig);
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeUsers?;
    get includeUsers(): boolean | cdktn.IResolvable;
    set includeUsers(value: boolean | cdktn.IResolvable);
    resetIncludeUsers(): void;
    get includeUsersInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
