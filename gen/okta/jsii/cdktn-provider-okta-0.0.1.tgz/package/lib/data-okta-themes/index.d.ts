import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaThemesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Brand ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/themes#brand_id DataOktaThemes#brand_id}
    */
    readonly brandId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/themes#id DataOktaThemes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOktaThemesThemes {
}
export declare function dataOktaThemesThemesToTerraform(struct?: DataOktaThemesThemes): any;
export declare function dataOktaThemesThemesToHclTerraform(struct?: DataOktaThemesThemes): any;
export declare class DataOktaThemesThemesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOktaThemesThemes | undefined;
    set internalValue(value: DataOktaThemesThemes | undefined);
    get backgroundImageUrl(): string;
    get emailTemplateTouchPointVariant(): string;
    get endUserDashboardTouchPointVariant(): string;
    get errorPageTouchPointVariant(): string;
    get faviconUrl(): string;
    get id(): string;
    get links(): string;
    get logoUrl(): string;
    get primaryColorContrastHex(): string;
    get primaryColorHex(): string;
    get secondaryColorContrastHex(): string;
    get secondaryColorHex(): string;
    get signInPageTouchPointVariant(): string;
}
export declare class DataOktaThemesThemesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOktaThemesThemesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/themes okta_themes}
*/
export declare class DataOktaThemes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_themes";
    /**
    * Generates CDKTN code for importing a DataOktaThemes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaThemes to import
    * @param importFromId The id of the existing DataOktaThemes that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/themes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaThemes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/themes okta_themes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaThemesConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaThemesConfig);
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    get brandIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _themes;
    get themes(): DataOktaThemesThemesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
