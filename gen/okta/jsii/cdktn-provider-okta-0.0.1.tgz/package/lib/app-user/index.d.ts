import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * App to associate user with
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user#app_id AppUser#app_id}
    */
    readonly appId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user#id AppUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The password to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user#password AppUser#password}
    */
    readonly password?: string;
    /**
    * The JSON profile of the App User.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user#profile AppUser#profile}
    */
    readonly profile?: string;
    /**
    * Retain the user assignment on destroy. If set to true, the resource will be removed from state but not from the Okta app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user#retain_assignment AppUser#retain_assignment}
    */
    readonly retainAssignment?: boolean | cdktn.IResolvable;
    /**
    * User associated with the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user#user_id AppUser#user_id}
    */
    readonly userId: string;
    /**
    * The username to use for the app user. In case the user is assigned to the app with `SHARED_USERNAME_AND_PASSWORD` credentials scheme, this field will be computed and should not be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user#username AppUser#username}
    */
    readonly username?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user okta_app_user}
*/
export declare class AppUser extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_app_user";
    /**
    * Generates CDKTN code for importing a AppUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppUser to import
    * @param importFromId The id of the existing AppUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user okta_app_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppUserConfig
    */
    constructor(scope: Construct, id: string, config: AppUserConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    get hasSharedUsername(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _profile?;
    get profile(): string;
    set profile(value: string);
    resetProfile(): void;
    get profileInput(): string | undefined;
    private _retainAssignment?;
    get retainAssignment(): boolean | cdktn.IResolvable;
    set retainAssignment(value: boolean | cdktn.IResolvable);
    resetRetainAssignment(): void;
    get retainAssignmentInput(): boolean | cdktn.IResolvable | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
