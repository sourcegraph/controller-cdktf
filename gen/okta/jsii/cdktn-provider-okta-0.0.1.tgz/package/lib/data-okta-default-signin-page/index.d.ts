import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaDefaultSigninPageConfig extends cdktn.TerraformMetaArguments {
    /**
    * brand id of the preview signin page
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/default_signin_page#brand_id DataOktaDefaultSigninPage#brand_id}
    */
    readonly brandId: string;
}
export interface DataOktaDefaultSigninPageContentSecurityPolicySetting {
}
export declare function dataOktaDefaultSigninPageContentSecurityPolicySettingToTerraform(struct?: DataOktaDefaultSigninPageContentSecurityPolicySetting | cdktn.IResolvable): any;
export declare function dataOktaDefaultSigninPageContentSecurityPolicySettingToHclTerraform(struct?: DataOktaDefaultSigninPageContentSecurityPolicySetting | cdktn.IResolvable): any;
export declare class DataOktaDefaultSigninPageContentSecurityPolicySettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDefaultSigninPageContentSecurityPolicySetting | cdktn.IResolvable | undefined;
    set internalValue(value: DataOktaDefaultSigninPageContentSecurityPolicySetting | cdktn.IResolvable | undefined);
    get mode(): string;
    get reportUri(): string;
    get srcList(): string[];
}
export interface DataOktaDefaultSigninPageWidgetCustomizations {
}
export declare function dataOktaDefaultSigninPageWidgetCustomizationsToTerraform(struct?: DataOktaDefaultSigninPageWidgetCustomizations | cdktn.IResolvable): any;
export declare function dataOktaDefaultSigninPageWidgetCustomizationsToHclTerraform(struct?: DataOktaDefaultSigninPageWidgetCustomizations | cdktn.IResolvable): any;
export declare class DataOktaDefaultSigninPageWidgetCustomizationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDefaultSigninPageWidgetCustomizations | cdktn.IResolvable | undefined;
    set internalValue(value: DataOktaDefaultSigninPageWidgetCustomizations | cdktn.IResolvable | undefined);
    get authenticatorPageCustomLinkLabel(): string;
    get authenticatorPageCustomLinkUrl(): string;
    get classicRecoveryFlowEmailOrUsernameLabel(): string;
    get customLink1Label(): string;
    get customLink1Url(): string;
    get customLink2Label(): string;
    get customLink2Url(): string;
    get forgotPasswordLabel(): string;
    get forgotPasswordUrl(): string;
    get helpLabel(): string;
    get helpUrl(): string;
    get passwordInfoTip(): string;
    get passwordLabel(): string;
    get showPasswordVisibilityToggle(): cdktn.IResolvable;
    get showUserIdentifier(): cdktn.IResolvable;
    get signInLabel(): string;
    get unlockAccountLabel(): string;
    get unlockAccountUrl(): string;
    get usernameInfoTip(): string;
    get usernameLabel(): string;
    get widgetGeneration(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/default_signin_page okta_default_signin_page}
*/
export declare class DataOktaDefaultSigninPage extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_default_signin_page";
    /**
    * Generates CDKTN code for importing a DataOktaDefaultSigninPage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaDefaultSigninPage to import
    * @param importFromId The id of the existing DataOktaDefaultSigninPage that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/default_signin_page#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaDefaultSigninPage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/default_signin_page okta_default_signin_page} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaDefaultSigninPageConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaDefaultSigninPageConfig);
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    get brandIdInput(): string | undefined;
    get id(): string;
    get pageContent(): string;
    get widgetVersion(): string;
    private _contentSecurityPolicySetting;
    get contentSecurityPolicySetting(): DataOktaDefaultSigninPageContentSecurityPolicySettingOutputReference;
    private _widgetCustomizations;
    get widgetCustomizations(): DataOktaDefaultSigninPageWidgetCustomizationsOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
