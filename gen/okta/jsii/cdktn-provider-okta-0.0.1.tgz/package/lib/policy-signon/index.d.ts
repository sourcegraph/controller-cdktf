import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PolicySignonConfig extends cdktn.TerraformMetaArguments {
    /**
    * Policy Description
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_signon#description PolicySignon#description}
    */
    readonly description?: string;
    /**
    * List of Group IDs to Include
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_signon#groups_included PolicySignon#groups_included}
    */
    readonly groupsIncluded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_signon#id PolicySignon#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Policy Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_signon#name PolicySignon#name}
    */
    readonly name: string;
    /**
    * Policy Priority, this attribute can be set to a valid priority. To avoid endless diff situation we error if an invalid priority is provided. API defaults it to the last (lowest) if not there.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_signon#priority PolicySignon#priority}
    */
    readonly priority?: number;
    /**
    * Policy Status: `ACTIVE` or `INACTIVE`. Default: `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_signon#status PolicySignon#status}
    */
    readonly status?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_signon okta_policy_signon}
*/
export declare class PolicySignon extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_policy_signon";
    /**
    * Generates CDKTN code for importing a PolicySignon resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicySignon to import
    * @param importFromId The id of the existing PolicySignon that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_signon#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicySignon to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_signon okta_policy_signon} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicySignonConfig
    */
    constructor(scope: Construct, id: string, config: PolicySignonConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _groupsIncluded?;
    get groupsIncluded(): string[];
    set groupsIncluded(value: string[]);
    resetGroupsIncluded(): void;
    get groupsIncludedInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
