import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppAutoLoginConfig extends cdktn.TerraformMetaArguments {
    /**
    * Custom error page URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#accessibility_error_redirect_url AppAutoLogin#accessibility_error_redirect_url}
    */
    readonly accessibilityErrorRedirectUrl?: string;
    /**
    * Custom login page URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#accessibility_login_redirect_url AppAutoLogin#accessibility_login_redirect_url}
    */
    readonly accessibilityLoginRedirectUrl?: string;
    /**
    * Enable self service. Default is `false`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#accessibility_self_service AppAutoLogin#accessibility_self_service}
    */
    readonly accessibilitySelfService?: boolean | cdktn.IResolvable;
    /**
    * Application notes for admins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#admin_note AppAutoLogin#admin_note}
    */
    readonly adminNote?: string;
    /**
    * Displays specific appLinks for the app. The value for each application link should be boolean.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#app_links_json AppAutoLogin#app_links_json}
    */
    readonly appLinksJson?: string;
    /**
    * Application settings in JSON format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#app_settings_json AppAutoLogin#app_settings_json}
    */
    readonly appSettingsJson?: string;
    /**
    * Display auto submit toolbar
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#auto_submit_toolbar AppAutoLogin#auto_submit_toolbar}
    */
    readonly autoSubmitToolbar?: boolean | cdktn.IResolvable;
    /**
    * Application credentials scheme. One of: `EDIT_USERNAME_AND_PASSWORD`, `ADMIN_SETS_CREDENTIALS`, `EDIT_PASSWORD_ONLY`, `EXTERNAL_PASSWORD_SYNC`, or `SHARED_USERNAME_AND_PASSWORD`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#credentials_scheme AppAutoLogin#credentials_scheme}
    */
    readonly credentialsScheme?: string;
    /**
    * Application notes for end users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#enduser_note AppAutoLogin#enduser_note}
    */
    readonly enduserNote?: string;
    /**
    * Do not display application icon on mobile app
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#hide_ios AppAutoLogin#hide_ios}
    */
    readonly hideIos?: boolean | cdktn.IResolvable;
    /**
    * Do not display application icon to users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#hide_web AppAutoLogin#hide_web}
    */
    readonly hideWeb?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#id AppAutoLogin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The Application's display name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#label AppAutoLogin#label}
    */
    readonly label: string;
    /**
    * Local file path to the logo. The file must be in PNG, JPG, or GIF format, and less than 1 MB in size.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#logo AppAutoLogin#logo}
    */
    readonly logo?: string;
    /**
    * Tells Okta to use an existing application in their application catalog, as opposed to a custom application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#preconfigured_app AppAutoLogin#preconfigured_app}
    */
    readonly preconfiguredApp?: string;
    /**
    * Allow user to reveal password. Default is false. It can not be set to true if credentials_scheme is "ADMIN_SETS_CREDENTIALS", "SHARED_USERNAME_AND_PASSWORD" or "EXTERNAL_PASSWORD_SYNC".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#reveal_password AppAutoLogin#reveal_password}
    */
    readonly revealPassword?: boolean | cdktn.IResolvable;
    /**
    * Shared password, required for certain schemes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#shared_password AppAutoLogin#shared_password}
    */
    readonly sharedPassword?: string;
    /**
    * Shared username, required for certain schemes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#shared_username AppAutoLogin#shared_username}
    */
    readonly sharedUsername?: string;
    /**
    * Post login redirect URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#sign_on_redirect_url AppAutoLogin#sign_on_redirect_url}
    */
    readonly signOnRedirectUrl?: string;
    /**
    * Login URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#sign_on_url AppAutoLogin#sign_on_url}
    */
    readonly signOnUrl?: string;
    /**
    * Status of application. By default, it is `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#status AppAutoLogin#status}
    */
    readonly status?: string;
    /**
    * Username template. Default: `${source.login}`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#user_name_template AppAutoLogin#user_name_template}
    */
    readonly userNameTemplate?: string;
    /**
    * Push username on update. Valid values: `PUSH` and `DONT_PUSH`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#user_name_template_push_status AppAutoLogin#user_name_template_push_status}
    */
    readonly userNameTemplatePushStatus?: string;
    /**
    * Username template suffix
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#user_name_template_suffix AppAutoLogin#user_name_template_suffix}
    */
    readonly userNameTemplateSuffix?: string;
    /**
    * Username template type. Default: `BUILT_IN`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#user_name_template_type AppAutoLogin#user_name_template_type}
    */
    readonly userNameTemplateType?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#timeouts AppAutoLogin#timeouts}
    */
    readonly timeouts?: AppAutoLoginTimeouts;
}
export interface AppAutoLoginTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#create AppAutoLogin#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#read AppAutoLogin#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#update AppAutoLogin#update}
    */
    readonly update?: string;
}
export declare function appAutoLoginTimeoutsToTerraform(struct?: AppAutoLoginTimeouts | cdktn.IResolvable): any;
export declare function appAutoLoginTimeoutsToHclTerraform(struct?: AppAutoLoginTimeouts | cdktn.IResolvable): any;
export declare class AppAutoLoginTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppAutoLoginTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AppAutoLoginTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login okta_app_auto_login}
*/
export declare class AppAutoLogin extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_app_auto_login";
    /**
    * Generates CDKTN code for importing a AppAutoLogin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppAutoLogin to import
    * @param importFromId The id of the existing AppAutoLogin that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppAutoLogin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_auto_login okta_app_auto_login} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppAutoLoginConfig
    */
    constructor(scope: Construct, id: string, config: AppAutoLoginConfig);
    private _accessibilityErrorRedirectUrl?;
    get accessibilityErrorRedirectUrl(): string;
    set accessibilityErrorRedirectUrl(value: string);
    resetAccessibilityErrorRedirectUrl(): void;
    get accessibilityErrorRedirectUrlInput(): string | undefined;
    private _accessibilityLoginRedirectUrl?;
    get accessibilityLoginRedirectUrl(): string;
    set accessibilityLoginRedirectUrl(value: string);
    resetAccessibilityLoginRedirectUrl(): void;
    get accessibilityLoginRedirectUrlInput(): string | undefined;
    private _accessibilitySelfService?;
    get accessibilitySelfService(): boolean | cdktn.IResolvable;
    set accessibilitySelfService(value: boolean | cdktn.IResolvable);
    resetAccessibilitySelfService(): void;
    get accessibilitySelfServiceInput(): boolean | cdktn.IResolvable | undefined;
    private _adminNote?;
    get adminNote(): string;
    set adminNote(value: string);
    resetAdminNote(): void;
    get adminNoteInput(): string | undefined;
    private _appLinksJson?;
    get appLinksJson(): string;
    set appLinksJson(value: string);
    resetAppLinksJson(): void;
    get appLinksJsonInput(): string | undefined;
    private _appSettingsJson?;
    get appSettingsJson(): string;
    set appSettingsJson(value: string);
    resetAppSettingsJson(): void;
    get appSettingsJsonInput(): string | undefined;
    private _autoSubmitToolbar?;
    get autoSubmitToolbar(): boolean | cdktn.IResolvable;
    set autoSubmitToolbar(value: boolean | cdktn.IResolvable);
    resetAutoSubmitToolbar(): void;
    get autoSubmitToolbarInput(): boolean | cdktn.IResolvable | undefined;
    private _credentialsScheme?;
    get credentialsScheme(): string;
    set credentialsScheme(value: string);
    resetCredentialsScheme(): void;
    get credentialsSchemeInput(): string | undefined;
    private _enduserNote?;
    get enduserNote(): string;
    set enduserNote(value: string);
    resetEnduserNote(): void;
    get enduserNoteInput(): string | undefined;
    private _hideIos?;
    get hideIos(): boolean | cdktn.IResolvable;
    set hideIos(value: boolean | cdktn.IResolvable);
    resetHideIos(): void;
    get hideIosInput(): boolean | cdktn.IResolvable | undefined;
    private _hideWeb?;
    get hideWeb(): boolean | cdktn.IResolvable;
    set hideWeb(value: boolean | cdktn.IResolvable);
    resetHideWeb(): void;
    get hideWebInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    get logoUrl(): string;
    get name(): string;
    private _preconfiguredApp?;
    get preconfiguredApp(): string;
    set preconfiguredApp(value: string);
    resetPreconfiguredApp(): void;
    get preconfiguredAppInput(): string | undefined;
    private _revealPassword?;
    get revealPassword(): boolean | cdktn.IResolvable;
    set revealPassword(value: boolean | cdktn.IResolvable);
    resetRevealPassword(): void;
    get revealPasswordInput(): boolean | cdktn.IResolvable | undefined;
    private _sharedPassword?;
    get sharedPassword(): string;
    set sharedPassword(value: string);
    resetSharedPassword(): void;
    get sharedPasswordInput(): string | undefined;
    private _sharedUsername?;
    get sharedUsername(): string;
    set sharedUsername(value: string);
    resetSharedUsername(): void;
    get sharedUsernameInput(): string | undefined;
    get signOnMode(): string;
    private _signOnRedirectUrl?;
    get signOnRedirectUrl(): string;
    set signOnRedirectUrl(value: string);
    resetSignOnRedirectUrl(): void;
    get signOnRedirectUrlInput(): string | undefined;
    private _signOnUrl?;
    get signOnUrl(): string;
    set signOnUrl(value: string);
    resetSignOnUrl(): void;
    get signOnUrlInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _userNameTemplate?;
    get userNameTemplate(): string;
    set userNameTemplate(value: string);
    resetUserNameTemplate(): void;
    get userNameTemplateInput(): string | undefined;
    private _userNameTemplatePushStatus?;
    get userNameTemplatePushStatus(): string;
    set userNameTemplatePushStatus(value: string);
    resetUserNameTemplatePushStatus(): void;
    get userNameTemplatePushStatusInput(): string | undefined;
    private _userNameTemplateSuffix?;
    get userNameTemplateSuffix(): string;
    set userNameTemplateSuffix(value: string);
    resetUserNameTemplateSuffix(): void;
    get userNameTemplateSuffixInput(): string | undefined;
    private _userNameTemplateType?;
    get userNameTemplateType(): string;
    set userNameTemplateType(value: string);
    resetUserNameTemplateType(): void;
    get userNameTemplateTypeInput(): string | undefined;
    private _timeouts;
    get timeouts(): AppAutoLoginTimeoutsOutputReference;
    putTimeouts(value: AppAutoLoginTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AppAutoLoginTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
