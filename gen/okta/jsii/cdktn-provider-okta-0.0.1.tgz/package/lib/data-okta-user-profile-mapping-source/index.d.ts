import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaUserProfileMappingSourceConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/user_profile_mapping_source okta_user_profile_mapping_source}
*/
export declare class DataOktaUserProfileMappingSource extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_user_profile_mapping_source";
    /**
    * Generates CDKTN code for importing a DataOktaUserProfileMappingSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaUserProfileMappingSource to import
    * @param importFromId The id of the existing DataOktaUserProfileMappingSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/user_profile_mapping_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaUserProfileMappingSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/user_profile_mapping_source okta_user_profile_mapping_source} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaUserProfileMappingSourceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaUserProfileMappingSourceConfig);
    get id(): string;
    get name(): string;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
