import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PolicyDeviceAssuranceMacosConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of disk encryption type, can be `ALL_INTERNAL_VOLUMES`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#disk_encryption_type PolicyDeviceAssuranceMacos#disk_encryption_type}
    */
    readonly diskEncryptionType?: string[];
    /**
    * Name of the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#name PolicyDeviceAssuranceMacos#name}
    */
    readonly name: string;
    /**
    * Minimum os version of the device in the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#os_version PolicyDeviceAssuranceMacos#os_version}
    */
    readonly osVersion?: string;
    /**
    * List of screenlock type, can be `BIOMETRIC` or `BIOMETRIC, PASSCODE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#screenlock_type PolicyDeviceAssuranceMacos#screenlock_type}
    */
    readonly screenlockType?: string[];
    /**
    * Is the device secure with hardware in the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#secure_hardware_present PolicyDeviceAssuranceMacos#secure_hardware_present}
    */
    readonly secureHardwarePresent?: boolean | cdktn.IResolvable;
    /**
    * Check to include third party signal provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#third_party_signal_providers PolicyDeviceAssuranceMacos#third_party_signal_providers}
    */
    readonly thirdPartySignalProviders?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider minimum browser version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_browser_version PolicyDeviceAssuranceMacos#tpsp_browser_version}
    */
    readonly tpspBrowserVersion?: string;
    /**
    * Third party signal provider builtin dns client enable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_builtin_dns_client_enabled PolicyDeviceAssuranceMacos#tpsp_builtin_dns_client_enabled}
    */
    readonly tpspBuiltinDnsClientEnabled?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider chrome remote desktop app blocked
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_chrome_remote_desktop_app_blocked PolicyDeviceAssuranceMacos#tpsp_chrome_remote_desktop_app_blocked}
    */
    readonly tpspChromeRemoteDesktopAppBlocked?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider device enrollment domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_device_enrollment_domain PolicyDeviceAssuranceMacos#tpsp_device_enrollment_domain}
    */
    readonly tpspDeviceEnrollmentDomain?: string;
    /**
    * Third party signal provider disk encrypted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_disk_encrypted PolicyDeviceAssuranceMacos#tpsp_disk_encrypted}
    */
    readonly tpspDiskEncrypted?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider key trust level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_key_trust_level PolicyDeviceAssuranceMacos#tpsp_key_trust_level}
    */
    readonly tpspKeyTrustLevel?: string;
    /**
    * Third party signal provider os firewall
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_os_firewall PolicyDeviceAssuranceMacos#tpsp_os_firewall}
    */
    readonly tpspOsFirewall?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider minimum os version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_os_version PolicyDeviceAssuranceMacos#tpsp_os_version}
    */
    readonly tpspOsVersion?: string;
    /**
    * Third party signal provider password protection warning trigger
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_password_proctection_warning_trigger PolicyDeviceAssuranceMacos#tpsp_password_proctection_warning_trigger}
    */
    readonly tpspPasswordProctectionWarningTrigger?: string;
    /**
    * Third party signal provider realtime url check mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_realtime_url_check_mode PolicyDeviceAssuranceMacos#tpsp_realtime_url_check_mode}
    */
    readonly tpspRealtimeUrlCheckMode?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider safe browsing protection level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_safe_browsing_protection_level PolicyDeviceAssuranceMacos#tpsp_safe_browsing_protection_level}
    */
    readonly tpspSafeBrowsingProtectionLevel?: string;
    /**
    * Third party signal provider screen lock secure
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_screen_lock_secured PolicyDeviceAssuranceMacos#tpsp_screen_lock_secured}
    */
    readonly tpspScreenLockSecured?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider site isolation enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#tpsp_site_isolation_enabled PolicyDeviceAssuranceMacos#tpsp_site_isolation_enabled}
    */
    readonly tpspSiteIsolationEnabled?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos okta_policy_device_assurance_macos}
*/
export declare class PolicyDeviceAssuranceMacos extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_policy_device_assurance_macos";
    /**
    * Generates CDKTN code for importing a PolicyDeviceAssuranceMacos resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicyDeviceAssuranceMacos to import
    * @param importFromId The id of the existing PolicyDeviceAssuranceMacos that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicyDeviceAssuranceMacos to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_macos okta_policy_device_assurance_macos} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicyDeviceAssuranceMacosConfig
    */
    constructor(scope: Construct, id: string, config: PolicyDeviceAssuranceMacosConfig);
    get createdBy(): string;
    get createdDate(): string;
    private _diskEncryptionType?;
    get diskEncryptionType(): string[];
    set diskEncryptionType(value: string[]);
    resetDiskEncryptionType(): void;
    get diskEncryptionTypeInput(): string[] | undefined;
    get id(): string;
    get lastUpdate(): string;
    get lastUpdatedBy(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _osVersion?;
    get osVersion(): string;
    set osVersion(value: string);
    resetOsVersion(): void;
    get osVersionInput(): string | undefined;
    get platform(): string;
    private _screenlockType?;
    get screenlockType(): string[];
    set screenlockType(value: string[]);
    resetScreenlockType(): void;
    get screenlockTypeInput(): string[] | undefined;
    private _secureHardwarePresent?;
    get secureHardwarePresent(): boolean | cdktn.IResolvable;
    set secureHardwarePresent(value: boolean | cdktn.IResolvable);
    resetSecureHardwarePresent(): void;
    get secureHardwarePresentInput(): boolean | cdktn.IResolvable | undefined;
    private _thirdPartySignalProviders?;
    get thirdPartySignalProviders(): boolean | cdktn.IResolvable;
    set thirdPartySignalProviders(value: boolean | cdktn.IResolvable);
    resetThirdPartySignalProviders(): void;
    get thirdPartySignalProvidersInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspBrowserVersion?;
    get tpspBrowserVersion(): string;
    set tpspBrowserVersion(value: string);
    resetTpspBrowserVersion(): void;
    get tpspBrowserVersionInput(): string | undefined;
    private _tpspBuiltinDnsClientEnabled?;
    get tpspBuiltinDnsClientEnabled(): boolean | cdktn.IResolvable;
    set tpspBuiltinDnsClientEnabled(value: boolean | cdktn.IResolvable);
    resetTpspBuiltinDnsClientEnabled(): void;
    get tpspBuiltinDnsClientEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspChromeRemoteDesktopAppBlocked?;
    get tpspChromeRemoteDesktopAppBlocked(): boolean | cdktn.IResolvable;
    set tpspChromeRemoteDesktopAppBlocked(value: boolean | cdktn.IResolvable);
    resetTpspChromeRemoteDesktopAppBlocked(): void;
    get tpspChromeRemoteDesktopAppBlockedInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspDeviceEnrollmentDomain?;
    get tpspDeviceEnrollmentDomain(): string;
    set tpspDeviceEnrollmentDomain(value: string);
    resetTpspDeviceEnrollmentDomain(): void;
    get tpspDeviceEnrollmentDomainInput(): string | undefined;
    private _tpspDiskEncrypted?;
    get tpspDiskEncrypted(): boolean | cdktn.IResolvable;
    set tpspDiskEncrypted(value: boolean | cdktn.IResolvable);
    resetTpspDiskEncrypted(): void;
    get tpspDiskEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspKeyTrustLevel?;
    get tpspKeyTrustLevel(): string;
    set tpspKeyTrustLevel(value: string);
    resetTpspKeyTrustLevel(): void;
    get tpspKeyTrustLevelInput(): string | undefined;
    private _tpspOsFirewall?;
    get tpspOsFirewall(): boolean | cdktn.IResolvable;
    set tpspOsFirewall(value: boolean | cdktn.IResolvable);
    resetTpspOsFirewall(): void;
    get tpspOsFirewallInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspOsVersion?;
    get tpspOsVersion(): string;
    set tpspOsVersion(value: string);
    resetTpspOsVersion(): void;
    get tpspOsVersionInput(): string | undefined;
    private _tpspPasswordProctectionWarningTrigger?;
    get tpspPasswordProctectionWarningTrigger(): string;
    set tpspPasswordProctectionWarningTrigger(value: string);
    resetTpspPasswordProctectionWarningTrigger(): void;
    get tpspPasswordProctectionWarningTriggerInput(): string | undefined;
    private _tpspRealtimeUrlCheckMode?;
    get tpspRealtimeUrlCheckMode(): boolean | cdktn.IResolvable;
    set tpspRealtimeUrlCheckMode(value: boolean | cdktn.IResolvable);
    resetTpspRealtimeUrlCheckMode(): void;
    get tpspRealtimeUrlCheckModeInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspSafeBrowsingProtectionLevel?;
    get tpspSafeBrowsingProtectionLevel(): string;
    set tpspSafeBrowsingProtectionLevel(value: string);
    resetTpspSafeBrowsingProtectionLevel(): void;
    get tpspSafeBrowsingProtectionLevelInput(): string | undefined;
    private _tpspScreenLockSecured?;
    get tpspScreenLockSecured(): boolean | cdktn.IResolvable;
    set tpspScreenLockSecured(value: boolean | cdktn.IResolvable);
    resetTpspScreenLockSecured(): void;
    get tpspScreenLockSecuredInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspSiteIsolationEnabled?;
    get tpspSiteIsolationEnabled(): boolean | cdktn.IResolvable;
    set tpspSiteIsolationEnabled(value: boolean | cdktn.IResolvable);
    resetTpspSiteIsolationEnabled(): void;
    get tpspSiteIsolationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
