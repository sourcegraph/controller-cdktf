import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AuthServerClaimConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to include claims in token, by default it is set to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#always_include_in_token AuthServerClaim#always_include_in_token}
    */
    readonly alwaysIncludeInToken?: boolean | cdktn.IResolvable;
    /**
    * ID of the authorization server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#auth_server_id AuthServerClaim#auth_server_id}
    */
    readonly authServerId: string;
    /**
    * Specifies whether the claim is for an access token `RESOURCE` or ID token `IDENTITY`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#claim_type AuthServerClaim#claim_type}
    */
    readonly claimType: string;
    /**
    * Specifies the type of group filter if `value_type` is `GROUPS`. Can be set to one of the following `STARTS_WITH`, `EQUALS`, `CONTAINS`, `REGEX`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#group_filter_type AuthServerClaim#group_filter_type}
    */
    readonly groupFilterType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#id AuthServerClaim#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the claim.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#name AuthServerClaim#name}
    */
    readonly name: string;
    /**
    * The list of scopes the auth server claim is tied to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#scopes AuthServerClaim#scopes}
    */
    readonly scopes?: string[];
    /**
    * Default to `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#status AuthServerClaim#status}
    */
    readonly status?: string;
    /**
    * The value of the claim.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#value AuthServerClaim#value}
    */
    readonly value: string;
    /**
    * The type of value of the claim. It can be set to `EXPRESSION` or `GROUPS`. It defaults to `EXPRESSION`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#value_type AuthServerClaim#value_type}
    */
    readonly valueType?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim okta_auth_server_claim}
*/
export declare class AuthServerClaim extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_auth_server_claim";
    /**
    * Generates CDKTN code for importing a AuthServerClaim resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthServerClaim to import
    * @param importFromId The id of the existing AuthServerClaim that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthServerClaim to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim okta_auth_server_claim} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthServerClaimConfig
    */
    constructor(scope: Construct, id: string, config: AuthServerClaimConfig);
    private _alwaysIncludeInToken?;
    get alwaysIncludeInToken(): boolean | cdktn.IResolvable;
    set alwaysIncludeInToken(value: boolean | cdktn.IResolvable);
    resetAlwaysIncludeInToken(): void;
    get alwaysIncludeInTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _authServerId?;
    get authServerId(): string;
    set authServerId(value: string);
    get authServerIdInput(): string | undefined;
    private _claimType?;
    get claimType(): string;
    set claimType(value: string);
    get claimTypeInput(): string | undefined;
    private _groupFilterType?;
    get groupFilterType(): string;
    set groupFilterType(value: string);
    resetGroupFilterType(): void;
    get groupFilterTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _valueType?;
    get valueType(): string;
    set valueType(value: string);
    resetValueType(): void;
    get valueTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
