import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PolicyProfileEnrollmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment#id PolicyProfileEnrollment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment#name PolicyProfileEnrollment#name}
    */
    readonly name: string;
    /**
    * Status of the policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment#status PolicyProfileEnrollment#status}
    */
    readonly status?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment okta_policy_profile_enrollment}
*/
export declare class PolicyProfileEnrollment extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_policy_profile_enrollment";
    /**
    * Generates CDKTN code for importing a PolicyProfileEnrollment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicyProfileEnrollment to import
    * @param importFromId The id of the existing PolicyProfileEnrollment that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicyProfileEnrollment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment okta_policy_profile_enrollment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicyProfileEnrollmentConfig
    */
    constructor(scope: Construct, id: string, config: PolicyProfileEnrollmentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
