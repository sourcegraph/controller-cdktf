import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TrustedServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Authorization server ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_server#auth_server_id TrustedServer#auth_server_id}
    */
    readonly authServerId: string;
    /**
    * A list of the authorization server IDs user want to trust
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_server#trusted TrustedServer#trusted}
    */
    readonly trusted: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_server okta_trusted_server}
*/
export declare class TrustedServer extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_trusted_server";
    /**
    * Generates CDKTN code for importing a TrustedServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TrustedServer to import
    * @param importFromId The id of the existing TrustedServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TrustedServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_server okta_trusted_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TrustedServerConfig
    */
    constructor(scope: Construct, id: string, config: TrustedServerConfig);
    private _authServerId?;
    get authServerId(): string;
    set authServerId(value: string);
    get authServerIdInput(): string | undefined;
    get id(): string;
    private _trusted?;
    get trusted(): string[];
    set trusted(value: string[]);
    get trustedInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
