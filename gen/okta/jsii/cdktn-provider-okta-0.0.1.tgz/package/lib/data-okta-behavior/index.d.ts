import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaBehaviorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Behavior ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/behavior#id DataOktaBehavior#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Behavior name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/behavior#name DataOktaBehavior#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/behavior okta_behavior}
*/
export declare class DataOktaBehavior extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_behavior";
    /**
    * Generates CDKTN code for importing a DataOktaBehavior resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaBehavior to import
    * @param importFromId The id of the existing DataOktaBehavior that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/behavior#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaBehavior to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/behavior okta_behavior} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaBehaviorConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaBehaviorConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _settings;
    get settings(): cdktn.StringMap;
    get status(): string;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
