import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Brand id of the domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain#brand_id Domain#brand_id}
    */
    readonly brandId?: string;
    /**
    * Certificate source type that indicates whether the certificate is provided by the user or Okta. Accepted values: `MANUAL`, `OKTA_MANAGED`. Warning: Use of OKTA_MANAGED requires a feature flag to be enabled. Default value = MANUAL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain#certificate_source_type Domain#certificate_source_type}
    */
    readonly certificateSourceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain#id Domain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Custom Domain name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain#name Domain#name}
    */
    readonly name: string;
}
export interface DomainDnsRecords {
}
export declare function domainDnsRecordsToTerraform(struct?: DomainDnsRecords): any;
export declare function domainDnsRecordsToHclTerraform(struct?: DomainDnsRecords): any;
export declare class DomainDnsRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DomainDnsRecords | undefined;
    set internalValue(value: DomainDnsRecords | undefined);
    get expiration(): string;
    get fqdn(): string;
    get recordType(): string;
    get values(): string[];
}
export declare class DomainDnsRecordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DomainDnsRecordsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain okta_domain}
*/
export declare class Domain extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_domain";
    /**
    * Generates CDKTN code for importing a Domain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Domain to import
    * @param importFromId The id of the existing Domain that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Domain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain okta_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DomainConfig
    */
    constructor(scope: Construct, id: string, config: DomainConfig);
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    resetBrandId(): void;
    get brandIdInput(): string | undefined;
    private _certificateSourceType?;
    get certificateSourceType(): string;
    set certificateSourceType(value: string);
    resetCertificateSourceType(): void;
    get certificateSourceTypeInput(): string | undefined;
    private _dnsRecords;
    get dnsRecords(): DomainDnsRecordsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get validationStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
