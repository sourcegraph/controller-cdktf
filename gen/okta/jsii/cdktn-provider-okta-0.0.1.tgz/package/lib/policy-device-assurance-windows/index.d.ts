import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PolicyDeviceAssuranceWindowsConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of disk encryption type, can be `ALL_INTERNAL_VOLUMES`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#disk_encryption_type PolicyDeviceAssuranceWindows#disk_encryption_type}
    */
    readonly diskEncryptionType?: string[];
    /**
    * Name of the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#name PolicyDeviceAssuranceWindows#name}
    */
    readonly name: string;
    /**
    * Minimum os version of the device in the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#os_version PolicyDeviceAssuranceWindows#os_version}
    */
    readonly osVersion?: string;
    /**
    * List of screenlock type, can be `BIOMETRIC` or `BIOMETRIC, PASSCODE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#screenlock_type PolicyDeviceAssuranceWindows#screenlock_type}
    */
    readonly screenlockType?: string[];
    /**
    * Is the device secure with hardware in the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#secure_hardware_present PolicyDeviceAssuranceWindows#secure_hardware_present}
    */
    readonly secureHardwarePresent?: boolean | cdktn.IResolvable;
    /**
    * Check to include third party signal provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#third_party_signal_providers PolicyDeviceAssuranceWindows#third_party_signal_providers}
    */
    readonly thirdPartySignalProviders?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider minimum browser version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_browser_version PolicyDeviceAssuranceWindows#tpsp_browser_version}
    */
    readonly tpspBrowserVersion?: string;
    /**
    * Third party signal provider builtin dns client enable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_builtin_dns_client_enabled PolicyDeviceAssuranceWindows#tpsp_builtin_dns_client_enabled}
    */
    readonly tpspBuiltinDnsClientEnabled?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider chrome remote desktop app blocked
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_chrome_remote_desktop_app_blocked PolicyDeviceAssuranceWindows#tpsp_chrome_remote_desktop_app_blocked}
    */
    readonly tpspChromeRemoteDesktopAppBlocked?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider crowdstrike agent id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_crowd_strike_agent_id PolicyDeviceAssuranceWindows#tpsp_crowd_strike_agent_id}
    */
    readonly tpspCrowdStrikeAgentId?: string;
    /**
    * Third party signal provider crowdstrike user id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_crowd_strike_customer_id PolicyDeviceAssuranceWindows#tpsp_crowd_strike_customer_id}
    */
    readonly tpspCrowdStrikeCustomerId?: string;
    /**
    * Third party signal provider device enrollment domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_device_enrollment_domain PolicyDeviceAssuranceWindows#tpsp_device_enrollment_domain}
    */
    readonly tpspDeviceEnrollmentDomain?: string;
    /**
    * Third party signal provider disk encrypted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_disk_encrypted PolicyDeviceAssuranceWindows#tpsp_disk_encrypted}
    */
    readonly tpspDiskEncrypted?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider key trust level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_key_trust_level PolicyDeviceAssuranceWindows#tpsp_key_trust_level}
    */
    readonly tpspKeyTrustLevel?: string;
    /**
    * Third party signal provider os firewall
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_os_firewall PolicyDeviceAssuranceWindows#tpsp_os_firewall}
    */
    readonly tpspOsFirewall?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider minimum os version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_os_version PolicyDeviceAssuranceWindows#tpsp_os_version}
    */
    readonly tpspOsVersion?: string;
    /**
    * Third party signal provider password protection warning trigger
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_password_proctection_warning_trigger PolicyDeviceAssuranceWindows#tpsp_password_proctection_warning_trigger}
    */
    readonly tpspPasswordProctectionWarningTrigger?: string;
    /**
    * Third party signal provider realtime url check mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_realtime_url_check_mode PolicyDeviceAssuranceWindows#tpsp_realtime_url_check_mode}
    */
    readonly tpspRealtimeUrlCheckMode?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider safe browsing protection level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_safe_browsing_protection_level PolicyDeviceAssuranceWindows#tpsp_safe_browsing_protection_level}
    */
    readonly tpspSafeBrowsingProtectionLevel?: string;
    /**
    * Third party signal provider screen lock secure
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_screen_lock_secured PolicyDeviceAssuranceWindows#tpsp_screen_lock_secured}
    */
    readonly tpspScreenLockSecured?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider secure boot enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_secure_boot_enabled PolicyDeviceAssuranceWindows#tpsp_secure_boot_enabled}
    */
    readonly tpspSecureBootEnabled?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider site isolation enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_site_isolation_enabled PolicyDeviceAssuranceWindows#tpsp_site_isolation_enabled}
    */
    readonly tpspSiteIsolationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider third party blocking enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_third_party_blocking_enabled PolicyDeviceAssuranceWindows#tpsp_third_party_blocking_enabled}
    */
    readonly tpspThirdPartyBlockingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider windows machine domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_windows_machine_domain PolicyDeviceAssuranceWindows#tpsp_windows_machine_domain}
    */
    readonly tpspWindowsMachineDomain?: string;
    /**
    * Third party signal provider windows user domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#tpsp_windows_user_domain PolicyDeviceAssuranceWindows#tpsp_windows_user_domain}
    */
    readonly tpspWindowsUserDomain?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows okta_policy_device_assurance_windows}
*/
export declare class PolicyDeviceAssuranceWindows extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_policy_device_assurance_windows";
    /**
    * Generates CDKTN code for importing a PolicyDeviceAssuranceWindows resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicyDeviceAssuranceWindows to import
    * @param importFromId The id of the existing PolicyDeviceAssuranceWindows that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicyDeviceAssuranceWindows to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_windows okta_policy_device_assurance_windows} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicyDeviceAssuranceWindowsConfig
    */
    constructor(scope: Construct, id: string, config: PolicyDeviceAssuranceWindowsConfig);
    get createdBy(): string;
    get createdDate(): string;
    private _diskEncryptionType?;
    get diskEncryptionType(): string[];
    set diskEncryptionType(value: string[]);
    resetDiskEncryptionType(): void;
    get diskEncryptionTypeInput(): string[] | undefined;
    get id(): string;
    get lastUpdate(): string;
    get lastUpdatedBy(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _osVersion?;
    get osVersion(): string;
    set osVersion(value: string);
    resetOsVersion(): void;
    get osVersionInput(): string | undefined;
    get platform(): string;
    private _screenlockType?;
    get screenlockType(): string[];
    set screenlockType(value: string[]);
    resetScreenlockType(): void;
    get screenlockTypeInput(): string[] | undefined;
    private _secureHardwarePresent?;
    get secureHardwarePresent(): boolean | cdktn.IResolvable;
    set secureHardwarePresent(value: boolean | cdktn.IResolvable);
    resetSecureHardwarePresent(): void;
    get secureHardwarePresentInput(): boolean | cdktn.IResolvable | undefined;
    private _thirdPartySignalProviders?;
    get thirdPartySignalProviders(): boolean | cdktn.IResolvable;
    set thirdPartySignalProviders(value: boolean | cdktn.IResolvable);
    resetThirdPartySignalProviders(): void;
    get thirdPartySignalProvidersInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspBrowserVersion?;
    get tpspBrowserVersion(): string;
    set tpspBrowserVersion(value: string);
    resetTpspBrowserVersion(): void;
    get tpspBrowserVersionInput(): string | undefined;
    private _tpspBuiltinDnsClientEnabled?;
    get tpspBuiltinDnsClientEnabled(): boolean | cdktn.IResolvable;
    set tpspBuiltinDnsClientEnabled(value: boolean | cdktn.IResolvable);
    resetTpspBuiltinDnsClientEnabled(): void;
    get tpspBuiltinDnsClientEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspChromeRemoteDesktopAppBlocked?;
    get tpspChromeRemoteDesktopAppBlocked(): boolean | cdktn.IResolvable;
    set tpspChromeRemoteDesktopAppBlocked(value: boolean | cdktn.IResolvable);
    resetTpspChromeRemoteDesktopAppBlocked(): void;
    get tpspChromeRemoteDesktopAppBlockedInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspCrowdStrikeAgentId?;
    get tpspCrowdStrikeAgentId(): string;
    set tpspCrowdStrikeAgentId(value: string);
    resetTpspCrowdStrikeAgentId(): void;
    get tpspCrowdStrikeAgentIdInput(): string | undefined;
    private _tpspCrowdStrikeCustomerId?;
    get tpspCrowdStrikeCustomerId(): string;
    set tpspCrowdStrikeCustomerId(value: string);
    resetTpspCrowdStrikeCustomerId(): void;
    get tpspCrowdStrikeCustomerIdInput(): string | undefined;
    private _tpspDeviceEnrollmentDomain?;
    get tpspDeviceEnrollmentDomain(): string;
    set tpspDeviceEnrollmentDomain(value: string);
    resetTpspDeviceEnrollmentDomain(): void;
    get tpspDeviceEnrollmentDomainInput(): string | undefined;
    private _tpspDiskEncrypted?;
    get tpspDiskEncrypted(): boolean | cdktn.IResolvable;
    set tpspDiskEncrypted(value: boolean | cdktn.IResolvable);
    resetTpspDiskEncrypted(): void;
    get tpspDiskEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspKeyTrustLevel?;
    get tpspKeyTrustLevel(): string;
    set tpspKeyTrustLevel(value: string);
    resetTpspKeyTrustLevel(): void;
    get tpspKeyTrustLevelInput(): string | undefined;
    private _tpspOsFirewall?;
    get tpspOsFirewall(): boolean | cdktn.IResolvable;
    set tpspOsFirewall(value: boolean | cdktn.IResolvable);
    resetTpspOsFirewall(): void;
    get tpspOsFirewallInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspOsVersion?;
    get tpspOsVersion(): string;
    set tpspOsVersion(value: string);
    resetTpspOsVersion(): void;
    get tpspOsVersionInput(): string | undefined;
    private _tpspPasswordProctectionWarningTrigger?;
    get tpspPasswordProctectionWarningTrigger(): string;
    set tpspPasswordProctectionWarningTrigger(value: string);
    resetTpspPasswordProctectionWarningTrigger(): void;
    get tpspPasswordProctectionWarningTriggerInput(): string | undefined;
    private _tpspRealtimeUrlCheckMode?;
    get tpspRealtimeUrlCheckMode(): boolean | cdktn.IResolvable;
    set tpspRealtimeUrlCheckMode(value: boolean | cdktn.IResolvable);
    resetTpspRealtimeUrlCheckMode(): void;
    get tpspRealtimeUrlCheckModeInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspSafeBrowsingProtectionLevel?;
    get tpspSafeBrowsingProtectionLevel(): string;
    set tpspSafeBrowsingProtectionLevel(value: string);
    resetTpspSafeBrowsingProtectionLevel(): void;
    get tpspSafeBrowsingProtectionLevelInput(): string | undefined;
    private _tpspScreenLockSecured?;
    get tpspScreenLockSecured(): boolean | cdktn.IResolvable;
    set tpspScreenLockSecured(value: boolean | cdktn.IResolvable);
    resetTpspScreenLockSecured(): void;
    get tpspScreenLockSecuredInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspSecureBootEnabled?;
    get tpspSecureBootEnabled(): boolean | cdktn.IResolvable;
    set tpspSecureBootEnabled(value: boolean | cdktn.IResolvable);
    resetTpspSecureBootEnabled(): void;
    get tpspSecureBootEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspSiteIsolationEnabled?;
    get tpspSiteIsolationEnabled(): boolean | cdktn.IResolvable;
    set tpspSiteIsolationEnabled(value: boolean | cdktn.IResolvable);
    resetTpspSiteIsolationEnabled(): void;
    get tpspSiteIsolationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspThirdPartyBlockingEnabled?;
    get tpspThirdPartyBlockingEnabled(): boolean | cdktn.IResolvable;
    set tpspThirdPartyBlockingEnabled(value: boolean | cdktn.IResolvable);
    resetTpspThirdPartyBlockingEnabled(): void;
    get tpspThirdPartyBlockingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspWindowsMachineDomain?;
    get tpspWindowsMachineDomain(): string;
    set tpspWindowsMachineDomain(value: string);
    resetTpspWindowsMachineDomain(): void;
    get tpspWindowsMachineDomainInput(): string | undefined;
    private _tpspWindowsUserDomain?;
    get tpspWindowsUserDomain(): string;
    set tpspWindowsUserDomain(value: string);
    resetTpspWindowsUserDomain(): void;
    get tpspWindowsUserDomainInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
