import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaBrandConfig extends cdktn.TerraformMetaArguments {
    /**
    * Brand ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/brand#brand_id DataOktaBrand#brand_id}
    */
    readonly brandId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/brand okta_brand}
*/
export declare class DataOktaBrand extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_brand";
    /**
    * Generates CDKTN code for importing a DataOktaBrand resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaBrand to import
    * @param importFromId The id of the existing DataOktaBrand that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/brand#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaBrand to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/brand okta_brand} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaBrandConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaBrandConfig);
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    get brandIdInput(): string | undefined;
    get customPrivacyPolicyUrl(): string;
    get id(): string;
    get links(): string;
    get name(): string;
    get removePoweredByOkta(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
