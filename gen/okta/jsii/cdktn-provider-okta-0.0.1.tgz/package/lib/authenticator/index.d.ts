import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AuthenticatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#id Authenticator#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A human-readable string that identifies the authenticator. Some authenticators are available by feature flag on the organization. Possible values inclue: `duo`, `external_idp`, `google_otp`, `okta_email`, `okta_password`, `okta_verify`, `onprem_mfa`, `phone_number`, `rsa_token`, `security_question`, `webauthn`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#key Authenticator#key}
    */
    readonly key: string;
    /**
    * Name does not trigger change detection (legacy behavior)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#legacy_ignore_name Authenticator#legacy_ignore_name}
    */
    readonly legacyIgnoreName?: boolean | cdktn.IResolvable;
    /**
    * Display name of the Authenticator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#name Authenticator#name}
    */
    readonly name: string;
    /**
    * The RADIUS server port (for example 1812). This is defined when the On-Prem RADIUS server is configured. Used only for authenticators with type `security_key`.  Conflicts with `provider_json` argument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#provider_auth_port Authenticator#provider_auth_port}
    */
    readonly providerAuthPort?: number;
    /**
    * (DUO specific) - The Duo Security API hostname. Conflicts with `provider_json` argument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#provider_host Authenticator#provider_host}
    */
    readonly providerHost?: string;
    /**
    * Server host name or IP address. Default is `localhost`. Used only for authenticators with type `security_key`. Conflicts with `provider_json` argument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#provider_hostname Authenticator#provider_hostname}
    */
    readonly providerHostname?: string;
    /**
    * (DUO specific) - The Duo Security integration key.  Conflicts with `provider_json` argument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#provider_integration_key Authenticator#provider_integration_key}
    */
    readonly providerIntegrationKey?: string;
    /**
    * Provider JSON allows for expressive providervalues. This argument conflicts with the other 'provider_xxx' arguments. The [CreateProvider](https://developer.okta.com/docs/reference/api/authenticators-admin/#request) illustrates detailed provider values for a Duo authenticator. [Provider values](https://developer.okta.com/docs/reference/api/authenticators-admin/#authenticators-administration-api-object)are listed in Okta API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#provider_json Authenticator#provider_json}
    */
    readonly providerJson?: string;
    /**
    * (DUO specific) - The Duo Security secret key.  Conflicts with `provider_json` argument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#provider_secret_key Authenticator#provider_secret_key}
    */
    readonly providerSecretKey?: string;
    /**
    * An authentication key that must be defined when the RADIUS server is configured, and must be the same on both the RADIUS client and server. Used only for authenticators with type `security_key`. Conflicts with `provider_json` argument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#provider_shared_secret Authenticator#provider_shared_secret}
    */
    readonly providerSharedSecret?: string;
    /**
    * Username template expected by the provider. Used only for authenticators with type `security_key`.  Conflicts with `provider_json` argument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#provider_user_name_template Authenticator#provider_user_name_template}
    */
    readonly providerUserNameTemplate?: string;
    /**
    * Settings for the authenticator. The settings JSON contains values based on Authenticator key. It is not used for authenticators with type `security_key`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#settings Authenticator#settings}
    */
    readonly settings?: string;
    /**
    * Authenticator status: `ACTIVE` or `INACTIVE`. Default: `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#status Authenticator#status}
    */
    readonly status?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator okta_authenticator}
*/
export declare class Authenticator extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_authenticator";
    /**
    * Generates CDKTN code for importing a Authenticator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Authenticator to import
    * @param importFromId The id of the existing Authenticator that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Authenticator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/authenticator okta_authenticator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthenticatorConfig
    */
    constructor(scope: Construct, id: string, config: AuthenticatorConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _legacyIgnoreName?;
    get legacyIgnoreName(): boolean | cdktn.IResolvable;
    set legacyIgnoreName(value: boolean | cdktn.IResolvable);
    resetLegacyIgnoreName(): void;
    get legacyIgnoreNameInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerAuthPort?;
    get providerAuthPort(): number;
    set providerAuthPort(value: number);
    resetProviderAuthPort(): void;
    get providerAuthPortInput(): number | undefined;
    private _providerHost?;
    get providerHost(): string;
    set providerHost(value: string);
    resetProviderHost(): void;
    get providerHostInput(): string | undefined;
    private _providerHostname?;
    get providerHostname(): string;
    set providerHostname(value: string);
    resetProviderHostname(): void;
    get providerHostnameInput(): string | undefined;
    get providerInstanceId(): string;
    private _providerIntegrationKey?;
    get providerIntegrationKey(): string;
    set providerIntegrationKey(value: string);
    resetProviderIntegrationKey(): void;
    get providerIntegrationKeyInput(): string | undefined;
    private _providerJson?;
    get providerJson(): string;
    set providerJson(value: string);
    resetProviderJson(): void;
    get providerJsonInput(): string | undefined;
    private _providerSecretKey?;
    get providerSecretKey(): string;
    set providerSecretKey(value: string);
    resetProviderSecretKey(): void;
    get providerSecretKeyInput(): string | undefined;
    private _providerSharedSecret?;
    get providerSharedSecret(): string;
    set providerSharedSecret(value: string);
    resetProviderSharedSecret(): void;
    get providerSharedSecretInput(): string | undefined;
    get providerType(): string;
    private _providerUserNameTemplate?;
    get providerUserNameTemplate(): string;
    set providerUserNameTemplate(value: string);
    resetProviderUserNameTemplate(): void;
    get providerUserNameTemplateInput(): string | undefined;
    private _settings?;
    get settings(): string;
    set settings(value: string);
    resetSettings(): void;
    get settingsInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
