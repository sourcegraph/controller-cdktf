import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TemplateSmsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/template_sms#id TemplateSms#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * SMS default template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/template_sms#template TemplateSms#template}
    */
    readonly template: string;
    /**
    * SMS template type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/template_sms#type TemplateSms#type}
    */
    readonly type: string;
    /**
    * translations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/template_sms#translations TemplateSms#translations}
    */
    readonly translations?: TemplateSmsTranslations[] | cdktn.IResolvable;
}
export interface TemplateSmsTranslations {
    /**
    * The language to map the template to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/template_sms#language TemplateSms#language}
    */
    readonly language: string;
    /**
    * The SMS message.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/template_sms#template TemplateSms#template}
    */
    readonly template: string;
}
export declare function templateSmsTranslationsToTerraform(struct?: TemplateSmsTranslations | cdktn.IResolvable): any;
export declare function templateSmsTranslationsToHclTerraform(struct?: TemplateSmsTranslations | cdktn.IResolvable): any;
export declare class TemplateSmsTranslationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TemplateSmsTranslations | cdktn.IResolvable | undefined;
    set internalValue(value: TemplateSmsTranslations | cdktn.IResolvable | undefined);
    private _language?;
    get language(): string;
    set language(value: string);
    get languageInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    get templateInput(): string | undefined;
}
export declare class TemplateSmsTranslationsList extends cdktn.ComplexList {
    internalValue?: TemplateSmsTranslations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TemplateSmsTranslationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/template_sms okta_template_sms}
*/
export declare class TemplateSms extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_template_sms";
    /**
    * Generates CDKTN code for importing a TemplateSms resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TemplateSms to import
    * @param importFromId The id of the existing TemplateSms that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/template_sms#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TemplateSms to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/template_sms okta_template_sms} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TemplateSmsConfig
    */
    constructor(scope: Construct, id: string, config: TemplateSmsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    get templateInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _translations;
    get translations(): TemplateSmsTranslationsList;
    putTranslations(value: TemplateSmsTranslations[] | cdktn.IResolvable): void;
    resetTranslations(): void;
    get translationsInput(): cdktn.IResolvable | TemplateSmsTranslations[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
