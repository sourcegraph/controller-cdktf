import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GroupOwnerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The id of the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_owner#group_id GroupOwner#group_id}
    */
    readonly groupId: string;
    /**
    * The user id of the group owner
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_owner#id_of_group_owner GroupOwner#id_of_group_owner}
    */
    readonly idOfGroupOwner: string;
    /**
    * The entity type of the owner. Enum: "GROUP" "USER"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_owner#type GroupOwner#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_owner okta_group_owner}
*/
export declare class GroupOwner extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_group_owner";
    /**
    * Generates CDKTN code for importing a GroupOwner resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupOwner to import
    * @param importFromId The id of the existing GroupOwner that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_owner#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupOwner to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_owner okta_group_owner} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupOwnerConfig
    */
    constructor(scope: Construct, id: string, config: GroupOwnerConfig);
    get displayName(): string;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    get id(): string;
    private _idOfGroupOwner?;
    get idOfGroupOwner(): string;
    set idOfGroupOwner(value: string);
    get idOfGroupOwnerInput(): string | undefined;
    get originId(): string;
    get originType(): string;
    get resolved(): cdktn.IResolvable;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
