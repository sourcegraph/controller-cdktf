import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PolicyDeviceAssuranceChromeosConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#name PolicyDeviceAssuranceChromeos#name}
    */
    readonly name: string;
    /**
    * Third party signal provider allow screen lock
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_allow_screen_lock PolicyDeviceAssuranceChromeos#tpsp_allow_screen_lock}
    */
    readonly tpspAllowScreenLock?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider minimum browser version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_browser_version PolicyDeviceAssuranceChromeos#tpsp_browser_version}
    */
    readonly tpspBrowserVersion?: string;
    /**
    * Third party signal provider builtin dns client enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_builtin_dns_client_enabled PolicyDeviceAssuranceChromeos#tpsp_builtin_dns_client_enabled}
    */
    readonly tpspBuiltinDnsClientEnabled?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider chrome remote desktop app blocked
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_chrome_remote_desktop_app_blocked PolicyDeviceAssuranceChromeos#tpsp_chrome_remote_desktop_app_blocked}
    */
    readonly tpspChromeRemoteDesktopAppBlocked?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider device enrollment domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_device_enrollment_domain PolicyDeviceAssuranceChromeos#tpsp_device_enrollment_domain}
    */
    readonly tpspDeviceEnrollmentDomain?: string;
    /**
    * Third party signal provider disk encrypted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_disk_encrypted PolicyDeviceAssuranceChromeos#tpsp_disk_encrypted}
    */
    readonly tpspDiskEncrypted?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider key trust level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_key_trust_level PolicyDeviceAssuranceChromeos#tpsp_key_trust_level}
    */
    readonly tpspKeyTrustLevel?: string;
    /**
    * Third party signal provider os firewall
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_os_firewall PolicyDeviceAssuranceChromeos#tpsp_os_firewall}
    */
    readonly tpspOsFirewall?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider minimum os version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_os_version PolicyDeviceAssuranceChromeos#tpsp_os_version}
    */
    readonly tpspOsVersion?: string;
    /**
    * Third party signal provider password protection warning trigger
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_password_proctection_warning_trigger PolicyDeviceAssuranceChromeos#tpsp_password_proctection_warning_trigger}
    */
    readonly tpspPasswordProctectionWarningTrigger?: string;
    /**
    * Third party signal provider realtime url check mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_realtime_url_check_mode PolicyDeviceAssuranceChromeos#tpsp_realtime_url_check_mode}
    */
    readonly tpspRealtimeUrlCheckMode?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider safe browsing protection level
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_safe_browsing_protection_level PolicyDeviceAssuranceChromeos#tpsp_safe_browsing_protection_level}
    */
    readonly tpspSafeBrowsingProtectionLevel?: string;
    /**
    * Third party signal provider screen lock secure
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_screen_lock_secured PolicyDeviceAssuranceChromeos#tpsp_screen_lock_secured}
    */
    readonly tpspScreenLockSecured?: boolean | cdktn.IResolvable;
    /**
    * Third party signal provider site isolation enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#tpsp_site_isolation_enabled PolicyDeviceAssuranceChromeos#tpsp_site_isolation_enabled}
    */
    readonly tpspSiteIsolationEnabled?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos okta_policy_device_assurance_chromeos}
*/
export declare class PolicyDeviceAssuranceChromeos extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_policy_device_assurance_chromeos";
    /**
    * Generates CDKTN code for importing a PolicyDeviceAssuranceChromeos resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicyDeviceAssuranceChromeos to import
    * @param importFromId The id of the existing PolicyDeviceAssuranceChromeos that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicyDeviceAssuranceChromeos to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_chromeos okta_policy_device_assurance_chromeos} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicyDeviceAssuranceChromeosConfig
    */
    constructor(scope: Construct, id: string, config: PolicyDeviceAssuranceChromeosConfig);
    get createdBy(): string;
    get createdDate(): string;
    get id(): string;
    get lastUpdate(): string;
    get lastUpdatedBy(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get platform(): string;
    private _tpspAllowScreenLock?;
    get tpspAllowScreenLock(): boolean | cdktn.IResolvable;
    set tpspAllowScreenLock(value: boolean | cdktn.IResolvable);
    resetTpspAllowScreenLock(): void;
    get tpspAllowScreenLockInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspBrowserVersion?;
    get tpspBrowserVersion(): string;
    set tpspBrowserVersion(value: string);
    resetTpspBrowserVersion(): void;
    get tpspBrowserVersionInput(): string | undefined;
    private _tpspBuiltinDnsClientEnabled?;
    get tpspBuiltinDnsClientEnabled(): boolean | cdktn.IResolvable;
    set tpspBuiltinDnsClientEnabled(value: boolean | cdktn.IResolvable);
    resetTpspBuiltinDnsClientEnabled(): void;
    get tpspBuiltinDnsClientEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspChromeRemoteDesktopAppBlocked?;
    get tpspChromeRemoteDesktopAppBlocked(): boolean | cdktn.IResolvable;
    set tpspChromeRemoteDesktopAppBlocked(value: boolean | cdktn.IResolvable);
    resetTpspChromeRemoteDesktopAppBlocked(): void;
    get tpspChromeRemoteDesktopAppBlockedInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspDeviceEnrollmentDomain?;
    get tpspDeviceEnrollmentDomain(): string;
    set tpspDeviceEnrollmentDomain(value: string);
    resetTpspDeviceEnrollmentDomain(): void;
    get tpspDeviceEnrollmentDomainInput(): string | undefined;
    private _tpspDiskEncrypted?;
    get tpspDiskEncrypted(): boolean | cdktn.IResolvable;
    set tpspDiskEncrypted(value: boolean | cdktn.IResolvable);
    resetTpspDiskEncrypted(): void;
    get tpspDiskEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspKeyTrustLevel?;
    get tpspKeyTrustLevel(): string;
    set tpspKeyTrustLevel(value: string);
    resetTpspKeyTrustLevel(): void;
    get tpspKeyTrustLevelInput(): string | undefined;
    private _tpspOsFirewall?;
    get tpspOsFirewall(): boolean | cdktn.IResolvable;
    set tpspOsFirewall(value: boolean | cdktn.IResolvable);
    resetTpspOsFirewall(): void;
    get tpspOsFirewallInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspOsVersion?;
    get tpspOsVersion(): string;
    set tpspOsVersion(value: string);
    resetTpspOsVersion(): void;
    get tpspOsVersionInput(): string | undefined;
    private _tpspPasswordProctectionWarningTrigger?;
    get tpspPasswordProctectionWarningTrigger(): string;
    set tpspPasswordProctectionWarningTrigger(value: string);
    resetTpspPasswordProctectionWarningTrigger(): void;
    get tpspPasswordProctectionWarningTriggerInput(): string | undefined;
    private _tpspRealtimeUrlCheckMode?;
    get tpspRealtimeUrlCheckMode(): boolean | cdktn.IResolvable;
    set tpspRealtimeUrlCheckMode(value: boolean | cdktn.IResolvable);
    resetTpspRealtimeUrlCheckMode(): void;
    get tpspRealtimeUrlCheckModeInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspSafeBrowsingProtectionLevel?;
    get tpspSafeBrowsingProtectionLevel(): string;
    set tpspSafeBrowsingProtectionLevel(value: string);
    resetTpspSafeBrowsingProtectionLevel(): void;
    get tpspSafeBrowsingProtectionLevelInput(): string | undefined;
    private _tpspScreenLockSecured?;
    get tpspScreenLockSecured(): boolean | cdktn.IResolvable;
    set tpspScreenLockSecured(value: boolean | cdktn.IResolvable);
    resetTpspScreenLockSecured(): void;
    get tpspScreenLockSecuredInput(): boolean | cdktn.IResolvable | undefined;
    private _tpspSiteIsolationEnabled?;
    get tpspSiteIsolationEnabled(): boolean | cdktn.IResolvable;
    set tpspSiteIsolationEnabled(value: boolean | cdktn.IResolvable);
    resetTpspSiteIsolationEnabled(): void;
    get tpspSiteIsolationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
