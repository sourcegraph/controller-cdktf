import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppOauthRedirectUriConfig extends cdktn.TerraformMetaArguments {
    /**
    * OAuth application ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_redirect_uri#app_id AppOauthRedirectUri#app_id}
    */
    readonly appId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_redirect_uri#id AppOauthRedirectUri#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Redirect URI to append to Okta OIDC application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_redirect_uri#uri AppOauthRedirectUri#uri}
    */
    readonly uri: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_redirect_uri okta_app_oauth_redirect_uri}
*/
export declare class AppOauthRedirectUri extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_app_oauth_redirect_uri";
    /**
    * Generates CDKTN code for importing a AppOauthRedirectUri resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppOauthRedirectUri to import
    * @param importFromId The id of the existing AppOauthRedirectUri that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_redirect_uri#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppOauthRedirectUri to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_redirect_uri okta_app_oauth_redirect_uri} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppOauthRedirectUriConfig
    */
    constructor(scope: Construct, id: string, config: AppOauthRedirectUriConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
