import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BehaviorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior#id Behavior#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Determines the method and level of detail used to evaluate the behavior. Required for `ANOMALOUS_LOCATION` behavior type. Can be set to `LAT_LONG`, `CITY`, `COUNTRY` or `SUBDIVISION`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior#location_granularity_type Behavior#location_granularity_type}
    */
    readonly locationGranularityType?: string;
    /**
    * Name of the behavior
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior#name Behavior#name}
    */
    readonly name: string;
    /**
    * The number of recent authentications used to evaluate the behavior. Required for `ANOMALOUS_LOCATION`, `ANOMALOUS_DEVICE` and `ANOMALOUS_IP` behavior types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior#number_of_authentications Behavior#number_of_authentications}
    */
    readonly numberOfAuthentications?: number;
    /**
    * Radius from location (in kilometers). Should be at least 5. Required when `location_granularity_type` is set to `LAT_LONG`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior#radius_from_location Behavior#radius_from_location}
    */
    readonly radiusFromLocation?: number;
    /**
    * Behavior status: ACTIVE or INACTIVE. Default: `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior#status Behavior#status}
    */
    readonly status?: string;
    /**
    * Type of the behavior. Can be set to `ANOMALOUS_LOCATION`, `ANOMALOUS_DEVICE`, `ANOMALOUS_IP` or `VELOCITY`. Resource will be recreated when the type changes.e
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior#type Behavior#type}
    */
    readonly type: string;
    /**
    * Velocity (in kilometers per hour). Should be at least 1. Required for `VELOCITY` behavior
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior#velocity Behavior#velocity}
    */
    readonly velocity?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior okta_behavior}
*/
export declare class Behavior extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_behavior";
    /**
    * Generates CDKTN code for importing a Behavior resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Behavior to import
    * @param importFromId The id of the existing Behavior that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Behavior to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/behavior okta_behavior} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BehaviorConfig
    */
    constructor(scope: Construct, id: string, config: BehaviorConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locationGranularityType?;
    get locationGranularityType(): string;
    set locationGranularityType(value: string);
    resetLocationGranularityType(): void;
    get locationGranularityTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _numberOfAuthentications?;
    get numberOfAuthentications(): number;
    set numberOfAuthentications(value: number);
    resetNumberOfAuthentications(): void;
    get numberOfAuthenticationsInput(): number | undefined;
    private _radiusFromLocation?;
    get radiusFromLocation(): number;
    set radiusFromLocation(value: number);
    resetRadiusFromLocation(): void;
    get radiusFromLocationInput(): number | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _velocity?;
    get velocity(): number;
    set velocity(value: number);
    resetVelocity(): void;
    get velocityInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
