import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GroupSchemaPropertyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Array of values that an array property's items can be set to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#array_enum GroupSchemaProperty#array_enum}
    */
    readonly arrayEnum?: string[];
    /**
    * The type of the array elements if `type` is set to `array`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#array_type GroupSchemaProperty#array_type}
    */
    readonly arrayType?: string;
    /**
    * The description of the user schema property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#description GroupSchemaProperty#description}
    */
    readonly description?: string;
    /**
    * Array of values a primitive property can be set to. See `array_enum` for arrays.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#enum GroupSchemaProperty#enum}
    */
    readonly enum?: string[];
    /**
    * External name of the user schema property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#external_name GroupSchemaProperty#external_name}
    */
    readonly externalName?: string;
    /**
    * External namespace of the user schema property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#external_namespace GroupSchemaProperty#external_namespace}
    */
    readonly externalNamespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#id GroupSchemaProperty#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Subschema unique string identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#index GroupSchemaProperty#index}
    */
    readonly index: string;
    /**
    * Master priority for the group schema property. It can be set to `PROFILE_MASTER`, `OVERRIDE` or `OKTA`. Default: `PROFILE_MASTER`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#master GroupSchemaProperty#master}
    */
    readonly master?: string;
    /**
    * The maximum length of the user property value. Only applies to type `string`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#max_length GroupSchemaProperty#max_length}
    */
    readonly maxLength?: number;
    /**
    * The minimum length of the user property value. Only applies to type `string`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#min_length GroupSchemaProperty#min_length}
    */
    readonly minLength?: number;
    /**
    * Access control permissions for the property. It can be set to `READ_WRITE`, `READ_ONLY`, `HIDE`. Default: `READ_ONLY`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#permissions GroupSchemaProperty#permissions}
    */
    readonly permissions?: string;
    /**
    * Whether the subschema is required
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#required GroupSchemaProperty#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#scope GroupSchemaProperty#scope}
    */
    readonly scope?: string;
    /**
    * Subschema title (display name)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#title GroupSchemaProperty#title}
    */
    readonly title: string;
    /**
    * The type of the schema property. It can be `string`, `boolean`, `number`, `integer`, `array`, or `object`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#type GroupSchemaProperty#type}
    */
    readonly type: string;
    /**
    * Whether the property should be unique. It can be set to `UNIQUE_VALIDATED` or `NOT_UNIQUE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#unique GroupSchemaProperty#unique}
    */
    readonly unique?: string;
    /**
    * array_one_of block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#array_one_of GroupSchemaProperty#array_one_of}
    */
    readonly arrayOneOf?: GroupSchemaPropertyArrayOneOf[] | cdktn.IResolvable;
    /**
    * master_override_priority block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#master_override_priority GroupSchemaProperty#master_override_priority}
    */
    readonly masterOverridePriority?: GroupSchemaPropertyMasterOverridePriority[] | cdktn.IResolvable;
    /**
    * one_of block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#one_of GroupSchemaProperty#one_of}
    */
    readonly oneOf?: GroupSchemaPropertyOneOf[] | cdktn.IResolvable;
}
export interface GroupSchemaPropertyArrayOneOf {
    /**
    * Value mapping to member of `array_enum`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#const GroupSchemaProperty#const}
    */
    readonly const: string;
    /**
    * Display name for the enum value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#title GroupSchemaProperty#title}
    */
    readonly title: string;
}
export declare function groupSchemaPropertyArrayOneOfToTerraform(struct?: GroupSchemaPropertyArrayOneOf | cdktn.IResolvable): any;
export declare function groupSchemaPropertyArrayOneOfToHclTerraform(struct?: GroupSchemaPropertyArrayOneOf | cdktn.IResolvable): any;
export declare class GroupSchemaPropertyArrayOneOfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GroupSchemaPropertyArrayOneOf | cdktn.IResolvable | undefined;
    set internalValue(value: GroupSchemaPropertyArrayOneOf | cdktn.IResolvable | undefined);
    private _const?;
    get const(): string;
    set const(value: string);
    get constInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
}
export declare class GroupSchemaPropertyArrayOneOfList extends cdktn.ComplexList {
    internalValue?: GroupSchemaPropertyArrayOneOf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GroupSchemaPropertyArrayOneOfOutputReference;
}
export interface GroupSchemaPropertyMasterOverridePriority {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#type GroupSchemaProperty#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#value GroupSchemaProperty#value}
    */
    readonly value: string;
}
export declare function groupSchemaPropertyMasterOverridePriorityToTerraform(struct?: GroupSchemaPropertyMasterOverridePriority | cdktn.IResolvable): any;
export declare function groupSchemaPropertyMasterOverridePriorityToHclTerraform(struct?: GroupSchemaPropertyMasterOverridePriority | cdktn.IResolvable): any;
export declare class GroupSchemaPropertyMasterOverridePriorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GroupSchemaPropertyMasterOverridePriority | cdktn.IResolvable | undefined;
    set internalValue(value: GroupSchemaPropertyMasterOverridePriority | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class GroupSchemaPropertyMasterOverridePriorityList extends cdktn.ComplexList {
    internalValue?: GroupSchemaPropertyMasterOverridePriority[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GroupSchemaPropertyMasterOverridePriorityOutputReference;
}
export interface GroupSchemaPropertyOneOf {
    /**
    * Enum value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#const GroupSchemaProperty#const}
    */
    readonly const: string;
    /**
    * Enum title
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#title GroupSchemaProperty#title}
    */
    readonly title: string;
}
export declare function groupSchemaPropertyOneOfToTerraform(struct?: GroupSchemaPropertyOneOf | cdktn.IResolvable): any;
export declare function groupSchemaPropertyOneOfToHclTerraform(struct?: GroupSchemaPropertyOneOf | cdktn.IResolvable): any;
export declare class GroupSchemaPropertyOneOfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GroupSchemaPropertyOneOf | cdktn.IResolvable | undefined;
    set internalValue(value: GroupSchemaPropertyOneOf | cdktn.IResolvable | undefined);
    private _const?;
    get const(): string;
    set const(value: string);
    get constInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
}
export declare class GroupSchemaPropertyOneOfList extends cdktn.ComplexList {
    internalValue?: GroupSchemaPropertyOneOf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GroupSchemaPropertyOneOfOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property okta_group_schema_property}
*/
export declare class GroupSchemaProperty extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_group_schema_property";
    /**
    * Generates CDKTN code for importing a GroupSchemaProperty resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupSchemaProperty to import
    * @param importFromId The id of the existing GroupSchemaProperty that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupSchemaProperty to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/group_schema_property okta_group_schema_property} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupSchemaPropertyConfig
    */
    constructor(scope: Construct, id: string, config: GroupSchemaPropertyConfig);
    private _arrayEnum?;
    get arrayEnum(): string[];
    set arrayEnum(value: string[]);
    resetArrayEnum(): void;
    get arrayEnumInput(): string[] | undefined;
    private _arrayType?;
    get arrayType(): string;
    set arrayType(value: string);
    resetArrayType(): void;
    get arrayTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enum?;
    get enum(): string[];
    set enum(value: string[]);
    resetEnum(): void;
    get enumInput(): string[] | undefined;
    private _externalName?;
    get externalName(): string;
    set externalName(value: string);
    resetExternalName(): void;
    get externalNameInput(): string | undefined;
    private _externalNamespace?;
    get externalNamespace(): string;
    set externalNamespace(value: string);
    resetExternalNamespace(): void;
    get externalNamespaceInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _master?;
    get master(): string;
    set master(value: string);
    resetMaster(): void;
    get masterInput(): string | undefined;
    private _maxLength?;
    get maxLength(): number;
    set maxLength(value: number);
    resetMaxLength(): void;
    get maxLengthInput(): number | undefined;
    private _minLength?;
    get minLength(): number;
    set minLength(value: number);
    resetMinLength(): void;
    get minLengthInput(): number | undefined;
    private _permissions?;
    get permissions(): string;
    set permissions(value: string);
    resetPermissions(): void;
    get permissionsInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _unique?;
    get unique(): string;
    set unique(value: string);
    resetUnique(): void;
    get uniqueInput(): string | undefined;
    private _arrayOneOf;
    get arrayOneOf(): GroupSchemaPropertyArrayOneOfList;
    putArrayOneOf(value: GroupSchemaPropertyArrayOneOf[] | cdktn.IResolvable): void;
    resetArrayOneOf(): void;
    get arrayOneOfInput(): cdktn.IResolvable | GroupSchemaPropertyArrayOneOf[] | undefined;
    private _masterOverridePriority;
    get masterOverridePriority(): GroupSchemaPropertyMasterOverridePriorityList;
    putMasterOverridePriority(value: GroupSchemaPropertyMasterOverridePriority[] | cdktn.IResolvable): void;
    resetMasterOverridePriority(): void;
    get masterOverridePriorityInput(): cdktn.IResolvable | GroupSchemaPropertyMasterOverridePriority[] | undefined;
    private _oneOf;
    get oneOf(): GroupSchemaPropertyOneOfList;
    putOneOf(value: GroupSchemaPropertyOneOf[] | cdktn.IResolvable): void;
    resetOneOf(): void;
    get oneOfInput(): cdktn.IResolvable | GroupSchemaPropertyOneOf[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
