import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataOktaAuthServerScopesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Auth server ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/auth_server_scopes#auth_server_id DataOktaAuthServerScopes#auth_server_id}
    */
    readonly authServerId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/auth_server_scopes#id DataOktaAuthServerScopes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOktaAuthServerScopesScopes {
}
export declare function dataOktaAuthServerScopesScopesToTerraform(struct?: DataOktaAuthServerScopesScopes): any;
export declare function dataOktaAuthServerScopesScopesToHclTerraform(struct?: DataOktaAuthServerScopesScopes): any;
export declare class DataOktaAuthServerScopesScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOktaAuthServerScopesScopes | undefined;
    set internalValue(value: DataOktaAuthServerScopesScopes | undefined);
    get consent(): string;
    get default(): cdktn.IResolvable;
    get description(): string;
    get displayName(): string;
    get id(): string;
    get metadataPublish(): string;
    get name(): string;
    get optional(): cdktn.IResolvable;
    get systemAttribute(): cdktn.IResolvable;
}
export declare class DataOktaAuthServerScopesScopesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOktaAuthServerScopesScopesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/auth_server_scopes okta_auth_server_scopes}
*/
export declare class DataOktaAuthServerScopes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "okta_auth_server_scopes";
    /**
    * Generates CDKTN code for importing a DataOktaAuthServerScopes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaAuthServerScopes to import
    * @param importFromId The id of the existing DataOktaAuthServerScopes that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/auth_server_scopes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaAuthServerScopes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/auth_server_scopes okta_auth_server_scopes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaAuthServerScopesConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaAuthServerScopesConfig);
    private _authServerId?;
    get authServerId(): string;
    set authServerId(value: string);
    get authServerIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _scopes;
    get scopes(): DataOktaAuthServerScopesScopesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
