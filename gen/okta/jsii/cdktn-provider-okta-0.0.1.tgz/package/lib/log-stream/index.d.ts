import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LogStreamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unique name for the Log Stream object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#name LogStream#name}
    */
    readonly name: string;
    /**
    * Stream status
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#status LogStream#status}
    */
    readonly status?: string;
    /**
    * Streaming provider used - 'aws_eventbridge' or 'splunk_cloud_logstreaming'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#type LogStream#type}
    */
    readonly type: string;
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#settings LogStream#settings}
    */
    readonly settings?: LogStreamSettings;
}
export interface LogStreamSettings {
    /**
    * AWS account ID. Required only for 'aws_eventbridge' type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#account_id LogStream#account_id}
    */
    readonly accountId?: string;
    /**
    * Edition of the Splunk Cloud instance. Could be one of: 'aws', 'aws_govcloud', 'gcp'. Required only for 'splunk_cloud_logstreaming' type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#edition LogStream#edition}
    */
    readonly edition?: string;
    /**
    * An alphanumeric name (no spaces) to identify this event source in AWS EventBridge. Required only for 'aws_eventbridge' type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#event_source_name LogStream#event_source_name}
    */
    readonly eventSourceName?: string;
    /**
    * The domain name for Splunk Cloud instance. Don't include http or https in the string. For example: 'acme.splunkcloud.com'. Required only for 'splunk_cloud_logstreaming' type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#host LogStream#host}
    */
    readonly host?: string;
    /**
    * The destination AWS region where event source is located. Required only for 'aws_eventbridge' type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#region LogStream#region}
    */
    readonly region?: string;
    /**
    * The HEC token for your Splunk Cloud HTTP Event Collector. Required only for 'splunk_cloud_logstreaming' type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#token LogStream#token}
    */
    readonly token?: string;
}
export declare function logStreamSettingsToTerraform(struct?: LogStreamSettings | cdktn.IResolvable): any;
export declare function logStreamSettingsToHclTerraform(struct?: LogStreamSettings | cdktn.IResolvable): any;
export declare class LogStreamSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogStreamSettings | cdktn.IResolvable | undefined;
    set internalValue(value: LogStreamSettings | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _edition?;
    get edition(): string;
    set edition(value: string);
    resetEdition(): void;
    get editionInput(): string | undefined;
    private _eventSourceName?;
    get eventSourceName(): string;
    set eventSourceName(value: string);
    resetEventSourceName(): void;
    get eventSourceNameInput(): string | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream okta_log_stream}
*/
export declare class LogStream extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_log_stream";
    /**
    * Generates CDKTN code for importing a LogStream resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogStream to import
    * @param importFromId The id of the existing LogStream that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogStream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/log_stream okta_log_stream} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogStreamConfig
    */
    constructor(scope: Construct, id: string, config: LogStreamConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _settings;
    get settings(): LogStreamSettingsOutputReference;
    putSettings(value: LogStreamSettings): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | LogStreamSettings | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
