import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TrustedOriginConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the Trusted Origin is active or not - can only be issued post-creation. By default, it is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_origin#active TrustedOrigin#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_origin#id TrustedOrigin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name for this trusted origin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_origin#name TrustedOrigin#name}
    */
    readonly name: string;
    /**
    * Unique origin URL for this trusted origin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_origin#origin TrustedOrigin#origin}
    */
    readonly origin: string;
    /**
    * Scopes of the Trusted Origin - can either be `CORS` and/or `REDIRECT`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_origin#scopes TrustedOrigin#scopes}
    */
    readonly scopes: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_origin okta_trusted_origin}
*/
export declare class TrustedOrigin extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_trusted_origin";
    /**
    * Generates CDKTN code for importing a TrustedOrigin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TrustedOrigin to import
    * @param importFromId The id of the existing TrustedOrigin that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_origin#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TrustedOrigin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/trusted_origin okta_trusted_origin} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TrustedOriginConfig
    */
    constructor(scope: Construct, id: string, config: TrustedOriginConfig);
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _origin?;
    get origin(): string;
    set origin(value: string);
    get originInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
