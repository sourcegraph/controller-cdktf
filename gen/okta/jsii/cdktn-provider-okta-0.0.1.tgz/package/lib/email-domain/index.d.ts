import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EmailDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Brand id of the email domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain#brand_id EmailDomain#brand_id}
    */
    readonly brandId: string;
    /**
    * Display name of the email domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain#display_name EmailDomain#display_name}
    */
    readonly displayName: string;
    /**
    * Mail domain to send from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain#domain EmailDomain#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain#id EmailDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * User name of the email domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain#user_name EmailDomain#user_name}
    */
    readonly userName: string;
}
export interface EmailDomainDnsValidationRecords {
}
export declare function emailDomainDnsValidationRecordsToTerraform(struct?: EmailDomainDnsValidationRecords): any;
export declare function emailDomainDnsValidationRecordsToHclTerraform(struct?: EmailDomainDnsValidationRecords): any;
export declare class EmailDomainDnsValidationRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EmailDomainDnsValidationRecords | undefined;
    set internalValue(value: EmailDomainDnsValidationRecords | undefined);
    get expiration(): string;
    get fqdn(): string;
    get recordType(): string;
    get value(): string;
}
export declare class EmailDomainDnsValidationRecordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EmailDomainDnsValidationRecordsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain okta_email_domain}
*/
export declare class EmailDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_email_domain";
    /**
    * Generates CDKTN code for importing a EmailDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EmailDomain to import
    * @param importFromId The id of the existing EmailDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EmailDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain okta_email_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EmailDomainConfig
    */
    constructor(scope: Construct, id: string, config: EmailDomainConfig);
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    get brandIdInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _dnsValidationRecords;
    get dnsValidationRecords(): EmailDomainDnsValidationRecordsList;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    get validationStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
