import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PolicyRuleMfaConfig extends cdktn.TerraformMetaArguments {
    /**
    * When a user should be prompted for MFA. It can be `CHALLENGE`, `LOGIN`, or `NEVER`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#enroll PolicyRuleMfa#enroll}
    */
    readonly enroll?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#id PolicyRuleMfa#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Policy Rule Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#name PolicyRuleMfa#name}
    */
    readonly name: string;
    /**
    * Network selection mode: `ANYWHERE`, `ZONE`, `ON_NETWORK`, or `OFF_NETWORK`. Default: `ANYWHERE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#network_connection PolicyRuleMfa#network_connection}
    */
    readonly networkConnection?: string;
    /**
    * Required if `network_connection` = `ZONE`. Indicates the network zones to exclude.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#network_excludes PolicyRuleMfa#network_excludes}
    */
    readonly networkExcludes?: string[];
    /**
    * Required if `network_connection` = `ZONE`. Indicates the network zones to include.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#network_includes PolicyRuleMfa#network_includes}
    */
    readonly networkIncludes?: string[];
    /**
    * Policy ID of the Rule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#policy_id PolicyRuleMfa#policy_id}
    */
    readonly policyId?: string;
    /**
    * Rule priority. This attribute can be set to a valid priority. To avoid an endless diff situation an error is thrown if an invalid property is provided. The Okta API defaults to the last (lowest) if not provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#priority PolicyRuleMfa#priority}
    */
    readonly priority?: number;
    /**
    * Policy Rule Status: `ACTIVE` or `INACTIVE`. Default: `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#status PolicyRuleMfa#status}
    */
    readonly status?: string;
    /**
    * Set of User IDs to Exclude
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#users_excluded PolicyRuleMfa#users_excluded}
    */
    readonly usersExcluded?: string[];
    /**
    * app_exclude block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#app_exclude PolicyRuleMfa#app_exclude}
    */
    readonly appExclude?: PolicyRuleMfaAppExclude[] | cdktn.IResolvable;
    /**
    * app_include block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#app_include PolicyRuleMfa#app_include}
    */
    readonly appInclude?: PolicyRuleMfaAppInclude[] | cdktn.IResolvable;
}
export interface PolicyRuleMfaAppExclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#id PolicyRuleMfa#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#name PolicyRuleMfa#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#type PolicyRuleMfa#type}
    */
    readonly type: string;
}
export declare function policyRuleMfaAppExcludeToTerraform(struct?: PolicyRuleMfaAppExclude | cdktn.IResolvable): any;
export declare function policyRuleMfaAppExcludeToHclTerraform(struct?: PolicyRuleMfaAppExclude | cdktn.IResolvable): any;
export declare class PolicyRuleMfaAppExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PolicyRuleMfaAppExclude | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyRuleMfaAppExclude | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class PolicyRuleMfaAppExcludeList extends cdktn.ComplexList {
    internalValue?: PolicyRuleMfaAppExclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PolicyRuleMfaAppExcludeOutputReference;
}
export interface PolicyRuleMfaAppInclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#id PolicyRuleMfa#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#name PolicyRuleMfa#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#type PolicyRuleMfa#type}
    */
    readonly type: string;
}
export declare function policyRuleMfaAppIncludeToTerraform(struct?: PolicyRuleMfaAppInclude | cdktn.IResolvable): any;
export declare function policyRuleMfaAppIncludeToHclTerraform(struct?: PolicyRuleMfaAppInclude | cdktn.IResolvable): any;
export declare class PolicyRuleMfaAppIncludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PolicyRuleMfaAppInclude | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyRuleMfaAppInclude | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class PolicyRuleMfaAppIncludeList extends cdktn.ComplexList {
    internalValue?: PolicyRuleMfaAppInclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PolicyRuleMfaAppIncludeOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa okta_policy_rule_mfa}
*/
export declare class PolicyRuleMfa extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_policy_rule_mfa";
    /**
    * Generates CDKTN code for importing a PolicyRuleMfa resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicyRuleMfa to import
    * @param importFromId The id of the existing PolicyRuleMfa that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicyRuleMfa to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_rule_mfa okta_policy_rule_mfa} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicyRuleMfaConfig
    */
    constructor(scope: Construct, id: string, config: PolicyRuleMfaConfig);
    private _enroll?;
    get enroll(): string;
    set enroll(value: string);
    resetEnroll(): void;
    get enrollInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkConnection?;
    get networkConnection(): string;
    set networkConnection(value: string);
    resetNetworkConnection(): void;
    get networkConnectionInput(): string | undefined;
    private _networkExcludes?;
    get networkExcludes(): string[];
    set networkExcludes(value: string[]);
    resetNetworkExcludes(): void;
    get networkExcludesInput(): string[] | undefined;
    private _networkIncludes?;
    get networkIncludes(): string[];
    set networkIncludes(value: string[]);
    resetNetworkIncludes(): void;
    get networkIncludesInput(): string[] | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _usersExcluded?;
    get usersExcluded(): string[];
    set usersExcluded(value: string[]);
    resetUsersExcluded(): void;
    get usersExcludedInput(): string[] | undefined;
    private _appExclude;
    get appExclude(): PolicyRuleMfaAppExcludeList;
    putAppExclude(value: PolicyRuleMfaAppExclude[] | cdktn.IResolvable): void;
    resetAppExclude(): void;
    get appExcludeInput(): cdktn.IResolvable | PolicyRuleMfaAppExclude[] | undefined;
    private _appInclude;
    get appInclude(): PolicyRuleMfaAppIncludeList;
    putAppInclude(value: PolicyRuleMfaAppInclude[] | cdktn.IResolvable): void;
    resetAppInclude(): void;
    get appIncludeInput(): cdktn.IResolvable | PolicyRuleMfaAppInclude[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
