import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppUserSchemaPropertyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Application's ID the user custom schema property should be assigned to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#app_id AppUserSchemaProperty#app_id}
    */
    readonly appId: string;
    /**
    * Array of values that an array property's items can be set to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#array_enum AppUserSchemaProperty#array_enum}
    */
    readonly arrayEnum?: string[];
    /**
    * The type of the array elements if `type` is set to `array`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#array_type AppUserSchemaProperty#array_type}
    */
    readonly arrayType?: string;
    /**
    * The description of the user schema property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#description AppUserSchemaProperty#description}
    */
    readonly description?: string;
    /**
    * Array of values a primitive property can be set to. See `array_enum` for arrays.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#enum AppUserSchemaProperty#enum}
    */
    readonly enum?: string[];
    /**
    * External name of the user schema property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#external_name AppUserSchemaProperty#external_name}
    */
    readonly externalName?: string;
    /**
    * External namespace of the user schema property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#external_namespace AppUserSchemaProperty#external_namespace}
    */
    readonly externalNamespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#id AppUserSchemaProperty#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Subschema unique string identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#index AppUserSchemaProperty#index}
    */
    readonly index: string;
    /**
    * Master priority for the user schema property. It can be set to `PROFILE_MASTER` or `OKTA`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#master AppUserSchemaProperty#master}
    */
    readonly master?: string;
    /**
    * The maximum length of the user property value. Only applies to type `string`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#max_length AppUserSchemaProperty#max_length}
    */
    readonly maxLength?: number;
    /**
    * The minimum length of the user property value. Only applies to type `string`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#min_length AppUserSchemaProperty#min_length}
    */
    readonly minLength?: number;
    /**
    * Access control permissions for the property. It can be set to `READ_WRITE`, `READ_ONLY`, `HIDE`. Default: `READ_ONLY`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#permissions AppUserSchemaProperty#permissions}
    */
    readonly permissions?: string;
    /**
    * Whether the subschema is required
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#required AppUserSchemaProperty#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * determines whether an app user attribute can be set at the Personal `SELF` or Group `NONE` level. Default value is `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#scope AppUserSchemaProperty#scope}
    */
    readonly scope?: string;
    /**
    * Subschema title (display name)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#title AppUserSchemaProperty#title}
    */
    readonly title: string;
    /**
    * The type of the schema property. It can be `string`, `boolean`, `number`, `integer`, `array`, or `object`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#type AppUserSchemaProperty#type}
    */
    readonly type: string;
    /**
    * If `type` is set to `array`, used to set whether attribute value is determined by group priority `false`, or combine values across groups `true`. Can not be set to `true` if `scope` is set to `SELF`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#union AppUserSchemaProperty#union}
    */
    readonly union?: boolean | cdktn.IResolvable;
    /**
    * Whether the property should be unique. It can be set to `UNIQUE_VALIDATED` or `NOT_UNIQUE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#unique AppUserSchemaProperty#unique}
    */
    readonly unique?: string;
    /**
    * User type ID. By default, it is `default`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#user_type AppUserSchemaProperty#user_type}
    */
    readonly userType?: string;
    /**
    * array_one_of block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#array_one_of AppUserSchemaProperty#array_one_of}
    */
    readonly arrayOneOf?: AppUserSchemaPropertyArrayOneOf[] | cdktn.IResolvable;
    /**
    * one_of block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#one_of AppUserSchemaProperty#one_of}
    */
    readonly oneOf?: AppUserSchemaPropertyOneOf[] | cdktn.IResolvable;
}
export interface AppUserSchemaPropertyArrayOneOf {
    /**
    * Value mapping to member of `array_enum`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#const AppUserSchemaProperty#const}
    */
    readonly const: string;
    /**
    * Display name for the enum value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#title AppUserSchemaProperty#title}
    */
    readonly title: string;
}
export declare function appUserSchemaPropertyArrayOneOfToTerraform(struct?: AppUserSchemaPropertyArrayOneOf | cdktn.IResolvable): any;
export declare function appUserSchemaPropertyArrayOneOfToHclTerraform(struct?: AppUserSchemaPropertyArrayOneOf | cdktn.IResolvable): any;
export declare class AppUserSchemaPropertyArrayOneOfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppUserSchemaPropertyArrayOneOf | cdktn.IResolvable | undefined;
    set internalValue(value: AppUserSchemaPropertyArrayOneOf | cdktn.IResolvable | undefined);
    private _const?;
    get const(): string;
    set const(value: string);
    get constInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
}
export declare class AppUserSchemaPropertyArrayOneOfList extends cdktn.ComplexList {
    internalValue?: AppUserSchemaPropertyArrayOneOf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppUserSchemaPropertyArrayOneOfOutputReference;
}
export interface AppUserSchemaPropertyOneOf {
    /**
    * Enum value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#const AppUserSchemaProperty#const}
    */
    readonly const: string;
    /**
    * Enum title
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#title AppUserSchemaProperty#title}
    */
    readonly title: string;
}
export declare function appUserSchemaPropertyOneOfToTerraform(struct?: AppUserSchemaPropertyOneOf | cdktn.IResolvable): any;
export declare function appUserSchemaPropertyOneOfToHclTerraform(struct?: AppUserSchemaPropertyOneOf | cdktn.IResolvable): any;
export declare class AppUserSchemaPropertyOneOfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppUserSchemaPropertyOneOf | cdktn.IResolvable | undefined;
    set internalValue(value: AppUserSchemaPropertyOneOf | cdktn.IResolvable | undefined);
    private _const?;
    get const(): string;
    set const(value: string);
    get constInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
}
export declare class AppUserSchemaPropertyOneOfList extends cdktn.ComplexList {
    internalValue?: AppUserSchemaPropertyOneOf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppUserSchemaPropertyOneOfOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property okta_app_user_schema_property}
*/
export declare class AppUserSchemaProperty extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_app_user_schema_property";
    /**
    * Generates CDKTN code for importing a AppUserSchemaProperty resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppUserSchemaProperty to import
    * @param importFromId The id of the existing AppUserSchemaProperty that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppUserSchemaProperty to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_user_schema_property okta_app_user_schema_property} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppUserSchemaPropertyConfig
    */
    constructor(scope: Construct, id: string, config: AppUserSchemaPropertyConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    private _arrayEnum?;
    get arrayEnum(): string[];
    set arrayEnum(value: string[]);
    resetArrayEnum(): void;
    get arrayEnumInput(): string[] | undefined;
    private _arrayType?;
    get arrayType(): string;
    set arrayType(value: string);
    resetArrayType(): void;
    get arrayTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enum?;
    get enum(): string[];
    set enum(value: string[]);
    resetEnum(): void;
    get enumInput(): string[] | undefined;
    private _externalName?;
    get externalName(): string;
    set externalName(value: string);
    resetExternalName(): void;
    get externalNameInput(): string | undefined;
    private _externalNamespace?;
    get externalNamespace(): string;
    set externalNamespace(value: string);
    resetExternalNamespace(): void;
    get externalNamespaceInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _master?;
    get master(): string;
    set master(value: string);
    resetMaster(): void;
    get masterInput(): string | undefined;
    private _maxLength?;
    get maxLength(): number;
    set maxLength(value: number);
    resetMaxLength(): void;
    get maxLengthInput(): number | undefined;
    private _minLength?;
    get minLength(): number;
    set minLength(value: number);
    resetMinLength(): void;
    get minLengthInput(): number | undefined;
    private _permissions?;
    get permissions(): string;
    set permissions(value: string);
    resetPermissions(): void;
    get permissionsInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _union?;
    get union(): boolean | cdktn.IResolvable;
    set union(value: boolean | cdktn.IResolvable);
    resetUnion(): void;
    get unionInput(): boolean | cdktn.IResolvable | undefined;
    private _unique?;
    get unique(): string;
    set unique(value: string);
    resetUnique(): void;
    get uniqueInput(): string | undefined;
    private _userType?;
    get userType(): string;
    set userType(value: string);
    resetUserType(): void;
    get userTypeInput(): string | undefined;
    private _arrayOneOf;
    get arrayOneOf(): AppUserSchemaPropertyArrayOneOfList;
    putArrayOneOf(value: AppUserSchemaPropertyArrayOneOf[] | cdktn.IResolvable): void;
    resetArrayOneOf(): void;
    get arrayOneOfInput(): cdktn.IResolvable | AppUserSchemaPropertyArrayOneOf[] | undefined;
    private _oneOf;
    get oneOf(): AppUserSchemaPropertyOneOfList;
    putOneOf(value: AppUserSchemaPropertyOneOf[] | cdktn.IResolvable): void;
    resetOneOf(): void;
    get oneOfInput(): cdktn.IResolvable | AppUserSchemaPropertyOneOf[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
