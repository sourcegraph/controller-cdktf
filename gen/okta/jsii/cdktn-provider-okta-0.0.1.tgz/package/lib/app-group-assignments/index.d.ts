import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppGroupAssignmentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the application to assign a group to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_group_assignments#app_id AppGroupAssignments#app_id}
    */
    readonly appId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_group_assignments#id AppGroupAssignments#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_group_assignments#group AppGroupAssignments#group}
    */
    readonly group: AppGroupAssignmentsGroup[] | cdktn.IResolvable;
}
export interface AppGroupAssignmentsGroup {
    /**
    * A group to associate with the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_group_assignments#id AppGroupAssignments#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Priority of group assignment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_group_assignments#priority AppGroupAssignments#priority}
    */
    readonly priority?: number;
    /**
    * JSON document containing [application profile](https://developer.okta.com/docs/reference/api/apps/#profile-object)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_group_assignments#profile AppGroupAssignments#profile}
    */
    readonly profile?: string;
}
export declare function appGroupAssignmentsGroupToTerraform(struct?: AppGroupAssignmentsGroup | cdktn.IResolvable): any;
export declare function appGroupAssignmentsGroupToHclTerraform(struct?: AppGroupAssignmentsGroup | cdktn.IResolvable): any;
export declare class AppGroupAssignmentsGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppGroupAssignmentsGroup | cdktn.IResolvable | undefined;
    set internalValue(value: AppGroupAssignmentsGroup | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _profile?;
    get profile(): string;
    set profile(value: string);
    resetProfile(): void;
    get profileInput(): string | undefined;
}
export declare class AppGroupAssignmentsGroupList extends cdktn.ComplexList {
    internalValue?: AppGroupAssignmentsGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppGroupAssignmentsGroupOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_group_assignments okta_app_group_assignments}
*/
export declare class AppGroupAssignments extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_app_group_assignments";
    /**
    * Generates CDKTN code for importing a AppGroupAssignments resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppGroupAssignments to import
    * @param importFromId The id of the existing AppGroupAssignments that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_group_assignments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppGroupAssignments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_group_assignments okta_app_group_assignments} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppGroupAssignmentsConfig
    */
    constructor(scope: Construct, id: string, config: AppGroupAssignmentsConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _group;
    get group(): AppGroupAssignmentsGroupList;
    putGroup(value: AppGroupAssignmentsGroup[] | cdktn.IResolvable): void;
    get groupInput(): cdktn.IResolvable | AppGroupAssignmentsGroup[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
