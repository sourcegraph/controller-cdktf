import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AuthServerScopeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Auth server ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope#auth_server_id AuthServerScope#auth_server_id}
    */
    readonly authServerId: string;
    /**
    * Indicates whether a consent dialog is needed for the scope. It can be set to `REQUIRED` or `IMPLICIT`. Default: `IMPLICIT`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope#consent AuthServerScope#consent}
    */
    readonly consent?: string;
    /**
    * A default scope will be returned in an access token when the client omits the scope parameter in a token request, provided this scope is allowed as part of the access policy rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope#default AuthServerScope#default}
    */
    readonly default?: boolean | cdktn.IResolvable;
    /**
    * Description of the Auth Server Scope.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope#description AuthServerScope#description}
    */
    readonly description?: string;
    /**
    * Name of the end user displayed in a consent dialog box
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope#display_name AuthServerScope#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope#id AuthServerScope#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to publish metadata or not. It can be set to `ALL_CLIENTS` or `NO_CLIENTS`. Default: `ALL_CLIENTS`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope#metadata_publish AuthServerScope#metadata_publish}
    */
    readonly metadataPublish?: string;
    /**
    * Auth server scope name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope#name AuthServerScope#name}
    */
    readonly name: string;
    /**
    * Whether the scope optional
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope#optional AuthServerScope#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope okta_auth_server_scope}
*/
export declare class AuthServerScope extends cdktn.TerraformResource {
    static readonly tfResourceType = "okta_auth_server_scope";
    /**
    * Generates CDKTN code for importing a AuthServerScope resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthServerScope to import
    * @param importFromId The id of the existing AuthServerScope that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthServerScope to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_scope okta_auth_server_scope} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthServerScopeConfig
    */
    constructor(scope: Construct, id: string, config: AuthServerScopeConfig);
    private _authServerId?;
    get authServerId(): string;
    set authServerId(value: string);
    get authServerIdInput(): string | undefined;
    private _consent?;
    get consent(): string;
    set consent(value: string);
    resetConsent(): void;
    get consentInput(): string | undefined;
    private _default?;
    get default(): boolean | cdktn.IResolvable;
    set default(value: boolean | cdktn.IResolvable);
    resetDefault(): void;
    get defaultInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadataPublish?;
    get metadataPublish(): string;
    set metadataPublish(value: string);
    resetMetadataPublish(): void;
    get metadataPublishInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    get systemAttribute(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
