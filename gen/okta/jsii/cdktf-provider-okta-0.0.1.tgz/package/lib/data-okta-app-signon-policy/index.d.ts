import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaAppSignonPolicyConfig extends cdktf.TerraformMetaArguments {
    /**
    * App ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_signon_policy#app_id DataOktaAppSignonPolicy#app_id}
    */
    readonly appId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_signon_policy#id DataOktaAppSignonPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_signon_policy okta_app_signon_policy}
*/
export declare class DataOktaAppSignonPolicy extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_app_signon_policy";
    /**
    * Generates CDKTF code for importing a DataOktaAppSignonPolicy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaAppSignonPolicy to import
    * @param importFromId The id of the existing DataOktaAppSignonPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_signon_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaAppSignonPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_signon_policy okta_app_signon_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaAppSignonPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaAppSignonPolicyConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
