import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaAuthServerConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/auth_server#id DataOktaAuthServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the auth server to retrieve.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/auth_server#name DataOktaAuthServer#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/auth_server okta_auth_server}
*/
export declare class DataOktaAuthServer extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_auth_server";
    /**
    * Generates CDKTF code for importing a DataOktaAuthServer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaAuthServer to import
    * @param importFromId The id of the existing DataOktaAuthServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/auth_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaAuthServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/auth_server okta_auth_server} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaAuthServerConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaAuthServerConfig);
    get audiences(): string[];
    get credentialsLastRotated(): string;
    get credentialsNextRotation(): string;
    get credentialsRotationMode(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuer(): string;
    get issuerMode(): string;
    get kid(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
