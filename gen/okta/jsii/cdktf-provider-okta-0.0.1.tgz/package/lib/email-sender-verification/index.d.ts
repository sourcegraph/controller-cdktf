import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EmailSenderVerificationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_sender_verification#id EmailSenderVerification#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Email sender ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_sender_verification#sender_id EmailSenderVerification#sender_id}
    */
    readonly senderId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_sender_verification okta_email_sender_verification}
*/
export declare class EmailSenderVerification extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_email_sender_verification";
    /**
    * Generates CDKTF code for importing a EmailSenderVerification resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EmailSenderVerification to import
    * @param importFromId The id of the existing EmailSenderVerification that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_sender_verification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EmailSenderVerification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_sender_verification okta_email_sender_verification} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EmailSenderVerificationConfig
    */
    constructor(scope: Construct, id: string, config: EmailSenderVerificationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _senderId?;
    get senderId(): string;
    set senderId(value: string);
    get senderIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
