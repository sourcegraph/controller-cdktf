import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface UserBaseSchemaPropertyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property#id UserBaseSchemaProperty#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Subschema unique string identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property#index UserBaseSchemaProperty#index}
    */
    readonly index: string;
    /**
    * Master priority for the user schema property. It can be set to `PROFILE_MASTER` or `OKTA`. Default: `PROFILE_MASTER`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property#master UserBaseSchemaProperty#master}
    */
    readonly master?: string;
    /**
    * The validation pattern to use for the subschema. Must be in form of '.+', or '[<pattern>]+' if present.'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property#pattern UserBaseSchemaProperty#pattern}
    */
    readonly pattern?: string;
    /**
    * Access control permissions for the property. It can be set to `READ_WRITE`, `READ_ONLY`, `HIDE`. Default: `READ_ONLY`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property#permissions UserBaseSchemaProperty#permissions}
    */
    readonly permissions?: string;
    /**
    * Whether the subschema is required
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property#required UserBaseSchemaProperty#required}
    */
    readonly required?: boolean | cdktf.IResolvable;
    /**
    * Subschema title (display name)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property#title UserBaseSchemaProperty#title}
    */
    readonly title: string;
    /**
    * The type of the schema property. It can be `string`, `boolean`, `number`, `integer`, `array`, or `object`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property#type UserBaseSchemaProperty#type}
    */
    readonly type: string;
    /**
    * User type ID. By default, it is `default`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property#user_type UserBaseSchemaProperty#user_type}
    */
    readonly userType?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property okta_user_base_schema_property}
*/
export declare class UserBaseSchemaProperty extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_user_base_schema_property";
    /**
    * Generates CDKTF code for importing a UserBaseSchemaProperty resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserBaseSchemaProperty to import
    * @param importFromId The id of the existing UserBaseSchemaProperty that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserBaseSchemaProperty to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_base_schema_property okta_user_base_schema_property} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserBaseSchemaPropertyConfig
    */
    constructor(scope: Construct, id: string, config: UserBaseSchemaPropertyConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _master?;
    get master(): string;
    set master(value: string);
    resetMaster(): void;
    get masterInput(): string | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _permissions?;
    get permissions(): string;
    set permissions(value: string);
    resetPermissions(): void;
    get permissionsInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktf.IResolvable;
    set required(value: boolean | cdktf.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktf.IResolvable | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _userType?;
    get userType(): string;
    set userType(value: string);
    resetUserType(): void;
    get userTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
