import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AppSamlConfig extends cdktf.TerraformMetaArguments {
    /**
    * Custom error page URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#accessibility_error_redirect_url AppSaml#accessibility_error_redirect_url}
    */
    readonly accessibilityErrorRedirectUrl?: string;
    /**
    * Custom login page URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#accessibility_login_redirect_url AppSaml#accessibility_login_redirect_url}
    */
    readonly accessibilityLoginRedirectUrl?: string;
    /**
    * Enable self service. Default is `false`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#accessibility_self_service AppSaml#accessibility_self_service}
    */
    readonly accessibilitySelfService?: boolean | cdktf.IResolvable;
    /**
    * An array of ACS endpoints. You can configure a maximum of 100 endpoints.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#acs_endpoints AppSaml#acs_endpoints}
    */
    readonly acsEndpoints?: string[];
    /**
    * Application notes for admins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#admin_note AppSaml#admin_note}
    */
    readonly adminNote?: string;
    /**
    * Displays specific appLinks for the app. The value for each application link should be boolean.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#app_links_json AppSaml#app_links_json}
    */
    readonly appLinksJson?: string;
    /**
    * Application settings in JSON format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#app_settings_json AppSaml#app_settings_json}
    */
    readonly appSettingsJson?: string;
    /**
    * Determines whether the SAML assertion is digitally signed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#assertion_signed AppSaml#assertion_signed}
    */
    readonly assertionSigned?: boolean | cdktf.IResolvable;
    /**
    * Audience Restriction
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#audience AppSaml#audience}
    */
    readonly audience?: string;
    /**
    * The ID of the associated `app_signon_policy`. If this property is removed from the application the `default` sign-on-policy will be associated with this application.y
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#authentication_policy AppSaml#authentication_policy}
    */
    readonly authenticationPolicy?: string;
    /**
    * Identifies the SAML authentication context class for the assertion’s authentication statement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#authn_context_class_ref AppSaml#authn_context_class_ref}
    */
    readonly authnContextClassRef?: string;
    /**
    * Display auto submit toolbar. Default is: `false`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#auto_submit_toolbar AppSaml#auto_submit_toolbar}
    */
    readonly autoSubmitToolbar?: boolean | cdktf.IResolvable;
    /**
    * Identifies a specific application resource in an IDP initiated SSO scenario.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#default_relay_state AppSaml#default_relay_state}
    */
    readonly defaultRelayState?: string;
    /**
    * Identifies the location where the SAML response is intended to be sent inside of the SAML assertion
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#destination AppSaml#destination}
    */
    readonly destination?: string;
    /**
    * Determines the digest algorithm used to digitally sign the SAML assertion and response
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#digest_algorithm AppSaml#digest_algorithm}
    */
    readonly digestAlgorithm?: string;
    /**
    * Application notes for end users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#enduser_note AppSaml#enduser_note}
    */
    readonly enduserNote?: string;
    /**
    * Do not display application icon on mobile app
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#hide_ios AppSaml#hide_ios}
    */
    readonly hideIos?: boolean | cdktf.IResolvable;
    /**
    * Do not display application icon to users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#hide_web AppSaml#hide_web}
    */
    readonly hideWeb?: boolean | cdktf.IResolvable;
    /**
    * Prompt user to re-authenticate if SP asks for it. Default is: `false`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#honor_force_authn AppSaml#honor_force_authn}
    */
    readonly honorForceAuthn?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#id AppSaml#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * SAML issuer ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#idp_issuer AppSaml#idp_issuer}
    */
    readonly idpIssuer?: string;
    /**
    * *Early Access Property*. Enable Federation Broker Mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#implicit_assignment AppSaml#implicit_assignment}
    */
    readonly implicitAssignment?: boolean | cdktf.IResolvable;
    /**
    * Saml Inline Hook setting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#inline_hook_id AppSaml#inline_hook_id}
    */
    readonly inlineHookId?: string;
    /**
    * Certificate name. This modulates the rotation of keys. New name == new key. Required to be set with `key_years_valid`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#key_name AppSaml#key_name}
    */
    readonly keyName?: string;
    /**
    * Number of years the certificate is valid (2 - 10 years).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#key_years_valid AppSaml#key_years_valid}
    */
    readonly keyYearsValid?: number;
    /**
    * The Application's display name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#label AppSaml#label}
    */
    readonly label: string;
    /**
    * Local file path to the logo. The file must be in PNG, JPG, or GIF format, and less than 1 MB in size.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#logo AppSaml#logo}
    */
    readonly logo?: string;
    /**
    * Name of application from the Okta Integration Network. For instance 'slack'. If not included a custom app will be created.  If not provided the following arguments are required:
    * 'sso_url'
    * 'recipient'
    * 'destination'
    * 'audience'
    * 'subject_name_id_template'
    * 'subject_name_id_format'
    * 'signature_algorithm'
    * 'digest_algorithm'
    * 'authn_context_class_ref'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#preconfigured_app AppSaml#preconfigured_app}
    */
    readonly preconfiguredApp?: string;
    /**
    * The location where the app may present the SAML assertion
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#recipient AppSaml#recipient}
    */
    readonly recipient?: string;
    /**
    * Denotes whether the request is compressed or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#request_compressed AppSaml#request_compressed}
    */
    readonly requestCompressed?: boolean | cdktf.IResolvable;
    /**
    * Determines whether the SAML auth response message is digitally signed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#response_signed AppSaml#response_signed}
    */
    readonly responseSigned?: boolean | cdktf.IResolvable;
    /**
    * SAML Signed Request enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#saml_signed_request_enabled AppSaml#saml_signed_request_enabled}
    */
    readonly samlSignedRequestEnabled?: boolean | cdktf.IResolvable;
    /**
    * SAML version for the app's sign-on mode. Valid values are: `2.0` or `1.1`. Default is `2.0`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#saml_version AppSaml#saml_version}
    */
    readonly samlVersion?: string;
    /**
    * Signature algorithm used to digitally sign the assertion and response
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#signature_algorithm AppSaml#signature_algorithm}
    */
    readonly signatureAlgorithm?: string;
    /**
    * x509 encoded certificate that the Service Provider uses to sign Single Logout requests. Note: should be provided without `-----BEGIN CERTIFICATE-----` and `-----END CERTIFICATE-----`, see [official documentation](https://developer.okta.com/docs/reference/api/apps/#service-provider-certificate).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#single_logout_certificate AppSaml#single_logout_certificate}
    */
    readonly singleLogoutCertificate?: string;
    /**
    * The issuer of the Service Provider that generates the Single Logout request
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#single_logout_issuer AppSaml#single_logout_issuer}
    */
    readonly singleLogoutIssuer?: string;
    /**
    * The location where the logout response is sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#single_logout_url AppSaml#single_logout_url}
    */
    readonly singleLogoutUrl?: string;
    /**
    * SAML SP issuer ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#sp_issuer AppSaml#sp_issuer}
    */
    readonly spIssuer?: string;
    /**
    * Single Sign On URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#sso_url AppSaml#sso_url}
    */
    readonly ssoUrl?: string;
    /**
    * Status of application. By default, it is `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#status AppSaml#status}
    */
    readonly status?: string;
    /**
    * Identifies the SAML processing rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#subject_name_id_format AppSaml#subject_name_id_format}
    */
    readonly subjectNameIdFormat?: string;
    /**
    * Template for app user's username when a user is assigned to the app
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#subject_name_id_template AppSaml#subject_name_id_template}
    */
    readonly subjectNameIdTemplate?: string;
    /**
    * Username template. Default: `${source.login}`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#user_name_template AppSaml#user_name_template}
    */
    readonly userNameTemplate?: string;
    /**
    * Push username on update. Valid values: `PUSH` and `DONT_PUSH`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#user_name_template_push_status AppSaml#user_name_template_push_status}
    */
    readonly userNameTemplatePushStatus?: string;
    /**
    * Username template suffix
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#user_name_template_suffix AppSaml#user_name_template_suffix}
    */
    readonly userNameTemplateSuffix?: string;
    /**
    * Username template type. Default: `BUILT_IN`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#user_name_template_type AppSaml#user_name_template_type}
    */
    readonly userNameTemplateType?: string;
    /**
    * attribute_statements block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#attribute_statements AppSaml#attribute_statements}
    */
    readonly attributeStatements?: AppSamlAttributeStatements[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#timeouts AppSaml#timeouts}
    */
    readonly timeouts?: AppSamlTimeouts;
}
export interface AppSamlKeys {
}
export declare function appSamlKeysToTerraform(struct?: AppSamlKeys): any;
export declare function appSamlKeysToHclTerraform(struct?: AppSamlKeys): any;
export declare class AppSamlKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSamlKeys | undefined;
    set internalValue(value: AppSamlKeys | undefined);
    get created(): string;
    get e(): string;
    get expiresAt(): string;
    get kid(): string;
    get kty(): string;
    get lastUpdated(): string;
    get n(): string;
    get use(): string;
    get x5C(): string[];
    get x5TS256(): string;
}
export declare class AppSamlKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSamlKeysOutputReference;
}
export interface AppSamlAttributeStatements {
    /**
    * Type of group attribute filter. Valid values are: `STARTS_WITH`, `EQUALS`, `CONTAINS`, or `REGEX`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#filter_type AppSaml#filter_type}
    */
    readonly filterType?: string;
    /**
    * Filter value to use
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#filter_value AppSaml#filter_value}
    */
    readonly filterValue?: string;
    /**
    * The reference name of the attribute statement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#name AppSaml#name}
    */
    readonly name: string;
    /**
    * The attribute namespace. It can be set to `urn:oasis:names:tc:SAML:2.0:attrname-format:unspecified`, `urn:oasis:names:tc:SAML:2.0:attrname-format:uri`, or `urn:oasis:names:tc:SAML:2.0:attrname-format:basic`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#namespace AppSaml#namespace}
    */
    readonly namespace?: string;
    /**
    * The type of attribute statements object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#type AppSaml#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#values AppSaml#values}
    */
    readonly values?: string[];
}
export declare function appSamlAttributeStatementsToTerraform(struct?: AppSamlAttributeStatements | cdktf.IResolvable): any;
export declare function appSamlAttributeStatementsToHclTerraform(struct?: AppSamlAttributeStatements | cdktf.IResolvable): any;
export declare class AppSamlAttributeStatementsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSamlAttributeStatements | cdktf.IResolvable | undefined;
    set internalValue(value: AppSamlAttributeStatements | cdktf.IResolvable | undefined);
    private _filterType?;
    get filterType(): string;
    set filterType(value: string);
    resetFilterType(): void;
    get filterTypeInput(): string | undefined;
    private _filterValue?;
    get filterValue(): string;
    set filterValue(value: string);
    resetFilterValue(): void;
    get filterValueInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class AppSamlAttributeStatementsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AppSamlAttributeStatements[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSamlAttributeStatementsOutputReference;
}
export interface AppSamlTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#create AppSaml#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#read AppSaml#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#update AppSaml#update}
    */
    readonly update?: string;
}
export declare function appSamlTimeoutsToTerraform(struct?: AppSamlTimeouts | cdktf.IResolvable): any;
export declare function appSamlTimeoutsToHclTerraform(struct?: AppSamlTimeouts | cdktf.IResolvable): any;
export declare class AppSamlTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSamlTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: AppSamlTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml okta_app_saml}
*/
export declare class AppSaml extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_app_saml";
    /**
    * Generates CDKTF code for importing a AppSaml resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppSaml to import
    * @param importFromId The id of the existing AppSaml that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppSaml to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_saml okta_app_saml} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppSamlConfig
    */
    constructor(scope: Construct, id: string, config: AppSamlConfig);
    private _accessibilityErrorRedirectUrl?;
    get accessibilityErrorRedirectUrl(): string;
    set accessibilityErrorRedirectUrl(value: string);
    resetAccessibilityErrorRedirectUrl(): void;
    get accessibilityErrorRedirectUrlInput(): string | undefined;
    private _accessibilityLoginRedirectUrl?;
    get accessibilityLoginRedirectUrl(): string;
    set accessibilityLoginRedirectUrl(value: string);
    resetAccessibilityLoginRedirectUrl(): void;
    get accessibilityLoginRedirectUrlInput(): string | undefined;
    private _accessibilitySelfService?;
    get accessibilitySelfService(): boolean | cdktf.IResolvable;
    set accessibilitySelfService(value: boolean | cdktf.IResolvable);
    resetAccessibilitySelfService(): void;
    get accessibilitySelfServiceInput(): boolean | cdktf.IResolvable | undefined;
    private _acsEndpoints?;
    get acsEndpoints(): string[];
    set acsEndpoints(value: string[]);
    resetAcsEndpoints(): void;
    get acsEndpointsInput(): string[] | undefined;
    private _adminNote?;
    get adminNote(): string;
    set adminNote(value: string);
    resetAdminNote(): void;
    get adminNoteInput(): string | undefined;
    private _appLinksJson?;
    get appLinksJson(): string;
    set appLinksJson(value: string);
    resetAppLinksJson(): void;
    get appLinksJsonInput(): string | undefined;
    private _appSettingsJson?;
    get appSettingsJson(): string;
    set appSettingsJson(value: string);
    resetAppSettingsJson(): void;
    get appSettingsJsonInput(): string | undefined;
    private _assertionSigned?;
    get assertionSigned(): boolean | cdktf.IResolvable;
    set assertionSigned(value: boolean | cdktf.IResolvable);
    resetAssertionSigned(): void;
    get assertionSignedInput(): boolean | cdktf.IResolvable | undefined;
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _authenticationPolicy?;
    get authenticationPolicy(): string;
    set authenticationPolicy(value: string);
    resetAuthenticationPolicy(): void;
    get authenticationPolicyInput(): string | undefined;
    private _authnContextClassRef?;
    get authnContextClassRef(): string;
    set authnContextClassRef(value: string);
    resetAuthnContextClassRef(): void;
    get authnContextClassRefInput(): string | undefined;
    private _autoSubmitToolbar?;
    get autoSubmitToolbar(): boolean | cdktf.IResolvable;
    set autoSubmitToolbar(value: boolean | cdktf.IResolvable);
    resetAutoSubmitToolbar(): void;
    get autoSubmitToolbarInput(): boolean | cdktf.IResolvable | undefined;
    get certificate(): string;
    private _defaultRelayState?;
    get defaultRelayState(): string;
    set defaultRelayState(value: string);
    resetDefaultRelayState(): void;
    get defaultRelayStateInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _digestAlgorithm?;
    get digestAlgorithm(): string;
    set digestAlgorithm(value: string);
    resetDigestAlgorithm(): void;
    get digestAlgorithmInput(): string | undefined;
    get embedUrl(): string;
    private _enduserNote?;
    get enduserNote(): string;
    set enduserNote(value: string);
    resetEnduserNote(): void;
    get enduserNoteInput(): string | undefined;
    get entityKey(): string;
    get entityUrl(): string;
    get features(): string[];
    private _hideIos?;
    get hideIos(): boolean | cdktf.IResolvable;
    set hideIos(value: boolean | cdktf.IResolvable);
    resetHideIos(): void;
    get hideIosInput(): boolean | cdktf.IResolvable | undefined;
    private _hideWeb?;
    get hideWeb(): boolean | cdktf.IResolvable;
    set hideWeb(value: boolean | cdktf.IResolvable);
    resetHideWeb(): void;
    get hideWebInput(): boolean | cdktf.IResolvable | undefined;
    private _honorForceAuthn?;
    get honorForceAuthn(): boolean | cdktf.IResolvable;
    set honorForceAuthn(value: boolean | cdktf.IResolvable);
    resetHonorForceAuthn(): void;
    get honorForceAuthnInput(): boolean | cdktf.IResolvable | undefined;
    get httpPostBinding(): string;
    get httpRedirectBinding(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idpIssuer?;
    get idpIssuer(): string;
    set idpIssuer(value: string);
    resetIdpIssuer(): void;
    get idpIssuerInput(): string | undefined;
    private _implicitAssignment?;
    get implicitAssignment(): boolean | cdktf.IResolvable;
    set implicitAssignment(value: boolean | cdktf.IResolvable);
    resetImplicitAssignment(): void;
    get implicitAssignmentInput(): boolean | cdktf.IResolvable | undefined;
    private _inlineHookId?;
    get inlineHookId(): string;
    set inlineHookId(value: string);
    resetInlineHookId(): void;
    get inlineHookIdInput(): string | undefined;
    get keyId(): string;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    resetKeyName(): void;
    get keyNameInput(): string | undefined;
    private _keyYearsValid?;
    get keyYearsValid(): number;
    set keyYearsValid(value: number);
    resetKeyYearsValid(): void;
    get keyYearsValidInput(): number | undefined;
    private _keys;
    get keys(): AppSamlKeysList;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    get logoUrl(): string;
    get metadata(): string;
    get metadataUrl(): string;
    get name(): string;
    private _preconfiguredApp?;
    get preconfiguredApp(): string;
    set preconfiguredApp(value: string);
    resetPreconfiguredApp(): void;
    get preconfiguredAppInput(): string | undefined;
    private _recipient?;
    get recipient(): string;
    set recipient(value: string);
    resetRecipient(): void;
    get recipientInput(): string | undefined;
    private _requestCompressed?;
    get requestCompressed(): boolean | cdktf.IResolvable;
    set requestCompressed(value: boolean | cdktf.IResolvable);
    resetRequestCompressed(): void;
    get requestCompressedInput(): boolean | cdktf.IResolvable | undefined;
    private _responseSigned?;
    get responseSigned(): boolean | cdktf.IResolvable;
    set responseSigned(value: boolean | cdktf.IResolvable);
    resetResponseSigned(): void;
    get responseSignedInput(): boolean | cdktf.IResolvable | undefined;
    private _samlSignedRequestEnabled?;
    get samlSignedRequestEnabled(): boolean | cdktf.IResolvable;
    set samlSignedRequestEnabled(value: boolean | cdktf.IResolvable);
    resetSamlSignedRequestEnabled(): void;
    get samlSignedRequestEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _samlVersion?;
    get samlVersion(): string;
    set samlVersion(value: string);
    resetSamlVersion(): void;
    get samlVersionInput(): string | undefined;
    get signOnMode(): string;
    private _signatureAlgorithm?;
    get signatureAlgorithm(): string;
    set signatureAlgorithm(value: string);
    resetSignatureAlgorithm(): void;
    get signatureAlgorithmInput(): string | undefined;
    private _singleLogoutCertificate?;
    get singleLogoutCertificate(): string;
    set singleLogoutCertificate(value: string);
    resetSingleLogoutCertificate(): void;
    get singleLogoutCertificateInput(): string | undefined;
    private _singleLogoutIssuer?;
    get singleLogoutIssuer(): string;
    set singleLogoutIssuer(value: string);
    resetSingleLogoutIssuer(): void;
    get singleLogoutIssuerInput(): string | undefined;
    private _singleLogoutUrl?;
    get singleLogoutUrl(): string;
    set singleLogoutUrl(value: string);
    resetSingleLogoutUrl(): void;
    get singleLogoutUrlInput(): string | undefined;
    private _spIssuer?;
    get spIssuer(): string;
    set spIssuer(value: string);
    resetSpIssuer(): void;
    get spIssuerInput(): string | undefined;
    private _ssoUrl?;
    get ssoUrl(): string;
    set ssoUrl(value: string);
    resetSsoUrl(): void;
    get ssoUrlInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _subjectNameIdFormat?;
    get subjectNameIdFormat(): string;
    set subjectNameIdFormat(value: string);
    resetSubjectNameIdFormat(): void;
    get subjectNameIdFormatInput(): string | undefined;
    private _subjectNameIdTemplate?;
    get subjectNameIdTemplate(): string;
    set subjectNameIdTemplate(value: string);
    resetSubjectNameIdTemplate(): void;
    get subjectNameIdTemplateInput(): string | undefined;
    private _userNameTemplate?;
    get userNameTemplate(): string;
    set userNameTemplate(value: string);
    resetUserNameTemplate(): void;
    get userNameTemplateInput(): string | undefined;
    private _userNameTemplatePushStatus?;
    get userNameTemplatePushStatus(): string;
    set userNameTemplatePushStatus(value: string);
    resetUserNameTemplatePushStatus(): void;
    get userNameTemplatePushStatusInput(): string | undefined;
    private _userNameTemplateSuffix?;
    get userNameTemplateSuffix(): string;
    set userNameTemplateSuffix(value: string);
    resetUserNameTemplateSuffix(): void;
    get userNameTemplateSuffixInput(): string | undefined;
    private _userNameTemplateType?;
    get userNameTemplateType(): string;
    set userNameTemplateType(value: string);
    resetUserNameTemplateType(): void;
    get userNameTemplateTypeInput(): string | undefined;
    private _attributeStatements;
    get attributeStatements(): AppSamlAttributeStatementsList;
    putAttributeStatements(value: AppSamlAttributeStatements[] | cdktf.IResolvable): void;
    resetAttributeStatements(): void;
    get attributeStatementsInput(): cdktf.IResolvable | AppSamlAttributeStatements[] | undefined;
    private _timeouts;
    get timeouts(): AppSamlTimeoutsOutputReference;
    putTimeouts(value: AppSamlTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | AppSamlTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
