import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AuthServerConfig extends cdktf.TerraformMetaArguments {
    /**
    * The recipients that the tokens are intended for. This becomes the `aud` claim in an access token. Currently Okta only supports a single value here.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server#audiences AuthServer#audiences}
    */
    readonly audiences: string[];
    /**
    * The key rotation mode for the authorization server. Can be `AUTO` or `MANUAL`. Default: `AUTO`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server#credentials_rotation_mode AuthServer#credentials_rotation_mode}
    */
    readonly credentialsRotationMode?: string;
    /**
    * The description of the authorization server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server#description AuthServer#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server#id AuthServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * *Early Access Property*. Allows you to use a custom issuer URL. It can be set to `CUSTOM_URL`, `ORG_URL`, or `DYNAMIC`. Default: `ORG_URL`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server#issuer_mode AuthServer#issuer_mode}
    */
    readonly issuerMode?: string;
    /**
    * The name of the authorization server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server#name AuthServer#name}
    */
    readonly name: string;
    /**
    * Default to `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server#status AuthServer#status}
    */
    readonly status?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server okta_auth_server}
*/
export declare class AuthServer extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_auth_server";
    /**
    * Generates CDKTF code for importing a AuthServer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthServer to import
    * @param importFromId The id of the existing AuthServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server okta_auth_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthServerConfig
    */
    constructor(scope: Construct, id: string, config: AuthServerConfig);
    private _audiences?;
    get audiences(): string[];
    set audiences(value: string[]);
    get audiencesInput(): string[] | undefined;
    get credentialsLastRotated(): string;
    get credentialsNextRotation(): string;
    private _credentialsRotationMode?;
    get credentialsRotationMode(): string;
    set credentialsRotationMode(value: string);
    resetCredentialsRotationMode(): void;
    get credentialsRotationModeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuer(): string;
    private _issuerMode?;
    get issuerMode(): string;
    set issuerMode(value: string);
    resetIssuerMode(): void;
    get issuerModeInput(): string | undefined;
    get kid(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
