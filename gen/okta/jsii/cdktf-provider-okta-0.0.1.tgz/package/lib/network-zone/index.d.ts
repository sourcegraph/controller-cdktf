import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NetworkZoneConfig extends cdktf.TerraformMetaArguments {
    /**
    * List of asns included. Format of each array value: a string representation of an ASN numeric value. Use with type `DYNAMIC` or `DYNAMIC_V2`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#asns NetworkZone#asns}
    */
    readonly asns?: string[];
    /**
    * Array of locations ISO-3166-1(2) included. Format code: countryCode OR countryCode-regionCode. Use with type `DYNAMIC` or `DYNAMIC_V2`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#dynamic_locations NetworkZone#dynamic_locations}
    */
    readonly dynamicLocations?: string[];
    /**
    * Array of locations ISO-3166-1(2) excluded. Format code: countryCode OR countryCode-regionCode. Use with type `DYNAMIC_V2`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#dynamic_locations_exclude NetworkZone#dynamic_locations_exclude}
    */
    readonly dynamicLocationsExclude?: string[];
    /**
    * Type of proxy being controlled by this dynamic network zone - can be one of `Any`, `TorAnonymizer` or `NotTorAnonymizer`. Use with type `DYNAMIC`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#dynamic_proxy_type NetworkZone#dynamic_proxy_type}
    */
    readonly dynamicProxyType?: string;
    /**
    * Array of values in CIDR/range form depending on the way it's been declared (i.e. CIDR will contain /suffix). Please check API docs for examples. Use with type `IP`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#gateways NetworkZone#gateways}
    */
    readonly gateways?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#id NetworkZone#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * List of ip service excluded. Use with type `DYNAMIC_V2`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#ip_service_categories_exclude NetworkZone#ip_service_categories_exclude}
    */
    readonly ipServiceCategoriesExclude?: string[];
    /**
    * List of ip service included. Use with type `DYNAMIC_V2`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#ip_service_categories_include NetworkZone#ip_service_categories_include}
    */
    readonly ipServiceCategoriesInclude?: string[];
    /**
    * Name of the Network Zone Resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#name NetworkZone#name}
    */
    readonly name: string;
    /**
    * Array of values in CIDR/range form depending on the way it's been declared (i.e. CIDR will contain /suffix). Please check API docs for examples. Can not be set if `usage` is set to `BLOCKLIST`. Use with type `IP`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#proxies NetworkZone#proxies}
    */
    readonly proxies?: string[];
    /**
    * Network Status - can either be `ACTIVE` or `INACTIVE` only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#status NetworkZone#status}
    */
    readonly status?: string;
    /**
    * Type of the Network Zone - can be `IP`, `DYNAMIC` or `DYNAMIC_V2` only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#type NetworkZone#type}
    */
    readonly type: string;
    /**
    * Usage of the Network Zone - can be either `POLICY` or `BLOCKLIST`. By default, it is `POLICY`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#usage NetworkZone#usage}
    */
    readonly usage?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone okta_network_zone}
*/
export declare class NetworkZone extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_network_zone";
    /**
    * Generates CDKTF code for importing a NetworkZone resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkZone to import
    * @param importFromId The id of the existing NetworkZone that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkZone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/network_zone okta_network_zone} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkZoneConfig
    */
    constructor(scope: Construct, id: string, config: NetworkZoneConfig);
    private _asns?;
    get asns(): string[];
    set asns(value: string[]);
    resetAsns(): void;
    get asnsInput(): string[] | undefined;
    private _dynamicLocations?;
    get dynamicLocations(): string[];
    set dynamicLocations(value: string[]);
    resetDynamicLocations(): void;
    get dynamicLocationsInput(): string[] | undefined;
    private _dynamicLocationsExclude?;
    get dynamicLocationsExclude(): string[];
    set dynamicLocationsExclude(value: string[]);
    resetDynamicLocationsExclude(): void;
    get dynamicLocationsExcludeInput(): string[] | undefined;
    private _dynamicProxyType?;
    get dynamicProxyType(): string;
    set dynamicProxyType(value: string);
    resetDynamicProxyType(): void;
    get dynamicProxyTypeInput(): string | undefined;
    private _gateways?;
    get gateways(): string[];
    set gateways(value: string[]);
    resetGateways(): void;
    get gatewaysInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipServiceCategoriesExclude?;
    get ipServiceCategoriesExclude(): string[];
    set ipServiceCategoriesExclude(value: string[]);
    resetIpServiceCategoriesExclude(): void;
    get ipServiceCategoriesExcludeInput(): string[] | undefined;
    private _ipServiceCategoriesInclude?;
    get ipServiceCategoriesInclude(): string[];
    set ipServiceCategoriesInclude(value: string[]);
    resetIpServiceCategoriesInclude(): void;
    get ipServiceCategoriesIncludeInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _proxies?;
    get proxies(): string[];
    set proxies(value: string[]);
    resetProxies(): void;
    get proxiesInput(): string[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _usage?;
    get usage(): string;
    set usage(value: string);
    resetUsage(): void;
    get usageInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
