import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaEmailTemplatesConfig extends cdktf.TerraformMetaArguments {
    /**
    * Brand ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_templates#brand_id DataOktaEmailTemplates#brand_id}
    */
    readonly brandId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_templates#id DataOktaEmailTemplates#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataOktaEmailTemplatesEmailTemplates {
}
export declare function dataOktaEmailTemplatesEmailTemplatesToTerraform(struct?: DataOktaEmailTemplatesEmailTemplates): any;
export declare function dataOktaEmailTemplatesEmailTemplatesToHclTerraform(struct?: DataOktaEmailTemplatesEmailTemplates): any;
export declare class DataOktaEmailTemplatesEmailTemplatesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOktaEmailTemplatesEmailTemplates | undefined;
    set internalValue(value: DataOktaEmailTemplatesEmailTemplates | undefined);
    get links(): string;
    get name(): string;
}
export declare class DataOktaEmailTemplatesEmailTemplatesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOktaEmailTemplatesEmailTemplatesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_templates okta_email_templates}
*/
export declare class DataOktaEmailTemplates extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_email_templates";
    /**
    * Generates CDKTF code for importing a DataOktaEmailTemplates resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaEmailTemplates to import
    * @param importFromId The id of the existing DataOktaEmailTemplates that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_templates#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaEmailTemplates to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_templates okta_email_templates} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaEmailTemplatesConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaEmailTemplatesConfig);
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    get brandIdInput(): string | undefined;
    private _emailTemplates;
    get emailTemplates(): DataOktaEmailTemplatesEmailTemplatesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
