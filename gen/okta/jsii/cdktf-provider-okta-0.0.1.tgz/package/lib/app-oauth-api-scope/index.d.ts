import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AppOauthApiScopeConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_api_scope#app_id AppOauthApiScope#app_id}
    */
    readonly appId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_api_scope#id AppOauthApiScope#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The issuer of your Org Authorization Server, your Org URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_api_scope#issuer AppOauthApiScope#issuer}
    */
    readonly issuer: string;
    /**
    * Scopes of the application for which consent is granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_api_scope#scopes AppOauthApiScope#scopes}
    */
    readonly scopes: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_api_scope okta_app_oauth_api_scope}
*/
export declare class AppOauthApiScope extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_app_oauth_api_scope";
    /**
    * Generates CDKTF code for importing a AppOauthApiScope resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppOauthApiScope to import
    * @param importFromId The id of the existing AppOauthApiScope that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_api_scope#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppOauthApiScope to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_api_scope okta_app_oauth_api_scope} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppOauthApiScopeConfig
    */
    constructor(scope: Construct, id: string, config: AppOauthApiScopeConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    get issuerInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
