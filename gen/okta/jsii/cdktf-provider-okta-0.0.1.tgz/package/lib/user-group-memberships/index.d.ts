import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface UserGroupMembershipsConfig extends cdktf.TerraformMetaArguments {
    /**
    * The list of Okta group IDs which the user should have membership managed for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_group_memberships#groups UserGroupMemberships#groups}
    */
    readonly groups: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_group_memberships#id UserGroupMemberships#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ID of a Okta User
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_group_memberships#user_id UserGroupMemberships#user_id}
    */
    readonly userId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_group_memberships okta_user_group_memberships}
*/
export declare class UserGroupMemberships extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_user_group_memberships";
    /**
    * Generates CDKTF code for importing a UserGroupMemberships resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserGroupMemberships to import
    * @param importFromId The id of the existing UserGroupMemberships that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_group_memberships#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserGroupMemberships to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/user_group_memberships okta_user_group_memberships} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserGroupMembershipsConfig
    */
    constructor(scope: Construct, id: string, config: UserGroupMembershipsConfig);
    private _groups?;
    get groups(): string[];
    set groups(value: string[]);
    get groupsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
