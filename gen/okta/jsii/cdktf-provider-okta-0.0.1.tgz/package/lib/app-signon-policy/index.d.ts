import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AppSignonPolicyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Description of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_signon_policy#description AppSignonPolicy#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_signon_policy#id AppSignonPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_signon_policy#name AppSignonPolicy#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_signon_policy okta_app_signon_policy}
*/
export declare class AppSignonPolicy extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_app_signon_policy";
    /**
    * Generates CDKTF code for importing a AppSignonPolicy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppSignonPolicy to import
    * @param importFromId The id of the existing AppSignonPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_signon_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppSignonPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_signon_policy okta_app_signon_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppSignonPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AppSignonPolicyConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
