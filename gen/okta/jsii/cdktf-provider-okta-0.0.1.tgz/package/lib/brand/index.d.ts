import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface BrandConfig extends cdktf.TerraformMetaArguments {
    /**
    * Is a required input flag with when changing custom_privacy_url, shouldn't be considered as a readable property
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand#agree_to_custom_privacy_policy Brand#agree_to_custom_privacy_policy}
    */
    readonly agreeToCustomPrivacyPolicy?: boolean | cdktf.IResolvable;
    /**
    * Brand ID - Note: Okta API for brands only reads and updates therefore the okta_brand resource needs to act as a quasi data source. Do this by setting brand_id. `DEPRECATED`: Okta has fully support brand creation, this attribute is a no op and will be removed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand#brand_id Brand#brand_id}
    */
    readonly brandId?: string;
    /**
    * Custom privacy policy URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand#custom_privacy_policy_url Brand#custom_privacy_policy_url}
    */
    readonly customPrivacyPolicyUrl?: string;
    /**
    * Default app app instance id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand#default_app_app_instance_id Brand#default_app_app_instance_id}
    */
    readonly defaultAppAppInstanceId?: string;
    /**
    * Default app app link name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand#default_app_app_link_name Brand#default_app_app_link_name}
    */
    readonly defaultAppAppLinkName?: string;
    /**
    * Default app classic application uri
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand#default_app_classic_application_uri Brand#default_app_classic_application_uri}
    */
    readonly defaultAppClassicApplicationUri?: string;
    /**
    * The language specified as an IETF BCP 47 language tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand#locale Brand#locale}
    */
    readonly locale?: string;
    /**
    * Name of the brand
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand#name Brand#name}
    */
    readonly name: string;
    /**
    * Removes "Powered by Okta" from the Okta-hosted sign-in page and "© 2021 Okta, Inc." from the Okta End-User Dashboard
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand#remove_powered_by_okta Brand#remove_powered_by_okta}
    */
    readonly removePoweredByOkta?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand okta_brand}
*/
export declare class Brand extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_brand";
    /**
    * Generates CDKTF code for importing a Brand resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Brand to import
    * @param importFromId The id of the existing Brand that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Brand to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/brand okta_brand} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BrandConfig
    */
    constructor(scope: Construct, id: string, config: BrandConfig);
    private _agreeToCustomPrivacyPolicy?;
    get agreeToCustomPrivacyPolicy(): boolean | cdktf.IResolvable;
    set agreeToCustomPrivacyPolicy(value: boolean | cdktf.IResolvable);
    resetAgreeToCustomPrivacyPolicy(): void;
    get agreeToCustomPrivacyPolicyInput(): boolean | cdktf.IResolvable | undefined;
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    resetBrandId(): void;
    get brandIdInput(): string | undefined;
    private _customPrivacyPolicyUrl?;
    get customPrivacyPolicyUrl(): string;
    set customPrivacyPolicyUrl(value: string);
    resetCustomPrivacyPolicyUrl(): void;
    get customPrivacyPolicyUrlInput(): string | undefined;
    private _defaultAppAppInstanceId?;
    get defaultAppAppInstanceId(): string;
    set defaultAppAppInstanceId(value: string);
    resetDefaultAppAppInstanceId(): void;
    get defaultAppAppInstanceIdInput(): string | undefined;
    private _defaultAppAppLinkName?;
    get defaultAppAppLinkName(): string;
    set defaultAppAppLinkName(value: string);
    resetDefaultAppAppLinkName(): void;
    get defaultAppAppLinkNameInput(): string | undefined;
    private _defaultAppClassicApplicationUri?;
    get defaultAppClassicApplicationUri(): string;
    set defaultAppClassicApplicationUri(value: string);
    resetDefaultAppClassicApplicationUri(): void;
    get defaultAppClassicApplicationUriInput(): string | undefined;
    get emailDomainId(): string;
    get id(): string;
    get isDefault(): cdktf.IResolvable;
    get links(): string;
    private _locale?;
    get locale(): string;
    set locale(value: string);
    resetLocale(): void;
    get localeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _removePoweredByOkta?;
    get removePoweredByOkta(): boolean | cdktf.IResolvable;
    set removePoweredByOkta(value: boolean | cdktf.IResolvable);
    resetRemovePoweredByOkta(): void;
    get removePoweredByOktaInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
