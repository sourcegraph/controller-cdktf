import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AuthServerClaimDefaultConfig extends cdktf.TerraformMetaArguments {
    /**
    * Specifies whether to include claims in token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim_default#always_include_in_token AuthServerClaimDefault#always_include_in_token}
    */
    readonly alwaysIncludeInToken?: boolean | cdktf.IResolvable;
    /**
    * ID of the authorization server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim_default#auth_server_id AuthServerClaimDefault#auth_server_id}
    */
    readonly authServerId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim_default#id AuthServerClaimDefault#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the claim. Can be set to `sub`, `address`, `birthdate`, `email`,`email_verified`, `family_name`, `gender`, `given_name`, `locale`, `middle_name`, `name`, `nickname`,`phone_number`, `picture`, `preferred_username`, `profile`, `updated_at`, `website`, `zoneinfo`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim_default#name AuthServerClaimDefault#name}
    */
    readonly name: string;
    /**
    * The value of the claim. Only required for `sub` claim.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim_default#value AuthServerClaimDefault#value}
    */
    readonly value?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim_default okta_auth_server_claim_default}
*/
export declare class AuthServerClaimDefault extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_auth_server_claim_default";
    /**
    * Generates CDKTF code for importing a AuthServerClaimDefault resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthServerClaimDefault to import
    * @param importFromId The id of the existing AuthServerClaimDefault that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim_default#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthServerClaimDefault to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_claim_default okta_auth_server_claim_default} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthServerClaimDefaultConfig
    */
    constructor(scope: Construct, id: string, config: AuthServerClaimDefaultConfig);
    private _alwaysIncludeInToken?;
    get alwaysIncludeInToken(): boolean | cdktf.IResolvable;
    set alwaysIncludeInToken(value: boolean | cdktf.IResolvable);
    resetAlwaysIncludeInToken(): void;
    get alwaysIncludeInTokenInput(): boolean | cdktf.IResolvable | undefined;
    private _authServerId?;
    get authServerId(): string;
    set authServerId(value: string);
    get authServerIdInput(): string | undefined;
    get claimType(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get scopes(): string[];
    get status(): string;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    get valueType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
