import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IdpSamlConfig extends cdktf.TerraformMetaArguments {
    /**
    * Specifies the account linking action for an IdP user. Default: `AUTO`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#account_link_action IdpSaml#account_link_action}
    */
    readonly accountLinkAction?: string;
    /**
    * Group memberships to determine link candidates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#account_link_group_include IdpSaml#account_link_group_include}
    */
    readonly accountLinkGroupInclude?: string[];
    /**
    * The type of ACS. It can be `INSTANCE` or `ORG`. Default: `INSTANCE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#acs_type IdpSaml#acs_type}
    */
    readonly acsType?: string;
    /**
    * Action for a previously deprovisioned IdP user during authentication. Can be `NONE` or `REACTIVATE`. Default: `NONE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#deprovisioned_action IdpSaml#deprovisioned_action}
    */
    readonly deprovisionedAction?: string;
    /**
    * Provisioning action for IdP user's group memberships. It can be `NONE`, `SYNC`, `APPEND`, or `ASSIGN`. Default: `NONE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#groups_action IdpSaml#groups_action}
    */
    readonly groupsAction?: string;
    /**
    * List of Okta Group IDs to add an IdP user as a member with the `ASSIGN` `groups_action`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#groups_assignment IdpSaml#groups_assignment}
    */
    readonly groupsAssignment?: string[];
    /**
    * IdP user profile attribute name (case-insensitive) for an array value that contains group memberships.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#groups_attribute IdpSaml#groups_attribute}
    */
    readonly groupsAttribute?: string;
    /**
    * Whitelist of Okta Group identifiers that are allowed for the `APPEND` or `SYNC` `groups_action`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#groups_filter IdpSaml#groups_filter}
    */
    readonly groupsFilter?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#id IdpSaml#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * URI that identifies the issuer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#issuer IdpSaml#issuer}
    */
    readonly issuer: string;
    /**
    * Indicates whether Okta uses the original Okta org domain URL, or a custom domain URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#issuer_mode IdpSaml#issuer_mode}
    */
    readonly issuerMode?: string;
    /**
    * The ID of the signing key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#kid IdpSaml#kid}
    */
    readonly kid: string;
    /**
    * Maximum allowable clock-skew when processing messages from the IdP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#max_clock_skew IdpSaml#max_clock_skew}
    */
    readonly maxClockSkew?: number;
    /**
    * Name of the IdP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#name IdpSaml#name}
    */
    readonly name: string;
    /**
    * The name identifier format to use. By default `urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#name_format IdpSaml#name_format}
    */
    readonly nameFormat?: string;
    /**
    * Determines if the IdP should act as a source of truth for user profile attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#profile_master IdpSaml#profile_master}
    */
    readonly profileMaster?: boolean | cdktf.IResolvable;
    /**
    * Provisioning action for an IdP user during authentication. Default: `AUTO`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#provisioning_action IdpSaml#provisioning_action}
    */
    readonly provisioningAction?: string;
    /**
    * The XML digital Signature Algorithm used when signing an `AuthnRequest` message. It can be `SHA-256` or `SHA-1`. Default: `SHA-256`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#request_signature_algorithm IdpSaml#request_signature_algorithm}
    */
    readonly requestSignatureAlgorithm?: string;
    /**
    * Specifies whether to digitally sign an AuthnRequest messages to the IdP. It can be `REQUEST` or `NONE`. Default: `REQUEST`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#request_signature_scope IdpSaml#request_signature_scope}
    */
    readonly requestSignatureScope?: string;
    /**
    * The minimum XML digital signature algorithm allowed when verifying a `SAMLResponse` message or Assertion element. It can be `SHA-256` or `SHA-1`. Default: `SHA-256`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#response_signature_algorithm IdpSaml#response_signature_algorithm}
    */
    readonly responseSignatureAlgorithm?: string;
    /**
    * Specifies whether to verify a `SAMLResponse` message or Assertion element XML digital signature. It can be `RESPONSE`, `ASSERTION`, or `ANY`. Default: `ANY`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#response_signature_scope IdpSaml#response_signature_scope}
    */
    readonly responseSignatureScope?: string;
    /**
    * The method of making an SSO request. It can be set to `HTTP-POST` or `HTTP-REDIRECT`. Default: `HTTP-POST`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#sso_binding IdpSaml#sso_binding}
    */
    readonly ssoBinding?: string;
    /**
    * URI reference indicating the address to which the AuthnRequest message is sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#sso_destination IdpSaml#sso_destination}
    */
    readonly ssoDestination?: string;
    /**
    * URL of binding-specific endpoint to send an AuthnRequest message to IdP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#sso_url IdpSaml#sso_url}
    */
    readonly ssoUrl: string;
    /**
    * Default to `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#status IdpSaml#status}
    */
    readonly status?: string;
    /**
    * Optional regular expression pattern used to filter untrusted IdP usernames.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#subject_filter IdpSaml#subject_filter}
    */
    readonly subjectFilter?: string;
    /**
    * The name format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#subject_format IdpSaml#subject_format}
    */
    readonly subjectFormat?: string[];
    /**
    * Okta user profile attribute for matching transformed IdP username. Only for matchType `CUSTOM_ATTRIBUTE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#subject_match_attribute IdpSaml#subject_match_attribute}
    */
    readonly subjectMatchAttribute?: string;
    /**
    * Determines the Okta user profile attribute match conditions for account linking and authentication of the transformed IdP username. By default, it is set to `USERNAME`. It can be set to `USERNAME`, `EMAIL`, `USERNAME_OR_EMAIL` or `CUSTOM_ATTRIBUTE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#subject_match_type IdpSaml#subject_match_type}
    */
    readonly subjectMatchType?: string;
    /**
    * Action for a previously suspended IdP user during authentication. Can be `NONE` or `REACTIVATE`. Default: `NONE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#suspended_action IdpSaml#suspended_action}
    */
    readonly suspendedAction?: string;
    /**
    * Okta EL Expression to generate or transform a unique username for the IdP user. Default: `idpuser.email`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#username_template IdpSaml#username_template}
    */
    readonly usernameTemplate?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml okta_idp_saml}
*/
export declare class IdpSaml extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_idp_saml";
    /**
    * Generates CDKTF code for importing a IdpSaml resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdpSaml to import
    * @param importFromId The id of the existing IdpSaml that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdpSaml to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/idp_saml okta_idp_saml} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdpSamlConfig
    */
    constructor(scope: Construct, id: string, config: IdpSamlConfig);
    private _accountLinkAction?;
    get accountLinkAction(): string;
    set accountLinkAction(value: string);
    resetAccountLinkAction(): void;
    get accountLinkActionInput(): string | undefined;
    private _accountLinkGroupInclude?;
    get accountLinkGroupInclude(): string[];
    set accountLinkGroupInclude(value: string[]);
    resetAccountLinkGroupInclude(): void;
    get accountLinkGroupIncludeInput(): string[] | undefined;
    get acsBinding(): string;
    private _acsType?;
    get acsType(): string;
    set acsType(value: string);
    resetAcsType(): void;
    get acsTypeInput(): string | undefined;
    get audience(): string;
    private _deprovisionedAction?;
    get deprovisionedAction(): string;
    set deprovisionedAction(value: string);
    resetDeprovisionedAction(): void;
    get deprovisionedActionInput(): string | undefined;
    private _groupsAction?;
    get groupsAction(): string;
    set groupsAction(value: string);
    resetGroupsAction(): void;
    get groupsActionInput(): string | undefined;
    private _groupsAssignment?;
    get groupsAssignment(): string[];
    set groupsAssignment(value: string[]);
    resetGroupsAssignment(): void;
    get groupsAssignmentInput(): string[] | undefined;
    private _groupsAttribute?;
    get groupsAttribute(): string;
    set groupsAttribute(value: string);
    resetGroupsAttribute(): void;
    get groupsAttributeInput(): string | undefined;
    private _groupsFilter?;
    get groupsFilter(): string[];
    set groupsFilter(value: string[]);
    resetGroupsFilter(): void;
    get groupsFilterInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    get issuerInput(): string | undefined;
    private _issuerMode?;
    get issuerMode(): string;
    set issuerMode(value: string);
    resetIssuerMode(): void;
    get issuerModeInput(): string | undefined;
    private _kid?;
    get kid(): string;
    set kid(value: string);
    get kidInput(): string | undefined;
    private _maxClockSkew?;
    get maxClockSkew(): number;
    set maxClockSkew(value: number);
    resetMaxClockSkew(): void;
    get maxClockSkewInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nameFormat?;
    get nameFormat(): string;
    set nameFormat(value: string);
    resetNameFormat(): void;
    get nameFormatInput(): string | undefined;
    private _profileMaster?;
    get profileMaster(): boolean | cdktf.IResolvable;
    set profileMaster(value: boolean | cdktf.IResolvable);
    resetProfileMaster(): void;
    get profileMasterInput(): boolean | cdktf.IResolvable | undefined;
    private _provisioningAction?;
    get provisioningAction(): string;
    set provisioningAction(value: string);
    resetProvisioningAction(): void;
    get provisioningActionInput(): string | undefined;
    private _requestSignatureAlgorithm?;
    get requestSignatureAlgorithm(): string;
    set requestSignatureAlgorithm(value: string);
    resetRequestSignatureAlgorithm(): void;
    get requestSignatureAlgorithmInput(): string | undefined;
    private _requestSignatureScope?;
    get requestSignatureScope(): string;
    set requestSignatureScope(value: string);
    resetRequestSignatureScope(): void;
    get requestSignatureScopeInput(): string | undefined;
    private _responseSignatureAlgorithm?;
    get responseSignatureAlgorithm(): string;
    set responseSignatureAlgorithm(value: string);
    resetResponseSignatureAlgorithm(): void;
    get responseSignatureAlgorithmInput(): string | undefined;
    private _responseSignatureScope?;
    get responseSignatureScope(): string;
    set responseSignatureScope(value: string);
    resetResponseSignatureScope(): void;
    get responseSignatureScopeInput(): string | undefined;
    private _ssoBinding?;
    get ssoBinding(): string;
    set ssoBinding(value: string);
    resetSsoBinding(): void;
    get ssoBindingInput(): string | undefined;
    private _ssoDestination?;
    get ssoDestination(): string;
    set ssoDestination(value: string);
    resetSsoDestination(): void;
    get ssoDestinationInput(): string | undefined;
    private _ssoUrl?;
    get ssoUrl(): string;
    set ssoUrl(value: string);
    get ssoUrlInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _subjectFilter?;
    get subjectFilter(): string;
    set subjectFilter(value: string);
    resetSubjectFilter(): void;
    get subjectFilterInput(): string | undefined;
    private _subjectFormat?;
    get subjectFormat(): string[];
    set subjectFormat(value: string[]);
    resetSubjectFormat(): void;
    get subjectFormatInput(): string[] | undefined;
    private _subjectMatchAttribute?;
    get subjectMatchAttribute(): string;
    set subjectMatchAttribute(value: string);
    resetSubjectMatchAttribute(): void;
    get subjectMatchAttributeInput(): string | undefined;
    private _subjectMatchType?;
    get subjectMatchType(): string;
    set subjectMatchType(value: string);
    resetSubjectMatchType(): void;
    get subjectMatchTypeInput(): string | undefined;
    private _suspendedAction?;
    get suspendedAction(): string;
    set suspendedAction(value: string);
    resetSuspendedAction(): void;
    get suspendedActionInput(): string | undefined;
    get type(): string;
    get userTypeId(): string;
    private _usernameTemplate?;
    get usernameTemplate(): string;
    set usernameTemplate(value: string);
    resetUsernameTemplate(): void;
    get usernameTemplateInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
