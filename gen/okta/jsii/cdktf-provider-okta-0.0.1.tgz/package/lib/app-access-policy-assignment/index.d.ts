import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AppAccessPolicyAssignmentConfig extends cdktf.TerraformMetaArguments {
    /**
    * The application ID; this value is immutable and can not be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_access_policy_assignment#app_id AppAccessPolicyAssignment#app_id}
    */
    readonly appId: string;
    /**
    * The access policy ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_access_policy_assignment#policy_id AppAccessPolicyAssignment#policy_id}
    */
    readonly policyId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_access_policy_assignment okta_app_access_policy_assignment}
*/
export declare class AppAccessPolicyAssignment extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_app_access_policy_assignment";
    /**
    * Generates CDKTF code for importing a AppAccessPolicyAssignment resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppAccessPolicyAssignment to import
    * @param importFromId The id of the existing AppAccessPolicyAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_access_policy_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppAccessPolicyAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_access_policy_assignment okta_app_access_policy_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppAccessPolicyAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: AppAccessPolicyAssignmentConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    get id(): string;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
