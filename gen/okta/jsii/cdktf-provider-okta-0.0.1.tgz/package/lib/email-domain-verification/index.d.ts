import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EmailDomainVerificationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Email domain ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain_verification#email_domain_id EmailDomainVerification#email_domain_id}
    */
    readonly emailDomainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain_verification#id EmailDomainVerification#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain_verification okta_email_domain_verification}
*/
export declare class EmailDomainVerification extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_email_domain_verification";
    /**
    * Generates CDKTF code for importing a EmailDomainVerification resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EmailDomainVerification to import
    * @param importFromId The id of the existing EmailDomainVerification that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain_verification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EmailDomainVerification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/email_domain_verification okta_email_domain_verification} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EmailDomainVerificationConfig
    */
    constructor(scope: Construct, id: string, config: EmailDomainVerificationConfig);
    private _emailDomainId?;
    get emailDomainId(): string;
    set emailDomainId(value: string);
    get emailDomainIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
