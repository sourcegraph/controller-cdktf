import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaDomainConfig extends cdktf.TerraformMetaArguments {
    /**
    * Brand ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/domain#domain_id_or_name DataOktaDomain#domain_id_or_name}
    */
    readonly domainIdOrName: string;
}
export interface DataOktaDomainDnsRecords {
}
export declare function dataOktaDomainDnsRecordsToTerraform(struct?: DataOktaDomainDnsRecords): any;
export declare function dataOktaDomainDnsRecordsToHclTerraform(struct?: DataOktaDomainDnsRecords): any;
export declare class DataOktaDomainDnsRecordsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOktaDomainDnsRecords | undefined;
    set internalValue(value: DataOktaDomainDnsRecords | undefined);
    get expiration(): string;
    get fqdn(): string;
    get recordType(): string;
    get values(): string[];
}
export declare class DataOktaDomainDnsRecordsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOktaDomainDnsRecordsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/domain okta_domain}
*/
export declare class DataOktaDomain extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_domain";
    /**
    * Generates CDKTF code for importing a DataOktaDomain resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaDomain to import
    * @param importFromId The id of the existing DataOktaDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/domain okta_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaDomainConfig);
    get certificateSourceType(): string;
    private _dnsRecords;
    get dnsRecords(): DataOktaDomainDnsRecordsList;
    get domain(): string;
    private _domainIdOrName?;
    get domainIdOrName(): string;
    set domainIdOrName(value: string);
    get domainIdOrNameInput(): string | undefined;
    get id(): string;
    private _publicCertificate;
    get publicCertificate(): cdktf.StringMap;
    get validationStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
