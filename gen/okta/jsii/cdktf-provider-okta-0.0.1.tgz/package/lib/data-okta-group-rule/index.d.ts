import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaGroupRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the Group Rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group_rule#id DataOktaGroupRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Group Rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group_rule#name DataOktaGroupRule#name}
    */
    readonly name?: string;
    /**
    * Default to `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group_rule#status DataOktaGroupRule#status}
    */
    readonly status?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group_rule okta_group_rule}
*/
export declare class DataOktaGroupRule extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_group_rule";
    /**
    * Generates CDKTF code for importing a DataOktaGroupRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaGroupRule to import
    * @param importFromId The id of the existing DataOktaGroupRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaGroupRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group_rule okta_group_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaGroupRuleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaGroupRuleConfig);
    get expressionType(): string;
    get expressionValue(): string;
    get groupAssignments(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get usersExcluded(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
