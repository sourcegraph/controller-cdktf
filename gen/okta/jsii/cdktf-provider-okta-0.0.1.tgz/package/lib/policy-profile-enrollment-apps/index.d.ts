import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PolicyProfileEnrollmentAppsConfig extends cdktf.TerraformMetaArguments {
    /**
    * List of app IDs to be added to this policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment_apps#apps PolicyProfileEnrollmentApps#apps}
    */
    readonly apps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment_apps#id PolicyProfileEnrollmentApps#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ID of the enrollment policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment_apps#policy_id PolicyProfileEnrollmentApps#policy_id}
    */
    readonly policyId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment_apps okta_policy_profile_enrollment_apps}
*/
export declare class PolicyProfileEnrollmentApps extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_policy_profile_enrollment_apps";
    /**
    * Generates CDKTF code for importing a PolicyProfileEnrollmentApps resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicyProfileEnrollmentApps to import
    * @param importFromId The id of the existing PolicyProfileEnrollmentApps that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment_apps#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicyProfileEnrollmentApps to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_profile_enrollment_apps okta_policy_profile_enrollment_apps} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicyProfileEnrollmentAppsConfig
    */
    constructor(scope: Construct, id: string, config: PolicyProfileEnrollmentAppsConfig);
    private _apps?;
    get apps(): string[];
    set apps(value: string[]);
    resetApps(): void;
    get appsInput(): string[] | undefined;
    get defaultPolicyId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
