import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface FactorTotpConfig extends cdktf.TerraformMetaArguments {
    /**
    * Clock drift interval. This setting allows you to build in tolerance for any drift between the token's current time and the server's current time. Valid values: `3`, `5`, `10`. Default is `3`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/factor_totp#clock_drift_interval FactorTotp#clock_drift_interval}
    */
    readonly clockDriftInterval?: number;
    /**
    * HMAC Algorithm. Valid values: `HMacSHA1`, `HMacSHA256`, `HMacSHA512`. Default is `HMacSHA512`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/factor_totp#hmac_algorithm FactorTotp#hmac_algorithm}
    */
    readonly hmacAlgorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/factor_totp#id FactorTotp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The TOTP name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/factor_totp#name FactorTotp#name}
    */
    readonly name: string;
    /**
    * Length of the password. Default is `6`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/factor_totp#otp_length FactorTotp#otp_length}
    */
    readonly otpLength?: number;
    /**
    * Shared secret encoding. Valid values: `base32`, `base64`, `hexadecimal`. Default is `base32`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/factor_totp#shared_secret_encoding FactorTotp#shared_secret_encoding}
    */
    readonly sharedSecretEncoding?: string;
    /**
    * Time step in seconds. Valid values: `15`, `30`, `60`. Default is `15`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/factor_totp#time_step FactorTotp#time_step}
    */
    readonly timeStep?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/factor_totp okta_factor_totp}
*/
export declare class FactorTotp extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_factor_totp";
    /**
    * Generates CDKTF code for importing a FactorTotp resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FactorTotp to import
    * @param importFromId The id of the existing FactorTotp that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/factor_totp#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FactorTotp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/factor_totp okta_factor_totp} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FactorTotpConfig
    */
    constructor(scope: Construct, id: string, config: FactorTotpConfig);
    private _clockDriftInterval?;
    get clockDriftInterval(): number;
    set clockDriftInterval(value: number);
    resetClockDriftInterval(): void;
    get clockDriftIntervalInput(): number | undefined;
    private _hmacAlgorithm?;
    get hmacAlgorithm(): string;
    set hmacAlgorithm(value: string);
    resetHmacAlgorithm(): void;
    get hmacAlgorithmInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _otpLength?;
    get otpLength(): number;
    set otpLength(value: number);
    resetOtpLength(): void;
    get otpLengthInput(): number | undefined;
    private _sharedSecretEncoding?;
    get sharedSecretEncoding(): string;
    set sharedSecretEncoding(value: string);
    resetSharedSecretEncoding(): void;
    get sharedSecretEncodingInput(): string | undefined;
    private _timeStep?;
    get timeStep(): number;
    set timeStep(value: number);
    resetTimeStep(): void;
    get timeStepInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
