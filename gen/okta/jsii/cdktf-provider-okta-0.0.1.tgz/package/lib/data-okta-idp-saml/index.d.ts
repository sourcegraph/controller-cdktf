import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaIdpSamlConfig extends cdktf.TerraformMetaArguments {
    /**
    * Id of idp.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_saml#id DataOktaIdpSaml#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the idp.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_saml#name DataOktaIdpSaml#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_saml okta_idp_saml}
*/
export declare class DataOktaIdpSaml extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_idp_saml";
    /**
    * Generates CDKTF code for importing a DataOktaIdpSaml resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaIdpSaml to import
    * @param importFromId The id of the existing DataOktaIdpSaml that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_saml#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaIdpSaml to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_saml okta_idp_saml} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaIdpSamlConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaIdpSamlConfig);
    get acsBinding(): string;
    get acsType(): string;
    get audience(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuer(): string;
    get issuerMode(): string;
    get kid(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get ssoBinding(): string;
    get ssoDestination(): string;
    get ssoUrl(): string;
    get subjectFilter(): string;
    get subjectFormat(): string[];
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
