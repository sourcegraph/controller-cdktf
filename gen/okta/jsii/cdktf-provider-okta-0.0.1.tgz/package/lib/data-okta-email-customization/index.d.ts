import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaEmailCustomizationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Brand ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_customization#brand_id DataOktaEmailCustomization#brand_id}
    */
    readonly brandId: string;
    /**
    * The ID of the customization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_customization#customization_id DataOktaEmailCustomization#customization_id}
    */
    readonly customizationId: string;
    /**
    * Template Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_customization#template_name DataOktaEmailCustomization#template_name}
    */
    readonly templateName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_customization okta_email_customization}
*/
export declare class DataOktaEmailCustomization extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_email_customization";
    /**
    * Generates CDKTF code for importing a DataOktaEmailCustomization resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaEmailCustomization to import
    * @param importFromId The id of the existing DataOktaEmailCustomization that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_customization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaEmailCustomization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/email_customization okta_email_customization} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaEmailCustomizationConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaEmailCustomizationConfig);
    get body(): string;
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    get brandIdInput(): string | undefined;
    private _customizationId?;
    get customizationId(): string;
    set customizationId(value: string);
    get customizationIdInput(): string | undefined;
    get id(): string;
    get isDefault(): cdktf.IResolvable;
    get language(): string;
    get links(): string;
    get subject(): string;
    private _templateName?;
    get templateName(): string;
    set templateName(value: string);
    get templateNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
