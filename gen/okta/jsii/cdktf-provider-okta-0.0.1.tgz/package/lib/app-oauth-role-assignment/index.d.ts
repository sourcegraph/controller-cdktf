import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AppOauthRoleAssignmentConfig extends cdktf.TerraformMetaArguments {
    /**
    * Client ID for the role to be assigned to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_role_assignment#client_id AppOauthRoleAssignment#client_id}
    */
    readonly clientId: string;
    /**
    * Resource set for the custom role to assign, must be the ID of the created resource set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_role_assignment#resource_set AppOauthRoleAssignment#resource_set}
    */
    readonly resourceSet?: string;
    /**
    * Custom Role ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_role_assignment#role AppOauthRoleAssignment#role}
    */
    readonly role?: string;
    /**
    * Role type to assign. This can be one of the standard Okta roles, such as `HELP_DESK_ADMIN`, or `CUSTOM`. Using custom requires the `resource_set` and `role` attributes to be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_role_assignment#type AppOauthRoleAssignment#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_role_assignment okta_app_oauth_role_assignment}
*/
export declare class AppOauthRoleAssignment extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_app_oauth_role_assignment";
    /**
    * Generates CDKTF code for importing a AppOauthRoleAssignment resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppOauthRoleAssignment to import
    * @param importFromId The id of the existing AppOauthRoleAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_role_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppOauthRoleAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth_role_assignment okta_app_oauth_role_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppOauthRoleAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: AppOauthRoleAssignmentConfig);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    get id(): string;
    get label(): string;
    private _resourceSet?;
    get resourceSet(): string;
    set resourceSet(value: string);
    resetResourceSet(): void;
    get resourceSetInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    get status(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
