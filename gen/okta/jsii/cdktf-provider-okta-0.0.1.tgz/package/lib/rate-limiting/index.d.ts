import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RateLimitingConfig extends cdktf.TerraformMetaArguments {
    /**
    * Called during authentication. Valid values: `ENFORCE` _(Enforce limit and log per client (recommended))_, `DISABLE` _(Do nothing (not recommended))_, `PREVIEW` _(Log per client)_.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/rate_limiting#authorize RateLimiting#authorize}
    */
    readonly authorize: string;
    /**
    * Enable or disable rate limiting communications. By default, it is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/rate_limiting#communications_enabled RateLimiting#communications_enabled}
    */
    readonly communicationsEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/rate_limiting#id RateLimiting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Called when accessing the Okta hosted login page. Valid values: `ENFORCE` _(Enforce limit and log per client (recommended))_, `DISABLE` _(Do nothing (not recommended))_, `PREVIEW` _(Log per client)_.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/rate_limiting#login RateLimiting#login}
    */
    readonly login: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/rate_limiting okta_rate_limiting}
*/
export declare class RateLimiting extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_rate_limiting";
    /**
    * Generates CDKTF code for importing a RateLimiting resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RateLimiting to import
    * @param importFromId The id of the existing RateLimiting that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/rate_limiting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RateLimiting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/rate_limiting okta_rate_limiting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RateLimitingConfig
    */
    constructor(scope: Construct, id: string, config: RateLimitingConfig);
    private _authorize?;
    get authorize(): string;
    set authorize(value: string);
    get authorizeInput(): string | undefined;
    private _communicationsEnabled?;
    get communicationsEnabled(): boolean | cdktf.IResolvable;
    set communicationsEnabled(value: boolean | cdktf.IResolvable);
    resetCommunicationsEnabled(): void;
    get communicationsEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _login?;
    get login(): string;
    set login(value: string);
    get loginInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
