import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaThemeConfig extends cdktf.TerraformMetaArguments {
    /**
    * Brand ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/theme#brand_id DataOktaTheme#brand_id}
    */
    readonly brandId: string;
    /**
    * Theme ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/theme#theme_id DataOktaTheme#theme_id}
    */
    readonly themeId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/theme okta_theme}
*/
export declare class DataOktaTheme extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_theme";
    /**
    * Generates CDKTF code for importing a DataOktaTheme resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaTheme to import
    * @param importFromId The id of the existing DataOktaTheme that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/theme#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaTheme to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/theme okta_theme} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaThemeConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaThemeConfig);
    get backgroundImageUrl(): string;
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    get brandIdInput(): string | undefined;
    get emailTemplateTouchPointVariant(): string;
    get endUserDashboardTouchPointVariant(): string;
    get errorPageTouchPointVariant(): string;
    get faviconUrl(): string;
    get id(): string;
    get links(): string;
    get logoUrl(): string;
    get primaryColorContrastHex(): string;
    get primaryColorHex(): string;
    get secondaryColorContrastHex(): string;
    get secondaryColorHex(): string;
    get signInPageTouchPointVariant(): string;
    private _themeId?;
    get themeId(): string;
    set themeId(value: string);
    get themeIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
