import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaIdpMetadataSamlConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_metadata_saml#id DataOktaIdpMetadataSaml#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The id of the IdP to retrieve metadata for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_metadata_saml#idp_id DataOktaIdpMetadataSaml#idp_id}
    */
    readonly idpId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_metadata_saml okta_idp_metadata_saml}
*/
export declare class DataOktaIdpMetadataSaml extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_idp_metadata_saml";
    /**
    * Generates CDKTF code for importing a DataOktaIdpMetadataSaml resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaIdpMetadataSaml to import
    * @param importFromId The id of the existing DataOktaIdpMetadataSaml that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_metadata_saml#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaIdpMetadataSaml to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_metadata_saml okta_idp_metadata_saml} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaIdpMetadataSamlConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaIdpMetadataSamlConfig);
    get assertionsSigned(): cdktf.IResolvable;
    get authnRequestSigned(): cdktf.IResolvable;
    get encryptionCertificate(): string;
    get entityId(): string;
    get httpPostBinding(): string;
    get httpRedirectBinding(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idpId?;
    get idpId(): string;
    set idpId(value: string);
    resetIdpId(): void;
    get idpIdInput(): string | undefined;
    get metadata(): string;
    get signingCertificate(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
