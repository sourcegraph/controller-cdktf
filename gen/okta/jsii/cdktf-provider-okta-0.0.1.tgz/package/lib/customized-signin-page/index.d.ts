import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CustomizedSigninPageConfig extends cdktf.TerraformMetaArguments {
    /**
    * brand id of the preview signin page
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#brand_id CustomizedSigninPage#brand_id}
    */
    readonly brandId: string;
    /**
    * page content of the preview signin page
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#page_content CustomizedSigninPage#page_content}
    */
    readonly pageContent: string;
    /**
    * widget version specified as a Semver. The following are currently supported
    * 			*, ^1, ^2, ^3, ^4, ^5, ^6, ^7, 1.6, 1.7, 1.8, 1.9, 1.10, 1.11, 1.12, 1.13, 2.1, 2.2, 2.3, 2.4,
    * 			2.5, 2.6, 2.7, 2.8, 2.9, 2.10, 2.11, 2.12, 2.13, 2.14, 2.15, 2.16, 2.17, 2.18, 2.19, 2.20, 2.21,
    * 			3.0, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 4.0, 4.1, 4.2, 4.3, 4.4, 4.5, 5.0, 5.1, 5.2, 5.3,
    * 			5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 5.10, 5.11, 5.12, 5.13, 5.14, 5.15, 5.16, 6.0, 6.1, 6.2, 6.3, 6.4, 6.5,
    * 			6.6, 6.7, 6.8, 6.9, 7.0, 7.1, 7.2, 7.3, 7.4, 7.5, 7.6, 7.7, 7.8, 7.9, 7.10, 7.11, 7.12, 7.13.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#widget_version CustomizedSigninPage#widget_version}
    */
    readonly widgetVersion: string;
    /**
    * content_security_policy_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#content_security_policy_setting CustomizedSigninPage#content_security_policy_setting}
    */
    readonly contentSecurityPolicySetting?: CustomizedSigninPageContentSecurityPolicySetting;
    /**
    * widget_customizations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#widget_customizations CustomizedSigninPage#widget_customizations}
    */
    readonly widgetCustomizations?: CustomizedSigninPageWidgetCustomizations;
}
export interface CustomizedSigninPageContentSecurityPolicySetting {
    /**
    * enforced or report_only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#mode CustomizedSigninPage#mode}
    */
    readonly mode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#report_uri CustomizedSigninPage#report_uri}
    */
    readonly reportUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#src_list CustomizedSigninPage#src_list}
    */
    readonly srcList?: string[];
}
export declare function customizedSigninPageContentSecurityPolicySettingToTerraform(struct?: CustomizedSigninPageContentSecurityPolicySetting | cdktf.IResolvable): any;
export declare function customizedSigninPageContentSecurityPolicySettingToHclTerraform(struct?: CustomizedSigninPageContentSecurityPolicySetting | cdktf.IResolvable): any;
export declare class CustomizedSigninPageContentSecurityPolicySettingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomizedSigninPageContentSecurityPolicySetting | cdktf.IResolvable | undefined;
    set internalValue(value: CustomizedSigninPageContentSecurityPolicySetting | cdktf.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _reportUri?;
    get reportUri(): string;
    set reportUri(value: string);
    resetReportUri(): void;
    get reportUriInput(): string | undefined;
    private _srcList?;
    get srcList(): string[];
    set srcList(value: string[]);
    resetSrcList(): void;
    get srcListInput(): string[] | undefined;
}
export interface CustomizedSigninPageWidgetCustomizations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#authenticator_page_custom_link_label CustomizedSigninPage#authenticator_page_custom_link_label}
    */
    readonly authenticatorPageCustomLinkLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#authenticator_page_custom_link_url CustomizedSigninPage#authenticator_page_custom_link_url}
    */
    readonly authenticatorPageCustomLinkUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#classic_recovery_flow_email_or_username_label CustomizedSigninPage#classic_recovery_flow_email_or_username_label}
    */
    readonly classicRecoveryFlowEmailOrUsernameLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#custom_link_1_label CustomizedSigninPage#custom_link_1_label}
    */
    readonly customLink1Label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#custom_link_1_url CustomizedSigninPage#custom_link_1_url}
    */
    readonly customLink1Url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#custom_link_2_label CustomizedSigninPage#custom_link_2_label}
    */
    readonly customLink2Label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#custom_link_2_url CustomizedSigninPage#custom_link_2_url}
    */
    readonly customLink2Url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#forgot_password_label CustomizedSigninPage#forgot_password_label}
    */
    readonly forgotPasswordLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#forgot_password_url CustomizedSigninPage#forgot_password_url}
    */
    readonly forgotPasswordUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#help_label CustomizedSigninPage#help_label}
    */
    readonly helpLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#help_url CustomizedSigninPage#help_url}
    */
    readonly helpUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#password_info_tip CustomizedSigninPage#password_info_tip}
    */
    readonly passwordInfoTip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#password_label CustomizedSigninPage#password_label}
    */
    readonly passwordLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#show_password_visibility_toggle CustomizedSigninPage#show_password_visibility_toggle}
    */
    readonly showPasswordVisibilityToggle?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#show_user_identifier CustomizedSigninPage#show_user_identifier}
    */
    readonly showUserIdentifier?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#sign_in_label CustomizedSigninPage#sign_in_label}
    */
    readonly signInLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#unlock_account_label CustomizedSigninPage#unlock_account_label}
    */
    readonly unlockAccountLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#unlock_account_url CustomizedSigninPage#unlock_account_url}
    */
    readonly unlockAccountUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#username_info_tip CustomizedSigninPage#username_info_tip}
    */
    readonly usernameInfoTip?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#username_label CustomizedSigninPage#username_label}
    */
    readonly usernameLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#widget_generation CustomizedSigninPage#widget_generation}
    */
    readonly widgetGeneration: string;
}
export declare function customizedSigninPageWidgetCustomizationsToTerraform(struct?: CustomizedSigninPageWidgetCustomizations | cdktf.IResolvable): any;
export declare function customizedSigninPageWidgetCustomizationsToHclTerraform(struct?: CustomizedSigninPageWidgetCustomizations | cdktf.IResolvable): any;
export declare class CustomizedSigninPageWidgetCustomizationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomizedSigninPageWidgetCustomizations | cdktf.IResolvable | undefined;
    set internalValue(value: CustomizedSigninPageWidgetCustomizations | cdktf.IResolvable | undefined);
    private _authenticatorPageCustomLinkLabel?;
    get authenticatorPageCustomLinkLabel(): string;
    set authenticatorPageCustomLinkLabel(value: string);
    resetAuthenticatorPageCustomLinkLabel(): void;
    get authenticatorPageCustomLinkLabelInput(): string | undefined;
    private _authenticatorPageCustomLinkUrl?;
    get authenticatorPageCustomLinkUrl(): string;
    set authenticatorPageCustomLinkUrl(value: string);
    resetAuthenticatorPageCustomLinkUrl(): void;
    get authenticatorPageCustomLinkUrlInput(): string | undefined;
    private _classicRecoveryFlowEmailOrUsernameLabel?;
    get classicRecoveryFlowEmailOrUsernameLabel(): string;
    set classicRecoveryFlowEmailOrUsernameLabel(value: string);
    resetClassicRecoveryFlowEmailOrUsernameLabel(): void;
    get classicRecoveryFlowEmailOrUsernameLabelInput(): string | undefined;
    private _customLink1Label?;
    get customLink1Label(): string;
    set customLink1Label(value: string);
    resetCustomLink1Label(): void;
    get customLink1LabelInput(): string | undefined;
    private _customLink1Url?;
    get customLink1Url(): string;
    set customLink1Url(value: string);
    resetCustomLink1Url(): void;
    get customLink1UrlInput(): string | undefined;
    private _customLink2Label?;
    get customLink2Label(): string;
    set customLink2Label(value: string);
    resetCustomLink2Label(): void;
    get customLink2LabelInput(): string | undefined;
    private _customLink2Url?;
    get customLink2Url(): string;
    set customLink2Url(value: string);
    resetCustomLink2Url(): void;
    get customLink2UrlInput(): string | undefined;
    private _forgotPasswordLabel?;
    get forgotPasswordLabel(): string;
    set forgotPasswordLabel(value: string);
    resetForgotPasswordLabel(): void;
    get forgotPasswordLabelInput(): string | undefined;
    private _forgotPasswordUrl?;
    get forgotPasswordUrl(): string;
    set forgotPasswordUrl(value: string);
    resetForgotPasswordUrl(): void;
    get forgotPasswordUrlInput(): string | undefined;
    private _helpLabel?;
    get helpLabel(): string;
    set helpLabel(value: string);
    resetHelpLabel(): void;
    get helpLabelInput(): string | undefined;
    private _helpUrl?;
    get helpUrl(): string;
    set helpUrl(value: string);
    resetHelpUrl(): void;
    get helpUrlInput(): string | undefined;
    private _passwordInfoTip?;
    get passwordInfoTip(): string;
    set passwordInfoTip(value: string);
    resetPasswordInfoTip(): void;
    get passwordInfoTipInput(): string | undefined;
    private _passwordLabel?;
    get passwordLabel(): string;
    set passwordLabel(value: string);
    resetPasswordLabel(): void;
    get passwordLabelInput(): string | undefined;
    private _showPasswordVisibilityToggle?;
    get showPasswordVisibilityToggle(): boolean | cdktf.IResolvable;
    set showPasswordVisibilityToggle(value: boolean | cdktf.IResolvable);
    resetShowPasswordVisibilityToggle(): void;
    get showPasswordVisibilityToggleInput(): boolean | cdktf.IResolvable | undefined;
    private _showUserIdentifier?;
    get showUserIdentifier(): boolean | cdktf.IResolvable;
    set showUserIdentifier(value: boolean | cdktf.IResolvable);
    resetShowUserIdentifier(): void;
    get showUserIdentifierInput(): boolean | cdktf.IResolvable | undefined;
    private _signInLabel?;
    get signInLabel(): string;
    set signInLabel(value: string);
    resetSignInLabel(): void;
    get signInLabelInput(): string | undefined;
    private _unlockAccountLabel?;
    get unlockAccountLabel(): string;
    set unlockAccountLabel(value: string);
    resetUnlockAccountLabel(): void;
    get unlockAccountLabelInput(): string | undefined;
    private _unlockAccountUrl?;
    get unlockAccountUrl(): string;
    set unlockAccountUrl(value: string);
    resetUnlockAccountUrl(): void;
    get unlockAccountUrlInput(): string | undefined;
    private _usernameInfoTip?;
    get usernameInfoTip(): string;
    set usernameInfoTip(value: string);
    resetUsernameInfoTip(): void;
    get usernameInfoTipInput(): string | undefined;
    private _usernameLabel?;
    get usernameLabel(): string;
    set usernameLabel(value: string);
    resetUsernameLabel(): void;
    get usernameLabelInput(): string | undefined;
    private _widgetGeneration?;
    get widgetGeneration(): string;
    set widgetGeneration(value: string);
    get widgetGenerationInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page okta_customized_signin_page}
*/
export declare class CustomizedSigninPage extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_customized_signin_page";
    /**
    * Generates CDKTF code for importing a CustomizedSigninPage resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomizedSigninPage to import
    * @param importFromId The id of the existing CustomizedSigninPage that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomizedSigninPage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/customized_signin_page okta_customized_signin_page} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomizedSigninPageConfig
    */
    constructor(scope: Construct, id: string, config: CustomizedSigninPageConfig);
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    get brandIdInput(): string | undefined;
    get id(): string;
    private _pageContent?;
    get pageContent(): string;
    set pageContent(value: string);
    get pageContentInput(): string | undefined;
    private _widgetVersion?;
    get widgetVersion(): string;
    set widgetVersion(value: string);
    get widgetVersionInput(): string | undefined;
    private _contentSecurityPolicySetting;
    get contentSecurityPolicySetting(): CustomizedSigninPageContentSecurityPolicySettingOutputReference;
    putContentSecurityPolicySetting(value: CustomizedSigninPageContentSecurityPolicySetting): void;
    resetContentSecurityPolicySetting(): void;
    get contentSecurityPolicySettingInput(): cdktf.IResolvable | CustomizedSigninPageContentSecurityPolicySetting | undefined;
    private _widgetCustomizations;
    get widgetCustomizations(): CustomizedSigninPageWidgetCustomizationsOutputReference;
    putWidgetCustomizations(value: CustomizedSigninPageWidgetCustomizations): void;
    resetWidgetCustomizations(): void;
    get widgetCustomizationsInput(): cdktf.IResolvable | CustomizedSigninPageWidgetCustomizations | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
