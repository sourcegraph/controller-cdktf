import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Force delay of the group read by N seconds. Useful when eventual consistency of group information needs to be allowed for; for instance, when group rules are known to have been applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group#delay_read_seconds DataOktaGroup#delay_read_seconds}
    */
    readonly delayReadSeconds?: string;
    /**
    * ID of group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group#id DataOktaGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Fetch group users, having default off cuts down on API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group#include_users DataOktaGroup#include_users}
    */
    readonly includeUsers?: boolean | cdktf.IResolvable;
    /**
    * Name of group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group#name DataOktaGroup#name}
    */
    readonly name?: string;
    /**
    * Type of the group. When specified in the terraform resource, will act as a filter when searching for the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group#type DataOktaGroup#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group okta_group}
*/
export declare class DataOktaGroup extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_group";
    /**
    * Generates CDKTF code for importing a DataOktaGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaGroup to import
    * @param importFromId The id of the existing DataOktaGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/group okta_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaGroupConfig);
    private _delayReadSeconds?;
    get delayReadSeconds(): string;
    set delayReadSeconds(value: string);
    resetDelayReadSeconds(): void;
    get delayReadSecondsInput(): string | undefined;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeUsers?;
    get includeUsers(): boolean | cdktf.IResolvable;
    set includeUsers(value: boolean | cdktf.IResolvable);
    resetIncludeUsers(): void;
    get includeUsersInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get users(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
