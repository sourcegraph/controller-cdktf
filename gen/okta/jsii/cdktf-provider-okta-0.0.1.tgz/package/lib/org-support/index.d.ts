import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface OrgSupportConfig extends cdktf.TerraformMetaArguments {
    /**
    * Number of days the support should be extended by
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/org_support#extend_by OrgSupport#extend_by}
    */
    readonly extendBy?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/org_support#id OrgSupport#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/org_support okta_org_support}
*/
export declare class OrgSupport extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_org_support";
    /**
    * Generates CDKTF code for importing a OrgSupport resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OrgSupport to import
    * @param importFromId The id of the existing OrgSupport that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/org_support#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OrgSupport to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/org_support okta_org_support} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrgSupportConfig = {}
    */
    constructor(scope: Construct, id: string, config?: OrgSupportConfig);
    get expiration(): string;
    private _extendBy?;
    get extendBy(): number;
    set extendBy(value: number);
    resetExtendBy(): void;
    get extendByInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
