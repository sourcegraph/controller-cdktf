import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DomainCertificateConfig extends cdktf.TerraformMetaArguments {
    /**
    * Certificate content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain_certificate#certificate DomainCertificate#certificate}
    */
    readonly certificate: string;
    /**
    * Certificate chain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain_certificate#certificate_chain DomainCertificate#certificate_chain}
    */
    readonly certificateChain: string;
    /**
    * Domain's ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain_certificate#domain_id DomainCertificate#domain_id}
    */
    readonly domainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain_certificate#id DomainCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Certificate private key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain_certificate#private_key DomainCertificate#private_key}
    */
    readonly privateKey: string;
    /**
    * Certificate type. Valid value is `PEM`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain_certificate#type DomainCertificate#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain_certificate okta_domain_certificate}
*/
export declare class DomainCertificate extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_domain_certificate";
    /**
    * Generates CDKTF code for importing a DomainCertificate resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DomainCertificate to import
    * @param importFromId The id of the existing DomainCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DomainCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/domain_certificate okta_domain_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DomainCertificateConfig
    */
    constructor(scope: Construct, id: string, config: DomainCertificateConfig);
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    get certificateInput(): string | undefined;
    private _certificateChain?;
    get certificateChain(): string;
    set certificateChain(value: string);
    get certificateChainInput(): string | undefined;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
