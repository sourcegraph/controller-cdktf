import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaAppGroupAssignmentsConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the Okta App being queried for groups
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_group_assignments#id DataOktaAppGroupAssignments#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_group_assignments okta_app_group_assignments}
*/
export declare class DataOktaAppGroupAssignments extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_app_group_assignments";
    /**
    * Generates CDKTF code for importing a DataOktaAppGroupAssignments resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaAppGroupAssignments to import
    * @param importFromId The id of the existing DataOktaAppGroupAssignments that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_group_assignments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaAppGroupAssignments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_group_assignments okta_app_group_assignments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaAppGroupAssignmentsConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaAppGroupAssignmentsConfig);
    get groups(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
