import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PolicyDeviceAssuranceIosConfig extends cdktf.TerraformMetaArguments {
    /**
    * Is the device jailbroken in the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_ios#jailbreak PolicyDeviceAssuranceIos#jailbreak}
    */
    readonly jailbreak?: boolean | cdktf.IResolvable;
    /**
    * Name of the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_ios#name PolicyDeviceAssuranceIos#name}
    */
    readonly name: string;
    /**
    * Minimum os version of the device in the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_ios#os_version PolicyDeviceAssuranceIos#os_version}
    */
    readonly osVersion?: string;
    /**
    * List of screenlock type, can be `BIOMETRIC` or `BIOMETRIC, PASSCODE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_ios#screenlock_type PolicyDeviceAssuranceIos#screenlock_type}
    */
    readonly screenlockType?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_ios okta_policy_device_assurance_ios}
*/
export declare class PolicyDeviceAssuranceIos extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_policy_device_assurance_ios";
    /**
    * Generates CDKTF code for importing a PolicyDeviceAssuranceIos resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicyDeviceAssuranceIos to import
    * @param importFromId The id of the existing PolicyDeviceAssuranceIos that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_ios#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicyDeviceAssuranceIos to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_ios okta_policy_device_assurance_ios} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicyDeviceAssuranceIosConfig
    */
    constructor(scope: Construct, id: string, config: PolicyDeviceAssuranceIosConfig);
    get createdBy(): string;
    get createdDate(): string;
    get id(): string;
    private _jailbreak?;
    get jailbreak(): boolean | cdktf.IResolvable;
    set jailbreak(value: boolean | cdktf.IResolvable);
    resetJailbreak(): void;
    get jailbreakInput(): boolean | cdktf.IResolvable | undefined;
    get lastUpdate(): string;
    get lastUpdatedBy(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _osVersion?;
    get osVersion(): string;
    set osVersion(value: string);
    resetOsVersion(): void;
    get osVersionInput(): string | undefined;
    get platform(): string;
    private _screenlockType?;
    get screenlockType(): string[];
    set screenlockType(value: string[]);
    resetScreenlockType(): void;
    get screenlockTypeInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
