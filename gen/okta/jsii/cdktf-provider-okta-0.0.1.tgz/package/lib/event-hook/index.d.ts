import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EventHookConfig extends cdktf.TerraformMetaArguments {
    /**
    * Details of the endpoint the event hook will hit.
    * 	- 'version' - (Required) The version of the channel. The currently-supported version is '1.0.0'.
    * 	- 'uri' - (Required) The URI the hook will hit.
    * 	- 'type' - (Optional) The type of hook to trigger. Currently, the only supported type is 'HTTP'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook#auth EventHook#auth}
    */
    readonly auth?: {
        [key: string]: string;
    };
    /**
    * Details of the endpoint the event hook will hit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook#channel EventHook#channel}
    */
    readonly channel: {
        [key: string]: string;
    };
    /**
    * The events that will be delivered to this hook. [See here for a list of supported events](https://developer.okta.com/docs/reference/api/event-types/?q=event-hook-eligible).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook#events EventHook#events}
    */
    readonly events: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook#id EventHook#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The event hook display name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook#name EventHook#name}
    */
    readonly name: string;
    /**
    * Default to `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook#status EventHook#status}
    */
    readonly status?: string;
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook#headers EventHook#headers}
    */
    readonly headers?: EventHookHeaders[] | cdktf.IResolvable;
}
export interface EventHookHeaders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook#key EventHook#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook#value EventHook#value}
    */
    readonly value?: string;
}
export declare function eventHookHeadersToTerraform(struct?: EventHookHeaders | cdktf.IResolvable): any;
export declare function eventHookHeadersToHclTerraform(struct?: EventHookHeaders | cdktf.IResolvable): any;
export declare class EventHookHeadersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventHookHeaders | cdktf.IResolvable | undefined;
    set internalValue(value: EventHookHeaders | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class EventHookHeadersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventHookHeaders[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventHookHeadersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook okta_event_hook}
*/
export declare class EventHook extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_event_hook";
    /**
    * Generates CDKTF code for importing a EventHook resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventHook to import
    * @param importFromId The id of the existing EventHook that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventHook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/event_hook okta_event_hook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventHookConfig
    */
    constructor(scope: Construct, id: string, config: EventHookConfig);
    private _auth?;
    get auth(): {
        [key: string]: string;
    };
    set auth(value: {
        [key: string]: string;
    });
    resetAuth(): void;
    get authInput(): {
        [key: string]: string;
    } | undefined;
    private _channel?;
    get channel(): {
        [key: string]: string;
    };
    set channel(value: {
        [key: string]: string;
    });
    get channelInput(): {
        [key: string]: string;
    } | undefined;
    private _events?;
    get events(): string[];
    set events(value: string[]);
    get eventsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _headers;
    get headers(): EventHookHeadersList;
    putHeaders(value: EventHookHeaders[] | cdktf.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktf.IResolvable | EventHookHeaders[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
