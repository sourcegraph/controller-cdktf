import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaAppOauthConfig extends cdktf.TerraformMetaArguments {
    /**
    * Search only ACTIVE applications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_oauth#active_only DataOktaAppOauth#active_only}
    */
    readonly activeOnly?: boolean | cdktf.IResolvable;
    /**
    * Id of application to retrieve, conflicts with label and label_prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_oauth#id DataOktaAppOauth#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The label of the app to retrieve, conflicts with
    * 				label_prefix and id. Label uses the ?q=<label> query parameter exposed by
    * 				Okta's List Apps API. The API will search both name and label using that
    * 				query. Therefore similarily named and labeled apps may be returned in the query
    * 				and have the unitended result of associating the wrong app with this data
    * 				source. See:
    * 				https://developer.okta.com/docs/reference/api/apps/#list-applications
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_oauth#label DataOktaAppOauth#label}
    */
    readonly label?: string;
    /**
    * Label prefix of the app to retrieve, conflicts with label and id. This will tell the
    * 				provider to do a starts with query as opposed to an equals query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_oauth#label_prefix DataOktaAppOauth#label_prefix}
    */
    readonly labelPrefix?: string;
    /**
    * Ignore groups sync. This is a temporary solution until 'groups' field is supported in all the app-like resources
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_oauth#skip_groups DataOktaAppOauth#skip_groups}
    */
    readonly skipGroups?: boolean | cdktf.IResolvable;
    /**
    * Ignore users sync. This is a temporary solution until 'users' field is supported in all the app-like resources
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_oauth#skip_users DataOktaAppOauth#skip_users}
    */
    readonly skipUsers?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_oauth okta_app_oauth}
*/
export declare class DataOktaAppOauth extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_app_oauth";
    /**
    * Generates CDKTF code for importing a DataOktaAppOauth resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaAppOauth to import
    * @param importFromId The id of the existing DataOktaAppOauth that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_oauth#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaAppOauth to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/app_oauth okta_app_oauth} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaAppOauthConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaAppOauthConfig);
    private _activeOnly?;
    get activeOnly(): boolean | cdktf.IResolvable;
    set activeOnly(value: boolean | cdktf.IResolvable);
    resetActiveOnly(): void;
    get activeOnlyInput(): boolean | cdktf.IResolvable | undefined;
    get autoSubmitToolbar(): cdktf.IResolvable;
    get clientId(): string;
    get clientSecret(): string;
    get clientUri(): string;
    get grantTypes(): string[];
    get hideIos(): cdktf.IResolvable;
    get hideWeb(): cdktf.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _labelPrefix?;
    get labelPrefix(): string;
    set labelPrefix(value: string);
    resetLabelPrefix(): void;
    get labelPrefixInput(): string | undefined;
    get links(): string;
    get loginMode(): string;
    get loginScopes(): string[];
    get loginUri(): string;
    get logoUri(): string;
    get name(): string;
    get policyUri(): string;
    get postLogoutRedirectUris(): string[];
    get redirectUris(): string[];
    get responseTypes(): string[];
    private _skipGroups?;
    get skipGroups(): boolean | cdktf.IResolvable;
    set skipGroups(value: boolean | cdktf.IResolvable);
    resetSkipGroups(): void;
    get skipGroupsInput(): boolean | cdktf.IResolvable | undefined;
    private _skipUsers?;
    get skipUsers(): boolean | cdktf.IResolvable;
    set skipUsers(value: boolean | cdktf.IResolvable);
    resetSkipUsers(): void;
    get skipUsersInput(): boolean | cdktf.IResolvable | undefined;
    get status(): string;
    get type(): string;
    get wildcardRedirect(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
