import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AuthServerPolicyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the Auth Server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_policy#auth_server_id AuthServerPolicy#auth_server_id}
    */
    readonly authServerId: string;
    /**
    * The clients to whitelist the policy for. `[ALL_CLIENTS]` is a special value that can be used to whitelist all clients, otherwise it is a list of client ids.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_policy#client_whitelist AuthServerPolicy#client_whitelist}
    */
    readonly clientWhitelist: string[];
    /**
    * The description of the Auth Server Policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_policy#description AuthServerPolicy#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_policy#id AuthServerPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Auth Server Policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_policy#name AuthServerPolicy#name}
    */
    readonly name: string;
    /**
    * Priority of the auth server policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_policy#priority AuthServerPolicy#priority}
    */
    readonly priority: number;
    /**
    * Default to `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_policy#status AuthServerPolicy#status}
    */
    readonly status?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_policy okta_auth_server_policy}
*/
export declare class AuthServerPolicy extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_auth_server_policy";
    /**
    * Generates CDKTF code for importing a AuthServerPolicy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthServerPolicy to import
    * @param importFromId The id of the existing AuthServerPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthServerPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/auth_server_policy okta_auth_server_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthServerPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AuthServerPolicyConfig);
    private _authServerId?;
    get authServerId(): string;
    set authServerId(value: string);
    get authServerIdInput(): string | undefined;
    private _clientWhitelist?;
    get clientWhitelist(): string[];
    set clientWhitelist(value: string[]);
    get clientWhitelistInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
