import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AppOauthConfig extends cdktf.TerraformMetaArguments {
    /**
    * Custom error page URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#accessibility_error_redirect_url AppOauth#accessibility_error_redirect_url}
    */
    readonly accessibilityErrorRedirectUrl?: string;
    /**
    * Custom login page URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#accessibility_login_redirect_url AppOauth#accessibility_login_redirect_url}
    */
    readonly accessibilityLoginRedirectUrl?: string;
    /**
    * Enable self service. Default is `false`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#accessibility_self_service AppOauth#accessibility_self_service}
    */
    readonly accessibilitySelfService?: boolean | cdktf.IResolvable;
    /**
    * Application notes for admins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#admin_note AppOauth#admin_note}
    */
    readonly adminNote?: string;
    /**
    * Displays specific appLinks for the app. The value for each application link should be boolean.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#app_links_json AppOauth#app_links_json}
    */
    readonly appLinksJson?: string;
    /**
    * Application settings in JSON format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#app_settings_json AppOauth#app_settings_json}
    */
    readonly appSettingsJson?: string;
    /**
    * The ID of the associated app_signon_policy. If this property is removed from the application the default sign-on-policy will be associated with this application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#authentication_policy AppOauth#authentication_policy}
    */
    readonly authenticationPolicy?: string;
    /**
    * Requested key rotation mode. If
    * 				auto_key_rotation isn't specified, the client automatically opts in for Okta's
    * 				key rotation. You can update this property via the API or via the administrator
    * 				UI.
    * 				See: https://developer.okta.com/docs/reference/api/apps/#oauth-credential-object"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#auto_key_rotation AppOauth#auto_key_rotation}
    */
    readonly autoKeyRotation?: boolean | cdktf.IResolvable;
    /**
    * Display auto submit toolbar
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#auto_submit_toolbar AppOauth#auto_submit_toolbar}
    */
    readonly autoSubmitToolbar?: boolean | cdktf.IResolvable;
    /**
    * The user provided OAuth client secret key value, this can be set when token_endpoint_auth_method is client_secret_basic. This does nothing when `omit_secret is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#client_basic_secret AppOauth#client_basic_secret}
    */
    readonly clientBasicSecret?: string;
    /**
    * OAuth client ID. If set during creation, app is created with this id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#client_id AppOauth#client_id}
    */
    readonly clientId?: string;
    /**
    * URI to a web page providing information about the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#client_uri AppOauth#client_uri}
    */
    readonly clientUri?: string;
    /**
    * *Early Access Property*. Indicates whether user consent is required or implicit. Valid values: REQUIRED, TRUSTED. Default value is TRUSTED
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#consent_method AppOauth#consent_method}
    */
    readonly consentMethod?: string;
    /**
    * Application notes for end users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#enduser_note AppOauth#enduser_note}
    */
    readonly enduserNote?: string;
    /**
    * List of OAuth 2.0 grant types. Conditional validation params found here https://developer.okta.com/docs/api/resources/apps#credentials-settings-details. Defaults to minimum requirements per app type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#grant_types AppOauth#grant_types}
    */
    readonly grantTypes?: string[];
    /**
    * Do not display application icon on mobile app
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#hide_ios AppOauth#hide_ios}
    */
    readonly hideIos?: boolean | cdktf.IResolvable;
    /**
    * Do not display application icon to users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#hide_web AppOauth#hide_web}
    */
    readonly hideWeb?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#id AppOauth#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * *Early Access Property*. Enable Federation Broker Mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#implicit_assignment AppOauth#implicit_assignment}
    */
    readonly implicitAssignment?: boolean | cdktf.IResolvable;
    /**
    * *Early Access Property*. Indicates whether the Okta Authorization Server uses the original Okta org domain URL or a custom domain URL as the issuer of ID token for this client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#issuer_mode AppOauth#issuer_mode}
    */
    readonly issuerMode?: string;
    /**
    * URL reference to JWKS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#jwks_uri AppOauth#jwks_uri}
    */
    readonly jwksUri?: string;
    /**
    * The Application's display name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#label AppOauth#label}
    */
    readonly label: string;
    /**
    * The type of Idp-Initiated login that the client supports, if any
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#login_mode AppOauth#login_mode}
    */
    readonly loginMode?: string;
    /**
    * List of scopes to use for the request
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#login_scopes AppOauth#login_scopes}
    */
    readonly loginScopes?: string[];
    /**
    * URI that initiates login.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#login_uri AppOauth#login_uri}
    */
    readonly loginUri?: string;
    /**
    * Local file path to the logo. The file must be in PNG, JPG, or GIF format, and less than 1 MB in size.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#logo AppOauth#logo}
    */
    readonly logo?: string;
    /**
    * URI that references a logo for the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#logo_uri AppOauth#logo_uri}
    */
    readonly logoUri?: string;
    /**
    * This tells the provider not manage the client_secret value in state. When this is false (the default), it will cause the auto-generated client_secret to be persisted in the client_secret attribute in state. This also means that every time an update to this app is run, this value is also set on the API. If this changes from false => true, the `client_secret` is dropped from state and the secret at the time of the apply is what remains. If this is ever changes from true => false your app will be recreated, due to the need to regenerate a secret we can store in state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#omit_secret AppOauth#omit_secret}
    */
    readonly omitSecret?: boolean | cdktf.IResolvable;
    /**
    * Require Proof Key for Code Exchange (PKCE) for additional verification key rotation mode. See: https://developer.okta.com/docs/reference/api/apps/#oauth-credential-object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#pkce_required AppOauth#pkce_required}
    */
    readonly pkceRequired?: boolean | cdktf.IResolvable;
    /**
    * URI to web page providing client policy document.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#policy_uri AppOauth#policy_uri}
    */
    readonly policyUri?: string;
    /**
    * List of URIs for redirection after logout. Note: see okta_app_oauth_post_logout_redirect_uri for appending to this list in a decentralized way.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#post_logout_redirect_uris AppOauth#post_logout_redirect_uris}
    */
    readonly postLogoutRedirectUris?: string[];
    /**
    * Custom JSON that represents an OAuth application's profile
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#profile AppOauth#profile}
    */
    readonly profile?: string;
    /**
    * List of URIs for use in the redirect-based flow. This is required for all application types except service. Note: see okta_app_oauth_redirect_uri for appending to this list in a decentralized way.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#redirect_uris AppOauth#redirect_uris}
    */
    readonly redirectUris?: string[];
    /**
    * *Early Access Property* Grace period for token rotation, required with grant types refresh_token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#refresh_token_leeway AppOauth#refresh_token_leeway}
    */
    readonly refreshTokenLeeway?: number;
    /**
    * *Early Access Property* Refresh token rotation behavior, required with grant types refresh_token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#refresh_token_rotation AppOauth#refresh_token_rotation}
    */
    readonly refreshTokenRotation?: string;
    /**
    * List of OAuth 2.0 response type strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#response_types AppOauth#response_types}
    */
    readonly responseTypes?: string[];
    /**
    * Status of application. By default, it is `ACTIVE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#status AppOauth#status}
    */
    readonly status?: string;
    /**
    * Requested authentication method for the token endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#token_endpoint_auth_method AppOauth#token_endpoint_auth_method}
    */
    readonly tokenEndpointAuthMethod?: string;
    /**
    * URI to web page providing client tos (terms of service).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#tos_uri AppOauth#tos_uri}
    */
    readonly tosUri?: string;
    /**
    * The type of client application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#type AppOauth#type}
    */
    readonly type: string;
    /**
    * Username template. Default: `${source.login}`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#user_name_template AppOauth#user_name_template}
    */
    readonly userNameTemplate?: string;
    /**
    * Push username on update. Valid values: `PUSH` and `DONT_PUSH`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#user_name_template_push_status AppOauth#user_name_template_push_status}
    */
    readonly userNameTemplatePushStatus?: string;
    /**
    * Username template suffix
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#user_name_template_suffix AppOauth#user_name_template_suffix}
    */
    readonly userNameTemplateSuffix?: string;
    /**
    * Username template type. Default: `BUILT_IN`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#user_name_template_type AppOauth#user_name_template_type}
    */
    readonly userNameTemplateType?: string;
    /**
    * *Early Access Property*. Indicates if the client is allowed to use wildcard matching of redirect_uris
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#wildcard_redirect AppOauth#wildcard_redirect}
    */
    readonly wildcardRedirect?: string;
    /**
    * groups_claim block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#groups_claim AppOauth#groups_claim}
    */
    readonly groupsClaim?: AppOauthGroupsClaim;
    /**
    * jwks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#jwks AppOauth#jwks}
    */
    readonly jwks?: AppOauthJwks[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#timeouts AppOauth#timeouts}
    */
    readonly timeouts?: AppOauthTimeouts;
}
export interface AppOauthGroupsClaim {
    /**
    * Groups claim filter. Can only be set if type is FILTER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#filter_type AppOauth#filter_type}
    */
    readonly filterType?: string;
    /**
    * Name of the claim that will be used in the token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#name AppOauth#name}
    */
    readonly name: string;
    /**
    * Groups claim type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#type AppOauth#type}
    */
    readonly type: string;
    /**
    * Value of the claim. Can be an Okta Expression Language statement that evaluates at the time the token is minted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#value AppOauth#value}
    */
    readonly value: string;
}
export declare function appOauthGroupsClaimToTerraform(struct?: AppOauthGroupsClaimOutputReference | AppOauthGroupsClaim): any;
export declare function appOauthGroupsClaimToHclTerraform(struct?: AppOauthGroupsClaimOutputReference | AppOauthGroupsClaim): any;
export declare class AppOauthGroupsClaimOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppOauthGroupsClaim | undefined;
    set internalValue(value: AppOauthGroupsClaim | undefined);
    private _filterType?;
    get filterType(): string;
    set filterType(value: string);
    resetFilterType(): void;
    get filterTypeInput(): string | undefined;
    get issuerMode(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface AppOauthJwks {
    /**
    * RSA Exponent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#e AppOauth#e}
    */
    readonly e?: string;
    /**
    * Key ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#kid AppOauth#kid}
    */
    readonly kid: string;
    /**
    * Key type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#kty AppOauth#kty}
    */
    readonly kty: string;
    /**
    * RSA Modulus
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#n AppOauth#n}
    */
    readonly n?: string;
    /**
    * X coordinate of the elliptic curve point
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#x AppOauth#x}
    */
    readonly x?: string;
    /**
    * Y coordinate of the elliptic curve point
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#y AppOauth#y}
    */
    readonly y?: string;
}
export declare function appOauthJwksToTerraform(struct?: AppOauthJwks | cdktf.IResolvable): any;
export declare function appOauthJwksToHclTerraform(struct?: AppOauthJwks | cdktf.IResolvable): any;
export declare class AppOauthJwksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppOauthJwks | cdktf.IResolvable | undefined;
    set internalValue(value: AppOauthJwks | cdktf.IResolvable | undefined);
    private _e?;
    get e(): string;
    set e(value: string);
    resetE(): void;
    get eInput(): string | undefined;
    private _kid?;
    get kid(): string;
    set kid(value: string);
    get kidInput(): string | undefined;
    private _kty?;
    get kty(): string;
    set kty(value: string);
    get ktyInput(): string | undefined;
    private _n?;
    get n(): string;
    set n(value: string);
    resetN(): void;
    get nInput(): string | undefined;
    private _x?;
    get x(): string;
    set x(value: string);
    resetX(): void;
    get xInput(): string | undefined;
    private _y?;
    get y(): string;
    set y(value: string);
    resetY(): void;
    get yInput(): string | undefined;
}
export declare class AppOauthJwksList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AppOauthJwks[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppOauthJwksOutputReference;
}
export interface AppOauthTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#create AppOauth#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#read AppOauth#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#update AppOauth#update}
    */
    readonly update?: string;
}
export declare function appOauthTimeoutsToTerraform(struct?: AppOauthTimeouts | cdktf.IResolvable): any;
export declare function appOauthTimeoutsToHclTerraform(struct?: AppOauthTimeouts | cdktf.IResolvable): any;
export declare class AppOauthTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppOauthTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: AppOauthTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth okta_app_oauth}
*/
export declare class AppOauth extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_app_oauth";
    /**
    * Generates CDKTF code for importing a AppOauth resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppOauth to import
    * @param importFromId The id of the existing AppOauth that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppOauth to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/app_oauth okta_app_oauth} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppOauthConfig
    */
    constructor(scope: Construct, id: string, config: AppOauthConfig);
    private _accessibilityErrorRedirectUrl?;
    get accessibilityErrorRedirectUrl(): string;
    set accessibilityErrorRedirectUrl(value: string);
    resetAccessibilityErrorRedirectUrl(): void;
    get accessibilityErrorRedirectUrlInput(): string | undefined;
    private _accessibilityLoginRedirectUrl?;
    get accessibilityLoginRedirectUrl(): string;
    set accessibilityLoginRedirectUrl(value: string);
    resetAccessibilityLoginRedirectUrl(): void;
    get accessibilityLoginRedirectUrlInput(): string | undefined;
    private _accessibilitySelfService?;
    get accessibilitySelfService(): boolean | cdktf.IResolvable;
    set accessibilitySelfService(value: boolean | cdktf.IResolvable);
    resetAccessibilitySelfService(): void;
    get accessibilitySelfServiceInput(): boolean | cdktf.IResolvable | undefined;
    private _adminNote?;
    get adminNote(): string;
    set adminNote(value: string);
    resetAdminNote(): void;
    get adminNoteInput(): string | undefined;
    private _appLinksJson?;
    get appLinksJson(): string;
    set appLinksJson(value: string);
    resetAppLinksJson(): void;
    get appLinksJsonInput(): string | undefined;
    private _appSettingsJson?;
    get appSettingsJson(): string;
    set appSettingsJson(value: string);
    resetAppSettingsJson(): void;
    get appSettingsJsonInput(): string | undefined;
    private _authenticationPolicy?;
    get authenticationPolicy(): string;
    set authenticationPolicy(value: string);
    resetAuthenticationPolicy(): void;
    get authenticationPolicyInput(): string | undefined;
    private _autoKeyRotation?;
    get autoKeyRotation(): boolean | cdktf.IResolvable;
    set autoKeyRotation(value: boolean | cdktf.IResolvable);
    resetAutoKeyRotation(): void;
    get autoKeyRotationInput(): boolean | cdktf.IResolvable | undefined;
    private _autoSubmitToolbar?;
    get autoSubmitToolbar(): boolean | cdktf.IResolvable;
    set autoSubmitToolbar(value: boolean | cdktf.IResolvable);
    resetAutoSubmitToolbar(): void;
    get autoSubmitToolbarInput(): boolean | cdktf.IResolvable | undefined;
    private _clientBasicSecret?;
    get clientBasicSecret(): string;
    set clientBasicSecret(value: string);
    resetClientBasicSecret(): void;
    get clientBasicSecretInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    get clientSecret(): string;
    private _clientUri?;
    get clientUri(): string;
    set clientUri(value: string);
    resetClientUri(): void;
    get clientUriInput(): string | undefined;
    private _consentMethod?;
    get consentMethod(): string;
    set consentMethod(value: string);
    resetConsentMethod(): void;
    get consentMethodInput(): string | undefined;
    private _enduserNote?;
    get enduserNote(): string;
    set enduserNote(value: string);
    resetEnduserNote(): void;
    get enduserNoteInput(): string | undefined;
    private _grantTypes?;
    get grantTypes(): string[];
    set grantTypes(value: string[]);
    resetGrantTypes(): void;
    get grantTypesInput(): string[] | undefined;
    private _hideIos?;
    get hideIos(): boolean | cdktf.IResolvable;
    set hideIos(value: boolean | cdktf.IResolvable);
    resetHideIos(): void;
    get hideIosInput(): boolean | cdktf.IResolvable | undefined;
    private _hideWeb?;
    get hideWeb(): boolean | cdktf.IResolvable;
    set hideWeb(value: boolean | cdktf.IResolvable);
    resetHideWeb(): void;
    get hideWebInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _implicitAssignment?;
    get implicitAssignment(): boolean | cdktf.IResolvable;
    set implicitAssignment(value: boolean | cdktf.IResolvable);
    resetImplicitAssignment(): void;
    get implicitAssignmentInput(): boolean | cdktf.IResolvable | undefined;
    private _issuerMode?;
    get issuerMode(): string;
    set issuerMode(value: string);
    resetIssuerMode(): void;
    get issuerModeInput(): string | undefined;
    private _jwksUri?;
    get jwksUri(): string;
    set jwksUri(value: string);
    resetJwksUri(): void;
    get jwksUriInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _loginMode?;
    get loginMode(): string;
    set loginMode(value: string);
    resetLoginMode(): void;
    get loginModeInput(): string | undefined;
    private _loginScopes?;
    get loginScopes(): string[];
    set loginScopes(value: string[]);
    resetLoginScopes(): void;
    get loginScopesInput(): string[] | undefined;
    private _loginUri?;
    get loginUri(): string;
    set loginUri(value: string);
    resetLoginUri(): void;
    get loginUriInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    private _logoUri?;
    get logoUri(): string;
    set logoUri(value: string);
    resetLogoUri(): void;
    get logoUriInput(): string | undefined;
    get logoUrl(): string;
    get name(): string;
    private _omitSecret?;
    get omitSecret(): boolean | cdktf.IResolvable;
    set omitSecret(value: boolean | cdktf.IResolvable);
    resetOmitSecret(): void;
    get omitSecretInput(): boolean | cdktf.IResolvable | undefined;
    private _pkceRequired?;
    get pkceRequired(): boolean | cdktf.IResolvable;
    set pkceRequired(value: boolean | cdktf.IResolvable);
    resetPkceRequired(): void;
    get pkceRequiredInput(): boolean | cdktf.IResolvable | undefined;
    private _policyUri?;
    get policyUri(): string;
    set policyUri(value: string);
    resetPolicyUri(): void;
    get policyUriInput(): string | undefined;
    private _postLogoutRedirectUris?;
    get postLogoutRedirectUris(): string[];
    set postLogoutRedirectUris(value: string[]);
    resetPostLogoutRedirectUris(): void;
    get postLogoutRedirectUrisInput(): string[] | undefined;
    private _profile?;
    get profile(): string;
    set profile(value: string);
    resetProfile(): void;
    get profileInput(): string | undefined;
    private _redirectUris?;
    get redirectUris(): string[];
    set redirectUris(value: string[]);
    resetRedirectUris(): void;
    get redirectUrisInput(): string[] | undefined;
    private _refreshTokenLeeway?;
    get refreshTokenLeeway(): number;
    set refreshTokenLeeway(value: number);
    resetRefreshTokenLeeway(): void;
    get refreshTokenLeewayInput(): number | undefined;
    private _refreshTokenRotation?;
    get refreshTokenRotation(): string;
    set refreshTokenRotation(value: string);
    resetRefreshTokenRotation(): void;
    get refreshTokenRotationInput(): string | undefined;
    private _responseTypes?;
    get responseTypes(): string[];
    set responseTypes(value: string[]);
    resetResponseTypes(): void;
    get responseTypesInput(): string[] | undefined;
    get signOnMode(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tokenEndpointAuthMethod?;
    get tokenEndpointAuthMethod(): string;
    set tokenEndpointAuthMethod(value: string);
    resetTokenEndpointAuthMethod(): void;
    get tokenEndpointAuthMethodInput(): string | undefined;
    private _tosUri?;
    get tosUri(): string;
    set tosUri(value: string);
    resetTosUri(): void;
    get tosUriInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _userNameTemplate?;
    get userNameTemplate(): string;
    set userNameTemplate(value: string);
    resetUserNameTemplate(): void;
    get userNameTemplateInput(): string | undefined;
    private _userNameTemplatePushStatus?;
    get userNameTemplatePushStatus(): string;
    set userNameTemplatePushStatus(value: string);
    resetUserNameTemplatePushStatus(): void;
    get userNameTemplatePushStatusInput(): string | undefined;
    private _userNameTemplateSuffix?;
    get userNameTemplateSuffix(): string;
    set userNameTemplateSuffix(value: string);
    resetUserNameTemplateSuffix(): void;
    get userNameTemplateSuffixInput(): string | undefined;
    private _userNameTemplateType?;
    get userNameTemplateType(): string;
    set userNameTemplateType(value: string);
    resetUserNameTemplateType(): void;
    get userNameTemplateTypeInput(): string | undefined;
    private _wildcardRedirect?;
    get wildcardRedirect(): string;
    set wildcardRedirect(value: string);
    resetWildcardRedirect(): void;
    get wildcardRedirectInput(): string | undefined;
    private _groupsClaim;
    get groupsClaim(): AppOauthGroupsClaimOutputReference;
    putGroupsClaim(value: AppOauthGroupsClaim): void;
    resetGroupsClaim(): void;
    get groupsClaimInput(): AppOauthGroupsClaim | undefined;
    private _jwks;
    get jwks(): AppOauthJwksList;
    putJwks(value: AppOauthJwks[] | cdktf.IResolvable): void;
    resetJwks(): void;
    get jwksInput(): cdktf.IResolvable | AppOauthJwks[] | undefined;
    private _timeouts;
    get timeouts(): AppOauthTimeoutsOutputReference;
    putTimeouts(value: AppOauthTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | AppOauthTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
