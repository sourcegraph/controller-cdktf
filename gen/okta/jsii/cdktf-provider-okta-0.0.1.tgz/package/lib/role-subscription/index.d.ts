import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RoleSubscriptionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/role_subscription#id RoleSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Type of the notification. Valid values:
    * 	- 'CONNECTOR_AGENT' -  Disconnects and reconnects: On-prem provisioning, on-prem MFA agents, and RADIUS server agent.
    * 	- 'USER_LOCKED_OUT' - User lockouts.
    * 	- 'APP_IMPORT' - App user import status.
    * 	- 'LDAP_AGENT' - Disconnects and reconnects: LDAP agent.
    * 	- 'AD_AGENT' - Disconnects and reconnects: AD agent.
    * 	- 'OKTA_ANNOUNCEMENT' - Okta release notes and announcements.
    * 	- 'OKTA_ISSUE' - Trust incidents and updates.
    * 	- 'OKTA_UPDATE' - Scheduled system updates.
    * 	- 'IWA_AGENT' - Disconnects and reconnects: IWA agent.
    * 	- 'USER_DEPROVISION' - User deprovisions.
    * 	- 'REPORT_SUSPICIOUS_ACTIVITY' - User reporting of suspicious activity.
    * 	- 'RATELIMIT_NOTIFICATION' - Rate limit warning and violation.
    * 	- 'AGENT_AUTO_UPDATE_NOTIFICATION' - Agent auto-update notifications: AD Agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/role_subscription#notification_type RoleSubscription#notification_type}
    */
    readonly notificationType: string;
    /**
    * Type of the role. Valid values:
    * 	'API_ADMIN',
    * 	'APP_ADMIN',
    * 	'CUSTOM',
    * 	'GROUP_MEMBERSHIP_ADMIN',
    * 	'HELP_DESK_ADMIN',
    * 	'MOBILE_ADMIN',
    * 	'ORG_ADMIN',
    * 	'READ_ONLY_ADMIN',
    * 	'REPORT_ADMIN',
    * 	'SUPER_ADMIN',
    * 	'USER_ADMIN'
    * 	. See [API docs](https://developer.okta.com/docs/reference/api/admin-notifications/#role-types).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/role_subscription#role_type RoleSubscription#role_type}
    */
    readonly roleType: string;
    /**
    * Subscription status. Valid values: `subscribed`, `unsubscribed`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/role_subscription#status RoleSubscription#status}
    */
    readonly status?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/role_subscription okta_role_subscription}
*/
export declare class RoleSubscription extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_role_subscription";
    /**
    * Generates CDKTF code for importing a RoleSubscription resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RoleSubscription to import
    * @param importFromId The id of the existing RoleSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/role_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RoleSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/role_subscription okta_role_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RoleSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: RoleSubscriptionConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _notificationType?;
    get notificationType(): string;
    set notificationType(value: string);
    get notificationTypeInput(): string | undefined;
    private _roleType?;
    get roleType(): string;
    set roleType(value: string);
    get roleTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
