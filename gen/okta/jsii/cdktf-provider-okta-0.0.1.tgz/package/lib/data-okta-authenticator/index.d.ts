import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaAuthenticatorConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the authenticator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/authenticator#id DataOktaAuthenticator#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A human-readable string that identifies the authenticator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/authenticator#key DataOktaAuthenticator#key}
    */
    readonly key?: string;
    /**
    * Name of the authenticator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/authenticator#name DataOktaAuthenticator#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/authenticator okta_authenticator}
*/
export declare class DataOktaAuthenticator extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_authenticator";
    /**
    * Generates CDKTF code for importing a DataOktaAuthenticator resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaAuthenticator to import
    * @param importFromId The id of the existing DataOktaAuthenticator that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/authenticator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaAuthenticator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/authenticator okta_authenticator} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaAuthenticatorConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaAuthenticatorConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get providerAuthPort(): number;
    get providerHostname(): string;
    get providerInstanceId(): string;
    get providerJson(): string;
    get providerType(): string;
    get providerUserNameTemplate(): string;
    get settings(): string;
    get status(): string;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
