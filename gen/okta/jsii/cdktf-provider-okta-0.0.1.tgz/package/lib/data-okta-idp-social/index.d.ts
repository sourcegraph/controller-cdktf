import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaIdpSocialConfig extends cdktf.TerraformMetaArguments {
    /**
    * The id of the social idp to retrieve, conflicts with `name`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_social#id DataOktaIdpSocial#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the social idp to retrieve, conflicts with `id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_social#name DataOktaIdpSocial#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_social okta_idp_social}
*/
export declare class DataOktaIdpSocial extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_idp_social";
    /**
    * Generates CDKTF code for importing a DataOktaIdpSocial resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaIdpSocial to import
    * @param importFromId The id of the existing DataOktaIdpSocial that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_social#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaIdpSocial to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_social okta_idp_social} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaIdpSocialConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaIdpSocialConfig);
    get accountLinkAction(): string;
    get accountLinkGroupInclude(): string[];
    get authorizationBinding(): string;
    get authorizationUrl(): string;
    get clientId(): string;
    get clientSecret(): string;
    get deprovisionedAction(): string;
    get groupsAction(): string;
    get groupsAssignment(): string[];
    get groupsAttribute(): string;
    get groupsFilter(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuerMode(): string;
    get maxClockSkew(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get profileMaster(): cdktf.IResolvable;
    get protocolType(): string;
    get provisioningAction(): string;
    get scopes(): string[];
    get status(): string;
    get subjectMatchAttribute(): string;
    get subjectMatchType(): string;
    get suspendedAction(): string;
    get tokenBinding(): string;
    get tokenUrl(): string;
    get type(): string;
    get usernameTemplate(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
