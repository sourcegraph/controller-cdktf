import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SecurityNotificationEmailsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/security_notification_emails#id SecurityNotificationEmails#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Notifies end users about suspicious or unrecognized activity from their account. Default is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/security_notification_emails#report_suspicious_activity_enabled SecurityNotificationEmails#report_suspicious_activity_enabled}
    */
    readonly reportSuspiciousActivityEnabled?: boolean | cdktf.IResolvable;
    /**
    * Notifies end users of any activity on their account related to MFA factor enrollment. Default is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/security_notification_emails#send_email_for_factor_enrollment_enabled SecurityNotificationEmails#send_email_for_factor_enrollment_enabled}
    */
    readonly sendEmailForFactorEnrollmentEnabled?: boolean | cdktf.IResolvable;
    /**
    * Notifies end users that one or more factors have been reset for their account. Default is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/security_notification_emails#send_email_for_factor_reset_enabled SecurityNotificationEmails#send_email_for_factor_reset_enabled}
    */
    readonly sendEmailForFactorResetEnabled?: boolean | cdktf.IResolvable;
    /**
    * Notifies end users about new sign-on activity. Default is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/security_notification_emails#send_email_for_new_device_enabled SecurityNotificationEmails#send_email_for_new_device_enabled}
    */
    readonly sendEmailForNewDeviceEnabled?: boolean | cdktf.IResolvable;
    /**
    * Notifies end users that the password for their account has changed. Default is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/security_notification_emails#send_email_for_password_changed_enabled SecurityNotificationEmails#send_email_for_password_changed_enabled}
    */
    readonly sendEmailForPasswordChangedEnabled?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/security_notification_emails okta_security_notification_emails}
*/
export declare class SecurityNotificationEmails extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_security_notification_emails";
    /**
    * Generates CDKTF code for importing a SecurityNotificationEmails resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecurityNotificationEmails to import
    * @param importFromId The id of the existing SecurityNotificationEmails that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/security_notification_emails#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecurityNotificationEmails to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/security_notification_emails okta_security_notification_emails} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecurityNotificationEmailsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: SecurityNotificationEmailsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _reportSuspiciousActivityEnabled?;
    get reportSuspiciousActivityEnabled(): boolean | cdktf.IResolvable;
    set reportSuspiciousActivityEnabled(value: boolean | cdktf.IResolvable);
    resetReportSuspiciousActivityEnabled(): void;
    get reportSuspiciousActivityEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _sendEmailForFactorEnrollmentEnabled?;
    get sendEmailForFactorEnrollmentEnabled(): boolean | cdktf.IResolvable;
    set sendEmailForFactorEnrollmentEnabled(value: boolean | cdktf.IResolvable);
    resetSendEmailForFactorEnrollmentEnabled(): void;
    get sendEmailForFactorEnrollmentEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _sendEmailForFactorResetEnabled?;
    get sendEmailForFactorResetEnabled(): boolean | cdktf.IResolvable;
    set sendEmailForFactorResetEnabled(value: boolean | cdktf.IResolvable);
    resetSendEmailForFactorResetEnabled(): void;
    get sendEmailForFactorResetEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _sendEmailForNewDeviceEnabled?;
    get sendEmailForNewDeviceEnabled(): boolean | cdktf.IResolvable;
    set sendEmailForNewDeviceEnabled(value: boolean | cdktf.IResolvable);
    resetSendEmailForNewDeviceEnabled(): void;
    get sendEmailForNewDeviceEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _sendEmailForPasswordChangedEnabled?;
    get sendEmailForPasswordChangedEnabled(): boolean | cdktf.IResolvable;
    set sendEmailForPasswordChangedEnabled(value: boolean | cdktf.IResolvable);
    resetSendEmailForPasswordChangedEnabled(): void;
    get sendEmailForPasswordChangedEnabledInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
