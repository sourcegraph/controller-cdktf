import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaIdpOidcConfig extends cdktf.TerraformMetaArguments {
    /**
    * Id of idp.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_oidc#id DataOktaIdpOidc#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the idp.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_oidc#name DataOktaIdpOidc#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_oidc okta_idp_oidc}
*/
export declare class DataOktaIdpOidc extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_idp_oidc";
    /**
    * Generates CDKTF code for importing a DataOktaIdpOidc resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaIdpOidc to import
    * @param importFromId The id of the existing DataOktaIdpOidc that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_oidc#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaIdpOidc to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/data-sources/idp_oidc okta_idp_oidc} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaIdpOidcConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaIdpOidcConfig);
    get authorizationBinding(): string;
    get authorizationUrl(): string;
    get clientId(): string;
    get clientSecret(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issuerMode(): string;
    get issuerUrl(): string;
    get jwksBinding(): string;
    get jwksUrl(): string;
    get maxClockSkew(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get protocolType(): string;
    get scopes(): string[];
    get tokenBinding(): string;
    get tokenUrl(): string;
    get type(): string;
    get userInfoBinding(): string;
    get userInfoUrl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
