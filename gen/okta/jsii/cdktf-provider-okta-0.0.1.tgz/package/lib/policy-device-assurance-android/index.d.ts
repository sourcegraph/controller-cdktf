import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PolicyDeviceAssuranceAndroidConfig extends cdktf.TerraformMetaArguments {
    /**
    * List of disk encryption type, can be `FULL`, `USER`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_android#disk_encryption_type PolicyDeviceAssuranceAndroid#disk_encryption_type}
    */
    readonly diskEncryptionType?: string[];
    /**
    * Is the device jailbroken in the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_android#jailbreak PolicyDeviceAssuranceAndroid#jailbreak}
    */
    readonly jailbreak?: boolean | cdktf.IResolvable;
    /**
    * Policy device assurance name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_android#name PolicyDeviceAssuranceAndroid#name}
    */
    readonly name: string;
    /**
    * Minimum os version of the device in the device assurance policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_android#os_version PolicyDeviceAssuranceAndroid#os_version}
    */
    readonly osVersion?: string;
    /**
    * List of screenlock type, can be `BIOMETRIC` or `BIOMETRIC, PASSCODE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_android#screenlock_type PolicyDeviceAssuranceAndroid#screenlock_type}
    */
    readonly screenlockType?: string[];
    /**
    * Indicates if the device contains a secure hardware functionality
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_android#secure_hardware_present PolicyDeviceAssuranceAndroid#secure_hardware_present}
    */
    readonly secureHardwarePresent?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_android okta_policy_device_assurance_android}
*/
export declare class PolicyDeviceAssuranceAndroid extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_policy_device_assurance_android";
    /**
    * Generates CDKTF code for importing a PolicyDeviceAssuranceAndroid resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicyDeviceAssuranceAndroid to import
    * @param importFromId The id of the existing PolicyDeviceAssuranceAndroid that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_android#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicyDeviceAssuranceAndroid to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.11.1/docs/resources/policy_device_assurance_android okta_policy_device_assurance_android} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicyDeviceAssuranceAndroidConfig
    */
    constructor(scope: Construct, id: string, config: PolicyDeviceAssuranceAndroidConfig);
    get createdBy(): string;
    get createdDate(): string;
    private _diskEncryptionType?;
    get diskEncryptionType(): string[];
    set diskEncryptionType(value: string[]);
    resetDiskEncryptionType(): void;
    get diskEncryptionTypeInput(): string[] | undefined;
    get id(): string;
    private _jailbreak?;
    get jailbreak(): boolean | cdktf.IResolvable;
    set jailbreak(value: boolean | cdktf.IResolvable);
    resetJailbreak(): void;
    get jailbreakInput(): boolean | cdktf.IResolvable | undefined;
    get lastUpdate(): string;
    get lastUpdatedBy(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _osVersion?;
    get osVersion(): string;
    set osVersion(value: string);
    resetOsVersion(): void;
    get osVersionInput(): string | undefined;
    get platform(): string;
    private _screenlockType?;
    get screenlockType(): string[];
    set screenlockType(value: string[]);
    resetScreenlockType(): void;
    get screenlockTypeInput(): string[] | undefined;
    private _secureHardwarePresent?;
    get secureHardwarePresent(): boolean | cdktf.IResolvable;
    set secureHardwarePresent(value: boolean | cdktf.IResolvable);
    resetSecureHardwarePresent(): void;
    get secureHardwarePresentInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
